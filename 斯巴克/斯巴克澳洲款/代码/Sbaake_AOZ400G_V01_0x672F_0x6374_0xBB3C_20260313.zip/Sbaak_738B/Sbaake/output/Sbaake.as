opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	79F738B
opt include "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\include\79f738b.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
	FNCALL	_main,_EEPROM_Page
	FNCALL	_main,_Initialize
	FNCALL	_main,_Run_Mode
	FNCALL	_main,_Set_PWM
	FNCALL	_main,_Set_Usart_Async
	FNCALL	_main,_Time_Count_Func
	FNCALL	_Run_Mode,_AllLedFlash
	FNCALL	_Run_Mode,_BuzzerSet
	FNCALL	_Run_Mode,_FactoryMode_Handle
	FNCALL	_Run_Mode,_GetMode_Handle
	FNCALL	_Run_Mode,_LedSetSt
	FNCALL	_Run_Mode,_SetStandbyState
	FNCALL	_Run_Mode,_ShiftMode_Handle
	FNCALL	_Run_Mode,_StandbyMode_Handle
	FNCALL	_StandbyMode_Handle,_BuzzerSet
	FNCALL	_StandbyMode_Handle,_LedSetSt
	FNCALL	_StandbyMode_Handle,_SetStandbyState
	FNCALL	_StandbyMode_Handle,_ShiftMode_Handle
	FNCALL	_StandbyMode_Handle,_StatusFun_Handle
	FNCALL	_StandbyMode_Handle,_WrterEEP
	FNCALL	_StatusFun_Handle,_SetStandbyState
	FNCALL	_StatusFun_Handle,_WashHandle
	FNCALL	_WashHandle,_LedSetSt
	FNCALL	_WashHandle,_SetStandbyState
	FNCALL	_GetMode_Handle,_ShiftMode_Handle
	FNCALL	_GetMode_Handle,_WrterEEP
	FNCALL	_FactoryMode_Handle,_AllLedFlash
	FNCALL	_FactoryMode_Handle,_BuzzerSet
	FNCALL	_FactoryMode_Handle,_LedSetSt
	FNCALL	_FactoryMode_Handle,_Time_Count_Func
	FNCALL	_Time_Count_Func,_AD_Testing
	FNCALL	_Time_Count_Func,_BuzzerSet
	FNCALL	_Time_Count_Func,_CheckKey
	FNCALL	_Time_Count_Func,_ErrorHandle
	FNCALL	_Time_Count_Func,_FilterKeyInputRest
	FNCALL	_Time_Count_Func,_FilterLifeFunc
	FNCALL	_Time_Count_Func,_GetDelayFilterFlag
	FNCALL	_Time_Count_Func,_Led_Handle
	FNCALL	_Time_Count_Func,_Page_ProgramData
	FNCALL	_Time_Count_Func,_SetStandbyState
	FNCALL	_Time_Count_Func,_TDS_Handle
	FNCALL	_Time_Count_Func,_TaskAlarmHandle
	FNCALL	_Time_Count_Func,_Tx_Display
	FNCALL	_Time_Count_Func,___CMS_CheckTouchKey
	FNCALL	___CMS_CheckTouchKey,___CMS_CheckKeyOldValue
	FNCALL	___CMS_CheckTouchKey,___CMS_CheckOnceResult
	FNCALL	___CMS_CheckTouchKey,___CMS_CheckValidTime
	FNCALL	___CMS_CheckTouchKey,___CMS_CurAdjust
	FNCALL	___CMS_CheckTouchKey,___CMS_KeyDatIIR
	FNCALL	___CMS_CheckTouchKey,___CMS_KeyModeSet
	FNCALL	___CMS_CheckTouchKey,___CMS_KeyStart
	FNCALL	___CMS_CheckTouchKey,___CMS_KeyStopClear
	FNCALL	___CMS_CheckTouchKey,___CMS_Key_UNNOL_Check
	FNCALL	___CMS_CheckTouchKey,___CMS_NewRAMClr
	FNCALL	___CMS_CheckTouchKey,___CMS_Noise_check
	FNCALL	___CMS_CheckTouchKey,___GET_32M_FREDAT
	FNCALL	___CMS_KeyStopClear,___CMS_KeyClearOne
	FNCALL	___CMS_CurAdjust,___CMS_CurAdjMode
	FNCALL	___CMS_CurAdjust,___CMS_CurJudge
	FNCALL	___CMS_CurAdjust,___CMS_KeyModeSet
	FNCALL	___CMS_CurAdjust,___CMS_KeyStart
	FNCALL	___CMS_CheckOnceResult,___CMS_KeyHaveDown
	FNCALL	___CMS_CheckOnceResult,___CMS_KeyIsIn
	FNCALL	___CMS_CheckOnceResult,___CMS_KeyOpen
	FNCALL	___CMS_CheckKeyOldValue,___CMS_KeyIsIn
	FNCALL	___CMS_CheckKeyOldValue,_abs
	FNCALL	_TDS_Handle,_GetCurTdsHz
	FNCALL	_TDS_Handle,___lldiv
	FNCALL	_TDS_Handle,___lmul
	FNCALL	_TDS_Handle,___lwdiv
	FNCALL	_Page_ProgramData,_Memory_Write
	FNCALL	_Led_Handle,_LedControlSt
	FNCALL	_Led_Handle,___bmul
	FNCALL	_GetDelayFilterFlag,_Dec
	FNCALL	_GetDelayFilterFlag,_DecF
	FNCALL	_FilterLifeFunc,_BuzzerSet
	FNCALL	_FilterLifeFunc,_FilterTimeHandle
	FNCALL	_FilterTimeHandle,_LedSetSt
	FNCALL	_FilterKeyInputRest,_BuzzerSet
	FNCALL	_FilterKeyInputRest,_LedSetSt
	FNCALL	_FilterKeyInputRest,_SetFilterDelayReset
	FNCALL	_FilterKeyInputRest,_ShiftMode_Handle
	FNCALL	_FilterKeyInputRest,_WrterEEP
	FNCALL	_ErrorHandle,_AllLedFlash
	FNCALL	_ErrorHandle,_BuzzerSet
	FNCALL	_ErrorHandle,_GetStop
	FNCALL	_ErrorHandle,_LedSetSt
	FNCALL	_ErrorHandle,_ShiftMode_Handle
	FNCALL	_ShiftMode_Handle,_BuzzerSet
	FNCALL	_ShiftMode_Handle,_LedSetSt
	FNCALL	_ShiftMode_Handle,_SetStandbyState
	FNCALL	_AllLedFlash,_LedSetSt
	FNCALL	_LedSetSt,___bmul
	FNCALL	_CheckKey,_KeyScan
	FNCALL	_KeyScan,_BuzzerSet
	FNCALL	_Initialize,_Init_ram
	FNCALL	_EEPROM_Page,_ReadDataArry
	FNCALL	_EEPROM_Page,_SetFilterDelayReset
	FNCALL	_EEPROM_Page,_WrterEEP
	FNCALL	_ReadDataArry,_Memory_Read
	FNROOT	_main
	FNCALL	_Timer1_Isr,___CMS_TouchKeyValue
	FNCALL	intlevel1,_Timer1_Isr
	global	intlevel1
	FNROOT	intlevel1
	global	_NTC_Tab
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	136
_NTC_Tab:
	retlw	0BCh
	retlw	0Bh

	retlw	098h
	retlw	0Bh

	retlw	075h
	retlw	0Bh

	retlw	051h
	retlw	0Bh

	retlw	02Ch
	retlw	0Bh

	retlw	07h
	retlw	0Bh

	retlw	0E2h
	retlw	0Ah

	retlw	0BCh
	retlw	0Ah

	retlw	097h
	retlw	0Ah

	retlw	070h
	retlw	0Ah

	retlw	04Ah
	retlw	0Ah

	retlw	023h
	retlw	0Ah

	retlw	0FCh
	retlw	09h

	retlw	0D5h
	retlw	09h

	retlw	0AEh
	retlw	09h

	retlw	087h
	retlw	09h

	retlw	060h
	retlw	09h

	retlw	038h
	retlw	09h

	retlw	011h
	retlw	09h

	retlw	0EAh
	retlw	08h

	retlw	0C3h
	retlw	08h

	retlw	09Bh
	retlw	08h

	retlw	074h
	retlw	08h

	retlw	04Dh
	retlw	08h

	retlw	027h
	retlw	08h

	retlw	0
	retlw	08h

	retlw	0DAh
	retlw	07h

	retlw	0B4h
	retlw	07h

	retlw	08Eh
	retlw	07h

	retlw	068h
	retlw	07h

	retlw	043h
	retlw	07h

	retlw	01Eh
	retlw	07h

	retlw	0F9h
	retlw	06h

	retlw	0D5h
	retlw	06h

	retlw	0B1h
	retlw	06h

	retlw	08Eh
	retlw	06h

	retlw	06Bh
	retlw	06h

	retlw	049h
	retlw	06h

	retlw	026h
	retlw	06h

	retlw	05h
	retlw	06h

	retlw	0E4h
	retlw	05h

	retlw	0C3h
	retlw	05h

	retlw	0A3h
	retlw	05h

	retlw	083h
	retlw	05h

	retlw	064h
	retlw	05h

	retlw	045h
	retlw	05h

	retlw	027h
	retlw	05h

	retlw	09h
	retlw	05h

	retlw	0ECh
	retlw	04h

	retlw	low(0)
	retlw	high(0)

	global __end_of_NTC_Tab
__end_of_NTC_Tab:
	global	_sc_FreScanTable1
psect	stringtext
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
_sc_FreScanTable1:
	retlw	low(0)
	retlw	01h
	retlw	low(0)
	retlw	01h
	retlw	low(0)
	retlw	01h
	retlw	low(0)
	retlw	01h
	global __end_of_sc_FreScanTable1
__end_of_sc_FreScanTable1:
	global	_sc_FreScanTable
psect	stringtext
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
_sc_FreScanTable:
	retlw	low(0)
	retlw	01h
	retlw	01h
	retlw	01h
	retlw	01h
	retlw	01h
	retlw	01h
	retlw	01h
	global __end_of_sc_FreScanTable
__end_of_sc_FreScanTable:
	global	_sc_Table_KeyFalg
psect	stringtext
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
_sc_Table_KeyFalg:
	retlw	01h
	retlw	02h
	retlw	04h
	retlw	08h
	retlw	010h
	retlw	020h
	retlw	040h
	retlw	080h
	global __end_of_sc_Table_KeyFalg
__end_of_sc_Table_KeyFalg:
	global	_sc_CurStep_Table
psect	stringtext
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
_sc_CurStep_Table:
	retlw	low(0)
	retlw	02h
	retlw	04h
	retlw	06h
	retlw	08h
	retlw	0Ah
	global __end_of_sc_CurStep_Table
__end_of_sc_CurStep_Table:
	global	_gc_Table_KeyDown
psect	stringtext
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	36
_gc_Table_KeyDown:
	retlw	03Ch
	retlw	0

	retlw	03Ch
	retlw	0

	global __end_of_gc_Table_KeyDown
__end_of_gc_Table_KeyDown:
	global	_gc_Table_KeyChannel
psect	stringtext
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	28
_gc_Table_KeyChannel:
	retlw	04h
	retlw	05h
	global __end_of_gc_Table_KeyChannel
__end_of_gc_Table_KeyChannel:
	global	_PureHz_Tab
psect	stringtext
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	60
_PureHz_Tab:
	retlw	01Ch
	retlw	0

	retlw	026h
	retlw	0

	retlw	030h
	retlw	0

	retlw	03Ah
	retlw	0

	retlw	044h
	retlw	0

	retlw	04Eh
	retlw	0

	retlw	058h
	retlw	0

	retlw	062h
	retlw	0

	retlw	06Ch
	retlw	0

	retlw	076h
	retlw	0

	retlw	083h
	retlw	0

	retlw	090h
	retlw	0

	retlw	09Ch
	retlw	0

	retlw	0A9h
	retlw	0

	retlw	0B6h
	retlw	0

	retlw	0C3h
	retlw	0

	retlw	0D0h
	retlw	0

	retlw	0DDh
	retlw	0

	retlw	0EAh
	retlw	0

	retlw	0F7h
	retlw	0

	retlw	0FFh
	retlw	0

	retlw	07h
	retlw	01h

	retlw	0Fh
	retlw	01h

	retlw	019h
	retlw	01h

	retlw	023h
	retlw	01h

	retlw	02Dh
	retlw	01h

	retlw	037h
	retlw	01h

	retlw	041h
	retlw	01h

	retlw	04Bh
	retlw	01h

	retlw	055h
	retlw	01h

	retlw	05Eh
	retlw	01h

	retlw	06Bh
	retlw	01h

	retlw	077h
	retlw	01h

	retlw	081h
	retlw	01h

	retlw	08Bh
	retlw	01h

	retlw	095h
	retlw	01h

	retlw	09Fh
	retlw	01h

	retlw	0A9h
	retlw	01h

	retlw	0B3h
	retlw	01h

	retlw	0BDh
	retlw	01h

	retlw	0C9h
	retlw	01h

	retlw	0D6h
	retlw	01h

	retlw	0E2h
	retlw	01h

	retlw	0EDh
	retlw	01h

	retlw	0F7h
	retlw	01h

	retlw	01h
	retlw	02h

	retlw	0Bh
	retlw	02h

	retlw	015h
	retlw	02h

	retlw	01Fh
	retlw	02h

	retlw	029h
	retlw	02h

	retlw	033h
	retlw	02h

	retlw	03Ah
	retlw	02h

	retlw	044h
	retlw	02h

	retlw	04Eh
	retlw	02h

	retlw	058h
	retlw	02h

	retlw	062h
	retlw	02h

	retlw	06Ch
	retlw	02h

	retlw	077h
	retlw	02h

	retlw	082h
	retlw	02h

	retlw	08Dh
	retlw	02h

	retlw	09Bh
	retlw	02h

	retlw	0A9h
	retlw	02h

	retlw	0B7h
	retlw	02h

	retlw	0C6h
	retlw	02h

	retlw	0D3h
	retlw	02h

	retlw	0E1h
	retlw	02h

	retlw	0EBh
	retlw	02h

	retlw	0F5h
	retlw	02h

	retlw	0FFh
	retlw	02h

	retlw	09h
	retlw	03h

	retlw	013h
	retlw	03h

	retlw	01Dh
	retlw	03h

	retlw	027h
	retlw	03h

	retlw	031h
	retlw	03h

	retlw	03Bh
	retlw	03h

	retlw	043h
	retlw	03h

	retlw	04Bh
	retlw	03h

	retlw	053h
	retlw	03h

	retlw	057h
	retlw	03h

	retlw	05Ch
	retlw	03h

	retlw	05Fh
	retlw	03h

	retlw	064h
	retlw	03h

	retlw	06Ch
	retlw	03h

	retlw	074h
	retlw	03h

	retlw	07Ch
	retlw	03h

	retlw	084h
	retlw	03h

	retlw	08Ch
	retlw	03h

	retlw	094h
	retlw	03h

	retlw	09Ch
	retlw	03h

	retlw	0A4h
	retlw	03h

	retlw	0ACh
	retlw	03h

	retlw	0B4h
	retlw	03h

	retlw	0BCh
	retlw	03h

	retlw	0C4h
	retlw	03h

	retlw	0CCh
	retlw	03h

	retlw	0D4h
	retlw	03h

	retlw	0DCh
	retlw	03h

	retlw	0E4h
	retlw	03h

	retlw	0ECh
	retlw	03h

	retlw	0F4h
	retlw	03h

	retlw	0FCh
	retlw	03h

	retlw	0Bh
	retlw	04h

	retlw	01Ah
	retlw	04h

	retlw	022h
	retlw	04h

	retlw	029h
	retlw	04h

	retlw	031h
	retlw	04h

	retlw	038h
	retlw	04h

	retlw	040h
	retlw	04h

	retlw	048h
	retlw	04h

	retlw	04Fh
	retlw	04h

	retlw	057h
	retlw	04h

	retlw	05Eh
	retlw	04h

	retlw	066h
	retlw	04h

	retlw	06Eh
	retlw	04h

	retlw	075h
	retlw	04h

	retlw	07Dh
	retlw	04h

	retlw	084h
	retlw	04h

	retlw	08Ch
	retlw	04h

	retlw	094h
	retlw	04h

	retlw	09Bh
	retlw	04h

	retlw	0A3h
	retlw	04h

	retlw	0AAh
	retlw	04h

	retlw	0B2h
	retlw	04h

	retlw	0BAh
	retlw	04h

	retlw	0C1h
	retlw	04h

	retlw	0C9h
	retlw	04h

	retlw	0D0h
	retlw	04h

	retlw	0D8h
	retlw	04h

	retlw	0E0h
	retlw	04h

	retlw	0E7h
	retlw	04h

	retlw	0EFh
	retlw	04h

	retlw	0F6h
	retlw	04h

	retlw	0FEh
	retlw	04h

	retlw	06h
	retlw	05h

	retlw	0Dh
	retlw	05h

	retlw	015h
	retlw	05h

	retlw	01Ch
	retlw	05h

	retlw	024h
	retlw	05h

	retlw	02Ch
	retlw	05h

	retlw	033h
	retlw	05h

	retlw	03Bh
	retlw	05h

	retlw	042h
	retlw	05h

	retlw	04Ah
	retlw	05h

	retlw	052h
	retlw	05h

	retlw	059h
	retlw	05h

	retlw	061h
	retlw	05h

	retlw	068h
	retlw	05h

	retlw	06Ch
	retlw	05h

	retlw	070h
	retlw	05h

	retlw	074h
	retlw	05h

	retlw	078h
	retlw	05h

	retlw	07Ch
	retlw	05h

	retlw	080h
	retlw	05h

	retlw	084h
	retlw	05h

	retlw	088h
	retlw	05h

	retlw	08Ch
	retlw	05h

	retlw	090h
	retlw	05h

	retlw	094h
	retlw	05h

	retlw	098h
	retlw	05h

	retlw	09Ch
	retlw	05h

	retlw	0A0h
	retlw	05h

	retlw	0A4h
	retlw	05h

	retlw	0A8h
	retlw	05h

	retlw	0ACh
	retlw	05h

	retlw	0B0h
	retlw	05h

	retlw	0B4h
	retlw	05h

	retlw	0B8h
	retlw	05h

	retlw	0BCh
	retlw	05h

	retlw	0C0h
	retlw	05h

	retlw	0C4h
	retlw	05h

	retlw	0C8h
	retlw	05h

	retlw	0CCh
	retlw	05h

	retlw	0D0h
	retlw	05h

	retlw	0D4h
	retlw	05h

	retlw	0D8h
	retlw	05h

	retlw	0DCh
	retlw	05h

	retlw	0E0h
	retlw	05h

	retlw	0E4h
	retlw	05h

	retlw	0E8h
	retlw	05h

	retlw	0ECh
	retlw	05h

	retlw	0F0h
	retlw	05h

	retlw	0F4h
	retlw	05h

	retlw	0F8h
	retlw	05h

	retlw	0FCh
	retlw	05h

	retlw	0
	retlw	06h

	retlw	04h
	retlw	06h

	retlw	08h
	retlw	06h

	retlw	0Ch
	retlw	06h

	retlw	010h
	retlw	06h

	retlw	014h
	retlw	06h

	global __end_of_PureHz_Tab
__end_of_PureHz_Tab:
psect	stringtext
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	124
_gc_KeyLDOSel:
	retlw	03h
	global __end_of_gc_KeyLDOSel
__end_of_gc_KeyLDOSel:
psect	stringtext
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	122
_gc_LMDValue:
	retlw	01h
	global __end_of_gc_LMDValue
__end_of_gc_LMDValue:
psect	stringtext
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	116
_gc_CmBase:
	retlw	06h
	global __end_of_gc_CmBase
__end_of_gc_CmBase:
psect	stringtext
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
_gc_VolValue:
	retlw	032h
	global __end_of_gc_VolValue
__end_of_gc_VolValue:
	global	_NTC_Tab
	global	_sc_FreScanTable1
	global	_sc_FreScanTable
	global	_sc_Table_KeyFalg
	global	_sc_CurStep_Table
	global	_gc_Table_KeyDown
	global	_gc_Table_KeyChannel
	global	_PureHz_Tab
	global	_919
	global	_Mode
	global	__BITS
	global	_927
	global	_926
	global	_925
	global	_924
	global	_gf_kerr
	global	_KeyPacket_y
	global	AD_Testing@admax
	global	AD_Testing@admin
	global	_PreTdsData
	global	_g_KeyFlag
	global	_923
	global	_922
	global	_921
	global	_920
	global	_918
	global	_917
	global	_916
	global	AD_Testing@adtimes
	global	StandbyMode_Handle@Ti_1h
	global	_BeepAlmCnt
	global	_ErrorVar
	global	_Time_Power_1s
	global	_Temp_Ntc
	global	_FilterBuzzer_1s
	global	_TdsCk60sFlag
	global	_PowerStep
	global	_Time_100ms
	global	_Time_GetWater_1s
	global	_Time_1s
	global	_Timer_Power_100ms
	global	_StandByStatus
	global	_Timer_TdsMake_1s
	global	_FilterFastCheck
	global	_Timer_ErrorLong_1s
	global	__BITS2
	global	__BITS1
	global	_FilterROGetWater
	global	_FilterPCFGetWater
	global	_FilterROState
	global	_FilterPCFState
	global	_WashRunTime
	global	_Read_Word_Buff
	global	___CMS_CheckValidTime@F1029
	global	___CMS_Noise_check@F969
	global	___CMS_Noise_check@F968
	global	AD_Testing@adsum
	global	CheckKey@KeyOldFlag
	global	FilterKeyInputRest@FilterSelect_10ms
	global	_BeepOnTimeCnt
	global	_BuzzerFilter
	global	_ML_Temp
	global	_Date_Temp
	global	_Timer_Standby_1H
	global	_Timer_BackT_1H
	global	_Timer_Standby_1s
	global	_Timer_WashRun_1s
	global	_FilterRst_1s
	global	_PreROu16Day
	global	_PrePCFu16Day
	global	_Timer_LongGetWater_1s
	global	_GetWater_ML
	global	_Time_made_1s
	global	___CMS_CheckTouchKey@F1073
	global	___CMS_CurAdjust@F1044
	global	___CMS_Key_UNNOL_Check@F1016
	global	___CMS_Noise_check@F967
	global	___CMS_Noise_check@F966
	global	___CMS_Noise_check@F965
	global	___CMS_Noise_check@F964
	global	Timer1_Isr@T1_1ms
	global	CheckKey@temp
	global	_FilterRO_time
	global	_FilterPCF_time
	global	_LedMod
	global	_PureTDSTyp
	global	_887
_887	set	13
	global	_T2CON
_T2CON	set	18
	global	_T1CON
_T1CON	set	16
	global	_TMR1H
_TMR1H	set	15
	global	_TMR1L
_TMR1L	set	14
	global	_INTCON
_INTCON	set	11
	global	_PORTC
_PORTC	set	7
	global	_PORTB
_PORTB	set	6
	global	_PORTA
_PORTA	set	5
	global	_TMR0
_TMR0	set	1
	global	_TMR1IF
_TMR1IF	set	96
	global	_TMR2IF
_TMR2IF	set	97
	global	_INTF
_INTF	set	89
	global	_T0IF
_T0IF	set	90
	global	_GIE
_GIE	set	95
	global	_RC1
_RC1	set	57
	global	_RC2
_RC2	set	58
	global	_RC3
_RC3	set	59
	global	_RB0
_RB0	set	48
	global	_RB2
_RB2	set	50
	global	_RB3
_RB3	set	51
	global	_RB4
_RB4	set	52
	global	_RB5
_RB5	set	53
	global	_RB6
_RB6	set	54
	global	_RA0
_RA0	set	40
	global	_RA1
_RA1	set	41
	global	_RA2
_RA2	set	42
	global	_RA6
_RA6	set	46
	global	_RA7
_RA7	set	47
	global	_ADCON1
_ADCON1	set	159
	global	_ADCON0
_ADCON0	set	158
	global	_ADRESH
_ADRESH	set	157
	global	_ADRESL
_ADRESL	set	156
	global	_WPUC
_WPUC	set	154
	global	_WPUA
_WPUA	set	153
	global	_SPBRG1
_SPBRG1	set	152
	global	_WPUB
_WPUB	set	149
	global	_PR2
_PR2	set	146
	global	_OSCCON
_OSCCON	set	143
	global	_PIE2
_PIE2	set	141
	global	_PIE1
_PIE1	set	140
	global	_ANSEL1
_ANSEL1	set	137
	global	_TRISD
_TRISD	set	136
	global	_TRISC
_TRISC	set	135
	global	_TRISB
_TRISB	set	134
	global	_TRISA
_TRISA	set	133
	global	_OPTION_REG
_OPTION_REG	set	129
	global	_GODONE
_GODONE	set	1265
	global	_RC1IE
_RC1IE	set	1129
	global	_TX1IE
_TX1IE	set	1130
	global	_TMR1IE
_TMR1IE	set	1120
	global	_INTEDG
_INTEDG	set	1038
	global	_PWMTH
_PWMTH	set	284
	global	_PWMTL
_PWMTL	set	283
	global	_PWMD01H
_PWMD01H	set	273
	global	_PWMD1L
_PWMD1L	set	269
	global	_PWMCON1
_PWMCON1	set	263
	global	_PWMCON0
_PWMCON0	set	262
	global	_SCKP1
_SCKP1	set	2299
	global	_SYNC1
_SYNC1	set	2300
	global	_TXEN1
_TXEN1	set	2301
	global	_TX9EN1
_TX9EN1	set	2302
	global	_PWM1EN
_PWM1EN	set	2097
	global	_CREN1
_CREN1	set	2092
	global	_RX9EN1
_RX9EN1	set	2094
	global	_SPEN1
_SPEN1	set	2095
	global	_914
_914	set	416
	global	_905
_905	set	416
	global	_903
_903	set	448
	global	_902
_902	set	416
	global	_900
_900	set	448
	global	_899
_899	set	416
	global	_897
_897	set	448
	global	_896
_896	set	416
	global	_913
_913	set	480
	global	_912
_912	set	464
	global	_911
_911	set	448
	global	_910
_910	set	432
	global	_909
_909	set	416
	global	_904
_904	set	480
	global	_901
_901	set	480
	global	_898
_898	set	480
	global	_886
_886	set	415
	global	_885
_885	set	412
	global	_884
_884	set	411
	global	_883
_883	set	414
	global	_882
_882	set	413
	global	_881
_881	set	410
	global	_880
_880	set	409
	global	_879
_879	set	408
	global	_878
_878	set	407
	global	_877
_877	set	406
	global	_876
_876	set	405
	global	_875
_875	set	404
	global	_874
_874	set	403
	global	_873
_873	set	402
	global	_872
_872	set	401
	global	_871
_871	set	400
	global	_EECON2
_EECON2	set	397
	global	_EECON1
_EECON1	set	396
	global	_EEADR
_EEADR	set	391
	global	_EEDAT
_EEDAT	set	390
	global	_RD
_RD	set	3168
	global	_WR
_WR	set	3169
	global	_WREN
_WREN	set	3170
	global	_WRERR
_WRERR	set	3171
	global	_EEPGD
_EEPGD	set	3175
; #config settings
	file	"Sbaake.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_927:
       ds      1

_926:
       ds      1

_925:
       ds      1

_924:
       ds      1

_gf_kerr:
       ds      1

psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_919:
       ds      1

_Mode:
       ds      1

__BITS:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_KeyPacket_y:
       ds      9

AD_Testing@admax:
       ds      2

AD_Testing@admin:
       ds      2

_PreTdsData:
       ds      2

_g_KeyFlag:
       ds      2

_923:
       ds      1

_922:
       ds      1

_921:
       ds      1

_920:
       ds      1

_918:
       ds      1

_917:
       ds      1

_916:
       ds      1

AD_Testing@adtimes:
       ds      1

StandbyMode_Handle@Ti_1h:
       ds      1

_BeepAlmCnt:
       ds      1

_ErrorVar:
       ds      1

_Time_Power_1s:
       ds      1

_Temp_Ntc:
       ds      1

_FilterBuzzer_1s:
       ds      1

_TdsCk60sFlag:
       ds      1

_PowerStep:
       ds      1

_Time_100ms:
       ds      1

_Time_GetWater_1s:
       ds      1

_Time_1s:
       ds      1

_Timer_Power_100ms:
       ds      1

_StandByStatus:
       ds      1

_Timer_TdsMake_1s:
       ds      1

_FilterFastCheck:
       ds      1

_Timer_ErrorLong_1s:
       ds      1

__BITS2:
       ds      1

__BITS1:
       ds      1

_FilterROGetWater:
       ds      2

_FilterPCFGetWater:
       ds      2

_FilterROState:
       ds      1

_FilterPCFState:
       ds      1

_WashRunTime:
       ds      1

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_Read_Word_Buff:
       ds      12

___CMS_CheckValidTime@F1029:
       ds      2

___CMS_Noise_check@F969:
       ds      2

___CMS_Noise_check@F968:
       ds      2

AD_Testing@adsum:
       ds      2

CheckKey@KeyOldFlag:
       ds      2

FilterKeyInputRest@FilterSelect_10ms:
       ds      2

_BeepOnTimeCnt:
       ds      2

_BuzzerFilter:
       ds      2

_ML_Temp:
       ds      2

_Date_Temp:
       ds      2

_Timer_Standby_1H:
       ds      2

_Timer_BackT_1H:
       ds      2

_Timer_Standby_1s:
       ds      2

_Timer_WashRun_1s:
       ds      2

_FilterRst_1s:
       ds      2

_PreROu16Day:
       ds      2

_PrePCFu16Day:
       ds      2

_Timer_LongGetWater_1s:
       ds      2

_GetWater_ML:
       ds      2

_Time_made_1s:
       ds      2

___CMS_CheckTouchKey@F1073:
       ds      1

___CMS_CurAdjust@F1044:
       ds      1

___CMS_Key_UNNOL_Check@F1016:
       ds      1

___CMS_Noise_check@F967:
       ds      1

___CMS_Noise_check@F966:
       ds      1

___CMS_Noise_check@F965:
       ds      1

___CMS_Noise_check@F964:
       ds      1

Timer1_Isr@T1_1ms:
       ds      1

CheckKey@temp:
       ds      1

_FilterRO_time:
       ds      5

_FilterPCF_time:
       ds      5

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_LedMod:
       ds      30

_PureTDSTyp:
       ds      17

	file	"Sbaake.as"
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
	clrf	((__pbssCOMMON)+1)&07Fh
	clrf	((__pbssCOMMON)+2)&07Fh
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+032h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+047h)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+02Fh)
	fcall	clear_ram0
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
??_Time_Count_Func:	; 1 bytes @ 0x0
	ds	3
	global	FactoryMode_Handle@Step
FactoryMode_Handle@Step:	; 1 bytes @ 0x3
	ds	1
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?___CMS_CheckTouchKey:	; 1 bytes @ 0x0
?_CheckKey:	; 1 bytes @ 0x0
?_FilterLifeFunc:	; 1 bytes @ 0x0
?_TaskAlarmHandle:	; 1 bytes @ 0x0
?_Led_Handle:	; 1 bytes @ 0x0
?_FilterKeyInputRest:	; 1 bytes @ 0x0
?_Tx_Display:	; 1 bytes @ 0x0
?_ErrorHandle:	; 1 bytes @ 0x0
?_Page_ProgramData:	; 1 bytes @ 0x0
?_WrterEEP:	; 1 bytes @ 0x0
?___CMS_TouchKeyValue:	; 1 bytes @ 0x0
??___CMS_TouchKeyValue:	; 1 bytes @ 0x0
?_GetDelayFilterFlag:	; 1 bytes @ 0x0
?_Time_Count_Func:	; 1 bytes @ 0x0
?_AllLedFlash:	; 1 bytes @ 0x0
?_GetStop:	; 1 bytes @ 0x0
?_ShiftMode_Handle:	; 1 bytes @ 0x0
?_GetMode_Handle:	; 1 bytes @ 0x0
?_WashHandle:	; 1 bytes @ 0x0
?_StatusFun_Handle:	; 1 bytes @ 0x0
?_FactoryMode_Handle:	; 1 bytes @ 0x0
?_StandbyMode_Handle:	; 1 bytes @ 0x0
?_Run_Mode:	; 1 bytes @ 0x0
?_ReadDataArry:	; 1 bytes @ 0x0
?_EEPROM_Page:	; 1 bytes @ 0x0
?_Init_ram:	; 1 bytes @ 0x0
?_Initialize:	; 1 bytes @ 0x0
?_Timer1_Isr:	; 1 bytes @ 0x0
??_Timer1_Isr:	; 1 bytes @ 0x0
?_Set_Usart_Async:	; 1 bytes @ 0x0
?_Set_PWM:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?___CMS_KeyIsIn:	; 1 bytes @ 0x0
?___CMS_KeyClearOne:	; 1 bytes @ 0x0
?___CMS_KeyStopClear:	; 1 bytes @ 0x0
?___CMS_Noise_check:	; 1 bytes @ 0x0
?___CMS_CheckOnceResult:	; 1 bytes @ 0x0
?___CMS_CheckKeyOldValue:	; 1 bytes @ 0x0
?___CMS_Key_UNNOL_Check:	; 1 bytes @ 0x0
?___CMS_KeyDatIIR:	; 1 bytes @ 0x0
?___CMS_CheckValidTime:	; 1 bytes @ 0x0
?___CMS_CurAdjMode:	; 1 bytes @ 0x0
?___CMS_KeyModeSet:	; 1 bytes @ 0x0
?___CMS_KeyStart:	; 1 bytes @ 0x0
?___CMS_CurJudge:	; 1 bytes @ 0x0
?___CMS_CurAdjust:	; 1 bytes @ 0x0
?___CMS_NewRAMClr:	; 1 bytes @ 0x0
?___GET_32M_FREDAT:	; 1 bytes @ 0x0
	ds	4
??_TaskAlarmHandle:	; 1 bytes @ 0x4
??_Tx_Display:	; 1 bytes @ 0x4
?_BuzzerSet:	; 1 bytes @ 0x4
?_SetStandbyState:	; 1 bytes @ 0x4
??_WrterEEP:	; 1 bytes @ 0x4
?_Dec:	; 1 bytes @ 0x4
?_DecF:	; 1 bytes @ 0x4
??_SetFilterDelayReset:	; 1 bytes @ 0x4
?_TDS_Handle:	; 1 bytes @ 0x4
?_LedControlSt:	; 1 bytes @ 0x4
??_GetStop:	; 1 bytes @ 0x4
??_Memory_Write:	; 1 bytes @ 0x4
??_Init_ram:	; 1 bytes @ 0x4
??_Initialize:	; 1 bytes @ 0x4
??_Set_Usart_Async:	; 1 bytes @ 0x4
??_Set_PWM:	; 1 bytes @ 0x4
??___CMS_KeyIsIn:	; 1 bytes @ 0x4
?___CMS_KeyOpen:	; 1 bytes @ 0x4
?___CMS_KeyHaveDown:	; 1 bytes @ 0x4
??___CMS_KeyClearOne:	; 1 bytes @ 0x4
??___CMS_Key_UNNOL_Check:	; 1 bytes @ 0x4
??___CMS_KeyDatIIR:	; 1 bytes @ 0x4
??___CMS_CheckValidTime:	; 1 bytes @ 0x4
??___CMS_CurAdjMode:	; 1 bytes @ 0x4
??___CMS_KeyModeSet:	; 1 bytes @ 0x4
??___CMS_KeyStart:	; 1 bytes @ 0x4
??___CMS_CurJudge:	; 1 bytes @ 0x4
??___CMS_NewRAMClr:	; 1 bytes @ 0x4
??___GET_32M_FREDAT:	; 1 bytes @ 0x4
??___lmul:	; 1 bytes @ 0x4
?___bmul:	; 1 bytes @ 0x4
??___lldiv:	; 1 bytes @ 0x4
??___lwdiv:	; 1 bytes @ 0x4
?_AD_Testing:	; 2 bytes @ 0x4
	global	?_abs
?_abs:	; 2 bytes @ 0x4
	global	?_Memory_Read
?_Memory_Read:	; 2 bytes @ 0x4
	global	Dec@max
Dec@max:	; 1 bytes @ 0x4
	global	SetFilterDelayReset@TimPtr
SetFilterDelayReset@TimPtr:	; 1 bytes @ 0x4
	global	TDS_Handle@Type
TDS_Handle@Type:	; 1 bytes @ 0x4
	global	LedControlSt@Sta
LedControlSt@Sta:	; 1 bytes @ 0x4
	global	SetStandbyState@Time
SetStandbyState@Time:	; 1 bytes @ 0x4
	global	Memory_Write@i
Memory_Write@i:	; 1 bytes @ 0x4
	global	AD_Testing@ad_ch
AD_Testing@ad_ch:	; 1 bytes @ 0x4
	global	___CMS_KeyIsIn@947
___CMS_KeyIsIn@947:	; 1 bytes @ 0x4
	global	___CMS_KeyOpen@952
___CMS_KeyOpen@952:	; 1 bytes @ 0x4
	global	___CMS_KeyHaveDown@956
___CMS_KeyHaveDown@956:	; 1 bytes @ 0x4
	global	___CMS_CurAdjMode@1032
___CMS_CurAdjMode@1032:	; 1 bytes @ 0x4
	global	___CMS_KeyModeSet@1035
___CMS_KeyModeSet@1035:	; 1 bytes @ 0x4
	global	___CMS_KeyStart@1038
___CMS_KeyStart@1038:	; 1 bytes @ 0x4
	global	___CMS_NewRAMClr@1051
___CMS_NewRAMClr@1051:	; 1 bytes @ 0x4
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x4
	global	DecF@max
DecF@max:	; 2 bytes @ 0x4
	global	BuzzerSet@filter
BuzzerSet@filter:	; 2 bytes @ 0x4
	global	Memory_Read@Addr
Memory_Read@Addr:	; 2 bytes @ 0x4
	global	abs@a
abs@a:	; 2 bytes @ 0x4
	ds	1
??_Page_ProgramData:	; 1 bytes @ 0x5
?_LedSetSt:	; 1 bytes @ 0x5
??_Dec:	; 1 bytes @ 0x5
??_LedControlSt:	; 1 bytes @ 0x5
??___CMS_KeyOpen:	; 1 bytes @ 0x5
??___CMS_KeyHaveDown:	; 1 bytes @ 0x5
??___bmul:	; 1 bytes @ 0x5
	global	Dec@var
Dec@var:	; 1 bytes @ 0x5
	global	LedSetSt@Sta
LedSetSt@Sta:	; 1 bytes @ 0x5
	global	LedControlSt@Num
LedControlSt@Num:	; 1 bytes @ 0x5
	global	SetStandbyState@Da
SetStandbyState@Da:	; 1 bytes @ 0x5
	global	AD_Testing@ad_lr
AD_Testing@ad_lr:	; 1 bytes @ 0x5
	global	___CMS_KeyIsIn@946
___CMS_KeyIsIn@946:	; 1 bytes @ 0x5
	global	___CMS_KeyOpen@951
___CMS_KeyOpen@951:	; 1 bytes @ 0x5
	global	___CMS_KeyHaveDown@955
___CMS_KeyHaveDown@955:	; 1 bytes @ 0x5
	ds	1
??___CMS_CheckTouchKey:	; 1 bytes @ 0x6
??_FilterLifeFunc:	; 1 bytes @ 0x6
??_FilterKeyInputRest:	; 1 bytes @ 0x6
??_ErrorHandle:	; 1 bytes @ 0x6
??_BuzzerSet:	; 1 bytes @ 0x6
??_SetStandbyState:	; 1 bytes @ 0x6
??_LedSetSt:	; 1 bytes @ 0x6
??_AllLedFlash:	; 1 bytes @ 0x6
??_ShiftMode_Handle:	; 1 bytes @ 0x6
??_GetMode_Handle:	; 1 bytes @ 0x6
??_StatusFun_Handle:	; 1 bytes @ 0x6
??_FactoryMode_Handle:	; 1 bytes @ 0x6
??_Memory_Read:	; 1 bytes @ 0x6
??_StandbyMode_Handle:	; 1 bytes @ 0x6
??_Run_Mode:	; 1 bytes @ 0x6
??_ReadDataArry:	; 1 bytes @ 0x6
??_EEPROM_Page:	; 1 bytes @ 0x6
??_main:	; 1 bytes @ 0x6
??___CMS_KeyStopClear:	; 1 bytes @ 0x6
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
??_AD_Testing:	; 1 bytes @ 0x0
??_abs:	; 1 bytes @ 0x0
??_DecF:	; 1 bytes @ 0x0
?_SetFilterDelayReset:	; 1 bytes @ 0x0
?_Memory_Write:	; 1 bytes @ 0x0
??___CMS_Noise_check:	; 1 bytes @ 0x0
??___CMS_CheckOnceResult:	; 1 bytes @ 0x0
??___CMS_CurAdjust:	; 1 bytes @ 0x0
	global	?_GetCurTdsHz
?_GetCurTdsHz:	; 2 bytes @ 0x0
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x0
	global	?___lmul
?___lmul:	; 4 bytes @ 0x0
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x0
	global	SetStandbyState@STY
SetStandbyState@STY:	; 1 bytes @ 0x0
	global	BuzzerSet@cnt
BuzzerSet@cnt:	; 1 bytes @ 0x0
	global	___CMS_KeyClearOne@958
___CMS_KeyClearOne@958:	; 1 bytes @ 0x0
	global	___CMS_Key_UNNOL_Check@1018
___CMS_Key_UNNOL_Check@1018:	; 1 bytes @ 0x0
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x0
	global	GetCurTdsHz@Tab
GetCurTdsHz@Tab:	; 2 bytes @ 0x0
	global	SetFilterDelayReset@Day
SetFilterDelayReset@Day:	; 2 bytes @ 0x0
	global	Memory_Write@Addr
Memory_Write@Addr:	; 2 bytes @ 0x0
	global	ReadDataArry@i
ReadDataArry@i:	; 2 bytes @ 0x0
	global	___CMS_KeyDatIIR@1023
___CMS_KeyDatIIR@1023:	; 2 bytes @ 0x0
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x0
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x0
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x0
	ds	1
?_KeyScan:	; 1 bytes @ 0x1
	global	KeyScan@num
KeyScan@num:	; 1 bytes @ 0x1
	global	___CMS_KeyStopClear@961
___CMS_KeyStopClear@961:	; 1 bytes @ 0x1
	global	___CMS_Key_UNNOL_Check@1017
___CMS_Key_UNNOL_Check@1017:	; 1 bytes @ 0x1
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x1
	ds	1
??_Led_Handle:	; 1 bytes @ 0x2
??_KeyScan:	; 1 bytes @ 0x2
??___CMS_CheckKeyOldValue:	; 1 bytes @ 0x2
	global	DecF@var
DecF@var:	; 1 bytes @ 0x2
	global	SetFilterDelayReset@hour
SetFilterDelayReset@hour:	; 1 bytes @ 0x2
	global	LedSetSt@Num
LedSetSt@Num:	; 1 bytes @ 0x2
	global	Memory_Write@Value
Memory_Write@Value:	; 1 bytes @ 0x2
	global	AD_Testing@ad_fd
AD_Testing@ad_fd:	; 1 bytes @ 0x2
	global	___CMS_CurAdjust@1046
___CMS_CurAdjust@1046:	; 1 bytes @ 0x2
	global	GetCurTdsHz@index
GetCurTdsHz@index:	; 2 bytes @ 0x2
	global	___CMS_KeyDatIIR@1024
___CMS_KeyDatIIR@1024:	; 2 bytes @ 0x2
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x2
	ds	1
??_GetDelayFilterFlag:	; 1 bytes @ 0x3
?_FilterTimeHandle:	; 1 bytes @ 0x3
??_WashHandle:	; 1 bytes @ 0x3
	global	SetFilterDelayReset@min
SetFilterDelayReset@min:	; 1 bytes @ 0x3
	global	AllLedFlash@Type
AllLedFlash@Type:	; 1 bytes @ 0x3
	global	ShiftMode_Handle@Mod
ShiftMode_Handle@Mod:	; 1 bytes @ 0x3
	global	___CMS_CurAdjust@1045
___CMS_CurAdjust@1045:	; 1 bytes @ 0x3
	global	AD_Testing@AD_Result
AD_Testing@AD_Result:	; 2 bytes @ 0x3
	global	Page_ProgramData@i
Page_ProgramData@i:	; 2 bytes @ 0x3
	global	___CMS_Noise_check@974
___CMS_Noise_check@974:	; 2 bytes @ 0x3
	global	FilterTimeHandle@Filter_time
FilterTimeHandle@Filter_time:	; 5 bytes @ 0x3
	ds	1
??_GetCurTdsHz:	; 1 bytes @ 0x4
	global	KeyScan@sw_port
KeyScan@sw_port:	; 1 bytes @ 0x4
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x4
	global	SetFilterDelayReset@sec
SetFilterDelayReset@sec:	; 2 bytes @ 0x4
	global	AllLedFlash@i
AllLedFlash@i:	; 2 bytes @ 0x4
	global	Led_Handle@i
Led_Handle@i:	; 2 bytes @ 0x4
	global	___CMS_CheckKeyOldValue@1006
___CMS_CheckKeyOldValue@1006:	; 2 bytes @ 0x4
	global	___CMS_KeyDatIIR@1022
___CMS_KeyDatIIR@1022:	; 2 bytes @ 0x4
	global	___CMS_CurAdjust@1047
___CMS_CurAdjust@1047:	; 2 bytes @ 0x4
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x4
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x4
	ds	1
??_CheckKey:	; 1 bytes @ 0x5
	global	GetDelayFilterFlag@PtrMin
GetDelayFilterFlag@PtrMin:	; 1 bytes @ 0x5
	global	AD_Testing@i
AD_Testing@i:	; 1 bytes @ 0x5
	global	___CMS_Noise_check@971
___CMS_Noise_check@971:	; 1 bytes @ 0x5
	global	___CMS_CheckOnceResult@989
___CMS_CheckOnceResult@989:	; 2 bytes @ 0x5
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x5
	ds	1
	global	CheckKey@St
CheckKey@St:	; 1 bytes @ 0x6
	global	___CMS_Noise_check@972
___CMS_Noise_check@972:	; 1 bytes @ 0x6
	global	___CMS_CheckKeyOldValue@1004
___CMS_CheckKeyOldValue@1004:	; 1 bytes @ 0x6
	global	AD_Testing@data
AD_Testing@data:	; 2 bytes @ 0x6
	global	___CMS_KeyDatIIR@1025
___CMS_KeyDatIIR@1025:	; 2 bytes @ 0x6
	ds	1
	global	___CMS_CheckOnceResult@980
___CMS_CheckOnceResult@980:	; 1 bytes @ 0x7
	global	CheckKey@i
CheckKey@i:	; 2 bytes @ 0x7
	global	___CMS_Noise_check@975
___CMS_Noise_check@975:	; 2 bytes @ 0x7
	global	___CMS_CheckKeyOldValue@1007
___CMS_CheckKeyOldValue@1007:	; 2 bytes @ 0x7
	ds	1
	global	FilterTimeHandle@FilterState
FilterTimeHandle@FilterState:	; 1 bytes @ 0x8
	global	___CMS_CheckOnceResult@981
___CMS_CheckOnceResult@981:	; 1 bytes @ 0x8
	global	___CMS_KeyDatIIR@1026
___CMS_KeyDatIIR@1026:	; 2 bytes @ 0x8
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x8
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x8
	ds	1
	global	FilterTimeHandle@Type
FilterTimeHandle@Type:	; 1 bytes @ 0x9
	global	___CMS_CheckOnceResult@985
___CMS_CheckOnceResult@985:	; 1 bytes @ 0x9
	global	___CMS_Noise_check@973
___CMS_Noise_check@973:	; 2 bytes @ 0x9
	global	___CMS_CheckKeyOldValue@1008
___CMS_CheckKeyOldValue@1008:	; 2 bytes @ 0x9
	ds	1
	global	FilterTimeHandle@FilterGetWater
FilterTimeHandle@FilterGetWater:	; 1 bytes @ 0xA
	global	___CMS_CheckOnceResult@986
___CMS_CheckOnceResult@986:	; 1 bytes @ 0xA
	global	___CMS_KeyDatIIR@1021
___CMS_KeyDatIIR@1021:	; 1 bytes @ 0xA
	global	GetCurTdsHz@i
GetCurTdsHz@i:	; 2 bytes @ 0xA
	ds	1
??_FilterTimeHandle:	; 1 bytes @ 0xB
	global	___CMS_Noise_check@970
___CMS_Noise_check@970:	; 1 bytes @ 0xB
	global	___CMS_CheckOnceResult@982
___CMS_CheckOnceResult@982:	; 1 bytes @ 0xB
	global	___CMS_CheckKeyOldValue@1009
___CMS_CheckKeyOldValue@1009:	; 2 bytes @ 0xB
	ds	1
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0xC
	global	GetCurTdsHz@tmp
GetCurTdsHz@tmp:	; 2 bytes @ 0xC
	global	___CMS_CheckOnceResult@990
___CMS_CheckOnceResult@990:	; 2 bytes @ 0xC
	ds	1
	global	___CMS_CheckKeyOldValue@1005
___CMS_CheckKeyOldValue@1005:	; 1 bytes @ 0xD
	ds	1
	global	GetCurTdsHz@AdPtr
GetCurTdsHz@AdPtr:	; 1 bytes @ 0xE
	global	___CMS_CheckKeyOldValue@1003
___CMS_CheckKeyOldValue@1003:	; 1 bytes @ 0xE
	global	___CMS_CheckOnceResult@991
___CMS_CheckOnceResult@991:	; 2 bytes @ 0xE
	ds	1
??_TDS_Handle:	; 1 bytes @ 0xF
	ds	1
	global	___CMS_CheckOnceResult@983
___CMS_CheckOnceResult@983:	; 1 bytes @ 0x10
	ds	1
	global	___CMS_CheckOnceResult@984
___CMS_CheckOnceResult@984:	; 1 bytes @ 0x11
	ds	1
	global	___CMS_CheckOnceResult@988
___CMS_CheckOnceResult@988:	; 1 bytes @ 0x12
	ds	1
	global	___CMS_CheckOnceResult@987
___CMS_CheckOnceResult@987:	; 1 bytes @ 0x13
	global	TDS_Handle@NTC_
TDS_Handle@NTC_:	; 4 bytes @ 0x13
	ds	1
	global	___CMS_CheckOnceResult@979
___CMS_CheckOnceResult@979:	; 1 bytes @ 0x14
	ds	3
	global	TDS_Handle@i
TDS_Handle@i:	; 2 bytes @ 0x17
	ds	2
	global	TDS_Handle@Muni_c
TDS_Handle@Muni_c:	; 4 bytes @ 0x19
	ds	4
	global	TDS_Handle@TDSTyp
TDS_Handle@TDSTyp:	; 1 bytes @ 0x1D
	ds	1
;!
;!Data Sizes:
;!    Strings     0
;!    Constant    520
;!    Data        0
;!    BSS         171
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14      6      10
;!    BANK0            80     30      80
;!    BANK1            80      4      75
;!    BANK2            80      0      47

;!
;!Pointer List with Targets:
;!
;!    SetStandbyState@Time	PTR unsigned char  size(1) Largest target is 1
;!		 -> WashRunTime(BANK0[1]), 
;!
;!    FilterTimeHandle@FilterGetWater	PTR unsigned int  size(1) Largest target is 2
;!		 -> FilterPCFGetWater(BANK0[2]), FilterROGetWater(BANK0[2]), 
;!
;!    FilterTimeHandle@FilterState	PTR unsigned char  size(1) Largest target is 1
;!		 -> FilterPCFState(BANK0[1]), FilterROState(BANK0[1]), 
;!
;!    TDS_Handle@TDSTyp	PTR struct . size(1) Largest target is 17
;!		 -> PureTDSTyp(BANK2[17]), 
;!
;!    GetDelayFilterFlag@PtrMin	PTR struct . size(1) Largest target is 5
;!		 -> FilterRO_time(BANK1[5]), FilterPCF_time(BANK1[5]), 
;!
;!    SetFilterDelayReset@TimPtr	PTR struct . size(1) Largest target is 5
;!		 -> FilterRO_time(BANK1[5]), FilterPCF_time(BANK1[5]), 
;!
;!    DecF@var	PTR unsigned int  size(1) Largest target is 5
;!		 -> FilterRO_time(BANK1[5]), FilterPCF_time(BANK1[5]), 
;!
;!    Dec@var	PTR unsigned char  size(1) Largest target is 5
;!		 -> FilterRO_time(BANK1[5]), FilterPCF_time(BANK1[5]), 
;!
;!    GetCurTdsHz@Tab	PTR unsigned int  size(2) Largest target is 380
;!		 -> PureHz_Tab(CODE[380]), 
;!
;!    GetCurTdsHz@AdPtr	PTR struct . size(1) Largest target is 17
;!		 -> PureTDSTyp(BANK2[17]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    _Run_Mode->_BuzzerSet
;!    _Run_Mode->_LedSetSt
;!    _Run_Mode->_SetStandbyState
;!    _StandbyMode_Handle->_BuzzerSet
;!    _StandbyMode_Handle->_LedSetSt
;!    _StandbyMode_Handle->_SetStandbyState
;!    _StatusFun_Handle->_SetStandbyState
;!    _WashHandle->_LedSetSt
;!    _WashHandle->_SetStandbyState
;!    _FactoryMode_Handle->_BuzzerSet
;!    _FactoryMode_Handle->_LedSetSt
;!    _Time_Count_Func->_AD_Testing
;!    _Time_Count_Func->_BuzzerSet
;!    _Time_Count_Func->_SetStandbyState
;!    _Time_Count_Func->_TaskAlarmHandle
;!    ___CMS_CheckTouchKey->___CMS_Key_UNNOL_Check
;!    ___CMS_KeyStopClear->___CMS_KeyClearOne
;!    ___CMS_CurAdjust->___CMS_CurJudge
;!    ___CMS_CheckOnceResult->___CMS_KeyHaveDown
;!    ___CMS_CheckOnceResult->___CMS_KeyIsIn
;!    ___CMS_CheckOnceResult->___CMS_KeyOpen
;!    ___CMS_CheckKeyOldValue->___CMS_KeyIsIn
;!    ___CMS_CheckKeyOldValue->_abs
;!    _Page_ProgramData->_Memory_Write
;!    _Led_Handle->_LedControlSt
;!    _GetDelayFilterFlag->_Dec
;!    _GetDelayFilterFlag->_DecF
;!    _FilterLifeFunc->_BuzzerSet
;!    _FilterTimeHandle->_LedSetSt
;!    _FilterKeyInputRest->_BuzzerSet
;!    _FilterKeyInputRest->_LedSetSt
;!    _ErrorHandle->_BuzzerSet
;!    _ErrorHandle->_LedSetSt
;!    _ShiftMode_Handle->_BuzzerSet
;!    _ShiftMode_Handle->_LedSetSt
;!    _ShiftMode_Handle->_SetStandbyState
;!    _AllLedFlash->_LedSetSt
;!    _LedSetSt->___bmul
;!    _KeyScan->_BuzzerSet
;!    _ReadDataArry->_Memory_Read
;!
;!Critical Paths under _Timer1_Isr in COMMON
;!
;!    None.
;!
;!Critical Paths under _main in BANK0
;!
;!    _StatusFun_Handle->_WashHandle
;!    _WashHandle->_LedSetSt
;!    _GetMode_Handle->_ShiftMode_Handle
;!    _Time_Count_Func->_TDS_Handle
;!    ___CMS_CheckTouchKey->___CMS_CheckOnceResult
;!    ___CMS_KeyStopClear->___CMS_KeyClearOne
;!    ___CMS_CheckKeyOldValue->_abs
;!    _TDS_Handle->_GetCurTdsHz
;!    _Page_ProgramData->_Memory_Write
;!    _Led_Handle->___bmul
;!    _GetDelayFilterFlag->_DecF
;!    _FilterLifeFunc->_FilterTimeHandle
;!    _FilterTimeHandle->_LedSetSt
;!    _FilterKeyInputRest->_SetFilterDelayReset
;!    _ErrorHandle->_AllLedFlash
;!    _ShiftMode_Handle->_LedSetSt
;!    _AllLedFlash->_LedSetSt
;!    _LedSetSt->___bmul
;!    _CheckKey->_KeyScan
;!    _KeyScan->_BuzzerSet
;!    _EEPROM_Page->_SetFilterDelayReset
;!
;!Critical Paths under _Timer1_Isr in BANK0
;!
;!    None.
;!
;!Critical Paths under _main in BANK1
;!
;!    _Run_Mode->_FactoryMode_Handle
;!    _FactoryMode_Handle->_Time_Count_Func
;!
;!Critical Paths under _Timer1_Isr in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Timer1_Isr in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 0, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 0     0      0  223694
;!                        _EEPROM_Page
;!                         _Initialize
;!                           _Run_Mode
;!                            _Set_PWM
;!                    _Set_Usart_Async
;!                    _Time_Count_Func
;! ---------------------------------------------------------------------------------
;! (1) _Set_Usart_Async                                      0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Set_PWM                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Run_Mode                                             0     0      0  149118
;!                        _AllLedFlash
;!                          _BuzzerSet
;!                 _FactoryMode_Handle
;!                     _GetMode_Handle
;!                           _LedSetSt
;!                    _SetStandbyState
;!                   _ShiftMode_Handle
;!                 _StandbyMode_Handle
;! ---------------------------------------------------------------------------------
;! (2) _StandbyMode_Handle                                   0     0      0   28126
;!                          _BuzzerSet
;!                           _LedSetSt
;!                    _SetStandbyState
;!                   _ShiftMode_Handle
;!                   _StatusFun_Handle
;!                           _WrterEEP
;! ---------------------------------------------------------------------------------
;! (3) _StatusFun_Handle                                     0     0      0    9460
;!                    _SetStandbyState
;!                         _WashHandle
;! ---------------------------------------------------------------------------------
;! (4) _WashHandle                                           2     2      0    7875
;!                                              3 BANK0      2     2      0
;!                           _LedSetSt
;!                    _SetStandbyState
;! ---------------------------------------------------------------------------------
;! (2) _GetMode_Handle                                       0     0      0    9364
;!                   _ShiftMode_Handle
;!                           _WrterEEP
;! ---------------------------------------------------------------------------------
;! (2) _FactoryMode_Handle                                   1     1      0   86542
;!                                              3 BANK1      1     1      0
;!                        _AllLedFlash
;!                          _BuzzerSet
;!                           _LedSetSt
;!                    _Time_Count_Func
;! ---------------------------------------------------------------------------------
;! (1) _Time_Count_Func                                      3     3      0   72359
;!                                              0 BANK1      3     3      0
;!                         _AD_Testing
;!                          _BuzzerSet
;!                           _CheckKey
;!                        _ErrorHandle
;!                 _FilterKeyInputRest
;!                     _FilterLifeFunc
;!                 _GetDelayFilterFlag
;!                         _Led_Handle
;!                   _Page_ProgramData
;!                    _SetStandbyState
;!                         _TDS_Handle
;!                    _TaskAlarmHandle
;!                         _Tx_Display
;!                ___CMS_CheckTouchKey
;! ---------------------------------------------------------------------------------
;! (2) ___CMS_CheckTouchKey                                  1     1      0    6997
;!             ___CMS_CheckKeyOldValue
;!              ___CMS_CheckOnceResult
;!               ___CMS_CheckValidTime
;!                    ___CMS_CurAdjust
;!                    ___CMS_KeyDatIIR
;!                   ___CMS_KeyModeSet
;!                     ___CMS_KeyStart
;!                 ___CMS_KeyStopClear
;!              ___CMS_Key_UNNOL_Check
;!                    ___CMS_NewRAMClr
;!                  ___CMS_Noise_check
;!                   ___GET_32M_FREDAT
;! ---------------------------------------------------------------------------------
;! (3) ___GET_32M_FREDAT                                     0     0      0       0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_Noise_check                                   12    12      0     380
;!                                              0 BANK0     12    12      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_NewRAMClr                                      1     1      0     223
;!                                              4 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_Key_UNNOL_Check                                4     4      0     359
;!                                              4 COMMON     2     2      0
;!                                              0 BANK0      2     2      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_KeyStopClear                                   1     1      0     347
;!                                              1 BANK0      1     1      0
;!                  ___CMS_KeyClearOne
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_KeyClearOne                                    3     3      0     248
;!                                              4 COMMON     2     2      0
;!                                              0 BANK0      1     1      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_KeyDatIIR                                     11    11      0     656
;!                                              0 BANK0     11    11      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_CurAdjust                                      6     6      0     528
;!                                              0 BANK0      6     6      0
;!                   ___CMS_CurAdjMode
;!                     ___CMS_CurJudge
;!                   ___CMS_KeyModeSet
;!                     ___CMS_KeyStart
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_KeyStart                                       1     1      0      74
;!                                              4 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_KeyModeSet                                     1     1      0      34
;!                                              4 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_CurJudge                                       2     2      0       0
;!                                              4 COMMON     2     2      0
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_CurAdjMode                                     1     1      0     145
;!                                              4 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_CheckValidTime                                 0     0      0       0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_CheckOnceResult                               21    21      0    2489
;!                                              0 BANK0     21    21      0
;!                  ___CMS_KeyHaveDown
;!                      ___CMS_KeyIsIn
;!                      ___CMS_KeyOpen
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_KeyOpen                                        2     1      1     161
;!                                              4 COMMON     2     1      1
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_KeyHaveDown                                    2     1      1     353
;!                                              4 COMMON     2     1      1
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_CheckKeyOldValue                              13    13      0    1907
;!                                              2 BANK0     13    13      0
;!                      ___CMS_KeyIsIn
;!                                _abs
;! ---------------------------------------------------------------------------------
;! (4) _abs                                                  4     2      2     465
;!                                              4 COMMON     2     0      2
;!                                              0 BANK0      2     2      0
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_KeyIsIn                                        2     2      0     102
;!                                              4 COMMON     2     2      0
;! ---------------------------------------------------------------------------------
;! (2) _Tx_Display                                           0     0      0       0
;! ---------------------------------------------------------------------------------
;! (2) _TaskAlarmHandle                                      2     2      0       0
;!                                              4 COMMON     2     2      0
;! ---------------------------------------------------------------------------------
;! (2) _TDS_Handle                                          16    15      1    3341
;!                                              4 COMMON     1     0      1
;!                                             15 BANK0     15    15      0
;!                        _GetCurTdsHz
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (3) ___lwdiv                                              7     3      4     532
;!                                              0 BANK0      7     3      4
;! ---------------------------------------------------------------------------------
;! (3) ___lmul                                              12     4      8     266
;!                                              0 BANK0     12     4      8
;! ---------------------------------------------------------------------------------
;! (3) ___lldiv                                             13     5      8     371
;!                                              0 BANK0     13     5      8
;! ---------------------------------------------------------------------------------
;! (3) _GetCurTdsHz                                         15    11      4     705
;!                                              0 BANK0     15    11      4
;! ---------------------------------------------------------------------------------
;! (2) _Page_ProgramData                                     2     2      0     359
;!                                              3 BANK0      2     2      0
;!                       _Memory_Write
;! ---------------------------------------------------------------------------------
;! (3) _Memory_Write                                         4     1      3     226
;!                                              4 COMMON     1     1      0
;!                                              0 BANK0      3     0      3
;! ---------------------------------------------------------------------------------
;! (2) _Led_Handle                                           4     4      0    2651
;!                                              2 BANK0      4     4      0
;!                       _LedControlSt
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (3) _LedControlSt                                         2     1      1     864
;!                                              4 COMMON     2     1      1
;! ---------------------------------------------------------------------------------
;! (2) _GetDelayFilterFlag                                   3     3      0     843
;!                                              3 BANK0      3     3      0
;!                                _Dec
;!                               _DecF
;! ---------------------------------------------------------------------------------
;! (3) _DecF                                                 5     3      2     157
;!                                              4 COMMON     2     0      2
;!                                              0 BANK0      3     3      0
;! ---------------------------------------------------------------------------------
;! (3) _Dec                                                  2     1      1     409
;!                                              4 COMMON     2     1      1
;! ---------------------------------------------------------------------------------
;! (2) _FilterLifeFunc                                       0     0      0    9018
;!                          _BuzzerSet
;!                   _FilterTimeHandle
;! ---------------------------------------------------------------------------------
;! (3) _FilterTimeHandle                                    12     4      8    7591
;!                                              3 BANK0     12     4      8
;!                           _LedSetSt
;! ---------------------------------------------------------------------------------
;! (2) _FilterKeyInputRest                                   0     0      0   19069
;!                          _BuzzerSet
;!                           _LedSetSt
;!                _SetFilterDelayReset
;!                   _ShiftMode_Handle
;!                           _WrterEEP
;! ---------------------------------------------------------------------------------
;! (2) _ErrorHandle                                          0     0      0   23501
;!                        _AllLedFlash
;!                          _BuzzerSet
;!                            _GetStop
;!                           _LedSetSt
;!                   _ShiftMode_Handle
;! ---------------------------------------------------------------------------------
;! (3) _ShiftMode_Handle                                     1     1      0    9364
;!                                              3 BANK0      1     1      0
;!                          _BuzzerSet
;!                           _LedSetSt
;!                    _SetStandbyState
;! ---------------------------------------------------------------------------------
;! (2) _SetStandbyState                                      3     1      2    1585
;!                                              4 COMMON     2     0      2
;!                                              0 BANK0      1     1      0
;! ---------------------------------------------------------------------------------
;! (3) _GetStop                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (3) _AllLedFlash                                          3     3      0    6420
;!                                              3 BANK0      3     3      0
;!                           _LedSetSt
;! ---------------------------------------------------------------------------------
;! (4) _LedSetSt                                             2     1      1    6290
;!                                              5 COMMON     1     0      1
;!                                              2 BANK0      1     1      0
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (3) ___bmul                                               3     2      1     941
;!                                              4 COMMON     1     0      1
;!                                              0 BANK0      2     2      0
;! ---------------------------------------------------------------------------------
;! (2) _CheckKey                                             4     4      0    2843
;!                                              5 BANK0      4     4      0
;!                            _KeyScan
;! ---------------------------------------------------------------------------------
;! (3) _KeyScan                                              4     3      1    2515
;!                                              1 BANK0      4     3      1
;!                          _BuzzerSet
;! ---------------------------------------------------------------------------------
;! (3) _BuzzerSet                                            3     1      2    1427
;!                                              4 COMMON     2     0      2
;!                                              0 BANK0      1     1      0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Testing                                          10     8      2     725
;!                                              4 COMMON     2     0      2
;!                                              0 BANK0      8     8      0
;! ---------------------------------------------------------------------------------
;! (1) _Initialize                                           0     0      0       0
;!                           _Init_ram
;! ---------------------------------------------------------------------------------
;! (2) _Init_ram                                             0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _EEPROM_Page                                          0     0      0    2217
;!                       _ReadDataArry
;!                _SetFilterDelayReset
;!                           _WrterEEP
;! ---------------------------------------------------------------------------------
;! (3) _WrterEEP                                             0     0      0       0
;! ---------------------------------------------------------------------------------
;! (3) _SetFilterDelayReset                                  7     1      6    1988
;!                                              4 COMMON     1     1      0
;!                                              0 BANK0      6     0      6
;! ---------------------------------------------------------------------------------
;! (2) _ReadDataArry                                         2     2      0     229
;!                                              0 BANK0      2     2      0
;!                        _Memory_Read
;! ---------------------------------------------------------------------------------
;! (3) _Memory_Read                                          2     0      2      96
;!                                              4 COMMON     2     0      2
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 4
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (8) _Timer1_Isr                                           4     4      0       0
;!                                              0 COMMON     4     4      0
;!                ___CMS_TouchKeyValue
;! ---------------------------------------------------------------------------------
;! (10) ___CMS_TouchKeyValue                                 0     0      0       0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 10
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _EEPROM_Page
;!     _ReadDataArry
;!       _Memory_Read
;!     _SetFilterDelayReset
;!     _WrterEEP
;!   _Initialize
;!     _Init_ram
;!   _Run_Mode
;!     _AllLedFlash
;!       _LedSetSt
;!         ___bmul
;!     _BuzzerSet
;!     _FactoryMode_Handle
;!       _AllLedFlash
;!         _LedSetSt
;!           ___bmul
;!       _BuzzerSet
;!       _LedSetSt
;!         ___bmul
;!       _Time_Count_Func
;!         _AD_Testing
;!         _BuzzerSet
;!         _CheckKey
;!           _KeyScan
;!             _BuzzerSet
;!         _ErrorHandle
;!           _AllLedFlash
;!             _LedSetSt
;!               ___bmul
;!           _BuzzerSet
;!           _GetStop
;!           _LedSetSt
;!             ___bmul
;!           _ShiftMode_Handle
;!             _BuzzerSet
;!             _LedSetSt
;!               ___bmul
;!             _SetStandbyState
;!         _FilterKeyInputRest
;!           _BuzzerSet
;!           _LedSetSt
;!             ___bmul
;!           _SetFilterDelayReset
;!           _ShiftMode_Handle
;!             _BuzzerSet
;!             _LedSetSt
;!               ___bmul
;!             _SetStandbyState
;!           _WrterEEP
;!         _FilterLifeFunc
;!           _BuzzerSet
;!           _FilterTimeHandle
;!             _LedSetSt
;!               ___bmul
;!         _GetDelayFilterFlag
;!           _Dec
;!           _DecF
;!         _Led_Handle
;!           _LedControlSt
;!           ___bmul
;!         _Page_ProgramData
;!           _Memory_Write
;!         _SetStandbyState
;!         _TDS_Handle
;!           _GetCurTdsHz
;!           ___lldiv
;!           ___lmul
;!           ___lwdiv
;!         _TaskAlarmHandle
;!         _Tx_Display
;!         ___CMS_CheckTouchKey
;!           ___CMS_CheckKeyOldValue
;!             ___CMS_KeyIsIn
;!             _abs
;!           ___CMS_CheckOnceResult
;!             ___CMS_KeyHaveDown
;!             ___CMS_KeyIsIn
;!             ___CMS_KeyOpen
;!           ___CMS_CheckValidTime
;!           ___CMS_CurAdjust
;!             ___CMS_CurAdjMode
;!             ___CMS_CurJudge
;!             ___CMS_KeyModeSet
;!             ___CMS_KeyStart
;!           ___CMS_KeyDatIIR
;!           ___CMS_KeyModeSet
;!           ___CMS_KeyStart
;!           ___CMS_KeyStopClear
;!             ___CMS_KeyClearOne
;!           ___CMS_Key_UNNOL_Check
;!           ___CMS_NewRAMClr
;!           ___CMS_Noise_check
;!           ___GET_32M_FREDAT
;!     _GetMode_Handle
;!       _ShiftMode_Handle
;!         _BuzzerSet
;!         _LedSetSt
;!           ___bmul
;!         _SetStandbyState
;!       _WrterEEP
;!     _LedSetSt
;!       ___bmul
;!     _SetStandbyState
;!     _ShiftMode_Handle
;!       _BuzzerSet
;!       _LedSetSt
;!         ___bmul
;!       _SetStandbyState
;!     _StandbyMode_Handle
;!       _BuzzerSet
;!       _LedSetSt
;!         ___bmul
;!       _SetStandbyState
;!       _ShiftMode_Handle
;!         _BuzzerSet
;!         _LedSetSt
;!           ___bmul
;!         _SetStandbyState
;!       _StatusFun_Handle
;!         _SetStandbyState
;!         _WashHandle
;!           _LedSetSt
;!             ___bmul
;!           _SetStandbyState
;!       _WrterEEP
;!   _Set_PWM
;!   _Set_Usart_Async
;!   _Time_Count_Func
;!     _AD_Testing
;!     _BuzzerSet
;!     _CheckKey
;!       _KeyScan
;!         _BuzzerSet
;!     _ErrorHandle
;!       _AllLedFlash
;!         _LedSetSt
;!           ___bmul
;!       _BuzzerSet
;!       _GetStop
;!       _LedSetSt
;!         ___bmul
;!       _ShiftMode_Handle
;!         _BuzzerSet
;!         _LedSetSt
;!           ___bmul
;!         _SetStandbyState
;!     _FilterKeyInputRest
;!       _BuzzerSet
;!       _LedSetSt
;!         ___bmul
;!       _SetFilterDelayReset
;!       _ShiftMode_Handle
;!         _BuzzerSet
;!         _LedSetSt
;!           ___bmul
;!         _SetStandbyState
;!       _WrterEEP
;!     _FilterLifeFunc
;!       _BuzzerSet
;!       _FilterTimeHandle
;!         _LedSetSt
;!           ___bmul
;!     _GetDelayFilterFlag
;!       _Dec
;!       _DecF
;!     _Led_Handle
;!       _LedControlSt
;!       ___bmul
;!     _Page_ProgramData
;!       _Memory_Write
;!     _SetStandbyState
;!     _TDS_Handle
;!       _GetCurTdsHz
;!       ___lldiv
;!       ___lmul
;!       ___lwdiv
;!     _TaskAlarmHandle
;!     _Tx_Display
;!     ___CMS_CheckTouchKey
;!       ___CMS_CheckKeyOldValue
;!         ___CMS_KeyIsIn
;!         _abs
;!       ___CMS_CheckOnceResult
;!         ___CMS_KeyHaveDown
;!         ___CMS_KeyIsIn
;!         ___CMS_KeyOpen
;!       ___CMS_CheckValidTime
;!       ___CMS_CurAdjust
;!         ___CMS_CurAdjMode
;!         ___CMS_CurJudge
;!         ___CMS_KeyModeSet
;!         ___CMS_KeyStart
;!       ___CMS_KeyDatIIR
;!       ___CMS_KeyModeSet
;!       ___CMS_KeyStart
;!       ___CMS_KeyStopClear
;!         ___CMS_KeyClearOne
;!       ___CMS_Key_UNNOL_Check
;!       ___CMS_NewRAMClr
;!       ___CMS_Noise_check
;!       ___GET_32M_FREDAT
;!
;! _Timer1_Isr (ROOT)
;!   ___CMS_TouchKeyValue
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BITCOMMON            E      0       1       0        7.1%
;!NULL                 0      0       0       0        0.0%
;!CODE                 0      0       0       0        0.0%
;!COMMON               E      6       A       1       71.4%
;!BITSFR0              0      0       0       1        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!SFR1                 0      0       0       2        0.0%
;!STACK                0      0       0       2        0.0%
;!BITBANK0            50      0       0       3        0.0%
;!BANK0               50     1E      50       4      100.0%
;!BITSFR3              0      0       0       4        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITBANK1            50      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BANK1               50      4      4B       6       93.8%
;!BANK2               50      0      2F       7       58.8%
;!ABS                  0      0      D4       8        0.0%
;!DATA                 0      0      D4       9        0.0%
;!BITBANK2            50      0       0      10        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 2739 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels required when called:   10
;; This function calls:
;;		_EEPROM_Page
;;		_Initialize
;;		_Run_Mode
;;		_Set_PWM
;;		_Set_Usart_Async
;;		_Time_Count_Func
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	2739
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	2739
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	2742
	
l11155:	
# 2742 "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	2743
# 2743 "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	maintext
	line	2744
	
l11157:	
;main.c: 2744: Initialize();
	fcall	_Initialize
	line	2745
	
l11159:	
;main.c: 2745: EEPROM_Page();
	fcall	_EEPROM_Page
	line	2747
	
l11161:	
;main.c: 2747: Set_PWM();
	fcall	_Set_PWM
	line	2748
	
l11163:	
;main.c: 2748: Set_Usart_Async();
	fcall	_Set_Usart_Async
	line	2755
	
l11165:	
;main.c: 2755: PreTdsData=PureTDSTyp.TdsData=0x03;
	movlw	low(0Fh)
	addlw	low(_PureTDSTyp|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	03h
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movlw	0
	movwf	indf
	movlw	03h
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_PreTdsData)
	movlw	0
	movwf	((_PreTdsData))+1
	line	2762
	
l11167:	
;main.c: 2762: RC2=0;
	bcf	(58/8),(58)&7	;volatile
	line	2763
	
l11169:	
;main.c: 2763: {RA2=0;_BITS2.Bits.bit_1=0;};
	bcf	(42/8),(42)&7	;volatile
	
l11171:	
	bcf	(__BITS2),1
	line	2764
	
l11173:	
;main.c: 2764: RC3=0;
	bcf	(59/8),(59)&7	;volatile
	line	2772
;main.c: 2772: while(1)
	
l1510:	
	line	2776
# 2776 "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	maintext
	line	2778
	
l11175:	
;main.c: 2778: Time_Count_Func();
	fcall	_Time_Count_Func
	line	2781
	
l11177:	
;main.c: 2781: Run_Mode();
	fcall	_Run_Mode
	goto	l1510
	global	start
	ljmp	start
	opt stack 0
	line	2789
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_Set_Usart_Async

;; *************** function _Set_Usart_Async *****************
;; Defined at:
;;		line 2682 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/200
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	2682
global __ptext1
__ptext1:	;psect for function _Set_Usart_Async
psect	text1
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	2682
	global	__size_of_Set_Usart_Async
	__size_of_Set_Usart_Async	equ	__end_of_Set_Usart_Async-_Set_Usart_Async
	
_Set_Usart_Async:	
;incstack = 0
	opt	stack 8
; Regs used in _Set_Usart_Async: [wreg]
	line	2698
	
l8813:	
;main.c: 2698: SPBRG1 = 103;
	movlw	low(067h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(152)^080h	;volatile
	line	2699
	
l8815:	
;main.c: 2699: SYNC1 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2300/8)^0100h,(2300)&7	;volatile
	line	2700
	
l8817:	
;main.c: 2700: SCKP1 = 0;
	bcf	(2299/8)^0100h,(2299)&7	;volatile
	line	2702
	
l8819:	
;main.c: 2702: SPEN1 = 1;
	bsf	(2095/8)^0100h,(2095)&7	;volatile
	line	2703
	
l8821:	
;main.c: 2703: RC1IE = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1129/8)^080h,(1129)&7	;volatile
	line	2704
	
l8823:	
;main.c: 2704: TX1IE = 0;
	bcf	(1130/8)^080h,(1130)&7	;volatile
	line	2705
	
l8825:	
;main.c: 2705: RX9EN1 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2094/8)^0100h,(2094)&7	;volatile
	line	2706
	
l8827:	
;main.c: 2706: TX9EN1 = 0;
	bcf	(2302/8)^0100h,(2302)&7	;volatile
	line	2707
	
l8829:	
;main.c: 2707: CREN1 = 0;
	bcf	(2092/8)^0100h,(2092)&7	;volatile
	line	2708
	
l8831:	
;main.c: 2708: TXEN1 = 1;
	bsf	(2301/8)^0100h,(2301)&7	;volatile
	line	2709
	
l1502:	
	return
	opt stack 0
GLOBAL	__end_of_Set_Usart_Async
	__end_of_Set_Usart_Async:
	signat	_Set_Usart_Async,89
	global	_Set_PWM

;; *************** function _Set_PWM *****************
;; Defined at:
;;		line 2710 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	line	2710
global __ptext2
__ptext2:	;psect for function _Set_PWM
psect	text2
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	2710
	global	__size_of_Set_PWM
	__size_of_Set_PWM	equ	__end_of_Set_PWM-_Set_PWM
	
_Set_PWM:	
;incstack = 0
	opt	stack 8
; Regs used in _Set_PWM: [wreg+status,2]
	line	2712
	
l8833:	
;main.c: 2712: PWMTL = 0xfa;
	movlw	low(0FAh)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(283)^0100h	;volatile
	line	2714
;main.c: 2714: PWMTH = 0B00000100;
	movlw	low(04h)
	movwf	(284)^0100h	;volatile
	line	2719
	
l8835:	
;main.c: 2719: PWMD01H = 0x00;
	clrf	(273)^0100h	;volatile
	line	2723
	
l8837:	
;main.c: 2723: PWMD1L = 0x7d;
	movlw	low(07Dh)
	movwf	(269)^0100h	;volatile
	line	2735
	
l8839:	
;main.c: 2735: PWMCON1 = 0B01000000;
	movlw	low(040h)
	movwf	(263)^0100h	;volatile
	line	2736
	
l8841:	
;main.c: 2736: PWMCON0 = 0B10100000;
	movlw	low(0A0h)
	movwf	(262)^0100h	;volatile
	line	2738
	
l1505:	
	return
	opt stack 0
GLOBAL	__end_of_Set_PWM
	__end_of_Set_PWM:
	signat	_Set_PWM,89
	global	_Run_Mode

;; *************** function _Run_Mode *****************
;; Defined at:
;;		line 1973 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    9
;; This function calls:
;;		_AllLedFlash
;;		_BuzzerSet
;;		_FactoryMode_Handle
;;		_GetMode_Handle
;;		_LedSetSt
;;		_SetStandbyState
;;		_ShiftMode_Handle
;;		_StandbyMode_Handle
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	line	1973
global __ptext3
__ptext3:	;psect for function _Run_Mode
psect	text3
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	1973
	global	__size_of_Run_Mode
	__size_of_Run_Mode	equ	__end_of_Run_Mode-_Run_Mode
	
_Run_Mode:	
;incstack = 0
	opt	stack 2
; Regs used in _Run_Mode: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1975
	
l11061:	
;main.c: 1975: switch(Mode){
	goto	l11119
	line	1979
	
l11063:	
;main.c: 1979: AllLedFlash(1);
	movlw	low(01h)
	fcall	_AllLedFlash
	line	1980
	
l11065:	
;main.c: 1980: _BITS.Bits.bit_5=0x01;
	bsf	(__BITS),5
	line	1981
	
l11067:	
;main.c: 1981: Timer_Power_100ms=0;
	clrf	(_Timer_Power_100ms)
	line	1982
	
l11069:	
;main.c: 1982: PowerStep=1;
	clrf	(_PowerStep)
	incf	(_PowerStep),f
	line	1983
	
l11071:	
;main.c: 1983: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	line	1984
	
l11073:	
;main.c: 1984: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1986
;main.c: 1986: break;
	goto	l1405
	line	1988
	
l11075:	
;main.c: 1988: if(Timer_Power_100ms>=30){
	movlw	low(01Eh)
	subwf	(_Timer_Power_100ms),w
	skipc
	goto	u10521
	goto	u10520
u10521:
	goto	l1405
u10520:
	line	1989
	
l11077:	
;main.c: 1989: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1990
	
l11079:	
;main.c: 1990: PowerStep=2;
	movlw	low(02h)
	movwf	(_PowerStep)
	goto	l1405
	line	1996
	
l11081:	
;main.c: 1996: if(Timer_Power_100ms>=31){
	movlw	low(01Fh)
	subwf	(_Timer_Power_100ms),w
	skipc
	goto	u10531
	goto	u10530
u10531:
	goto	l1405
u10530:
	line	1997
	
l11083:	
;main.c: 1997: ShiftMode_Handle(2);
	movlw	low(02h)
	fcall	_ShiftMode_Handle
	line	1999
;main.c: 1999: SetStandbyState(WashState,&WashRunTime, 18);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(012h)
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	goto	l1405
	line	2003
	
l11085:	
;main.c: 2003: Timer_Power_100ms=0;
	clrf	(_Timer_Power_100ms)
	line	2004
	
l11087:	
;main.c: 2004: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	2008
	
l11089:	
;main.c: 2008: LedSetSt(1, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(01h)
	fcall	_LedSetSt
	line	2009
	
l11091:	
;main.c: 2009: LedSetSt(5, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(05h)
	fcall	_LedSetSt
	line	2010
	
l11093:	
;main.c: 2010: LedSetSt(3, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(03h)
	fcall	_LedSetSt
	line	2017
	
l11095:	
;main.c: 2017: PowerStep=4;
	movlw	low(04h)
	movwf	(_PowerStep)
	line	2018
;main.c: 2018: break;
	goto	l1405
	line	2020
	
l11097:	
;main.c: 2020: if(Timer_Power_100ms>=10){
	movlw	low(0Ah)
	subwf	(_Timer_Power_100ms),w
	skipc
	goto	u10541
	goto	u10540
u10541:
	goto	l1405
u10540:
	line	2021
	
l11099:	
;main.c: 2021: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	2022
;main.c: 2022: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	line	2023
;main.c: 2023: LedSetSt(4, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(04h)
	fcall	_LedSetSt
	line	2024
;main.c: 2024: LedSetSt(2, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(02h)
	fcall	_LedSetSt
	line	2035
	
l11101:	
;main.c: 2035: PowerStep=5;
	movlw	low(05h)
	movwf	(_PowerStep)
	goto	l1405
	line	2041
	
l11103:	
;main.c: 2041: if(Timer_Power_100ms>=20){
	movlw	low(014h)
	subwf	(_Timer_Power_100ms),w
	skipc
	goto	u10551
	goto	u10550
u10551:
	goto	l1405
u10550:
	line	2042
	
l11105:	
;main.c: 2042: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	2043
;main.c: 2043: ShiftMode_Handle(2);
	movlw	low(02h)
	fcall	_ShiftMode_Handle
	goto	l1405
	line	1977
	
l11109:	
	movf	(_PowerStep),w
	; Switch size 1, requested type "space"
; Number of cases is 6, Range of values is 0 to 5
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           19    10 (average)
; direct_byte           26     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l11063
	xorlw	1^0	; case 1
	skipnz
	goto	l11075
	xorlw	2^1	; case 2
	skipnz
	goto	l11081
	xorlw	3^2	; case 3
	skipnz
	goto	l11085
	xorlw	4^3	; case 4
	skipnz
	goto	l11097
	xorlw	5^4	; case 5
	skipnz
	goto	l11103
	goto	l1405
	opt asmopt_pop

	line	2051
	
l11111:	
;main.c: 2051: StandbyMode_Handle();
	fcall	_StandbyMode_Handle
	line	2052
;main.c: 2052: break;
	goto	l1405
	line	2054
	
l11113:	
;main.c: 2054: GetMode_Handle();
	fcall	_GetMode_Handle
	line	2055
;main.c: 2055: break;
	goto	l1405
	line	2057
	
l11115:	
;main.c: 2057: FactoryMode_Handle();
	fcall	_FactoryMode_Handle
	line	2058
;main.c: 2058: break;
	goto	l1405
	line	2059
;main.c: 2059: case 3:
	
l1404:	
	line	2060
;main.c: 2060: {RA2=0;_BITS2.Bits.bit_1=0;};
	bcf	(42/8),(42)&7	;volatile
	bcf	(__BITS2),1
	line	2061
;main.c: 2061: RC3=0;
	bcf	(59/8),(59)&7	;volatile
	line	2062
;main.c: 2062: RC2=0;
	bcf	(58/8),(58)&7	;volatile
	line	2063
;main.c: 2063: break;
	goto	l1405
	line	1975
	
l11119:	
	movf	(_Mode),w
	; Switch size 1, requested type "space"
; Number of cases is 5, Range of values is 0 to 5
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           16     9 (average)
; direct_byte           26     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l11109
	xorlw	2^0	; case 2
	skipnz
	goto	l11111
	xorlw	3^2	; case 3
	skipnz
	goto	l1404
	xorlw	4^3	; case 4
	skipnz
	goto	l11113
	xorlw	5^4	; case 5
	skipnz
	goto	l11115
	goto	l1405
	opt asmopt_pop

	line	2065
	
l1405:	
	return
	opt stack 0
GLOBAL	__end_of_Run_Mode
	__end_of_Run_Mode:
	signat	_Run_Mode,89
	global	_StandbyMode_Handle

;; *************** function _StandbyMode_Handle *****************
;; Defined at:
;;		line 1838 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    7
;; This function calls:
;;		_BuzzerSet
;;		_LedSetSt
;;		_SetStandbyState
;;		_ShiftMode_Handle
;;		_StatusFun_Handle
;;		_WrterEEP
;; This function is called by:
;;		_Run_Mode
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	line	1838
global __ptext4
__ptext4:	;psect for function _StandbyMode_Handle
psect	text4
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	1838
	global	__size_of_StandbyMode_Handle
	__size_of_StandbyMode_Handle	equ	__end_of_StandbyMode_Handle-_StandbyMode_Handle
	
_StandbyMode_Handle:	
;incstack = 0
	opt	stack 3
; Regs used in _StandbyMode_Handle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1843
	
l10957:	
;main.c: 1842: static U8_T Ti_1h=0;
;main.c: 1843: if(Read_Word_Buff[11]==2)
		movlw	2
	bsf	status, 5	;RP0=1, select bank1
	xorwf	(0+(_Read_Word_Buff)^080h+0Bh),w
	btfss	status,2
	goto	u10331
	goto	u10330
u10331:
	goto	l10977
u10330:
	line	1846
	
l10959:	
;main.c: 1844: {
;main.c: 1846: if(Timer_Standby_1s>=300)
	movlw	01h
	subwf	(_Timer_Standby_1s+1)^080h,w
	movlw	02Ch
	skipnz
	subwf	(_Timer_Standby_1s)^080h,w
	skipc
	goto	u10341
	goto	u10340
u10341:
	goto	l10967
u10340:
	line	1849
	
l10961:	
;main.c: 1847: {
;main.c: 1849: if(_BITS1.Bits.bit_4==0){
	bcf	status, 5	;RP0=0, select bank0
	btfsc	(__BITS1),4
	goto	u10351
	goto	u10350
u10351:
	goto	l10967
u10350:
	line	1850
	
l10963:	
;main.c: 1850: _BITS1.Bits.bit_4=1;
	bsf	(__BITS1),4
	line	1851
	
l10965:	
;main.c: 1851: SetStandbyState(BackState,&WashRunTime, 30);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(01Eh)
	movwf	(SetStandbyState@Da)
	movlw	low(03h)
	fcall	_SetStandbyState
	line	1857
	
l10967:	
;main.c: 1852: }
;main.c: 1853: }
;main.c: 1857: if(Timer_BackT_1H>=11)
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_BackT_1H+1)^080h,w
	movlw	0Bh
	skipnz
	subwf	(_Timer_BackT_1H)^080h,w
	skipc
	goto	u10361
	goto	u10360
u10361:
	goto	l10977
u10360:
	line	1860
	
l10969:	
;main.c: 1859: {
;main.c: 1860: Timer_BackT_1H=0;
	clrf	(_Timer_BackT_1H)^080h
	clrf	(_Timer_BackT_1H+1)^080h
	line	1861
	
l10971:	
;main.c: 1861: if(_BITS1.Bits.bit_6==0)
	bcf	status, 5	;RP0=0, select bank0
	btfsc	(__BITS1),6
	goto	u10371
	goto	u10370
u10371:
	goto	l10977
u10370:
	line	1863
	
l10973:	
;main.c: 1862: {
;main.c: 1863: _BITS1.Bits.bit_6=1;
	bsf	(__BITS1),6
	line	1864
	
l10975:	
;main.c: 1864: SetStandbyState(BackState,&WashRunTime, 30);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(01Eh)
	movwf	(SetStandbyState@Da)
	movlw	low(03h)
	fcall	_SetStandbyState
	line	1870
	
l10977:	
;main.c: 1866: }
;main.c: 1867: }
;main.c: 1868: }
;main.c: 1870: if(Timer_Standby_1s>=1800)
	movlw	07h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_Standby_1s+1)^080h,w
	movlw	08h
	skipnz
	subwf	(_Timer_Standby_1s)^080h,w
	skipc
	goto	u10381
	goto	u10380
u10381:
	goto	l10991
u10380:
	line	1872
	
l10979:	
;main.c: 1871: {
;main.c: 1872: Timer_Standby_1s=0;
	clrf	(_Timer_Standby_1s)^080h
	clrf	(_Timer_Standby_1s+1)^080h
	line	1873
	
l10981:	
;main.c: 1873: if(Timer_Standby_1H<0xf0)
	movlw	0
	subwf	(_Timer_Standby_1H+1)^080h,w
	movlw	0F0h
	skipnz
	subwf	(_Timer_Standby_1H)^080h,w
	skipnc
	goto	u10391
	goto	u10390
u10391:
	goto	l1367
u10390:
	line	1874
	
l10983:	
;main.c: 1874: Timer_Standby_1H++;
	incf	(_Timer_Standby_1H)^080h,f
	skipnz
	incf	(_Timer_Standby_1H+1)^080h,f
	
l1367:	
	line	1875
;main.c: 1875: Timer_BackT_1H++;
	incf	(_Timer_BackT_1H)^080h,f
	skipnz
	incf	(_Timer_BackT_1H+1)^080h,f
	line	1876
	
l10985:	
;main.c: 1876: if(++Ti_1h>=10){
	movlw	low(0Ah)
	bcf	status, 5	;RP0=0, select bank0
	incf	(StandbyMode_Handle@Ti_1h),f
	subwf	((StandbyMode_Handle@Ti_1h)),w
	skipc
	goto	u10401
	goto	u10400
u10401:
	goto	l10991
u10400:
	line	1877
	
l10987:	
;main.c: 1877: Ti_1h=0;
	clrf	(StandbyMode_Handle@Ti_1h)
	line	1878
	
l10989:	
;main.c: 1878: WrterEEP();
	fcall	_WrterEEP
	line	1902
	
l10991:	
;main.c: 1879: }
;main.c: 1880: }
;main.c: 1901: if((KeyPacket_y[2].KeyState==LongPressDown)
;main.c: 1902: &&(KeyPacket_y[1].KeyState==NotPress))
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u10411
	goto	u10410
u10411:
	goto	l11027
u10410:
	
l10993:	
	movf	(0+(_KeyPacket_y)+03h),w
	btfss	status,2
	goto	u10421
	goto	u10420
u10421:
	goto	l11027
u10420:
	line	1904
	
l10995:	
;main.c: 1903: {
;main.c: 1904: KeyPacket_y[2].KeyState=SuperPressDown;
	movlw	low(03h)
	movwf	0+(_KeyPacket_y)+06h
	line	1905
;main.c: 1905: if(Time_Power_1s<=10){
	movlw	low(0Bh)
	subwf	(_Time_Power_1s),w
	skipnc
	goto	u10431
	goto	u10430
u10431:
	goto	l11001
u10430:
	line	1906
	
l10997:	
;main.c: 1906: BuzzerSet(3, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(03h)
	fcall	_BuzzerSet
	line	1907
	
l10999:	
;main.c: 1907: FilterFastCheck=1;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_FilterFastCheck)
	incf	(_FilterFastCheck),f
	line	1908
;main.c: 1908: }
	goto	l11027
	line	1911
	
l11001:	
;main.c: 1909: else
;main.c: 1910: {
;main.c: 1911: if(Read_Word_Buff[11]==0){
	bsf	status, 5	;RP0=1, select bank1
	movf	(0+(_Read_Word_Buff)^080h+0Bh),w
	btfss	status,2
	goto	u10441
	goto	u10440
u10441:
	goto	l11005
u10440:
	line	1912
	
l11003:	
;main.c: 1912: Read_Word_Buff[11]=3;
	movlw	low(03h)
	movwf	0+(_Read_Word_Buff)^080h+0Bh
	line	1913
;main.c: 1913: }
	goto	l11007
	line	1916
	
l11005:	
;main.c: 1914: else
;main.c: 1915: {
;main.c: 1916: Read_Word_Buff[11]=0;
	clrf	0+(_Read_Word_Buff)^080h+0Bh
	line	1920
	
l11007:	
;main.c: 1917: }
;main.c: 1920: WrterEEP();
	fcall	_WrterEEP
	line	1921
	
l11009:	
;main.c: 1921: if(Read_Word_Buff[11])
	bsf	status, 5	;RP0=1, select bank1
	movf	(0+(_Read_Word_Buff)^080h+0Bh),w
	btfsc	status,2
	goto	u10451
	goto	u10450
u10451:
	goto	l11023
u10450:
	line	1923
	
l11011:	
;main.c: 1922: {
;main.c: 1923: Read_Word_Buff[11]=3;
	movlw	low(03h)
	movwf	0+(_Read_Word_Buff)^080h+0Bh
	line	1924
	
l11013:	
;main.c: 1924: Timer_Standby_1s=0;
	clrf	(_Timer_Standby_1s)^080h
	clrf	(_Timer_Standby_1s+1)^080h
	line	1925
	
l11015:	
;main.c: 1925: Timer_BackT_1H=0;
	clrf	(_Timer_BackT_1H)^080h
	clrf	(_Timer_BackT_1H+1)^080h
	line	1926
	
l11017:	
;main.c: 1926: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1927
	
l11019:	
;main.c: 1927: LedSetSt(1, 5);
	movlw	low(05h)
	movwf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1928
	
l11021:	
;main.c: 1928: LedMod[1].LedFlashNum=1;
	bsf	status, 6	;RP1=1, select bank2
	clrf	0+(_LedMod)^0100h+08h
	incf	0+(_LedMod)^0100h+08h,f
	clrf	1+(_LedMod)^0100h+08h
	line	1929
;main.c: 1929: }
	goto	l11027
	line	1932
	
l11023:	
;main.c: 1930: else
;main.c: 1931: {
;main.c: 1932: LedSetSt(1, 5);
	movlw	low(05h)
	movwf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1933
	
l11025:	
;main.c: 1933: BuzzerSet(3, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(03h)
	fcall	_BuzzerSet
	line	1939
	
l11027:	
;main.c: 1934: }
;main.c: 1936: }
;main.c: 1937: }
;main.c: 1939: if(KeyPacket_y[2].KeyState==ShortRelease)
		movlw	6
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	xorwf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u10461
	goto	u10460
u10461:
	goto	l11041
u10460:
	line	1941
	
l11029:	
;main.c: 1940: {
;main.c: 1941: KeyPacket_y[2].KeyState=NotPress;
	clrf	0+(_KeyPacket_y)+06h
	line	1942
	
l11031:	
;main.c: 1942: if(_BITS1.Bits.bit_0==0){
	btfsc	(__BITS1),0
	goto	u10471
	goto	u10470
u10471:
	goto	l11041
u10470:
	line	1943
	
l11033:	
;main.c: 1943: BuzzerSet(1, 50);
	movlw	032h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1944
	
l11035:	
;main.c: 1944: if(StandByStatus==WashState)
	bcf	status, 5	;RP0=0, select bank0
		decf	((_StandByStatus)),w
	btfss	status,2
	goto	u10481
	goto	u10480
u10481:
	goto	l11039
u10480:
	line	1946
	
l11037:	
;main.c: 1945: {
;main.c: 1946: LedSetSt(1, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1947
;main.c: 1947: SetStandbyState(NornalStopState,&WashRunTime, 0);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	clrf	(SetStandbyState@Da)
	movlw	low(0)
	fcall	_SetStandbyState
	line	1948
;main.c: 1948: }
	goto	l11041
	line	1951
	
l11039:	
;main.c: 1949: else
;main.c: 1950: {
;main.c: 1951: SetStandbyState(WashState,&WashRunTime, 180);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(0B4h)
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	line	1960
	
l11041:	
;main.c: 1952: }
;main.c: 1953: }
;main.c: 1955: }
;main.c: 1960: if(KeyPacket_y[0].KeyState==NotPress){
	bcf	status, 5	;RP0=0, select bank0
	movf	((_KeyPacket_y)),w
	btfss	status,2
	goto	u10491
	goto	u10490
u10491:
	goto	l11045
u10490:
	line	1961
	
l11043:	
;main.c: 1961: StatusFun_Handle();
	fcall	_StatusFun_Handle
	line	1962
;main.c: 1962: }
	goto	l1383
	line	1965
	
l11045:	
;main.c: 1963: else
;main.c: 1964: {
;main.c: 1965: if(StandByStatus==BackState)
		movlw	3
	xorwf	((_StandByStatus)),w
	btfss	status,2
	goto	u10501
	goto	u10500
u10501:
	goto	l1382
u10500:
	line	1967
	
l11047:	
;main.c: 1966: {
;main.c: 1967: SetStandbyState(NornalStopState,&WashRunTime, 0);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	clrf	(SetStandbyState@Da)
	movlw	low(0)
	fcall	_SetStandbyState
	line	1968
	
l1382:	
	line	1969
;main.c: 1968: }
;main.c: 1969: ShiftMode_Handle(4);
	movlw	low(04h)
	fcall	_ShiftMode_Handle
	line	1972
	
l1383:	
	return
	opt stack 0
GLOBAL	__end_of_StandbyMode_Handle
	__end_of_StandbyMode_Handle:
	signat	_StandbyMode_Handle,89
	global	_StatusFun_Handle

;; *************** function _StatusFun_Handle *****************
;; Defined at:
;;		line 1451 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_SetStandbyState
;;		_WashHandle
;; This function is called by:
;;		_StandbyMode_Handle
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	line	1451
global __ptext5
__ptext5:	;psect for function _StatusFun_Handle
psect	text5
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	1451
	global	__size_of_StatusFun_Handle
	__size_of_StatusFun_Handle	equ	__end_of_StatusFun_Handle-_StatusFun_Handle
	
_StatusFun_Handle:	
;incstack = 0
	opt	stack 3
; Regs used in _StatusFun_Handle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1453
	
l10825:	
;main.c: 1453: switch(StandByStatus){
	goto	l10833
	line	1457
	
l10827:	
;main.c: 1456: case BackState:
;main.c: 1457: WashHandle();
	fcall	_WashHandle
	line	1458
;main.c: 1458: break;
	goto	l1269
	line	1460
	
l10829:	
;main.c: 1460: SetStandbyState(NornalStopState,&WashRunTime, 0);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	clrf	(SetStandbyState@Da)
	movlw	low(0)
	fcall	_SetStandbyState
	line	1461
;main.c: 1461: break;
	goto	l1269
	line	1453
	
l10833:	
	movf	(_StandByStatus),w
	; Switch size 1, requested type "space"
; Number of cases is 3, Range of values is 0 to 3
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           10     6 (average)
; direct_byte           20     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l10829
	xorlw	1^0	; case 1
	skipnz
	goto	l10827
	xorlw	3^1	; case 3
	skipnz
	goto	l10827
	goto	l1269
	opt asmopt_pop

	line	1463
	
l1269:	
	return
	opt stack 0
GLOBAL	__end_of_StatusFun_Handle
	__end_of_StatusFun_Handle:
	signat	_StatusFun_Handle,89
	global	_WashHandle

;; *************** function _WashHandle *****************
;; Defined at:
;;		line 1430 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_LedSetSt
;;		_SetStandbyState
;; This function is called by:
;;		_StatusFun_Handle
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	line	1430
global __ptext6
__ptext6:	;psect for function _WashHandle
psect	text6
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	1430
	global	__size_of_WashHandle
	__size_of_WashHandle	equ	__end_of_WashHandle-_WashHandle
	
_WashHandle:	
;incstack = 0
	opt	stack 3
; Regs used in _WashHandle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1431
	
l10683:	
;main.c: 1431: if((LedMod[1].LedState==0)&&(StandByStatus==WashState)){
	bsf	status, 6	;RP1=1, select bank2
	movf	(0+(_LedMod)^0100h+05h),w
	btfss	status,2
	goto	u9921
	goto	u9920
u9921:
	goto	l10689
u9920:
	
l10685:	
	bcf	status, 6	;RP1=0, select bank0
		decf	((_StandByStatus)),w
	btfss	status,2
	goto	u9931
	goto	u9930
u9931:
	goto	l10689
u9930:
	line	1432
	
l10687:	
;main.c: 1432: LedSetSt(1, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1434
	
l10689:	
;main.c: 1433: }
;main.c: 1434: if(Timer_WashRun_1s>=WashRunTime){
	bcf	status, 6	;RP1=0, select bank0
	movf	(_WashRunTime),w
	movwf	(??_WashHandle+0)+0
	clrf	(??_WashHandle+0)+0+1
	movf	1+(??_WashHandle+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_WashRun_1s+1)^080h,w
	skipz
	goto	u9945
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_WashHandle+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_WashRun_1s)^080h,w
u9945:
	skipc
	goto	u9941
	goto	u9940
u9941:
	goto	l1261
u9940:
	line	1440
	
l10691:	
;main.c: 1440: Time_made_1s=0;
	clrf	(_Time_made_1s)^080h
	clrf	(_Time_made_1s+1)^080h
	line	1443
	
l10693:	
;main.c: 1443: _BITS1.Bits.bit_0=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(__BITS1),0
	line	1444
	
l10695:	
;main.c: 1444: _BITS1.Bits.bit_6=0;
	bcf	(__BITS1),6
	line	1445
	
l10697:	
;main.c: 1445: LedSetSt(1, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1446
	
l10699:	
;main.c: 1446: SetStandbyState(NornalStopState,&WashRunTime, 0);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	clrf	(SetStandbyState@Da)
	movlw	low(0)
	fcall	_SetStandbyState
	line	1448
	
l1261:	
	return
	opt stack 0
GLOBAL	__end_of_WashHandle
	__end_of_WashHandle:
	signat	_WashHandle,89
	global	_GetMode_Handle

;; *************** function _GetMode_Handle *****************
;; Defined at:
;;		line 1334 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_ShiftMode_Handle
;;		_WrterEEP
;; This function is called by:
;;		_Run_Mode
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	line	1334
global __ptext7
__ptext7:	;psect for function _GetMode_Handle
psect	text7
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	1334
	global	__size_of_GetMode_Handle
	__size_of_GetMode_Handle	equ	__end_of_GetMode_Handle-_GetMode_Handle
	
_GetMode_Handle:	
;incstack = 0
	opt	stack 4
; Regs used in _GetMode_Handle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1338
	
l10843:	
;main.c: 1338: if(KeyPacket_y[0].KeyState==NotPress)
	movf	((_KeyPacket_y)),w
	btfss	status,2
	goto	u10161
	goto	u10160
u10161:
	goto	l10849
u10160:
	line	1340
	
l10845:	
;main.c: 1339: {
;main.c: 1340: ShiftMode_Handle(2);
	movlw	low(02h)
	fcall	_ShiftMode_Handle
	line	1341
	
l10847:	
;main.c: 1341: Timer_Standby_1H=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_Timer_Standby_1H)^080h
	clrf	(_Timer_Standby_1H+1)^080h
	line	1345
	
l10849:	
;main.c: 1342: }
;main.c: 1345: if(Time_GetWater_1s>=60){
	movlw	low(03Ch)
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_Time_GetWater_1s),w
	skipc
	goto	u10171
	goto	u10170
u10171:
	goto	l10867
u10170:
	line	1346
	
l10851:	
;main.c: 1346: Time_GetWater_1s=0;
	clrf	(_Time_GetWater_1s)
	line	1347
	
l10853:	
;main.c: 1347: GetWater_ML+=11;
	movlw	0Bh
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_GetWater_ML)^080h,f
	skipnc
	incf	(_GetWater_ML+1)^080h,f
	line	1364
	
l10855:	
;main.c: 1364: if(GetWater_ML>=(11*10)){
	movlw	0
	subwf	(_GetWater_ML+1)^080h,w
	movlw	06Eh
	skipnz
	subwf	(_GetWater_ML)^080h,w
	skipc
	goto	u10181
	goto	u10180
u10181:
	goto	l10867
u10180:
	line	1365
	
l10857:	
;main.c: 1365: GetWater_ML=0;
	clrf	(_GetWater_ML)^080h
	clrf	(_GetWater_ML+1)^080h
	line	1366
	
l10859:	
;main.c: 1366: if(FilterROGetWater<0xfff0)
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_FilterROGetWater+1),w
	movlw	0F0h
	skipnz
	subwf	(_FilterROGetWater),w
	skipnc
	goto	u10191
	goto	u10190
u10191:
	goto	l1245
u10190:
	line	1367
	
l10861:	
;main.c: 1367: FilterROGetWater+=11;
	movlw	0Bh
	addwf	(_FilterROGetWater),f
	skipnc
	incf	(_FilterROGetWater+1),f
	
l1245:	
	line	1368
;main.c: 1368: if(FilterPCFGetWater<0xfff0)
	movlw	0FFh
	subwf	(_FilterPCFGetWater+1),w
	movlw	0F0h
	skipnz
	subwf	(_FilterPCFGetWater),w
	skipnc
	goto	u10201
	goto	u10200
u10201:
	goto	l10865
u10200:
	line	1369
	
l10863:	
;main.c: 1369: FilterPCFGetWater+=11;
	movlw	0Bh
	addwf	(_FilterPCFGetWater),f
	skipnc
	incf	(_FilterPCFGetWater+1),f
	line	1370
	
l10865:	
;main.c: 1370: WrterEEP();
	fcall	_WrterEEP
	line	1380
	
l10867:	
;main.c: 1371: }
;main.c: 1373: }
;main.c: 1379: if((FilterROGetWater>=(11*2))
;main.c: 1380: &&(FilterPCFGetWater>=(11*2))){
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_FilterROGetWater+1),w
	movlw	016h
	skipnz
	subwf	(_FilterROGetWater),w
	skipc
	goto	u10211
	goto	u10210
u10211:
	goto	l10873
u10210:
	
l10869:	
	movlw	0
	subwf	(_FilterPCFGetWater+1),w
	movlw	016h
	skipnz
	subwf	(_FilterPCFGetWater),w
	skipc
	goto	u10221
	goto	u10220
u10221:
	goto	l10873
u10220:
	line	1382
	
l10871:	
;main.c: 1382: _BITS1.Bits.bit_7=1;
	bsf	(__BITS1),7
	line	1384
	
l10873:	
;main.c: 1383: }
;main.c: 1384: if(Read_Word_Buff[11]!=0)
	bsf	status, 5	;RP0=1, select bank1
	movf	(0+(_Read_Word_Buff)^080h+0Bh),w
	btfsc	status,2
	goto	u10231
	goto	u10230
u10231:
	goto	l1249
u10230:
	line	1385
	
l10875:	
;main.c: 1385: Read_Word_Buff[11]=2;
	movlw	low(02h)
	movwf	0+(_Read_Word_Buff)^080h+0Bh
	line	1387
	
l1249:	
	return
	opt stack 0
GLOBAL	__end_of_GetMode_Handle
	__end_of_GetMode_Handle:
	signat	_GetMode_Handle,89
	global	_FactoryMode_Handle

;; *************** function _FactoryMode_Handle *****************
;; Defined at:
;;		line 1465 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  Step            1    3[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       1       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       1       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    8
;; This function calls:
;;		_AllLedFlash
;;		_BuzzerSet
;;		_LedSetSt
;;		_Time_Count_Func
;; This function is called by:
;;		_Run_Mode
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	1465
global __ptext8
__ptext8:	;psect for function _FactoryMode_Handle
psect	text8
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	1465
	global	__size_of_FactoryMode_Handle
	__size_of_FactoryMode_Handle	equ	__end_of_FactoryMode_Handle-_FactoryMode_Handle
	
_FactoryMode_Handle:	
;incstack = 0
	opt	stack 2
; Regs used in _FactoryMode_Handle: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1466
	
l10877:	
;main.c: 1466: U8_T Step=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(FactoryMode_Handle@Step)^080h
	line	1467
;main.c: 1467: Timer_Power_100ms=0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_Timer_Power_100ms)
	line	1468
	
l10879:	
;main.c: 1468: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1469
;main.c: 1469: while(1){
	
l1272:	
	line	1470
# 1470 "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text8
	line	1471
	
l10881:	
;main.c: 1471: _BITS.Bits.bit_5=0x01;
	bsf	(__BITS),5
	line	1472
;main.c: 1472: switch(Step){
	goto	l10953
	line	1477
	
l10883:	
;main.c: 1477: LedSetSt(1, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(01h)
	fcall	_LedSetSt
	line	1492
	
l10885:	
;main.c: 1492: if(Timer_Power_100ms>=10){
	movlw	low(0Ah)
	subwf	(_Timer_Power_100ms),w
	skipc
	goto	u10241
	goto	u10240
u10241:
	goto	l10955
u10240:
	line	1494
	
l10887:	
;main.c: 1494: Step=1;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(FactoryMode_Handle@Step)^080h
	incf	(FactoryMode_Handle@Step)^080h,f
	goto	l10955
	line	1497
;main.c: 1497: case 1:
	
l1277:	
	line	1498
;main.c: 1498: RC2=1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(58/8),(58)&7	;volatile
	line	1499
;main.c: 1499: {RA2=1;_BITS2.Bits.bit_1=1;};
	bsf	(42/8),(42)&7	;volatile
	bsf	(__BITS2),1
	line	1500
;main.c: 1500: RC3=1;
	bsf	(59/8),(59)&7	;volatile
	line	1501
;main.c: 1501: RA1=1;
	bsf	(41/8),(41)&7	;volatile
	line	1502
	
l10889:	
;main.c: 1502: if(KeyPacket_y[1].KeyState==ShortRelease)
		movlw	6
	xorwf	(0+(_KeyPacket_y)+03h),w
	btfss	status,2
	goto	u10251
	goto	u10250
u10251:
	goto	l10955
u10250:
	line	1504
	
l10891:	
;main.c: 1503: {
;main.c: 1504: KeyPacket_y[1].KeyState=NotPress;
	clrf	0+(_KeyPacket_y)+03h
	line	1505
	
l10893:	
;main.c: 1505: RC2=0;
	bcf	(58/8),(58)&7	;volatile
	line	1506
	
l10895:	
;main.c: 1506: {RA2=0;_BITS2.Bits.bit_1=0;};
	bcf	(42/8),(42)&7	;volatile
	
l10897:	
	bcf	(__BITS2),1
	line	1507
	
l10899:	
;main.c: 1507: RC3=0;
	bcf	(59/8),(59)&7	;volatile
	line	1508
	
l10901:	
;main.c: 1508: RA1=0;
	bcf	(41/8),(41)&7	;volatile
	line	1509
	
l10903:	
;main.c: 1509: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1510
	
l10905:	
;main.c: 1510: Step=2;
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(FactoryMode_Handle@Step)^080h
	line	1511
	
l10907:	
;main.c: 1511: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	goto	l10955
	line	1515
	
l10909:	
;main.c: 1515: if(KeyPacket_y[0].KeyState==NotPress)
	bcf	status, 5	;RP0=0, select bank0
	movf	((_KeyPacket_y)),w
	btfss	status,2
	goto	u10261
	goto	u10260
u10261:
	goto	l10913
u10260:
	line	1517
	
l10911:	
;main.c: 1516: {
;main.c: 1517: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1518
;main.c: 1518: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1519
;main.c: 1519: LedSetSt(0, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(0)
	fcall	_LedSetSt
	line	1520
;main.c: 1520: }
	goto	l10915
	line	1523
	
l10913:	
;main.c: 1521: else
;main.c: 1522: {
;main.c: 1523: LedSetSt(4, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(04h)
	fcall	_LedSetSt
	line	1524
;main.c: 1524: LedSetSt(2, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(02h)
	fcall	_LedSetSt
	line	1525
;main.c: 1525: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	line	1527
	
l10915:	
;main.c: 1526: }
;main.c: 1527: if(KeyPacket_y[2].KeyState==ShortRelease)
		movlw	6
	xorwf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u10271
	goto	u10270
u10271:
	goto	l10955
u10270:
	line	1529
	
l10917:	
;main.c: 1528: {
;main.c: 1529: KeyPacket_y[2].KeyState=NotPress;
	clrf	0+(_KeyPacket_y)+06h
	line	1530
	
l10919:	
;main.c: 1530: Step=3;
	movlw	low(03h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(FactoryMode_Handle@Step)^080h
	line	1531
	
l10921:	
;main.c: 1531: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1532
	
l10923:	
;main.c: 1532: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	goto	l10955
	line	1537
	
l10925:	
;main.c: 1537: if(PureTDSTyp.TdsData>10&&PureTDSTyp.TdsData<50){
	movlw	0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	1+(_PureTDSTyp)^0100h+0Fh,w
	movlw	0Bh
	skipnz
	subwf	0+(_PureTDSTyp)^0100h+0Fh,w
	skipc
	goto	u10281
	goto	u10280
u10281:
	goto	l10931
u10280:
	
l10927:	
	movlw	0
	subwf	1+(_PureTDSTyp)^0100h+0Fh,w
	movlw	032h
	skipnz
	subwf	0+(_PureTDSTyp)^0100h+0Fh,w
	skipnc
	goto	u10291
	goto	u10290
u10291:
	goto	l10931
u10290:
	line	1538
	
l10929:	
;main.c: 1538: LedSetSt(5, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(05h)
	fcall	_LedSetSt
	line	1539
;main.c: 1539: LedSetSt(3, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(03h)
	fcall	_LedSetSt
	line	1540
;main.c: 1540: LedSetSt(1, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(01h)
	fcall	_LedSetSt
	line	1541
;main.c: 1541: }
	goto	l10933
	line	1544
	
l10931:	
;main.c: 1542: else
;main.c: 1543: {
;main.c: 1544: LedSetSt(4, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(04h)
	fcall	_LedSetSt
	line	1545
;main.c: 1545: LedSetSt(2, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(02h)
	fcall	_LedSetSt
	line	1546
;main.c: 1546: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	line	1548
	
l10933:	
;main.c: 1547: }
;main.c: 1548: if(KeyPacket_y[2].KeyState==ShortPressDown)
		decf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u10301
	goto	u10300
u10301:
	goto	l10955
u10300:
	line	1550
	
l10935:	
;main.c: 1549: {
;main.c: 1550: KeyPacket_y[2].KeyState=NotPress;
	clrf	0+(_KeyPacket_y)+06h
	line	1551
	
l10937:	
;main.c: 1551: Step=4;
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(FactoryMode_Handle@Step)^080h
	line	1552
	
l10939:	
;main.c: 1552: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1553
	
l10941:	
;main.c: 1553: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	goto	l10955
	line	1557
	
l10943:	
;main.c: 1557: if(Temp_Ntc>15&&PureTDSTyp.TdsData<45){
	movlw	low(010h)
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_Temp_Ntc),w
	skipc
	goto	u10311
	goto	u10310
u10311:
	goto	l10949
u10310:
	
l10945:	
	movlw	0
	bsf	status, 6	;RP1=1, select bank2
	subwf	1+(_PureTDSTyp)^0100h+0Fh,w
	movlw	02Dh
	skipnz
	subwf	0+(_PureTDSTyp)^0100h+0Fh,w
	skipnc
	goto	u10321
	goto	u10320
u10321:
	goto	l10949
u10320:
	line	1559
	
l10947:	
;main.c: 1559: LedSetSt(1, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(01h)
	fcall	_LedSetSt
	line	1560
;main.c: 1560: }
	goto	l10955
	line	1563
	
l10949:	
;main.c: 1561: else
;main.c: 1562: {
;main.c: 1563: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	goto	l10955
	line	1472
	
l10953:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(FactoryMode_Handle@Step)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 5, Range of values is 0 to 4
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           16     9 (average)
; direct_byte           23     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l10883
	xorlw	1^0	; case 1
	skipnz
	goto	l1277
	xorlw	2^1	; case 2
	skipnz
	goto	l10909
	xorlw	3^2	; case 3
	skipnz
	goto	l10925
	xorlw	4^3	; case 4
	skipnz
	goto	l10943
	goto	l10955
	opt asmopt_pop

	line	1567
	
l10955:	
;main.c: 1567: Time_Count_Func();
	fcall	_Time_Count_Func
	goto	l1272
	return
	opt stack 0
	line	1571
GLOBAL	__end_of_FactoryMode_Handle
	__end_of_FactoryMode_Handle:
	signat	_FactoryMode_Handle,89
	global	_Time_Count_Func

;; *************** function _Time_Count_Func *****************
;; Defined at:
;;		line 604 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       3       0
;;      Totals:         0       0       3       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    7
;; This function calls:
;;		_AD_Testing
;;		_BuzzerSet
;;		_CheckKey
;;		_ErrorHandle
;;		_FilterKeyInputRest
;;		_FilterLifeFunc
;;		_GetDelayFilterFlag
;;		_Led_Handle
;;		_Page_ProgramData
;;		_SetStandbyState
;;		_TDS_Handle
;;		_TaskAlarmHandle
;;		_Tx_Display
;;		___CMS_CheckTouchKey
;; This function is called by:
;;		_FactoryMode_Handle
;;		_main
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	604
global __ptext9
__ptext9:	;psect for function _Time_Count_Func
psect	text9
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	604
	global	__size_of_Time_Count_Func
	__size_of_Time_Count_Func	equ	__end_of_Time_Count_Func-_Time_Count_Func
	
_Time_Count_Func:	
;incstack = 0
	opt	stack 4
; Regs used in _Time_Count_Func: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	606
	
l10701:	
;main.c: 606: if(_BITS2.Bits.bit_0){
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(__BITS2),0
	goto	u9951
	goto	u9950
u9951:
	goto	l1108
u9950:
	line	607
	
l10703:	
;main.c: 607: _BITS2.Bits.bit_0=0;
	bcf	(__BITS2),0
	line	609
	
l10705:	
;main.c: 609: AD_Testing(1,15,0);
	movlw	low(0Fh)
	movwf	(AD_Testing@ad_ch)
	clrf	(AD_Testing@ad_lr)
	movlw	low(01h)
	fcall	_AD_Testing
	line	610
;main.c: 610: __CMS_CheckTouchKey();
	fcall	___CMS_CheckTouchKey
	line	611
	
l10707:	
;main.c: 611: CheckKey();
	fcall	_CheckKey
	line	613
	
l10709:	
;main.c: 613: if(Mode!=5)
		movlw	5
	xorwf	((_Mode)),w
	btfsc	status,2
	goto	u9961
	goto	u9960
u9961:
	goto	l10713
u9960:
	line	614
	
l10711:	
;main.c: 614: FilterLifeFunc();
	fcall	_FilterLifeFunc
	line	615
	
l10713:	
;main.c: 615: TaskAlarmHandle();
	fcall	_TaskAlarmHandle
	line	616
	
l10715:	
;main.c: 616: Led_Handle();
	fcall	_Led_Handle
	line	620
	
l10717:	
;main.c: 620: FilterKeyInputRest();
	fcall	_FilterKeyInputRest
	line	621
	
l10719:	
;main.c: 621: Time_100ms++;
	bcf	status, 5	;RP0=0, select bank0
	incf	(_Time_100ms),f
	line	622
	
l10721:	
;main.c: 622: if(Time_100ms>=10){
	movlw	low(0Ah)
	subwf	(_Time_100ms),w
	skipc
	goto	u9971
	goto	u9970
u9971:
	goto	l1108
u9970:
	line	623
	
l10723:	
;main.c: 623: Time_100ms=0;
	clrf	(_Time_100ms)
	line	624
	
l10725:	
;main.c: 624: Timer_Power_100ms++;
	incf	(_Timer_Power_100ms),f
	line	626
	
l10727:	
;main.c: 626: Time_1s++;
	incf	(_Time_1s),f
	line	627
	
l10729:	
;main.c: 627: if(Time_1s>=10){
	movlw	low(0Ah)
	subwf	(_Time_1s),w
	skipc
	goto	u9981
	goto	u9980
u9981:
	goto	l1108
u9980:
	line	628
	
l10731:	
;main.c: 628: Time_1s=0;
	clrf	(_Time_1s)
	line	629
	
l10733:	
;main.c: 629: if(Mode!=0){
	movf	((_Mode)),w
	btfsc	status,2
	goto	u9991
	goto	u9990
u9991:
	goto	l10737
u9990:
	line	630
	
l10735:	
;main.c: 630: Tx_Display();
	fcall	_Tx_Display
	line	632
	
l10737:	
;main.c: 631: }
;main.c: 632: if(Mode!=0)
	movf	((_Mode)),w
	btfsc	status,2
	goto	u10001
	goto	u10000
u10001:
	goto	l10741
u10000:
	line	633
	
l10739:	
;main.c: 633: ErrorHandle();
	fcall	_ErrorHandle
	line	635
	
l10741:	
;main.c: 635: if(Time_Power_1s<0xf0)
	movlw	low(0F0h)
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_Time_Power_1s),w
	skipnc
	goto	u10011
	goto	u10010
u10011:
	goto	l10745
u10010:
	line	636
	
l10743:	
;main.c: 636: Time_Power_1s++;
	incf	(_Time_Power_1s),f
	line	637
	
l10745:	
;main.c: 637: if(_BITS.Bits.bit_4==1){
	btfss	(__BITS),4
	goto	u10021
	goto	u10020
u10021:
	goto	l10751
u10020:
	line	638
	
l10747:	
;main.c: 638: _BITS.Bits.bit_4=0;
	bcf	(__BITS),4
	line	639
	
l10749:	
;main.c: 639: Page_ProgramData();
	fcall	_Page_ProgramData
	line	641
	
l10751:	
;main.c: 640: }
;main.c: 641: if(FilterRst_1s<0xfff0)
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_FilterRst_1s+1)^080h,w
	movlw	0F0h
	skipnz
	subwf	(_FilterRst_1s)^080h,w
	skipnc
	goto	u10031
	goto	u10030
u10031:
	goto	l10755
u10030:
	line	642
	
l10753:	
;main.c: 642: FilterRst_1s++;
	incf	(_FilterRst_1s)^080h,f
	skipnz
	incf	(_FilterRst_1s+1)^080h,f
	line	645
	
l10755:	
;main.c: 645: if(_BITS2.Bits.bit_1==1){
	bcf	status, 5	;RP0=0, select bank0
	btfss	(__BITS2),1
	goto	u10041
	goto	u10040
u10041:
	goto	l10759
u10040:
	line	646
	
l10757:	
;main.c: 646: Timer_LongGetWater_1s++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_Timer_LongGetWater_1s)^080h,f
	skipnz
	incf	(_Timer_LongGetWater_1s+1)^080h,f
	line	647
;main.c: 647: }
	goto	l10761
	line	650
	
l10759:	
;main.c: 648: else
;main.c: 649: {
;main.c: 650: Timer_LongGetWater_1s=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_Timer_LongGetWater_1s)^080h
	clrf	(_Timer_LongGetWater_1s+1)^080h
	line	653
	
l10761:	
;main.c: 651: }
;main.c: 653: if(_BITS.Bits.bit_5==0x01){
	btfss	(__BITS),5
	goto	u10051
	goto	u10050
u10051:
	goto	l10795
u10050:
	line	654
	
l10763:	
;main.c: 654: _BITS1.Bits.bit_4=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(__BITS1),4
	line	655
;main.c: 655: _BITS1.Bits.bit_6=0;
	bcf	(__BITS1),6
	line	656
;main.c: 656: _BITS2.Bits.bit_2=0;
	bcf	(__BITS2),2
	line	657
	
l10765:	
;main.c: 657: Time_GetWater_1s++;
	incf	(_Time_GetWater_1s),f
	line	658
	
l10767:	
;main.c: 658: Timer_Standby_1s=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_Timer_Standby_1s)^080h
	clrf	(_Timer_Standby_1s+1)^080h
	line	659
	
l10769:	
;main.c: 659: Timer_BackT_1H=0;
	clrf	(_Timer_BackT_1H)^080h
	clrf	(_Timer_BackT_1H+1)^080h
	line	661
	
l10771:	
;main.c: 661: if(FilterFastCheck==1){
	bcf	status, 5	;RP0=0, select bank0
		decf	((_FilterFastCheck)),w
	btfss	status,2
	goto	u10061
	goto	u10060
u10061:
	goto	l10775
u10060:
	line	662
	
l10773:	
;main.c: 662: FilterROGetWater+=11;
	movlw	0Bh
	addwf	(_FilterROGetWater),f
	skipnc
	incf	(_FilterROGetWater+1),f
	line	663
;main.c: 663: FilterPCFGetWater+=11;
	movlw	0Bh
	addwf	(_FilterPCFGetWater),f
	skipnc
	incf	(_FilterPCFGetWater+1),f
	line	666
	
l10775:	
;main.c: 664: }
;main.c: 666: Time_made_1s++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_Time_made_1s)^080h,f
	skipnz
	incf	(_Time_made_1s+1)^080h,f
	line	667
	
l10777:	
;main.c: 667: RA0=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(40/8),(40)&7	;volatile
	line	674
;main.c: 674: if(++Timer_TdsMake_1s>=60){
	movlw	low(03Ch)
	incf	(_Timer_TdsMake_1s),f
	subwf	((_Timer_TdsMake_1s)),w
	skipc
	goto	u10071
	goto	u10070
u10071:
	goto	l10781
u10070:
	line	675
	
l10779:	
;main.c: 675: _BITS.Bits.bit_6=1;
	bsf	(__BITS),6
	line	678
	
l10781:	
;main.c: 676: }
;main.c: 678: TDS_Handle(&PureTDSTyp,1);
	clrf	(TDS_Handle@Type)
	incf	(TDS_Handle@Type),f
	movlw	(low(_PureTDSTyp|((0x1)<<8)))&0ffh
	fcall	_TDS_Handle
	line	683
	
l10783:	
;main.c: 683: if((FilterROState==3)||(FilterPCFState==3)){
		movlw	3
	xorwf	((_FilterROState)),w
	btfsc	status,2
	goto	u10081
	goto	u10080
u10081:
	goto	l10787
u10080:
	
l10785:	
		movlw	3
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u10091
	goto	u10090
u10091:
	goto	l1102
u10090:
	line	684
	
l10787:	
;main.c: 684: FilterBuzzer_1s++;
	incf	(_FilterBuzzer_1s),f
	line	685
	
l10789:	
;main.c: 685: if(FilterBuzzer_1s>=2){
	movlw	low(02h)
	subwf	(_FilterBuzzer_1s),w
	skipc
	goto	u10101
	goto	u10100
u10101:
	goto	l1102
u10100:
	line	686
	
l10791:	
;main.c: 686: FilterBuzzer_1s=0;
	clrf	(_FilterBuzzer_1s)
	line	687
	
l10793:	
;main.c: 687: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	goto	l1102
	line	693
	
l10795:	
;main.c: 691: else
;main.c: 692: {
;main.c: 693: FilterBuzzer_1s=0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_FilterBuzzer_1s)
	line	695
	
l10797:	
;main.c: 695: if((Time_made_1s>=300)&&(Mode!=3)){
	movlw	01h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Time_made_1s+1)^080h,w
	movlw	02Ch
	skipnz
	subwf	(_Time_made_1s)^080h,w
	skipc
	goto	u10111
	goto	u10110
u10111:
	goto	l10813
u10110:
	
l10799:	
		movlw	3
	xorwf	((_Mode)),w
	btfsc	status,2
	goto	u10121
	goto	u10120
u10121:
	goto	l10813
u10120:
	line	696
	
l10801:	
;main.c: 696: Time_made_1s=0;
	clrf	(_Time_made_1s)^080h
	clrf	(_Time_made_1s+1)^080h
	line	697
	
l10803:	
;main.c: 697: if(StandByStatus!=WashState){
	bcf	status, 5	;RP0=0, select bank0
		decf	((_StandByStatus)),w
	btfsc	status,2
	goto	u10131
	goto	u10130
u10131:
	goto	l10807
u10130:
	line	698
	
l10805:	
;main.c: 698: SetStandbyState(WashState,&WashRunTime, 6);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(06h)
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	line	699
;main.c: 699: }
	goto	l10813
	line	702
	
l10807:	
;main.c: 700: else
;main.c: 701: {
;main.c: 702: if(StandByStatus!=BackState){
		movlw	3
	xorwf	((_StandByStatus)),w
	btfsc	status,2
	goto	u10141
	goto	u10140
u10141:
	goto	l10813
u10140:
	line	703
	
l10809:	
;main.c: 703: if(WashRunTime-Timer_WashRun_1s<6){
	movf	(_WashRunTime),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(??_Time_Count_Func+0)^080h+0
	movf	(_Timer_WashRun_1s)^080h,w
	subwf	(??_Time_Count_Func+0)^080h+0,w
	movwf	(??_Time_Count_Func+1)^080h+0
	comf	(_Timer_WashRun_1s+1)^080h,w
	skipnc
	addlw	1
	movwf	((??_Time_Count_Func+1)^080h+0)+1
	movlw	0
	subwf	1+(??_Time_Count_Func+1)^080h+0,w
	movlw	06h
	skipnz
	subwf	0+(??_Time_Count_Func+1)^080h+0,w
	skipnc
	goto	u10151
	goto	u10150
u10151:
	goto	l1105
u10150:
	line	704
	
l10811:	
;main.c: 704: SetStandbyState(WashState,&WashRunTime, 6);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(06h)
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	goto	l10813
	line	707
	
l1105:	
	line	710
	
l10813:	
;main.c: 705: }
;main.c: 706: }
;main.c: 707: }
;main.c: 708: }
;main.c: 710: RA0=1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(40/8),(40)&7	;volatile
	line	711
	
l10815:	
;main.c: 711: _BITS.Bits.bit_6=0;
	bcf	(__BITS),6
	line	712
	
l10817:	
;main.c: 712: TdsCk60sFlag=0;
	clrf	(_TdsCk60sFlag)
	line	713
	
l10819:	
;main.c: 713: Timer_TdsMake_1s=0;
	clrf	(_Timer_TdsMake_1s)
	line	714
	
l10821:	
;main.c: 714: Timer_WashRun_1s++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_Timer_WashRun_1s)^080h,f
	skipnz
	incf	(_Timer_WashRun_1s+1)^080h,f
	line	716
	
l10823:	
;main.c: 716: Timer_Standby_1s++;
	incf	(_Timer_Standby_1s)^080h,f
	skipnz
	incf	(_Timer_Standby_1s+1)^080h,f
	line	718
	
l1102:	
	line	724
;main.c: 718: }
;main.c: 724: GetDelayFilterFlag(&FilterPCF_time);
	movlw	(low(_FilterPCF_time|((0x0)<<8)))&0ffh
	fcall	_GetDelayFilterFlag
	line	725
;main.c: 725: GetDelayFilterFlag(&FilterRO_time);
	movlw	(low(_FilterRO_time|((0x0)<<8)))&0ffh
	fcall	_GetDelayFilterFlag
	line	732
	
l1108:	
	return
	opt stack 0
GLOBAL	__end_of_Time_Count_Func
	__end_of_Time_Count_Func:
	signat	_Time_Count_Func,89
	global	___CMS_CheckTouchKey

;; *************** function ___CMS_CheckTouchKey *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1074            1    0        unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		___CMS_CheckKeyOldValue
;;		___CMS_CheckOnceResult
;;		___CMS_CheckValidTime
;;		___CMS_CurAdjust
;;		___CMS_KeyDatIIR
;;		___CMS_KeyModeSet
;;		___CMS_KeyStart
;;		___CMS_KeyStopClear
;;		___CMS_Key_UNNOL_Check
;;		___CMS_NewRAMClr
;;		___CMS_Noise_check
;;		___GET_32M_FREDAT
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=1
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
global __ptext10
__ptext10:	;psect for function ___CMS_CheckTouchKey
psect	text10
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CheckTouchKey
	__size_of___CMS_CheckTouchKey	equ	__end_of___CMS_CheckTouchKey-___CMS_CheckTouchKey
	
___CMS_CheckTouchKey:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CheckTouchKey: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	
l10297:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text10
	btfsc	(_924/8),(_924)&7	;volatile
	goto	u9291
	goto	u9290
u9291:
	goto	l10305
u9290:
	
l10299:	
	bsf	(_924/8),(_924)&7	;volatile
	
l10301:	
	fcall	___CMS_NewRAMClr
	
l10303:	
	fcall	___GET_32M_FREDAT
	
l10305:	
	btfsc	(_926/8),(_926)&7	;volatile
	goto	u9301
	goto	u9300
u9301:
	goto	l10309
u9300:
	
l10307:	
	fcall	___CMS_CurAdjust
	goto	l10361
	
l10309:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_918)),w	;volatile
	btfsc	status,2
	goto	u9311
	goto	u9310
u9311:
	goto	l10353
u9310:
	
l10311:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_CheckTouchKey@F1073)^080h
	
l10313:	
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	xorwf	((_918)),w	;volatile
	btfsc	status,2
	goto	u9321
	goto	u9320
u9321:
	goto	l10319
u9320:
	
l10315:	
	fcall	___CMS_KeyDatIIR
	
l10317:	
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_918)	;volatile
	goto	l10361
	
l10319:	
	fcall	___CMS_Noise_check
	
l10321:	
	fcall	___CMS_CheckKeyOldValue
	
l10323:	
	fcall	___CMS_CheckOnceResult
	
l10325:	
	movlw	low(08h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_920),f	;volatile
	subwf	((_920)),w	;volatile
	skipc
	goto	u9331
	goto	u9330
u9331:
	goto	l10329
u9330:
	
l10327:	
	clrf	(_920)	;volatile
	
l10329:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u9341
	goto	u9340
u9341:
	goto	l10333
u9340:
	
l10331:	
	movf	(_920),w
	addlw	low(((_sc_FreScanTable)|8000h))
	movwf	fsr0
	movlw	high(((_sc_FreScanTable)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(_921)	;volatile
	goto	l10335
	
l10333:	
	movf	(_920),w
	addlw	low(((_sc_FreScanTable1)|8000h))
	movwf	fsr0
	movlw	high(((_sc_FreScanTable1)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(_921)	;volatile
	
l10335:	
	btfsc	(_gf_kerr/8),(_gf_kerr)&7	;volatile
	goto	u9351
	goto	u9350
u9351:
	goto	l10339
u9350:
	
l10337:	
	movlw	low(03h)
	subwf	(_917),w	;volatile
	skipc
	goto	u9361
	goto	u9360
u9361:
	goto	l10343
u9360:
	
l10339:	
	fcall	___CMS_KeyStopClear
	
l10341:	
	bcf	(_gf_kerr/8),(_gf_kerr)&7	;volatile
	
l10343:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_917)	;volatile
	
l10345:	
	fcall	___CMS_Key_UNNOL_Check
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_918)	;volatile
	
l10347:	
	btfss	(_926/8),(_926)&7	;volatile
	goto	u9371
	goto	u9370
u9371:
	goto	l3657
u9370:
	
l10349:	
	fcall	___CMS_KeyModeSet
	
l10351:	
	fcall	___CMS_KeyStart
	goto	l10361
	
l10353:	
	movlw	low(0FAh)
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_CheckTouchKey@F1073)^080h,f
	subwf	((___CMS_CheckTouchKey@F1073)^080h),w
	skipc
	goto	u9381
	goto	u9380
u9381:
	goto	l10361
u9380:
	
l10355:	
	clrf	(___CMS_CheckTouchKey@F1073)^080h
	clrf	(_919)	;volatile
	goto	l10349
	
l3657:	
	
l10361:	
	fcall	___CMS_CheckValidTime
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text10
	
l3659:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CheckTouchKey
	__end_of___CMS_CheckTouchKey:
	signat	___CMS_CheckTouchKey,89
	global	___GET_32M_FREDAT

;; *************** function ___GET_32M_FREDAT *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=1
global __ptext11
__ptext11:	;psect for function ___GET_32M_FREDAT
psect	text11
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___GET_32M_FREDAT
	__size_of___GET_32M_FREDAT	equ	__end_of___GET_32M_FREDAT-___GET_32M_FREDAT
	
___GET_32M_FREDAT:	
;incstack = 0
	opt	stack 6
; Regs used in ___GET_32M_FREDAT: [wreg+status,2+status,0]
	
l10025:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text11
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	bsf	(404)^0180h+(0/8),(0)&7	;volatile
	
l10027:	
	movf	(404)^0180h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_916)	;volatile
	
l10029:	
	movlw	low(070h)
	andwf	(_916),f	;volatile
	
l10031:	
	movlw	low(061h)
	subwf	(_916),w	;volatile
	skipc
	goto	u8771
	goto	u8770
u8771:
	goto	l10035
u8770:
	
l10033:	
	movlw	low(060h)
	movwf	(_916)	;volatile
	goto	l3614
	
l10035:	
	movlw	low(010h)
	subwf	(_916),w	;volatile
	skipnc
	goto	u8781
	goto	u8780
u8781:
	goto	l3614
u8780:
	
l10037:	
	movlw	low(010h)
	movwf	(_916)	;volatile
	
l3614:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text11
	
l3616:	
	return
	opt stack 0
GLOBAL	__end_of___GET_32M_FREDAT
	__end_of___GET_32M_FREDAT:
	signat	___GET_32M_FREDAT,89
	global	___CMS_Noise_check

;; *************** function ___CMS_Noise_check *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  973             2    9[BANK0 ] unsigned short 
;;  975             2    7[BANK0 ] unsigned short 
;;  974             2    3[BANK0 ] unsigned short 
;;  970             1   11[BANK0 ] unsigned char 
;;  972             1    6[BANK0 ] unsigned char 
;;  971             1    5[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       9       0       0
;;      Temps:          0       3       0       0
;;      Totals:         0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=1
global __ptext12
__ptext12:	;psect for function ___CMS_Noise_check
psect	text12
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_Noise_check
	__size_of___CMS_Noise_check	equ	__end_of___CMS_Noise_check-___CMS_Noise_check
	
___CMS_Noise_check:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_Noise_check: [wreg-fsr0h+status,2+status,0]
	
l9481:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text12
	
l9483:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_Noise_check@970)
	clrf	(___CMS_Noise_check@971)
	clrf	(___CMS_Noise_check@972)
	clrf	(___CMS_Noise_check@973)
	clrf	(___CMS_Noise_check@973+1)
	
l9485:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9487:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_Noise_check@970),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_Noise_check@974)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_Noise_check@974+1)
	
l9489:	
	movf	((_921)),w	;volatile
	btfsc	status,2
	goto	u7941
	goto	u7940
u7941:
	goto	l9495
u7940:
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
	
l9491:	
	clrc
	rlf	(___CMS_Noise_check@970),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_Noise_check@975)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_Noise_check@975+1)
	
l9493:	
	movlw	04Bh
	addwf	(___CMS_Noise_check@975),f
	skipnc
	incf	(___CMS_Noise_check@975+1),f
	line	1
	goto	l9499
	line	114
	
l9495:	
	clrc
	rlf	(___CMS_Noise_check@970),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_Noise_check@975)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_Noise_check@975+1)
	
l9497:	
	movlw	064h
	addwf	(___CMS_Noise_check@975),f
	skipnc
	incf	(___CMS_Noise_check@975+1),f
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9499:	
	movf	(___CMS_Noise_check@974+1),w
	subwf	(___CMS_Noise_check@975+1),w
	skipz
	goto	u7955
	movf	(___CMS_Noise_check@974),w
	subwf	(___CMS_Noise_check@975),w
u7955:
	skipnc
	goto	u7951
	goto	u7950
u7951:
	goto	l9505
u7950:
	
l9501:	
	incf	(___CMS_Noise_check@970),w
	movwf	(??___CMS_Noise_check+0)+0
	movlw	01h
	movwf	(??___CMS_Noise_check+1)+0
	movlw	0
	movwf	(??___CMS_Noise_check+1)+0+1
	goto	u7964
u7965:
	clrc
	rlf	(??___CMS_Noise_check+1)+0,f
	rlf	(??___CMS_Noise_check+1)+1,f
u7964:
	decfsz	(??___CMS_Noise_check+0)+0,f
	goto	u7965
	
	movf	0+(??___CMS_Noise_check+1)+0,w
	iorwf	(___CMS_Noise_check@973),f
	movf	1+(??___CMS_Noise_check+1)+0,w
	iorwf	(___CMS_Noise_check@973+1),f
	
l9503:	
	incf	(___CMS_Noise_check@971),f
	
l9505:	
	movlw	low(02h)
	incf	(___CMS_Noise_check@970),f
	subwf	((___CMS_Noise_check@970)),w
	skipc
	goto	u7971
	goto	u7970
u7971:
	goto	l9485
u7970:
	
l9507:	
	movlw	low(02h)
	subwf	(___CMS_Noise_check@971),w
	skipc
	goto	u7981
	goto	u7980
u7981:
	goto	l9519
u7980:
	
l9509:	
	clrf	(___CMS_Noise_check@972)
	incf	(___CMS_Noise_check@972),f
	
l9511:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_Noise_check@F967)^080h
	
l9513:	
	movlw	low(02h)
	incf	(___CMS_Noise_check@F966)^080h,f
	subwf	((___CMS_Noise_check@F966)^080h),w
	skipc
	goto	u7991
	goto	u7990
u7991:
	goto	l9523
u7990:
	
l9515:	
	clrf	(___CMS_Noise_check@F966)^080h
	
l9517:	
	bsf	(_925/8),(_925)&7	;volatile
	goto	l9523
	
l9519:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Noise_check@F967)^080h,f
	subwf	((___CMS_Noise_check@F967)^080h),w
	skipc
	goto	u8001
	goto	u8000
u8001:
	goto	l9523
u8000:
	
l9521:	
	clrf	(___CMS_Noise_check@F967)^080h
	clrf	(___CMS_Noise_check@F966)^080h
	
l9523:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___CMS_Noise_check@973),w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(___CMS_Noise_check@F969)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??___CMS_Noise_check+0)+0
	movf	(___CMS_Noise_check@973+1),w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(___CMS_Noise_check@F969+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??___CMS_Noise_check+0)+0
	movf	((??___CMS_Noise_check+0)+0),w
iorwf	((??___CMS_Noise_check+0)+1),w
	btfsc	status,2
	goto	u8011
	goto	u8010
u8011:
	goto	l9535
u8010:
	
l9525:	
	clrf	(___CMS_Noise_check@972)
	incf	(___CMS_Noise_check@972),f
	
l9527:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_Noise_check@F965)^080h
	
l9529:	
	movlw	low(02h)
	incf	(___CMS_Noise_check@F964)^080h,f
	subwf	((___CMS_Noise_check@F964)^080h),w
	skipc
	goto	u8021
	goto	u8020
u8021:
	goto	l9539
u8020:
	
l9531:	
	clrf	(___CMS_Noise_check@F964)^080h
	
l9533:	
	bsf	(_925/8),(_925)&7	;volatile
	goto	l9539
	
l9535:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Noise_check@F965)^080h,f
	subwf	((___CMS_Noise_check@F965)^080h),w
	skipc
	goto	u8031
	goto	u8030
u8031:
	goto	l9539
u8030:
	
l9537:	
	clrf	(___CMS_Noise_check@F965)^080h
	clrf	(___CMS_Noise_check@F964)^080h
	
l9539:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___CMS_Noise_check@973+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___CMS_Noise_check@F969+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___CMS_Noise_check@973),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___CMS_Noise_check@F969)^080h
	
l9541:	
	btfss	(_925/8),(_925)&7	;volatile
	goto	u8041
	goto	u8040
u8041:
	goto	l9561
u8040:
	
l9543:	
	bcf	status, 5	;RP0=0, select bank0
	movf	((___CMS_Noise_check@972)),w
	btfss	status,2
	goto	u8051
	goto	u8050
u8051:
	goto	l9561
u8050:
	
l9545:	
	movf	((_g_KeyFlag)),w	;volatile
	btfss	status,2
	goto	u8061
	goto	u8060
u8061:
	goto	l9555
u8060:
	
l9547:	
	movf	(0+(_g_KeyFlag)+01h),w	;volatile
	btfss	status,2
	goto	u8071
	goto	u8070
u8071:
	goto	l9555
u8070:
	
l9549:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Noise_check@F968)^080h,f
	skipnz
	incf	(___CMS_Noise_check@F968+1)^080h,f
	movlw	0
	subwf	((___CMS_Noise_check@F968+1)^080h),w
	movlw	064h
	skipnz
	subwf	((___CMS_Noise_check@F968)^080h),w
	skipc
	goto	u8081
	goto	u8080
u8081:
	goto	l3446
u8080:
	
l9551:	
	clrf	(___CMS_Noise_check@F968)^080h
	clrf	(___CMS_Noise_check@F968+1)^080h
	
l9553:	
	bcf	(_925/8),(_925)&7	;volatile
	goto	l3446
	
l9555:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Noise_check@F968)^080h,f
	skipnz
	incf	(___CMS_Noise_check@F968+1)^080h,f
	movlw	01h
	subwf	((___CMS_Noise_check@F968+1)^080h),w
	movlw	02Ch
	skipnz
	subwf	((___CMS_Noise_check@F968)^080h),w
	skipc
	goto	u8091
	goto	u8090
u8091:
	goto	l3446
u8090:
	goto	l9551
	
l9561:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_Noise_check@F968)^080h
	clrf	(___CMS_Noise_check@F968+1)^080h
	
l3446:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text12
	
l3447:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_Noise_check
	__end_of___CMS_Noise_check:
	signat	___CMS_Noise_check,89
	global	___CMS_NewRAMClr

;; *************** function ___CMS_NewRAMClr *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1051            1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=1
global __ptext13
__ptext13:	;psect for function ___CMS_NewRAMClr
psect	text13
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_NewRAMClr
	__size_of___CMS_NewRAMClr	equ	__end_of___CMS_NewRAMClr-___CMS_NewRAMClr
	
___CMS_NewRAMClr:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_NewRAMClr: [wreg-fsr0h+status,2+status,0]
	
l9999:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text13
	
l10001:	
	clrf	(___CMS_NewRAMClr@1051)
	
l10007:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10009:	
	movf	(___CMS_NewRAMClr@1051),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l10011:	
	movlw	low(02h)
	movwf	(415)^0180h	;volatile
	movf	(___CMS_NewRAMClr@1051),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l10013:	
	movlw	low(04h)
	movwf	(415)^0180h	;volatile
	
l10015:	
	movf	(___CMS_NewRAMClr@1051),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	movlw	low(08h)
	movwf	(415)^0180h	;volatile
	
l10017:	
	movf	(___CMS_NewRAMClr@1051),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l10019:	
	movlw	low(010h)
	movwf	(415)^0180h	;volatile
	movf	(___CMS_NewRAMClr@1051),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l10021:	
	incf	(___CMS_NewRAMClr@1051),f
	
l10023:	
	movlw	low(050h)
	subwf	(___CMS_NewRAMClr@1051),w
	skipc
	goto	u8761
	goto	u8760
u8761:
	goto	l10007
u8760:
	
l3609:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text13
	
l3610:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_NewRAMClr
	__end_of___CMS_NewRAMClr:
	signat	___CMS_NewRAMClr,89
	global	___CMS_Key_UNNOL_Check

;; *************** function ___CMS_Key_UNNOL_Check *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1017            1    1[BANK0 ] unsigned char 
;;  1018            1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       2       0       0
;;      Temps:          2       0       0       0
;;      Totals:         2       2       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=1
global __ptext14
__ptext14:	;psect for function ___CMS_Key_UNNOL_Check
psect	text14
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_Key_UNNOL_Check
	__size_of___CMS_Key_UNNOL_Check	equ	__end_of___CMS_Key_UNNOL_Check-___CMS_Key_UNNOL_Check
	
___CMS_Key_UNNOL_Check:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_Key_UNNOL_Check: [wreg-fsr0h+status,2+status,0]
	
l9809:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text14
	
l9811:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_Key_UNNOL_Check@1017)
	clrf	(___CMS_Key_UNNOL_Check@1018)
	
l9813:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u8461
	goto	u8460
u8461:
	goto	l3518
u8460:
	
l9815:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9817:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	movlw	0Ch
	subwf	1+(??___CMS_Key_UNNOL_Check+0)+0,w
	movlw	01h
	skipnz
	subwf	0+(??___CMS_Key_UNNOL_Check+0)+0,w
	skipnc
	goto	u8471
	goto	u8470
u8471:
	goto	l9821
u8470:
	
l9819:	
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	movlw	04h
	subwf	1+(??___CMS_Key_UNNOL_Check+0)+0,w
	movlw	0
	skipnz
	subwf	0+(??___CMS_Key_UNNOL_Check+0)+0,w
	skipnc
	goto	u8481
	goto	u8480
u8481:
	goto	l9825
u8480:
	
l9821:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Key_UNNOL_Check@F1016)^080h,f
	
l9823:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___CMS_Key_UNNOL_Check@1018)
	incf	(___CMS_Key_UNNOL_Check@1018),f
	
l9825:	
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	movlw	0Ch
	subwf	1+(??___CMS_Key_UNNOL_Check+0)+0,w
	movlw	01h
	skipnz
	subwf	0+(??___CMS_Key_UNNOL_Check+0)+0,w
	skipnc
	goto	u8491
	goto	u8490
u8491:
	goto	l9829
u8490:
	
l9827:	
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	movlw	04h
	subwf	1+(??___CMS_Key_UNNOL_Check+0)+0,w
	movlw	0
	skipnz
	subwf	0+(??___CMS_Key_UNNOL_Check+0)+0,w
	skipnc
	goto	u8501
	goto	u8500
u8501:
	goto	l9833
u8500:
	
l9829:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Key_UNNOL_Check@F1016)^080h,f
	
l9831:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___CMS_Key_UNNOL_Check@1018)
	incf	(___CMS_Key_UNNOL_Check@1018),f
	
l9833:	
	movlw	low(02h)
	incf	(___CMS_Key_UNNOL_Check@1017),f
	subwf	((___CMS_Key_UNNOL_Check@1017)),w
	skipc
	goto	u8511
	goto	u8510
u8511:
	goto	l9815
u8510:
	
l9835:	
	movf	((___CMS_Key_UNNOL_Check@1018)),w
	btfss	status,2
	goto	u8521
	goto	u8520
u8521:
	goto	l9839
u8520:
	
l9837:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_Key_UNNOL_Check@F1016)^080h
	goto	l3518
	
l9839:	
	movlw	low(0C8h)
	bsf	status, 5	;RP0=1, select bank1
	subwf	(___CMS_Key_UNNOL_Check@F1016)^080h,w
	skipc
	goto	u8531
	goto	u8530
u8531:
	goto	l3518
u8530:
	
l9841:	
	clrf	(___CMS_Key_UNNOL_Check@F1016)^080h
	
l9843:	
	bcf	(_926/8),(_926)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_920)	;volatile
	clrf	(_921)	;volatile
	
l9845:	
	bcf	(_927/8),(_927)&7	;volatile
	clrf	(___CMS_Key_UNNOL_Check@1017)
	
l9851:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9853:	
	movlw	0
	movwf	(??___CMS_Key_UNNOL_Check+0)+0
	movlw	0Ch
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_Key_UNNOL_Check+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_Key_UNNOL_Check+0)+1,w
	movwf	indf
	
l9855:	
	movlw	0
	movwf	(??___CMS_Key_UNNOL_Check+0)+0
	movlw	0Ch
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_Key_UNNOL_Check+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_Key_UNNOL_Check+0)+1,w
	movwf	indf
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9857:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l9859:	
	incf	(___CMS_Key_UNNOL_Check@1017),f
	
l9861:	
	movlw	low(02h)
	subwf	(___CMS_Key_UNNOL_Check@1017),w
	skipc
	goto	u8541
	goto	u8540
u8541:
	goto	l9851
u8540:
	
l9863:	
	clrf	(_g_KeyFlag)	;volatile
	clrf	0+(_g_KeyFlag)+01h	;volatile
	
l3518:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text14
	
l3532:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_Key_UNNOL_Check
	__end_of___CMS_Key_UNNOL_Check:
	signat	___CMS_Key_UNNOL_Check,89
	global	___CMS_KeyStopClear

;; *************** function ___CMS_KeyStopClear *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  961             1    1[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       1       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___CMS_KeyClearOne
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=1
global __ptext15
__ptext15:	;psect for function ___CMS_KeyStopClear
psect	text15
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyStopClear
	__size_of___CMS_KeyStopClear	equ	__end_of___CMS_KeyStopClear-___CMS_KeyStopClear
	
___CMS_KeyStopClear:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_KeyStopClear: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	
l9467:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text15
	
l9469:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_g_KeyFlag)	;volatile
	clrf	0+(_g_KeyFlag)+01h	;volatile
	clrf	(___CMS_KeyStopClear@961)
	
l9475:	
	movf	(___CMS_KeyStopClear@961),w
	fcall	___CMS_KeyClearOne
	
l9477:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(___CMS_KeyStopClear@961),f
	
l9479:	
	movlw	low(02h)
	subwf	(___CMS_KeyStopClear@961),w
	skipc
	goto	u7931
	goto	u7930
u7931:
	goto	l9475
u7930:
	
l3412:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text15
	
l3413:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyStopClear
	__end_of___CMS_KeyStopClear:
	signat	___CMS_KeyStopClear,89
	global	___CMS_KeyClearOne

;; *************** function ___CMS_KeyClearOne *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;  958             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  958             1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          2       0       0       0
;;      Totals:         2       1       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_KeyStopClear
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=1
global __ptext16
__ptext16:	;psect for function ___CMS_KeyClearOne
psect	text16
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyClearOne
	__size_of___CMS_KeyClearOne	equ	__end_of___CMS_KeyClearOne-___CMS_KeyClearOne
	
___CMS_KeyClearOne:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_KeyClearOne: [wreg-fsr0h+status,2+status,0]
;___CMS_KeyClearOne@958 stored from wreg
	movwf	(___CMS_KeyClearOne@958)
	
l8977:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text16
	
l8979:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l8981:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_KeyClearOne@958),w
	addlw	low(464|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l8983:	
	movf	(___CMS_KeyClearOne@958),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l8985:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyClearOne@958),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	
l8987:	
	clrc
	rlf	(___CMS_KeyClearOne@958),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l8989:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_KeyClearOne@958),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l8991:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_KeyClearOne@958),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l8993:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u7231
	goto	u7230
u7231:
	goto	l3407
u7230:
	
l8995:	
	movlw	0
	movwf	(??___CMS_KeyClearOne+0)+0
	movlw	0Ch
	movwf	(??___CMS_KeyClearOne+0)+0+1
	clrc
	rlf	(___CMS_KeyClearOne@958),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_KeyClearOne+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_KeyClearOne+0)+1,w
	movwf	indf
	movlw	0
	movwf	(??___CMS_KeyClearOne+0)+0
	movlw	0Ch
	movwf	(??___CMS_KeyClearOne+0)+0+1
	clrc
	rlf	(___CMS_KeyClearOne@958),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_KeyClearOne+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_KeyClearOne+0)+1,w
	movwf	indf
	
l3407:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text16
	
l3408:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyClearOne
	__end_of___CMS_KeyClearOne:
	signat	___CMS_KeyClearOne,4217
	global	___CMS_KeyDatIIR

;; *************** function ___CMS_KeyDatIIR *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1026            2    8[BANK0 ] unsigned short 
;;  1025            2    6[BANK0 ] unsigned short 
;;  1022            2    4[BANK0 ] unsigned short 
;;  1024            2    2[BANK0 ] unsigned short 
;;  1023            2    0[BANK0 ] unsigned short 
;;  1021            1   10[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0      11       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0      11       0       0
;;Total ram usage:       11 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=1
global __ptext17
__ptext17:	;psect for function ___CMS_KeyDatIIR
psect	text17
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyDatIIR
	__size_of___CMS_KeyDatIIR	equ	__end_of___CMS_KeyDatIIR-___CMS_KeyDatIIR
	
___CMS_KeyDatIIR:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_KeyDatIIR: [wreg-fsr0h+status,2+status,0]
	
l9865:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text17
	
l9867:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_KeyDatIIR@1021)
	
l9869:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9871:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1023)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1023+1)
	
l9873:	
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1024)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1024+1)
	
l9875:	
	movlw	low(08h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9877:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1022)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1022+1)
	
l9879:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9881:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u8551
	goto	u8550
u8551:
	goto	l9885
u8550:
	
l9883:	
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1025)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1025+1)
	goto	l9887
	
l9885:	
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1025)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1025+1)
	
l9887:	
	movf	((___CMS_KeyDatIIR@1022)),w
iorwf	((___CMS_KeyDatIIR@1022+1)),w
	btfsc	status,2
	goto	u8561
	goto	u8560
u8561:
	goto	l9911
u8560:
	
l9889:	
	movf	((___CMS_KeyDatIIR@1025)),w
iorwf	((___CMS_KeyDatIIR@1025+1)),w
	btfsc	status,2
	goto	u8571
	goto	u8570
u8571:
	goto	l9911
u8570:
	
l9891:	
	movf	(___CMS_KeyDatIIR@1025),w
	addwf	(___CMS_KeyDatIIR@1022),w
	movwf	(___CMS_KeyDatIIR@1026)
	movf	(___CMS_KeyDatIIR@1025+1),w
	skipnc
	incf	(___CMS_KeyDatIIR@1025+1),w
	addwf	(___CMS_KeyDatIIR@1022+1),w
	movwf	1+(___CMS_KeyDatIIR@1026)
	
l9893:	
	clrc
	rrf	(___CMS_KeyDatIIR@1026+1),f
	rrf	(___CMS_KeyDatIIR@1026),f
	movlw	low(08h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9895:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_KeyDatIIR@1026),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_KeyDatIIR@1026+1),w
	movwf	indf
	
l9897:	
	movf	(___CMS_KeyDatIIR@1025),w
	addwf	(___CMS_KeyDatIIR@1024),w
	movwf	(___CMS_KeyDatIIR@1026)
	movf	(___CMS_KeyDatIIR@1025+1),w
	skipnc
	incf	(___CMS_KeyDatIIR@1025+1),w
	addwf	(___CMS_KeyDatIIR@1024+1),w
	movwf	1+(___CMS_KeyDatIIR@1026)
	
l9899:	
	clrc
	rrf	(___CMS_KeyDatIIR@1026+1),f
	rrf	(___CMS_KeyDatIIR@1026),f
	
l9901:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9903:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_KeyDatIIR@1026),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_KeyDatIIR@1026+1),w
	movwf	indf
	
l9905:	
	movf	(___CMS_KeyDatIIR@1025),w
	addwf	(___CMS_KeyDatIIR@1023),w
	movwf	(___CMS_KeyDatIIR@1026)
	movf	(___CMS_KeyDatIIR@1025+1),w
	skipnc
	incf	(___CMS_KeyDatIIR@1025+1),w
	addwf	(___CMS_KeyDatIIR@1023+1),w
	movwf	1+(___CMS_KeyDatIIR@1026)
	clrc
	rrf	(___CMS_KeyDatIIR@1026+1),f
	rrf	(___CMS_KeyDatIIR@1026),f
	
l9907:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9909:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_KeyDatIIR@1026),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_KeyDatIIR@1026+1),w
	movwf	indf
	
l9911:	
	movlw	low(02h)
	incf	(___CMS_KeyDatIIR@1021),f
	subwf	((___CMS_KeyDatIIR@1021)),w
	skipc
	goto	u8581
	goto	u8580
u8581:
	goto	l9869
u8580:
	
l3535:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text17
	
l3541:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyDatIIR
	__end_of___CMS_KeyDatIIR:
	signat	___CMS_KeyDatIIR,89
	global	___CMS_CurAdjust

;; *************** function ___CMS_CurAdjust *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1047            2    4[BANK0 ] unsigned short 
;;  1045            1    3[BANK0 ] unsigned char 
;;  1046            1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       4       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0       6       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___CMS_CurAdjMode
;;		___CMS_CurJudge
;;		___CMS_KeyModeSet
;;		___CMS_KeyStart
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=1
global __ptext18
__ptext18:	;psect for function ___CMS_CurAdjust
psect	text18
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CurAdjust
	__size_of___CMS_CurAdjust	equ	__end_of___CMS_CurAdjust-___CMS_CurAdjust
	
___CMS_CurAdjust:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CurAdjust: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	
l9925:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text18
	
l9927:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_CurAdjust@1046)
	clrf	(___CMS_CurAdjust@1047)
	clrf	(___CMS_CurAdjust@1047+1)
	
l9929:	
	btfsc	(_927/8),(_927)&7	;volatile
	goto	u8611
	goto	u8610
u8611:
	goto	l9937
u8610:
	
l9931:	
	bsf	(_927/8),(_927)&7	;volatile
	
l9933:	
	fcall	___CMS_KeyModeSet
	
l9935:	
	fcall	___CMS_CurAdjMode
	goto	l3586
	
l9937:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9939:	
	btfsc	(402)^0180h,(7)&7	;volatile
	goto	u8621
	goto	u8620
u8621:
	goto	l9983
u8620:
	
l9941:	
	bcf	status, 6	;RP1=0, select bank1
	clrf	(___CMS_CurAdjust@F1044)^080h
	
l9943:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(414)^0180h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___CMS_CurAdjust@1047+1)
	clrf	(___CMS_CurAdjust@1047)
	
l9945:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(413)^0180h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	iorwf	(___CMS_CurAdjust@1047),f
	
l9947:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	btfss	(402)^0180h,(3)&7	;volatile
	goto	u8631
	goto	u8630
u8631:
	goto	l9957
u8630:
	
l9949:	
	movlw	08h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	subwf	(___CMS_CurAdjust@1047+1),w
	movlw	081h
	skipnz
	subwf	(___CMS_CurAdjust@1047),w
	skipnc
	goto	u8641
	goto	u8640
u8641:
	goto	l9975
u8640:
	
l9951:	
	movlw	07h
	subwf	(___CMS_CurAdjust@1047+1),w
	movlw	080h
	skipnz
	subwf	(___CMS_CurAdjust@1047),w
	skipc
	goto	u8651
	goto	u8650
u8651:
	goto	l9975
u8650:
	
l9953:	
	fcall	___CMS_CurJudge
	goto	l9975
	
l9957:	
	
l3592:	
	movlw	0Ch
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	subwf	(___CMS_CurAdjust@1047+1),w
	movlw	0
	skipnz
	subwf	(___CMS_CurAdjust@1047),w
	skipnc
	goto	u8661
	goto	u8660
u8661:
	goto	l9965
u8660:
	
l9959:	
	movlw	04h
	subwf	(___CMS_CurAdjust@1047+1),w
	movlw	01h
	skipnz
	subwf	(___CMS_CurAdjust@1047),w
	skipc
	goto	u8671
	goto	u8670
u8671:
	goto	l9965
u8670:
	
l9961:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
		incf	((406)^0180h),w	;volatile
	btfsc	status,2
	goto	u8681
	goto	u8680
u8681:
	goto	l9965
u8680:
	goto	l9953
	
l9965:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u8691
	goto	u8690
u8691:
	goto	l9971
u8690:
	
l9967:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	movlw	low(0Fh)
	andwf	(indf),w
	movwf	(??___CMS_CurAdjust+0)+0
	movlw	low(06h)
	subwf	0+(??___CMS_CurAdjust+0)+0,w
	skipc
	goto	u8701
	goto	u8700
u8701:
	goto	l9975
u8700:
	
l9969:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	movwf	indf
	goto	l9975
	
l9971:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(010h)
	bsf	status, 7	;select IRP bank3
	addwf	indf,f
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_CurAdjust+0)+0
	movlw	04h
u8715:
	clrc
	rrf	(??___CMS_CurAdjust+0)+0,f
	addlw	-1
	skipz
	goto	u8715
	movlw	low(0Fh)
	andwf	0+(??___CMS_CurAdjust+0)+0,w
	movwf	(??___CMS_CurAdjust+1)+0
	movlw	low(06h)
	subwf	0+(??___CMS_CurAdjust+1)+0,w
	skipc
	goto	u8721
	goto	u8720
u8721:
	goto	l9975
u8720:
	
l9973:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(0Fh)
	andwf	indf,f
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(050h)
	iorwf	indf,f
	
l9975:	
	fcall	___CMS_KeyModeSet
	
l9977:	
	btfsc	(_926/8),(_926)&7	;volatile
	goto	u8731
	goto	u8730
u8731:
	goto	l9981
u8730:
	goto	l9935
	
l9981:	
	fcall	___CMS_KeyStart
	goto	l3586
	
l9983:	
	movlw	low(0C8h)
	bcf	status, 6	;RP1=0, select bank1
	incf	(___CMS_CurAdjust@F1044)^080h,f
	subwf	((___CMS_CurAdjust@F1044)^080h),w
	skipc
	goto	u8741
	goto	u8740
u8741:
	goto	l3586
u8740:
	
l9985:	
	clrf	(___CMS_CurAdjust@F1044)^080h
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_921)	;volatile
	
l9987:	
	bcf	(_927/8),(_927)&7	;volatile
	clrf	(___CMS_CurAdjust@1045)
	
l9993:	
	movf	(___CMS_CurAdjust@1045),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l9995:	
	incf	(___CMS_CurAdjust@1045),f
	
l9997:	
	movlw	low(02h)
	subwf	(___CMS_CurAdjust@1045),w
	skipc
	goto	u8751
	goto	u8750
u8751:
	goto	l9993
u8750:
	
l3586:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text18
	
l3605:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CurAdjust
	__end_of___CMS_CurAdjust:
	signat	___CMS_CurAdjust,89
	global	___CMS_KeyStart

;; *************** function ___CMS_KeyStart *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1038            1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CurAdjust
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=1
global __ptext19
__ptext19:	;psect for function ___CMS_KeyStart
psect	text19
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyStart
	__size_of___CMS_KeyStart	equ	__end_of___CMS_KeyStart-___CMS_KeyStart
	
___CMS_KeyStart:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_KeyStart: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
	
l9067:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text19
	
l9069:	
	movlw	low(0C2h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(400)^0180h,f	;volatile
	movlw	low(0E0h)
	andwf	(401)^0180h,f	;volatile
	
l9071:	
	movf	(_919),w
	addlw	low(((_gc_Table_KeyChannel)|8000h))
	movwf	fsr0
	movlw	high(((_gc_Table_KeyChannel)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	andlw	01Fh
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(401)^0180h,f	;volatile
	
l9073:	
	movlw	low(010h)
	movwf	(415)^0180h	;volatile
	
l9075:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u7301
	goto	u7300
u7301:
	goto	l9087
u7300:
	
l9077:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_KeyStart@1038)
	
l9079:	
	movlw	low(0Fh)
	andwf	(___CMS_KeyStart@1038),f
	
l9081:	
	movlw	low(0F1h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(405)^0180h,f	;volatile
	
l9083:	
	movf	(___CMS_KeyStart@1038),w
	addlw	low(((_sc_CurStep_Table)|8000h))
	movwf	fsr0
	movlw	high(((_sc_CurStep_Table)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(405)^0180h,f	;volatile
	
l9085:	
	movf	(_919),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(406)^0180h	;volatile
	goto	l9097
	
l9087:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	swapf	indf,w
	andlw	(0ffh shr 4) & 0ffh
	movwf	(___CMS_KeyStart@1038)
	
l9089:	
	movlw	low(0Fh)
	andwf	(___CMS_KeyStart@1038),f
	
l9091:	
	movlw	low(0F1h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(405)^0180h,f	;volatile
	
l9093:	
	movf	(___CMS_KeyStart@1038),w
	addlw	low(((_sc_CurStep_Table)|8000h))
	movwf	fsr0
	movlw	high(((_sc_CurStep_Table)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(405)^0180h,f	;volatile
	
l9095:	
	movf	(_919),w
	addlw	low(432|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(406)^0180h	;volatile
	
l9097:	
	movf	(406)^0180h,w	;volatile
	movwf	(407)^0180h	;volatile
	
l9101:	
	bsf	(400)^0180h+(0/8),(0)&7	;volatile
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text19
	
l3572:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyStart
	__end_of___CMS_KeyStart:
	signat	___CMS_KeyStart,89
	global	___CMS_KeyModeSet

;; *************** function ___CMS_KeyModeSet *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1035            1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CurAdjust
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=1
global __ptext20
__ptext20:	;psect for function ___CMS_KeyModeSet
psect	text20
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyModeSet
	__size_of___CMS_KeyModeSet	equ	__end_of___CMS_KeyModeSet-___CMS_KeyModeSet
	
___CMS_KeyModeSet:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_KeyModeSet: [wreg+status,2+status,0]
	
l9041:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text20
	
l9043:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(400)^0180h	;volatile
	movlw	low(0E0h)
	movwf	(403)^0180h	;volatile
	
l9045:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_916),w	;volatile
	addlw	01h
	iorlw	0Ch
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(404)^0180h	;volatile
	
l9047:	
	movlw	low(030h)
	movwf	(405)^0180h	;volatile
	
l9049:	
	movlw	low(099h)
	movwf	(408)^0180h	;volatile
	
l9051:	
	movlw	low(040h)
	movwf	(401)^0180h	;volatile
	
l9053:	
	bsf	(401)^0180h+(5/8),(5)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfsc	status,2
	goto	u7281
	goto	u7280
u7281:
	goto	l9059
u7280:
	
l9055:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	incf	(403)^0180h,f
	incf	(403)^0180h,f	;volatile
	
l9057:	
	movlw	low(010h)
	addwf	(404)^0180h,f	;volatile
	goto	l3561
	
l9059:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	incf	(403)^0180h,f
	incf	(403)^0180h,f	;volatile
	
l9061:	
	movlw	010h
	subwf	(404)^0180h,f	;volatile
	
l9063:	
	bsf	(405)^0180h+(7/8),(7)&7	;volatile
	
l3561:	
	movlw	low(014h)
	movwf	(___CMS_KeyModeSet@1035)
	
l9065:	
	decf	(___CMS_KeyModeSet@1035),f
		incf	(((___CMS_KeyModeSet@1035))),w
	btfss	status,2
	goto	u7291
	goto	u7290
u7291:
	goto	l9065
u7290:
	
l3564:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text20
	
l3565:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyModeSet
	__end_of___CMS_KeyModeSet:
	signat	___CMS_KeyModeSet,89
	global	___CMS_CurJudge

;; *************** function ___CMS_CurJudge *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          2       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CurAdjust
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=1
global __ptext21
__ptext21:	;psect for function ___CMS_CurJudge
psect	text21
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CurJudge
	__size_of___CMS_CurJudge	equ	__end_of___CMS_CurJudge-___CMS_CurJudge
	
___CMS_CurJudge:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CurJudge: [wreg-fsr0h+status,2+status,0]
	
l9103:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text21
	
l9105:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9107:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u7311
	goto	u7310
u7311:
	goto	l9111
u7310:
	
l9109:	
	movf	(_919),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(406)^0180h,w	;volatile
	bsf	status, 7	;select IRP bank3
	movwf	indf
	goto	l9113
	
l9111:	
	movf	(_919),w
	addlw	low(432|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(406)^0180h,w	;volatile
	bsf	status, 7	;select IRP bank3
	movwf	indf
	
l9113:	
	movlw	low(04h)
	movwf	(415)^0180h	;volatile
	
l9115:	
	movlw	0
	movwf	(??___CMS_CurJudge+0)+0
	movlw	0Ch
	movwf	(??___CMS_CurJudge+0)+0+1
	clrc
	rlf	(_919),w	;volatile
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_CurJudge+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_CurJudge+0)+1,w
	movwf	indf
	
l9117:	
	movlw	0
	movwf	(??___CMS_CurJudge+0)+0
	movlw	0Ch
	movwf	(??___CMS_CurJudge+0)+0+1
	clrc
	rlf	(_919),w	;volatile
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_CurJudge+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_CurJudge+0)+1,w
	movwf	indf
	
l9119:	
	movlw	low(02h)
	incf	(_919),f	;volatile
	subwf	((_919)),w	;volatile
	skipc
	goto	u7321
	goto	u7320
u7321:
	goto	l3577
u7320:
	
l9121:	
	clrf	(_919)	;volatile
	
l9123:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u7331
	goto	u7330
u7331:
	goto	l3578
u7330:
	
l9125:	
	movlw	low(01h)
	movwf	(_921)	;volatile
	goto	l3577
	
l3578:	
	bcf	(13)+(6/8),(6)&7	;volatile
	bsf	(_926/8),(_926)&7	;volatile
	
l9127:	
	clrf	(_920)	;volatile
	clrf	(_921)	;volatile
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(402)^0180h	;volatile
	
l3577:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text21
	
l3580:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CurJudge
	__end_of___CMS_CurJudge:
	signat	___CMS_CurJudge,89
	global	___CMS_CurAdjMode

;; *************** function ___CMS_CurAdjMode *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1032            1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CurAdjust
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=1
global __ptext22
__ptext22:	;psect for function ___CMS_CurAdjMode
psect	text22
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CurAdjMode
	__size_of___CMS_CurAdjMode	equ	__end_of___CMS_CurAdjMode-___CMS_CurAdjMode
	
___CMS_CurAdjMode:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CurAdjMode: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
	
l9003:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text22
	
l9005:	
	
l9007:	
	movf	(_919),w
	addlw	low(((_gc_Table_KeyChannel)|8000h))
	movwf	fsr0
	movlw	high(((_gc_Table_KeyChannel)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	andlw	01Fh
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(401)^0180h,f	;volatile
	
l9009:	
	movlw	low(010h)
	movwf	(415)^0180h	;volatile
	
l9011:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u7251
	goto	u7250
u7251:
	goto	l9025
u7250:
	
l9013:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_CurAdjMode@1032)
	
l9015:	
	movlw	low(0Fh)
	andwf	(___CMS_CurAdjMode@1032),f
	
l9017:	
	movlw	low(06h)
	subwf	(___CMS_CurAdjMode@1032),w
	skipc
	goto	u7261
	goto	u7260
u7261:
	goto	l9021
u7260:
	
l9019:	
	movlw	low(05h)
	movwf	(___CMS_CurAdjMode@1032)
	
l9021:	
	movlw	low(0F1h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(405)^0180h,f	;volatile
	
l9023:	
	movf	(___CMS_CurAdjMode@1032),w
	addlw	low(((_sc_CurStep_Table)|8000h))
	movwf	fsr0
	movlw	high(((_sc_CurStep_Table)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(405)^0180h,f	;volatile
	goto	l9037
	
l9025:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	swapf	indf,w
	andlw	(0ffh shr 4) & 0ffh
	movwf	(___CMS_CurAdjMode@1032)
	
l9027:	
	movlw	low(0Fh)
	andwf	(___CMS_CurAdjMode@1032),f
	
l9029:	
	movlw	low(06h)
	subwf	(___CMS_CurAdjMode@1032),w
	skipc
	goto	u7271
	goto	u7270
u7271:
	goto	l9021
u7270:
	goto	l9019
	
l9037:	
	movlw	low(010h)
	movwf	(402)^0180h	;volatile
	
l9039:	
	bsf	(402)^0180h+(7/8),(7)&7	;volatile
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text22
	
l3557:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CurAdjMode
	__end_of___CMS_CurAdjMode:
	signat	___CMS_CurAdjMode,89
	global	___CMS_CheckValidTime

;; *************** function ___CMS_CheckValidTime *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=1
global __ptext23
__ptext23:	;psect for function ___CMS_CheckValidTime
psect	text23
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CheckValidTime
	__size_of___CMS_CheckValidTime	equ	__end_of___CMS_CheckValidTime-___CMS_CheckValidTime
	
___CMS_CheckValidTime:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_CheckValidTime: [wreg+status,2+status,0]
	
l9913:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text23
	
l9915:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	0+(_g_KeyFlag)+01h,w	;volatile
	iorwf	(_g_KeyFlag),w	;volatile
	btfsc	status,2
	goto	u8591
	goto	u8590
u8591:
	goto	l9921
u8590:
	
l9917:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_CheckValidTime@F1029)^080h,f
	skipnz
	incf	(___CMS_CheckValidTime@F1029+1)^080h,f
	movlw	013h
	subwf	((___CMS_CheckValidTime@F1029+1)^080h),w
	movlw	088h
	skipnz
	subwf	((___CMS_CheckValidTime@F1029)^080h),w
	skipc
	goto	u8601
	goto	u8600
u8601:
	goto	l3546
u8600:
	
l9919:	
	bsf	(_gf_kerr/8),(_gf_kerr)&7	;volatile
	
l9921:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_CheckValidTime@F1029)^080h
	clrf	(___CMS_CheckValidTime@F1029+1)^080h
	
l3546:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text23
	
l3550:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CheckValidTime
	__end_of___CMS_CheckValidTime:
	signat	___CMS_CheckValidTime,89
	global	___CMS_CheckOnceResult

;; *************** function ___CMS_CheckOnceResult *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  991             2   14[BANK0 ] unsigned short 
;;  990             2   12[BANK0 ] unsigned short 
;;  989             2    5[BANK0 ] unsigned short 
;;  979             1   20[BANK0 ] unsigned char 
;;  987             1   19[BANK0 ] unsigned char 
;;  988             1   18[BANK0 ] unsigned char 
;;  984             1   17[BANK0 ] unsigned char 
;;  983             1   16[BANK0 ] unsigned char 
;;  982             1   11[BANK0 ] unsigned char 
;;  986             1   10[BANK0 ] unsigned char 
;;  985             1    9[BANK0 ] unsigned char 
;;  981             1    8[BANK0 ] unsigned char 
;;  980             1    7[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0      16       0       0
;;      Temps:          0       5       0       0
;;      Totals:         0      21       0       0
;;Total ram usage:       21 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___CMS_KeyHaveDown
;;		___CMS_KeyIsIn
;;		___CMS_KeyOpen
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=1
global __ptext24
__ptext24:	;psect for function ___CMS_CheckOnceResult
psect	text24
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CheckOnceResult
	__size_of___CMS_CheckOnceResult	equ	__end_of___CMS_CheckOnceResult-___CMS_CheckOnceResult
	
___CMS_CheckOnceResult:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CheckOnceResult: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	
l9563:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text24
	
l9565:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_CheckOnceResult@979)
	
l9567:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u8101
	goto	u8100
u8101:
	goto	l9571
u8100:
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	112
	
l9569:	
	movlw	low(03h)
	movwf	(___CMS_CheckOnceResult@987)
	line	1
	goto	l3452
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9571:	
	movlw	low(04h)
	movwf	(___CMS_CheckOnceResult@987)
	
l3452:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9573:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u8111
	goto	u8110
u8111:
	goto	l9577
u8110:
	
l9575:	
	clrc
	rlf	(___CMS_CheckOnceResult@979),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@991)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@991+1)
	goto	l9579
	
l9577:	
	clrc
	rlf	(___CMS_CheckOnceResult@979),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@991)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@991+1)
	
l9579:	
	clrc
	rlf	(___CMS_CheckOnceResult@979),w
	addlw	low(((_gc_Table_KeyDown)|8000h))
	movwf	fsr0
	movlw	high(((_gc_Table_KeyDown)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(___CMS_CheckOnceResult@989)
	fcall	stringtab
	movwf	(___CMS_CheckOnceResult@989+1)
	
l9581:	
	movf	((___CMS_CheckOnceResult@991)),w
iorwf	((___CMS_CheckOnceResult@991+1)),w
	btfsc	status,2
	goto	u8121
	goto	u8120
u8121:
	goto	l9691
u8120:
	
l9583:	
	movlw	0Ch
	subwf	(___CMS_CheckOnceResult@991+1),w
	movlw	0
	skipnz
	subwf	(___CMS_CheckOnceResult@991),w
	skipnc
	goto	u8131
	goto	u8130
u8131:
	goto	l9691
u8130:
	
l9585:	
	movf	(___CMS_CheckOnceResult@979),w
	andlw	07h
	addlw	low(((_sc_Table_KeyFalg)|8000h))
	movwf	fsr0
	movlw	high(((_sc_Table_KeyFalg)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(___CMS_CheckOnceResult@988)
	
l9587:	
	movf	(___CMS_CheckOnceResult@989),w
	addwf	(___CMS_CheckOnceResult@991),w
	movwf	(___CMS_CheckOnceResult@990)
	movf	(___CMS_CheckOnceResult@989+1),w
	skipnc
	incf	(___CMS_CheckOnceResult@989+1),w
	addwf	(___CMS_CheckOnceResult@991+1),w
	movwf	1+(___CMS_CheckOnceResult@990)
	
l9589:	
	clrf	(___CMS_CheckOnceResult@980)
	
l9591:	
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyIsIn
	xorlw	0
	skipnz
	goto	u8141
	goto	u8140
u8141:
	goto	l9597
u8140:
	
l9593:	
	clrf	(___CMS_CheckOnceResult@980)
	incf	(___CMS_CheckOnceResult@980),f
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	115
	
l9595:	
	movf	(___CMS_CheckOnceResult@990),w
	addlw	low(0FFE7h)
	movwf	(___CMS_CheckOnceResult@990)
	movf	(___CMS_CheckOnceResult@990+1),w
	skipnc
	addlw	1
	addlw	high(0FFE7h)
	movwf	1+(___CMS_CheckOnceResult@990)
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9597:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9599:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrc
	rlf	indf,f
	
l9601:	
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(464|((0x1)<<8))&0ffh
	movwf	fsr0
	clrc
	rlf	indf,f
	
l9603:	
	movlw	low(08h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9605:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckOnceResult@979),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_CheckOnceResult+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_CheckOnceResult+0)+0+1
	movf	(___CMS_CheckOnceResult@990+1),w
	subwf	1+(??___CMS_CheckOnceResult+0)+0,w
	skipz
	goto	u8155
	movf	(___CMS_CheckOnceResult@990),w
	subwf	0+(??___CMS_CheckOnceResult+0)+0,w
u8155:
	skipc
	goto	u8151
	goto	u8150
u8151:
	goto	l9613
u8150:
	
l9607:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9609:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	indf+(0/8),(0)&7
	
l9611:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(464|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	indf+(0/8),(0)&7
	goto	l9621
	
l9613:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9615:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckOnceResult@979),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_CheckOnceResult+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_CheckOnceResult+0)+0+1
	movf	(___CMS_CheckOnceResult@990+1),w
	subwf	1+(??___CMS_CheckOnceResult+0)+0,w
	skipz
	goto	u8165
	movf	(___CMS_CheckOnceResult@990),w
	subwf	0+(??___CMS_CheckOnceResult+0)+0,w
u8165:
	skipc
	goto	u8161
	goto	u8160
u8161:
	goto	l9621
u8160:
	
l9617:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	goto	l9611
	
l9621:	
	clrf	(___CMS_CheckOnceResult@983)
	
l9623:	
	clrf	(___CMS_CheckOnceResult@984)
	
l9625:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(464|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@985)
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@986)
	
l9627:	
	clrf	(___CMS_CheckOnceResult@981)
	goto	l9639
	
l3461:	
	btfss	(___CMS_CheckOnceResult@985),(0)&7
	goto	u8171
	goto	u8170
u8171:
	goto	l9631
u8170:
	
l9629:	
	incf	(___CMS_CheckOnceResult@983),f
	
l9631:	
	clrc
	rrf	(___CMS_CheckOnceResult@985),f
	
l9633:	
	btfss	(___CMS_CheckOnceResult@986),(0)&7
	goto	u8181
	goto	u8180
u8181:
	goto	l9637
u8180:
	
l9635:	
	incf	(___CMS_CheckOnceResult@984),f
	
l9637:	
	clrc
	rrf	(___CMS_CheckOnceResult@986),f
	incf	(___CMS_CheckOnceResult@981),f
	
l9639:	
	clrc
	rlf	(___CMS_CheckOnceResult@987),w
	subwf	(___CMS_CheckOnceResult@981),w
	skipc
	goto	u8191
	goto	u8190
u8191:
	goto	l3461
u8190:
	
l9641:	
	clrf	(___CMS_CheckOnceResult@982)
	
l9643:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9645:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckOnceResult@987),w
	subwf	(___CMS_CheckOnceResult@984),w
	skipc
	goto	u8201
	goto	u8200
u8201:
	goto	l3465
u8200:
	
l9647:	
	movf	(___CMS_CheckOnceResult@988),w
	movwf	(___CMS_KeyHaveDown@956)
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyHaveDown
	
l9649:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_CheckOnceResult@982)
	incf	(___CMS_CheckOnceResult@982),f
	
l9651:	
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l9669
	
l3465:	
	btfss	(_925/8),(_925)&7	;volatile
	goto	u8211
	goto	u8210
u8211:
	goto	l9669
u8210:
	
l9653:	
	clrc
	rlf	(___CMS_CheckOnceResult@987),w
	subwf	(___CMS_CheckOnceResult@983),w
	skipc
	goto	u8221
	goto	u8220
u8221:
	goto	l9661
u8220:
	
l9655:	
	movf	(___CMS_CheckOnceResult@988),w
	movwf	(___CMS_KeyHaveDown@956)
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyHaveDown
	goto	l9649
	
l9661:	
	movf	(___CMS_CheckOnceResult@987),w
	movwf	(??___CMS_CheckOnceResult+0)+0
	clrc
	rlf	(??___CMS_CheckOnceResult+0)+0,f
	movlw	low(01h)
	addwf	0+(??___CMS_CheckOnceResult+0)+0,w
	movwf	(??___CMS_CheckOnceResult+1)+0
	movf	(___CMS_CheckOnceResult@984),w
	addwf	(___CMS_CheckOnceResult@983),w
	movwf	(??___CMS_CheckOnceResult+2)+0
	clrf	(??___CMS_CheckOnceResult+2)+0+1
	rlf	1+(??___CMS_CheckOnceResult+2)+0,f
	
	movf	1+(??___CMS_CheckOnceResult+2)+0,w
	xorlw	80h
	movwf	(??___CMS_CheckOnceResult+4)+0
	movlw	80h
	subwf	(??___CMS_CheckOnceResult+4)+0,w
	skipz
	goto	u8235
	movf	0+(??___CMS_CheckOnceResult+1)+0,w
	subwf	0+(??___CMS_CheckOnceResult+2)+0,w
u8235:

	skipc
	goto	u8231
	goto	u8230
u8231:
	goto	l3467
u8230:
	
l9663:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@988),w
	movwf	(___CMS_KeyHaveDown@956)
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyHaveDown
	goto	l9649
	
l3467:	
	
l9669:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((___CMS_CheckOnceResult@982)),w
	btfss	status,2
	goto	u8241
	goto	u8240
u8241:
	goto	l9691
u8240:
	
l9671:	
	movf	((___CMS_CheckOnceResult@980)),w
	btfsc	status,2
	goto	u8251
	goto	u8250
u8251:
	goto	l9691
u8250:
	
l9673:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9675:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u8261
	goto	u8260
u8261:
	goto	l9681
u8260:
	
l9677:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckOnceResult@987),w
	addlw	0FFh
	subwf	(___CMS_CheckOnceResult@984),w
	skipnc
	goto	u8271
	goto	u8270
u8271:
	goto	l3475
u8270:
	
l9679:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	goto	l3475
	
l9681:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@987),w
	movwf	(??___CMS_CheckOnceResult+0)+0
	clrc
	rlf	(??___CMS_CheckOnceResult+0)+0,f
	movlw	low(0FFh)
	addwf	0+(??___CMS_CheckOnceResult+0)+0,w
	movwf	(??___CMS_CheckOnceResult+1)+0
	movf	(___CMS_CheckOnceResult@984),w
	addwf	(___CMS_CheckOnceResult@983),w
	movwf	(??___CMS_CheckOnceResult+2)+0
	clrf	(??___CMS_CheckOnceResult+2)+0+1
	rlf	1+(??___CMS_CheckOnceResult+2)+0,f
	
	movf	1+(??___CMS_CheckOnceResult+2)+0,w
	xorlw	80h
	movwf	(??___CMS_CheckOnceResult+4)+0
	movlw	80h
	subwf	(??___CMS_CheckOnceResult+4)+0,w
	skipz
	goto	u8285
	movf	0+(??___CMS_CheckOnceResult+1)+0,w
	subwf	0+(??___CMS_CheckOnceResult+2)+0,w
u8285:

	skipnc
	goto	u8281
	goto	u8280
u8281:
	goto	l3475
u8280:
	goto	l9679
	
l3475:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrc
	rlf	(___CMS_CheckOnceResult@987),w
	addlw	0FFh
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u8291
	goto	u8290
u8291:
	goto	l9689
u8290:
	
l9685:	
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l9687:	
	movf	(___CMS_CheckOnceResult@988),w
	movwf	(___CMS_KeyOpen@952)
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyOpen
	goto	l9691
	
l9689:	
	movf	(___CMS_CheckOnceResult@988),w
	movwf	(___CMS_KeyHaveDown@956)
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyHaveDown
	
l9691:	
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(___CMS_CheckOnceResult@979),f
	subwf	((___CMS_CheckOnceResult@979)),w
	skipc
	goto	u8301
	goto	u8300
u8301:
	goto	l3452
u8300:
	
l3479:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text24
	
l3480:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CheckOnceResult
	__end_of___CMS_CheckOnceResult:
	signat	___CMS_CheckOnceResult,89
	global	___CMS_KeyOpen

;; *************** function ___CMS_KeyOpen *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;  951             1    wreg     unsigned char 
;;  952             1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  951             1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckOnceResult
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=1
global __ptext25
__ptext25:	;psect for function ___CMS_KeyOpen
psect	text25
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyOpen
	__size_of___CMS_KeyOpen	equ	__end_of___CMS_KeyOpen-___CMS_KeyOpen
	
___CMS_KeyOpen:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_KeyOpen: [wreg+status,2+status,0]
;___CMS_KeyOpen@951 stored from wreg
	movwf	(___CMS_KeyOpen@951)
	
l8957:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text25
	
l8959:	
	movlw	low(0FFh)
	xorwf	(___CMS_KeyOpen@952),f
	
l8961:	
	btfss	(___CMS_KeyOpen@951),(3)&7
	goto	u7211
	goto	u7210
u7211:
	goto	l8965
u7210:
	
l8963:	
	movf	(___CMS_KeyOpen@952),w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	andwf	0+(_g_KeyFlag)+01h,f	;volatile
	goto	l3398
	
l8965:	
	movf	(___CMS_KeyOpen@952),w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	andwf	(_g_KeyFlag),f	;volatile
	
l3398:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text25
	
l3399:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyOpen
	__end_of___CMS_KeyOpen:
	signat	___CMS_KeyOpen,8313
	global	___CMS_KeyHaveDown

;; *************** function ___CMS_KeyHaveDown *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;  955             1    wreg     unsigned char 
;;  956             1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  955             1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckOnceResult
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=1
global __ptext26
__ptext26:	;psect for function ___CMS_KeyHaveDown
psect	text26
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyHaveDown
	__size_of___CMS_KeyHaveDown	equ	__end_of___CMS_KeyHaveDown-___CMS_KeyHaveDown
	
___CMS_KeyHaveDown:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_KeyHaveDown: [wreg+status,2+status,0]
;___CMS_KeyHaveDown@955 stored from wreg
	movwf	(___CMS_KeyHaveDown@955)
	
l8967:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text26
	
l8969:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_917),f	;volatile
	
l8971:	
	btfss	(___CMS_KeyHaveDown@955),(3)&7
	goto	u7221
	goto	u7220
u7221:
	goto	l8975
u7220:
	
l8973:	
	movf	(___CMS_KeyHaveDown@956),w
	iorwf	0+(_g_KeyFlag)+01h,f	;volatile
	goto	l3403
	
l8975:	
	movf	(___CMS_KeyHaveDown@956),w
	iorwf	(_g_KeyFlag),f	;volatile
	
l3403:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text26
	
l3404:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyHaveDown
	__end_of___CMS_KeyHaveDown:
	signat	___CMS_KeyHaveDown,8313
	global	___CMS_CheckKeyOldValue

;; *************** function ___CMS_CheckKeyOldValue *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1009            2   11[BANK0 ] unsigned short 
;;  1008            2    9[BANK0 ] unsigned short 
;;  1007            2    7[BANK0 ] unsigned short 
;;  1006            2    4[BANK0 ] unsigned short 
;;  1003            1   14[BANK0 ] unsigned char 
;;  1005            1   13[BANK0 ] unsigned char 
;;  1004            1    6[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0      11       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0      13       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___CMS_KeyIsIn
;;		_abs
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=1
global __ptext27
__ptext27:	;psect for function ___CMS_CheckKeyOldValue
psect	text27
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CheckKeyOldValue
	__size_of___CMS_CheckKeyOldValue	equ	__end_of___CMS_CheckKeyOldValue-___CMS_CheckKeyOldValue
	
___CMS_CheckKeyOldValue:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CheckKeyOldValue: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	
l9693:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text27
	
l9695:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_CheckKeyOldValue@1003)
	
l9697:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u8311
	goto	u8310
u8311:
	goto	l9703
u8310:
	
l9699:	
	movlw	low(08h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9701:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1009)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1009+1)
	goto	l9707
	
l9703:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9705:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1009)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1009+1)
	
l9707:	
	movf	((_921)),w	;volatile
	btfsc	status,2
	goto	u8321
	goto	u8320
u8321:
	goto	l9755
u8320:
	
l9709:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9711:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1007)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1007+1)
	
l9713:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1008)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1008+1)
	
l9715:	
	movf	(___CMS_CheckKeyOldValue@1007+1),w
	movwf	(abs@a+1)
	movf	(___CMS_CheckKeyOldValue@1007),w
	movwf	(abs@a)
	movf	(___CMS_CheckKeyOldValue@1009),w
	subwf	(abs@a),f
	movf	(___CMS_CheckKeyOldValue@1009+1),w
	skipc
	decf	(abs@a+1),f
	subwf	(abs@a+1),f
	fcall	_abs
	movf	(1+(?_abs)),w
	movwf	(___CMS_CheckKeyOldValue@1006+1)
	movf	(0+(?_abs)),w
	movwf	(___CMS_CheckKeyOldValue@1006)
	
l9717:	
	movlw	0Ch
	subwf	(___CMS_CheckKeyOldValue@1008+1),w
	movlw	0
	skipnz
	subwf	(___CMS_CheckKeyOldValue@1008),w
	skipnc
	goto	u8331
	goto	u8330
u8331:
	goto	l9721
u8330:
	
l9719:	
	movf	((___CMS_CheckKeyOldValue@1008)),w
iorwf	((___CMS_CheckKeyOldValue@1008+1)),w
	btfss	status,2
	goto	u8341
	goto	u8340
u8341:
	goto	l9727
u8340:
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
	
l9721:	
	movlw	low(04Bh)
	movwf	(___CMS_CheckKeyOldValue@1004)
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9723:	
	
l9725:	
	movlw	low(06h)
	movwf	(___CMS_CheckKeyOldValue@1005)
	goto	l3491
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
	
l9727:	
	movlw	low(032h)
	movwf	(___CMS_CheckKeyOldValue@1004)
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9729:	
	btfss	(_925/8),(_925)&7	;volatile
	goto	u8351
	goto	u8350
u8351:
	goto	l9725
u8350:
	
l9731:	
	movlw	low(0Ch)
	movwf	(___CMS_CheckKeyOldValue@1005)
	
l3491:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9735:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_CheckKeyOldValue@1009),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_CheckKeyOldValue@1009+1),w
	movwf	indf
	
l9737:	
	movf	(___CMS_CheckKeyOldValue@1003),w
	fcall	___CMS_KeyIsIn
	xorlw	0
	skipz
	goto	u8361
	goto	u8360
u8361:
	goto	l9751
u8360:
	
l9739:	
	movf	(___CMS_CheckKeyOldValue@1004),w
	movwf	(??___CMS_CheckKeyOldValue+0)+0
	clrf	(??___CMS_CheckKeyOldValue+0)+0+1
	movf	(___CMS_CheckKeyOldValue@1006+1),w
	subwf	1+(??___CMS_CheckKeyOldValue+0)+0,w
	skipz
	goto	u8375
	movf	(___CMS_CheckKeyOldValue@1006),w
	subwf	0+(??___CMS_CheckKeyOldValue+0)+0,w
u8375:
	skipc
	goto	u8371
	goto	u8370
u8371:
	goto	l9751
u8370:
	
l9741:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9743:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	movf	(___CMS_CheckKeyOldValue@1005),w
	subwf	(indf),w
	skipc
	goto	u8381
	goto	u8380
u8381:
	goto	l9807
u8380:
	
l9745:	
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l9747:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9749:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_CheckKeyOldValue@1007),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_CheckKeyOldValue@1007+1),w
	movwf	indf
	goto	l9807
	
l9751:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9753:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l9807
	
l9755:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9757:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1007)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1007+1)
	
l9759:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1008)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1008+1)
	
l9761:	
	movf	(___CMS_CheckKeyOldValue@1007+1),w
	movwf	(abs@a+1)
	movf	(___CMS_CheckKeyOldValue@1007),w
	movwf	(abs@a)
	movf	(___CMS_CheckKeyOldValue@1009),w
	subwf	(abs@a),f
	movf	(___CMS_CheckKeyOldValue@1009+1),w
	skipc
	decf	(abs@a+1),f
	subwf	(abs@a+1),f
	fcall	_abs
	movf	(1+(?_abs)),w
	movwf	(___CMS_CheckKeyOldValue@1006+1)
	movf	(0+(?_abs)),w
	movwf	(___CMS_CheckKeyOldValue@1006)
	
l9763:	
	movlw	0Ch
	subwf	(___CMS_CheckKeyOldValue@1008+1),w
	movlw	0
	skipnz
	subwf	(___CMS_CheckKeyOldValue@1008),w
	skipnc
	goto	u8391
	goto	u8390
u8391:
	goto	l9767
u8390:
	
l9765:	
	movf	((___CMS_CheckKeyOldValue@1008)),w
iorwf	((___CMS_CheckKeyOldValue@1008+1)),w
	btfss	status,2
	goto	u8401
	goto	u8400
u8401:
	goto	l9777
u8400:
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
	
l9767:	
	movlw	low(064h)
	movwf	(___CMS_CheckKeyOldValue@1004)
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9769:	
	
l9771:	
	movlw	low(04h)
	movwf	(___CMS_CheckKeyOldValue@1005)
	goto	l3505
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
	
l9777:	
	movlw	low(04Bh)
	movwf	(___CMS_CheckKeyOldValue@1004)
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9779:	
	btfss	(_925/8),(_925)&7	;volatile
	goto	u8411
	goto	u8410
u8411:
	goto	l9783
u8410:
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	116
	
l9781:	
	movlw	low(06h)
	movwf	(___CMS_CheckKeyOldValue@1005)
	line	1
	goto	l3505
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9783:	
	goto	l9771
	
l3505:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9787:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_CheckKeyOldValue@1009),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_CheckKeyOldValue@1009+1),w
	movwf	indf
	
l9789:	
	movf	(___CMS_CheckKeyOldValue@1003),w
	fcall	___CMS_KeyIsIn
	xorlw	0
	skipz
	goto	u8421
	goto	u8420
u8421:
	goto	l9803
u8420:
	
l9791:	
	movf	(___CMS_CheckKeyOldValue@1004),w
	movwf	(??___CMS_CheckKeyOldValue+0)+0
	clrf	(??___CMS_CheckKeyOldValue+0)+0+1
	movf	(___CMS_CheckKeyOldValue@1006+1),w
	subwf	1+(??___CMS_CheckKeyOldValue+0)+0,w
	skipz
	goto	u8435
	movf	(___CMS_CheckKeyOldValue@1006),w
	subwf	0+(??___CMS_CheckKeyOldValue+0)+0,w
u8435:
	skipc
	goto	u8431
	goto	u8430
u8431:
	goto	l9803
u8430:
	
l9793:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9795:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	movf	(___CMS_CheckKeyOldValue@1005),w
	subwf	(indf),w
	skipc
	goto	u8441
	goto	u8440
u8441:
	goto	l9807
u8440:
	
l9797:	
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l9799:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9801:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_CheckKeyOldValue@1007),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_CheckKeyOldValue@1007+1),w
	movwf	indf
	goto	l9807
	
l9803:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9805:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l9807:	
	movlw	low(02h)
	incf	(___CMS_CheckKeyOldValue@1003),f
	subwf	((___CMS_CheckKeyOldValue@1003)),w
	skipc
	goto	u8451
	goto	u8450
u8451:
	goto	l9697
u8450:
	
l3512:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text27
	
l3513:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CheckKeyOldValue
	__end_of___CMS_CheckKeyOldValue:
	signat	___CMS_CheckKeyOldValue,89
	global	_abs

;; *************** function _abs *****************
;; Defined at:
;;		line 4 in file "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\abs.c"
;; Parameters:    Size  Location     Type
;;  a               2    4[COMMON] int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  2    4[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       2       0       0
;;      Totals:         2       2       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckKeyOldValue
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=2
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\abs.c"
	line	4
global __ptext28
__ptext28:	;psect for function _abs
psect	text28
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\abs.c"
	line	4
	global	__size_of_abs
	__size_of_abs	equ	__end_of_abs-_abs
	
_abs:	
;incstack = 0
	opt	stack 5
; Regs used in _abs: [wreg+status,2+status,0]
	line	6
	
l8997:	
	btfss	(abs@a+1),7
	goto	u7241
	goto	u7240
u7241:
	goto	l3724
u7240:
	line	7
	
l8999:	
	comf	(abs@a),w
	movwf	(??_abs+0)+0
	comf	(abs@a+1),w
	movwf	((??_abs+0)+0+1)
	incf	(??_abs+0)+0,f
	skipnz
	incf	((??_abs+0)+0+1),f
	movf	0+(??_abs+0)+0,w
	movwf	(?_abs)
	movf	1+(??_abs+0)+0,w
	movwf	(?_abs+1)
	goto	l3725
	
l3724:	
	line	8
	line	9
	
l3725:	
	return
	opt stack 0
GLOBAL	__end_of_abs
	__end_of_abs:
	signat	_abs,4218
	global	___CMS_KeyIsIn

;; *************** function ___CMS_KeyIsIn *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;  946             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  946             1    5[COMMON] unsigned char 
;;  947             1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         2       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckOnceResult
;;		___CMS_CheckKeyOldValue
;; This function uses a non-reentrant model
;;
psect	text29,local,class=CODE,delta=2,merge=1,group=1
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
global __ptext29
__ptext29:	;psect for function ___CMS_KeyIsIn
psect	text29
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyIsIn
	__size_of___CMS_KeyIsIn	equ	__end_of___CMS_KeyIsIn-___CMS_KeyIsIn
	
___CMS_KeyIsIn:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_KeyIsIn: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
;___CMS_KeyIsIn@946 stored from wreg
	movwf	(___CMS_KeyIsIn@946)
	
l8941:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text29
	
l8943:	
	movf	(___CMS_KeyIsIn@946),w
	andlw	07h
	addlw	low(((_sc_Table_KeyFalg)|8000h))
	movwf	fsr0
	movlw	high(((_sc_Table_KeyFalg)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	movwf	(___CMS_KeyIsIn@947)
	
l8945:	
	btfss	(___CMS_KeyIsIn@946),(3)&7
	goto	u7201
	goto	u7200
u7201:
	goto	l8949
u7200:
	
l8947:	
	movf	0+(_g_KeyFlag)+01h,w	;volatile
	andwf	(___CMS_KeyIsIn@947),f
	goto	l8951
	
l8949:	
	movf	(_g_KeyFlag),w	;volatile
	andwf	(___CMS_KeyIsIn@947),f
	
l8951:	
	movf	(___CMS_KeyIsIn@947),w
	
l3394:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyIsIn
	__end_of___CMS_KeyIsIn:
	signat	___CMS_KeyIsIn,4217
	global	_Tx_Display

;; *************** function _Tx_Display *****************
;; Defined at:
;;		line 2195 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text30,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	2195
global __ptext30
__ptext30:	;psect for function _Tx_Display
psect	text30
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	2195
	global	__size_of_Tx_Display
	__size_of_Tx_Display	equ	__end_of_Tx_Display-_Tx_Display
	
_Tx_Display:	
;incstack = 0
	opt	stack 7
; Regs used in _Tx_Display: []
	line	2277
	
l1431:	
	return
	opt stack 0
GLOBAL	__end_of_Tx_Display
	__end_of_Tx_Display:
	signat	_Tx_Display,89
	global	_TaskAlarmHandle

;; *************** function _TaskAlarmHandle *****************
;; Defined at:
;;		line 1592 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          2       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text31,local,class=CODE,delta=2,merge=1,group=0
	line	1592
global __ptext31
__ptext31:	;psect for function _TaskAlarmHandle
psect	text31
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	1592
	global	__size_of_TaskAlarmHandle
	__size_of_TaskAlarmHandle	equ	__end_of_TaskAlarmHandle-_TaskAlarmHandle
	
_TaskAlarmHandle:	
;incstack = 0
	opt	stack 7
; Regs used in _TaskAlarmHandle: [wreg+status,2+status,0]
	line	1596
	
l10419:	
;main.c: 1596: if(BeepAlmCnt)
	bcf	status, 5	;RP0=0, select bank0
	movf	((_BeepAlmCnt)),w
	btfsc	status,2
	goto	u9521
	goto	u9520
u9521:
	goto	l1304
u9520:
	line	1598
	
l10421:	
;main.c: 1597: {
;main.c: 1598: if(BeepOnTimeCnt)
	bsf	status, 5	;RP0=1, select bank1
	movf	((_BeepOnTimeCnt)^080h),w
iorwf	((_BeepOnTimeCnt+1)^080h),w
	btfsc	status,2
	goto	u9531
	goto	u9530
u9531:
	goto	l10429
u9530:
	line	1600
	
l10423:	
;main.c: 1599: {
;main.c: 1600: BeepOnTimeCnt--;
	movlw	01h
	subwf	(_BeepOnTimeCnt)^080h,f
	movlw	0
	skipc
	decf	(_BeepOnTimeCnt+1)^080h,f
	subwf	(_BeepOnTimeCnt+1)^080h,f
	line	1602
	
l10425:	
;main.c: 1602: if(BeepOnTimeCnt>=(BuzzerFilter>>1)){PWM1EN=1;}
	movf	(_BuzzerFilter+1)^080h,w
	movwf	(??_TaskAlarmHandle+0)+0+1
	movf	(_BuzzerFilter)^080h,w
	movwf	(??_TaskAlarmHandle+0)+0
	clrc
	rrf	(??_TaskAlarmHandle+0)+1,f
	rrf	(??_TaskAlarmHandle+0)+0,f
	movf	1+(??_TaskAlarmHandle+0)+0,w
	subwf	(_BeepOnTimeCnt+1)^080h,w
	skipz
	goto	u9545
	movf	0+(??_TaskAlarmHandle+0)+0,w
	subwf	(_BeepOnTimeCnt)^080h,w
u9545:
	skipc
	goto	u9541
	goto	u9540
u9541:
	goto	l1306
u9540:
	
l10427:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2097/8)^0100h,(2097)&7	;volatile
	goto	l1310
	line	1605
	
l1306:	
;main.c: 1605: else {PWM1EN=0;}
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2097/8)^0100h,(2097)&7	;volatile
	goto	l1310
	line	1609
	
l10429:	
;main.c: 1607: else
;main.c: 1608: {
;main.c: 1609: BeepAlmCnt--;
	bcf	status, 5	;RP0=0, select bank0
	decf	(_BeepAlmCnt),f
	line	1610
	
l10431:	
;main.c: 1610: BeepOnTimeCnt=BuzzerFilter;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_BuzzerFilter+1)^080h,w
	movwf	(_BeepOnTimeCnt+1)^080h
	movf	(_BuzzerFilter)^080h,w
	movwf	(_BeepOnTimeCnt)^080h
	goto	l1310
	line	1613
	
l1304:	
	line	1615
;main.c: 1613: else
;main.c: 1614: {
;main.c: 1615: _BITS.Bits.bit_7=0;
	bcf	(__BITS),7
	line	1617
	
l1310:	
	return
	opt stack 0
GLOBAL	__end_of_TaskAlarmHandle
	__end_of_TaskAlarmHandle:
	signat	_TaskAlarmHandle,89
	global	_TDS_Handle

;; *************** function _TDS_Handle *****************
;; Defined at:
;;		line 439 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  TDSTyp          1    wreg     PTR struct .
;;		 -> PureTDSTyp(17), 
;;  Type            1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  TDSTyp          1   29[BANK0 ] PTR struct .
;;		 -> PureTDSTyp(17), 
;;  Muni_c          4   25[BANK0 ] unsigned long 
;;  NTC_            4   19[BANK0 ] unsigned long 
;;  i               2   23[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         0      11       0       0
;;      Temps:          0       4       0       0
;;      Totals:         1      15       0       0
;;Total ram usage:       16 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_GetCurTdsHz
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text32,local,class=CODE,delta=2,merge=1,group=0
	line	439
global __ptext32
__ptext32:	;psect for function _TDS_Handle
psect	text32
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	439
	global	__size_of_TDS_Handle
	__size_of_TDS_Handle	equ	__end_of_TDS_Handle-_TDS_Handle
	
_TDS_Handle:	
;incstack = 0
	opt	stack 6
; Regs used in _TDS_Handle: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
;TDS_Handle@TDSTyp stored from wreg
	movwf	(TDS_Handle@TDSTyp)
	line	442
	
l10123:	
	line	443
;main.c: 443: U32_T Muni_c=0;
	clrf	(TDS_Handle@Muni_c)
	clrf	(TDS_Handle@Muni_c+1)
	clrf	(TDS_Handle@Muni_c+2)
	clrf	(TDS_Handle@Muni_c+3)
	line	447
	
l10125:	
	line	448
	
l10127:	
;main.c: 448: Temp_Ntc=25;
	movlw	low(019h)
	movwf	(_Temp_Ntc)
	line	449
	
l10129:	
;main.c: 449: (TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)])=(TDSTyp->HzCount);
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Dh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+1
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	clrc
	rlf	indf,w
	addwf	(TDS_Handle@TDSTyp),w
	movwf	(??_TDS_Handle+2)+0
	movf	0+(??_TDS_Handle+2)+0,w
	movwf	fsr0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	indf
	line	450
	
l10131:	
;main.c: 450: (TDSTyp->HzCount)=0;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Dh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	452
	
l10133:	
;main.c: 452: if(Mode!=5){
		movlw	5
	xorwf	((_Mode)),w
	btfsc	status,2
	goto	u8961
	goto	u8960
u8961:
	goto	l10151
u8960:
	line	453
	
l10135:	
;main.c: 453: if(Type==1){
		decf	((TDS_Handle@Type)),w
	btfss	status,2
	goto	u8971
	goto	u8970
u8971:
	goto	l1052
u8970:
	line	455
	
l10137:	
;main.c: 455: if(Temp_Ntc >= 25){
	movlw	low(019h)
	subwf	(_Temp_Ntc),w
	skipc
	goto	u8981
	goto	u8980
u8981:
	goto	l10141
u8980:
	line	456
	
l10139:	
;main.c: 456: NTC_ = (U32_T)(Temp_Ntc -25);
	movf	(_Temp_Ntc),w
	addlw	low(-25)
	movwf	(TDS_Handle@NTC_)
	movlw	high(-25)
	skipnc
	movlw	(high(-25)+1)&0ffh
	movwf	((TDS_Handle@NTC_))+1
	clrf	(TDS_Handle@NTC_)+2
	btfsc	(TDS_Handle@NTC_)+1,7
	decf	2+(TDS_Handle@NTC_),f
	movf	(TDS_Handle@NTC_)+2,w
	movwf	3+(TDS_Handle@NTC_)
	line	457
;main.c: 457: NTC_ += 100;
	movlw	064h
	addwf	(TDS_Handle@NTC_),f
	movlw	1
	skipnc
	addwf	(TDS_Handle@NTC_+1),f
	skipnc
	addwf	(TDS_Handle@NTC_+2),f
	skipnc
	addwf	(TDS_Handle@NTC_+3),f
	line	458
;main.c: 458: }
	goto	l10143
	line	460
	
l10141:	
;main.c: 459: else {
;main.c: 460: NTC_ = (U32_T)(25-Temp_Ntc);
	movlw	019h
	movwf	(??_TDS_Handle+0)+0
	movf	(_Temp_Ntc),w
	subwf	(??_TDS_Handle+0)+0,w
	movwf	(TDS_Handle@NTC_)
	clrf	(TDS_Handle@NTC_)+1
	skipc
	decf	1+(TDS_Handle@NTC_),f
	
	clrf	(TDS_Handle@NTC_)+2
	btfsc	(TDS_Handle@NTC_)+1,7
	decf	2+(TDS_Handle@NTC_),f
	movf	(TDS_Handle@NTC_)+2,w
	movwf	3+(TDS_Handle@NTC_)
	line	461
;main.c: 461: NTC_ = 100-NTC_;
	movlw	064h
	movwf	((??_TDS_Handle+0)+0)
	movlw	0
	movwf	((??_TDS_Handle+0)+0+1)
	movlw	0
	movwf	((??_TDS_Handle+0)+0+2)
	movlw	0
	movwf	((??_TDS_Handle+0)+0+3)
	movf	(TDS_Handle@NTC_),w
	subwf	(??_TDS_Handle+0)+0,f
	movf	(TDS_Handle@NTC_+1),w
	skipc
	incfsz	(TDS_Handle@NTC_+1),w
	goto	u8991
	goto	u8992
u8991:
	subwf	(??_TDS_Handle+0)+1,f
u8992:
	movf	(TDS_Handle@NTC_+2),w
	skipc
	incfsz	(TDS_Handle@NTC_+2),w
	goto	u8993
	goto	u8994
u8993:
	subwf	(??_TDS_Handle+0)+2,f
u8994:
	movf	(TDS_Handle@NTC_+3),w
	skipc
	incfsz	(TDS_Handle@NTC_+3),w
	goto	u8995
	goto	u8996
u8995:
	subwf	(??_TDS_Handle+0)+3,f
u8996:

	movf	3+(??_TDS_Handle+0)+0,w
	movwf	(TDS_Handle@NTC_+3)
	movf	2+(??_TDS_Handle+0)+0,w
	movwf	(TDS_Handle@NTC_+2)
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	(TDS_Handle@NTC_+1)
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	(TDS_Handle@NTC_)

	line	464
	
l10143:	
;main.c: 462: }
;main.c: 464: Muni_c = TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)];
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	clrc
	rlf	indf,w
	addwf	(TDS_Handle@TDSTyp),w
	movwf	(??_TDS_Handle+0)+0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+1)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+1)+0+1
	movf	0+(??_TDS_Handle+1)+0,w
	movwf	(TDS_Handle@Muni_c)
	movf	1+(??_TDS_Handle+1)+0,w
	movwf	((TDS_Handle@Muni_c))+1
	clrf	2+((TDS_Handle@Muni_c))
	clrf	3+((TDS_Handle@Muni_c))
	line	465
	
l10145:	
;main.c: 465: Muni_c *= 100;
	movlw	064h
	movwf	(___lmul@multiplier)
	clrf	(___lmul@multiplier+1)
	clrf	(___lmul@multiplier+2)
	clrf	(___lmul@multiplier+3)

	movf	(TDS_Handle@Muni_c+3),w
	movwf	(___lmul@multiplicand+3)
	movf	(TDS_Handle@Muni_c+2),w
	movwf	(___lmul@multiplicand+2)
	movf	(TDS_Handle@Muni_c+1),w
	movwf	(___lmul@multiplicand+1)
	movf	(TDS_Handle@Muni_c),w
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(TDS_Handle@Muni_c+3)
	movf	(2+(?___lmul)),w
	movwf	(TDS_Handle@Muni_c+2)
	movf	(1+(?___lmul)),w
	movwf	(TDS_Handle@Muni_c+1)
	movf	(0+(?___lmul)),w
	movwf	(TDS_Handle@Muni_c)

	line	466
	
l10147:	
;main.c: 466: Muni_c /= NTC_;
	movf	(TDS_Handle@NTC_+3),w
	movwf	(___lldiv@divisor+3)
	movf	(TDS_Handle@NTC_+2),w
	movwf	(___lldiv@divisor+2)
	movf	(TDS_Handle@NTC_+1),w
	movwf	(___lldiv@divisor+1)
	movf	(TDS_Handle@NTC_),w
	movwf	(___lldiv@divisor)

	movf	(TDS_Handle@Muni_c+3),w
	movwf	(___lldiv@dividend+3)
	movf	(TDS_Handle@Muni_c+2),w
	movwf	(___lldiv@dividend+2)
	movf	(TDS_Handle@Muni_c+1),w
	movwf	(___lldiv@dividend+1)
	movf	(TDS_Handle@Muni_c),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(TDS_Handle@Muni_c+3)
	movf	(2+(?___lldiv)),w
	movwf	(TDS_Handle@Muni_c+2)
	movf	(1+(?___lldiv)),w
	movwf	(TDS_Handle@Muni_c+1)
	movf	(0+(?___lldiv)),w
	movwf	(TDS_Handle@Muni_c)

	line	467
	
l10149:	
;main.c: 467: TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)] = Muni_c;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	clrc
	rlf	indf,w
	addwf	(TDS_Handle@TDSTyp),w
	movwf	(??_TDS_Handle+0)+0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	fsr0
	movf	(TDS_Handle@Muni_c),w
	movwf	indf
	incf	fsr0,f
	movf	(TDS_Handle@Muni_c+1),w
	movwf	indf
	line	468
;main.c: 468: }
	goto	l10151
	line	469
	
l1052:	
	line	497
	
l10151:	
;main.c: 472: }
;main.c: 473: }
;main.c: 497: (TDSTyp->TdsTime)++;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	incf	indf,f
	line	498
;main.c: 498: if((TDSTyp->TdsTime)>=5){
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u9001
	goto	u9000
u9001:
	goto	l1081
u9000:
	line	499
	
l10153:	
;main.c: 499: (TDSTyp->TdsTime)=0;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	clrf	indf
	line	501
;main.c: 501: (TDSTyp->TdsHz)=0;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	502
	
l10155:	
;main.c: 502: for(i=0;i<5;i++){
	clrf	(TDS_Handle@i)
	clrf	(TDS_Handle@i+1)
	line	503
	
l10161:	
;main.c: 503: TDSTyp->TdsHz+=TDSTyp->TdsHz_Tab[i];
	clrc
	rlf	(TDS_Handle@i),w
	addwf	(TDS_Handle@TDSTyp),w
	movwf	(??_TDS_Handle+0)+0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+1)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+1)+0+1
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	movf	0+(??_TDS_Handle+1)+0,w
	addwf	indf,f
	incfsz	fsr0,f
	movf	indf,w
	skipnc
	incf	indf,w
	movwf	btemp+1
	movf	1+(??_TDS_Handle+1)+0,w
	addwf	btemp+1,w
	movwf	indf
	decf	fsr0,f
	line	502
	
l10163:	
	incf	(TDS_Handle@i),f
	skipnz
	incf	(TDS_Handle@i+1),f
	
l10165:	
	movlw	0
	subwf	(TDS_Handle@i+1),w
	movlw	05h
	skipnz
	subwf	(TDS_Handle@i),w
	skipc
	goto	u9011
	goto	u9010
u9011:
	goto	l10161
u9010:
	line	505
	
l10167:	
;main.c: 504: }
;main.c: 505: (TDSTyp->TdsHz)/=5;
	movlw	05h
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	movf	indf,w
	movwf	(___lwdiv@dividend)
	incf	fsr0,f
	movf	indf,w
	movwf	(___lwdiv@dividend+1)
	fcall	___lwdiv
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	movf	(0+(?___lwdiv)),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(1+(?___lwdiv)),w
	movwf	indf
	line	511
	
l10169:	
;main.c: 511: PreTdsData=TDSTyp->TdsData;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	indf,w
	movwf	(_PreTdsData)
	incf	fsr0,f
	movf	indf,w
	movwf	(_PreTdsData+1)
	line	512
	
l10171:	
;main.c: 512: if(TDSTyp->TdsHz>PureHz_Tab[189])
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+1
	movlw	low(((_PureHz_Tab+017Ah)|8000h))
	movwf	fsr0
	movlw	high(((_PureHz_Tab+017Ah)|8000h))
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_TDS_Handle+2)+0
	fcall	stringtab
	movwf	(??_TDS_Handle+2)+0+1
	movf	1+(??_TDS_Handle+0)+0,w
	subwf	1+(??_TDS_Handle+2)+0,w
	skipz
	goto	u9025
	movf	0+(??_TDS_Handle+0)+0,w
	subwf	0+(??_TDS_Handle+2)+0,w
u9025:
	skipnc
	goto	u9021
	goto	u9020
u9021:
	goto	l10175
u9020:
	line	514
	
l10173:	
;main.c: 513: {
;main.c: 514: TDSTyp->TdsData=189+(TDSTyp->TdsHz-PureHz_Tab[189])/5;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(___lwdiv@dividend)
	incf	fsr0,f
	movf	indf,w
	movwf	(___lwdiv@dividend+1)
	movlw	low(((_PureHz_Tab+017Ah)|8000h))
	movwf	fsr0
	movlw	high(((_PureHz_Tab+017Ah)|8000h))
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_TDS_Handle+0)+0
	fcall	stringtab
	movwf	(??_TDS_Handle+0)+0+1
	movf	0+(??_TDS_Handle+0)+0,w
	subwf	(___lwdiv@dividend),f
	movf	1+(??_TDS_Handle+0)+0,w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	movlw	05h
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	fcall	___lwdiv
	movf	(0+(?___lwdiv)),w
	addlw	low(0BDh)
	movwf	(??_TDS_Handle+2)+0
	movf	(1+(?___lwdiv)),w
	skipnc
	addlw	1
	addlw	high(0BDh)
	movwf	1+(??_TDS_Handle+2)+0
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	0+(??_TDS_Handle+2)+0,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+2)+0,w
	movwf	indf
	line	515
;main.c: 515: }
	goto	l10177
	line	518
	
l10175:	
;main.c: 516: else
;main.c: 517: {
;main.c: 518: TDSTyp->TdsData=GetCurTdsHz(TDSTyp,(U16_T *)PureHz_Tab,189);
	movlw	low(((_PureHz_Tab)|8000h))
	movwf	(GetCurTdsHz@Tab)
	movlw	high(((_PureHz_Tab)|8000h))
	movwf	((GetCurTdsHz@Tab))+1
	movlw	0BDh
	movwf	(GetCurTdsHz@index)
	clrf	(GetCurTdsHz@index+1)
	movf	(TDS_Handle@TDSTyp),w
	fcall	_GetCurTdsHz
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	(0+(?_GetCurTdsHz)),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(1+(?_GetCurTdsHz)),w
	movwf	indf
	line	521
	
l10177:	
;main.c: 519: }
;main.c: 521: if(TDSTyp->TdsData>999)
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+1
	movlw	03h
	subwf	1+(??_TDS_Handle+0)+0,w
	movlw	0E8h
	skipnz
	subwf	0+(??_TDS_Handle+0)+0,w
	skipc
	goto	u9031
	goto	u9030
u9031:
	goto	l10181
u9030:
	line	523
	
l10179:	
;main.c: 522: {
;main.c: 523: TDSTyp->TdsData=999;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movlw	0E7h
	movwf	indf
	incf	fsr0,f
	movlw	03h
	movwf	indf
	line	524
;main.c: 524: }
	goto	l10185
	line	525
	
l10181:	
;main.c: 525: else if(TDSTyp->TdsData<3)
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+1
	movlw	0
	subwf	1+(??_TDS_Handle+0)+0,w
	movlw	03h
	skipnz
	subwf	0+(??_TDS_Handle+0)+0,w
	skipnc
	goto	u9041
	goto	u9040
u9041:
	goto	l10185
u9040:
	line	527
	
l10183:	
;main.c: 526: {
;main.c: 527: TDSTyp->TdsData=3;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movlw	03h
	movwf	indf
	incf	fsr0,f
	movlw	0
	movwf	indf
	line	530
	
l10185:	
;main.c: 528: }
;main.c: 530: if(Mode!=5)
		movlw	5
	xorwf	((_Mode)),w
	btfsc	status,2
	goto	u9051
	goto	u9050
u9051:
	goto	l1064
u9050:
	line	548
	
l10187:	
;main.c: 531: {
;main.c: 548: if(_BITS.Bits.bit_6==0)
	btfsc	(__BITS),6
	goto	u9061
	goto	u9060
u9061:
	goto	l1064
u9060:
	line	550
	
l10189:	
;main.c: 549: {
;main.c: 550: if(TDSTyp->TdsData>=PreTdsData){
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+1
	movf	(_PreTdsData+1),w
	subwf	1+(??_TDS_Handle+0)+0,w
	skipz
	goto	u9075
	movf	(_PreTdsData),w
	subwf	0+(??_TDS_Handle+0)+0,w
u9075:
	skipc
	goto	u9071
	goto	u9070
u9071:
	goto	l1066
u9070:
	line	551
	
l10191:	
;main.c: 551: TdsCk60sFlag+=1;
	incf	(_TdsCk60sFlag),f
	line	552
	
l10193:	
;main.c: 552: if(TdsCk60sFlag>=4){
	movlw	low(04h)
	subwf	(_TdsCk60sFlag),w
	skipc
	goto	u9081
	goto	u9080
u9081:
	goto	l10197
u9080:
	line	553
	
l10195:	
;main.c: 553: TdsCk60sFlag=0;
	clrf	(_TdsCk60sFlag)
	line	555
	
l10197:	
;main.c: 554: }
;main.c: 555: if(TdsCk60sFlag==1){
		decf	((_TdsCk60sFlag)),w
	btfss	status,2
	goto	u9091
	goto	u9090
u9091:
	goto	l10201
u9090:
	line	556
	
l10199:	
;main.c: 556: TDSTyp->TdsData=PreTdsData+2;
	movf	(_PreTdsData),w
	addlw	low(02h)
	movwf	(??_TDS_Handle+0)+0
	movf	(_PreTdsData+1),w
	skipnc
	addlw	1
	addlw	high(02h)
	movwf	1+(??_TDS_Handle+0)+0
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	indf
	line	557
;main.c: 557: }
	goto	l1064
	line	558
	
l10201:	
;main.c: 558: else if(TdsCk60sFlag==2)
		movlw	2
	xorwf	((_TdsCk60sFlag)),w
	btfss	status,2
	goto	u9101
	goto	u9100
u9101:
	goto	l10209
u9100:
	line	560
	
l10203:	
;main.c: 559: {
;main.c: 560: if(PreTdsData>3)
	movlw	0
	subwf	(_PreTdsData+1),w
	movlw	04h
	skipnz
	subwf	(_PreTdsData),w
	skipc
	goto	u9111
	goto	u9110
u9111:
	goto	l10207
u9110:
	line	561
	
l10205:	
;main.c: 561: TDSTyp->TdsData=PreTdsData-3;
	movf	(_PreTdsData),w
	addlw	low(0FFFDh)
	movwf	(??_TDS_Handle+0)+0
	movf	(_PreTdsData+1),w
	skipnc
	addlw	1
	addlw	high(0FFFDh)
	movwf	1+(??_TDS_Handle+0)+0
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	indf
	goto	l1064
	line	562
	
l10207:	
;main.c: 562: else TDSTyp->TdsData=1;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movlw	01h
	movwf	indf
	incf	fsr0,f
	movlw	0
	movwf	indf
	goto	l1064
	line	564
	
l10209:	
;main.c: 564: else if(TdsCk60sFlag==3)
		movlw	3
	xorwf	((_TdsCk60sFlag)),w
	btfss	status,2
	goto	u9121
	goto	u9120
u9121:
	goto	l10217
u9120:
	line	566
	
l10211:	
;main.c: 565: {
;main.c: 566: if(PreTdsData>2)
	movlw	0
	subwf	(_PreTdsData+1),w
	movlw	03h
	skipnz
	subwf	(_PreTdsData),w
	skipc
	goto	u9131
	goto	u9130
u9131:
	goto	l10215
u9130:
	line	567
	
l10213:	
;main.c: 567: TDSTyp->TdsData=PreTdsData-2;
	movf	(_PreTdsData),w
	addlw	low(0FFFEh)
	movwf	(??_TDS_Handle+0)+0
	movf	(_PreTdsData+1),w
	skipnc
	addlw	1
	addlw	high(0FFFEh)
	movwf	1+(??_TDS_Handle+0)+0
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	indf
	goto	l1064
	line	568
	
l10215:	
;main.c: 568: else TDSTyp->TdsData=1;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movlw	01h
	movwf	indf
	incf	fsr0,f
	movlw	0
	movwf	indf
	goto	l1064
	line	571
	
l10217:	
;main.c: 571: else if(TdsCk60sFlag==0)
	movf	((_TdsCk60sFlag)),w
	btfss	status,2
	goto	u9141
	goto	u9140
u9141:
	goto	l1069
u9140:
	line	573
	
l10219:	
;main.c: 572: {
;main.c: 573: TDSTyp->TdsData=PreTdsData+3;
	movf	(_PreTdsData),w
	addlw	low(03h)
	movwf	(??_TDS_Handle+0)+0
	movf	(_PreTdsData+1),w
	skipnc
	addlw	1
	addlw	high(03h)
	movwf	1+(??_TDS_Handle+0)+0
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	indf
	goto	l1064
	line	575
	
l1069:	
;main.c: 574: }
;main.c: 575: }
	goto	l1064
	line	576
	
l1066:	
	line	578
;main.c: 576: else
;main.c: 577: {
;main.c: 578: _BITS.Bits.bit_6=1;
	bsf	(__BITS),6
	line	581
	
l1064:	
	line	582
;main.c: 579: }
;main.c: 580: }
;main.c: 581: }
;main.c: 582: if(_BITS.Bits.bit_6){
	btfss	(__BITS),6
	goto	u9151
	goto	u9150
u9151:
	goto	l1081
u9150:
	line	583
	
l10221:	
;main.c: 583: PreTdsData=TDSTyp->TdsData;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	indf,w
	movwf	(_PreTdsData)
	incf	fsr0,f
	movf	indf,w
	movwf	(_PreTdsData+1)
	line	602
	
l1081:	
	return
	opt stack 0
GLOBAL	__end_of_TDS_Handle
	__end_of_TDS_Handle:
	signat	_TDS_Handle,8313
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK0 ] unsigned int 
;;  dividend        2    2[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    5[BANK0 ] unsigned int 
;;  counter         1    4[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       4       0       0
;;      Locals:         0       3       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       7       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_TDS_Handle
;; This function uses a non-reentrant model
;;
psect	text33,local,class=CODE,delta=2,merge=1,group=2
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lwdiv.c"
	line	6
global __ptext33
__ptext33:	;psect for function ___lwdiv
psect	text33
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 6
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l10077:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l10079:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u8861
	goto	u8860
u8861:
	goto	l10099
u8860:
	line	16
	
l10081:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l10085
	line	18
	
l10083:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l10085:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u8871
	goto	u8870
u8871:
	goto	l10083
u8870:
	line	22
	
l10087:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l10089:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u8885
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u8885:
	skipc
	goto	u8881
	goto	u8880
u8881:
	goto	l10095
u8880:
	line	24
	
l10091:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l10093:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l10095:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l10097:	
	decfsz	(___lwdiv@counter),f
	goto	u8891
	goto	u8890
u8891:
	goto	l10087
u8890:
	line	30
	
l10099:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l4018:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    0[BANK0 ] unsigned long 
;;  multiplicand    4    4[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4    8[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    0[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       8       0       0
;;      Locals:         0       4       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_TDS_Handle
;; This function uses a non-reentrant model
;;
psect	text34,local,class=CODE,delta=2,merge=1,group=2
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul32.c"
	line	15
global __ptext34
__ptext34:	;psect for function ___lmul
psect	text34
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 6
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l10039:	
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l3686:	
	line	121
	btfss	(___lmul@multiplier),(0)&7
	goto	u8791
	goto	u8790
u8791:
	goto	l10043
u8790:
	line	122
	
l10041:	
	movf	(___lmul@multiplicand),w
	addwf	(___lmul@product),f
	movf	(___lmul@multiplicand+1),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u8801
	addwf	(___lmul@product+1),f
u8801:
	movf	(___lmul@multiplicand+2),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u8802
	addwf	(___lmul@product+2),f
u8802:
	movf	(___lmul@multiplicand+3),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u8803
	addwf	(___lmul@product+3),f
u8803:

	line	123
	
l10043:	
	clrc
	rlf	(___lmul@multiplicand),f
	rlf	(___lmul@multiplicand+1),f
	rlf	(___lmul@multiplicand+2),f
	rlf	(___lmul@multiplicand+3),f
	line	124
	
l10045:	
	clrc
	rrf	(___lmul@multiplier+3),f
	rrf	(___lmul@multiplier+2),f
	rrf	(___lmul@multiplier+1),f
	rrf	(___lmul@multiplier),f
	line	125
	movf	(___lmul@multiplier+3),w
	iorwf	(___lmul@multiplier+2),w
	iorwf	(___lmul@multiplier+1),w
	iorwf	(___lmul@multiplier),w
	skipz
	goto	u8811
	goto	u8810
u8811:
	goto	l3686
u8810:
	line	128
	
l10047:	
	movf	(___lmul@product+3),w
	movwf	(?___lmul+3)
	movf	(___lmul@product+2),w
	movwf	(?___lmul+2)
	movf	(___lmul@product+1),w
	movwf	(?___lmul+1)
	movf	(___lmul@product),w
	movwf	(?___lmul)

	line	129
	
l3689:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    0[BANK0 ] unsigned long 
;;  dividend        4    4[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4    8[BANK0 ] unsigned long 
;;  counter         1   12[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    0[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       8       0       0
;;      Locals:         0       5       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0      13       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_TDS_Handle
;; This function uses a non-reentrant model
;;
psect	text35,local,class=CODE,delta=2,merge=1,group=2
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lldiv.c"
	line	6
global __ptext35
__ptext35:	;psect for function ___lldiv
psect	text35
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 6
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l10051:	
	clrf	(___lldiv@quotient)
	clrf	(___lldiv@quotient+1)
	clrf	(___lldiv@quotient+2)
	clrf	(___lldiv@quotient+3)
	line	15
	
l10053:	
	movf	(___lldiv@divisor+3),w
	iorwf	(___lldiv@divisor+2),w
	iorwf	(___lldiv@divisor+1),w
	iorwf	(___lldiv@divisor),w
	skipnz
	goto	u8821
	goto	u8820
u8821:
	goto	l10073
u8820:
	line	16
	
l10055:	
	clrf	(___lldiv@counter)
	incf	(___lldiv@counter),f
	line	17
	goto	l10059
	line	18
	
l10057:	
	clrc
	rlf	(___lldiv@divisor),f
	rlf	(___lldiv@divisor+1),f
	rlf	(___lldiv@divisor+2),f
	rlf	(___lldiv@divisor+3),f
	line	19
	incf	(___lldiv@counter),f
	line	17
	
l10059:	
	btfss	(___lldiv@divisor+3),(31)&7
	goto	u8831
	goto	u8830
u8831:
	goto	l10057
u8830:
	line	22
	
l10061:	
	clrc
	rlf	(___lldiv@quotient),f
	rlf	(___lldiv@quotient+1),f
	rlf	(___lldiv@quotient+2),f
	rlf	(___lldiv@quotient+3),f
	line	23
	
l10063:	
	movf	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),w
	skipz
	goto	u8845
	movf	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),w
	skipz
	goto	u8845
	movf	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),w
	skipz
	goto	u8845
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),w
u8845:
	skipc
	goto	u8841
	goto	u8840
u8841:
	goto	l10069
u8840:
	line	24
	
l10065:	
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),f
	movf	(___lldiv@divisor+1),w
	skipc
	incfsz	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),f
	movf	(___lldiv@divisor+2),w
	skipc
	incfsz	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),f
	movf	(___lldiv@divisor+3),w
	skipc
	incfsz	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),f
	line	25
	
l10067:	
	bsf	(___lldiv@quotient)+(0/8),(0)&7
	line	27
	
l10069:	
	clrc
	rrf	(___lldiv@divisor+3),f
	rrf	(___lldiv@divisor+2),f
	rrf	(___lldiv@divisor+1),f
	rrf	(___lldiv@divisor),f
	line	28
	
l10071:	
	decfsz	(___lldiv@counter),f
	goto	u8851
	goto	u8850
u8851:
	goto	l10061
u8850:
	line	30
	
l10073:	
	movf	(___lldiv@quotient+3),w
	movwf	(?___lldiv+3)
	movf	(___lldiv@quotient+2),w
	movwf	(?___lldiv+2)
	movf	(___lldiv@quotient+1),w
	movwf	(?___lldiv+1)
	movf	(___lldiv@quotient),w
	movwf	(?___lldiv)

	line	31
	
l3965:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	_GetCurTdsHz

;; *************** function _GetCurTdsHz *****************
;; Defined at:
;;		line 364 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  AdPtr           1    wreg     PTR struct .
;;		 -> PureTDSTyp(17), 
;;  Tab             2    0[BANK0 ] PTR unsigned int 
;;		 -> PureHz_Tab(380), 
;;  index           2    2[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  AdPtr           1   14[BANK0 ] PTR struct .
;;		 -> PureTDSTyp(17), 
;;  tmp             2   12[BANK0 ] unsigned int 
;;  i               2   10[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2    0[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       4       0       0
;;      Locals:         0       5       0       0
;;      Temps:          0       6       0       0
;;      Totals:         0      15       0       0
;;Total ram usage:       15 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_TDS_Handle
;; This function uses a non-reentrant model
;;
psect	text36,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	364
global __ptext36
__ptext36:	;psect for function _GetCurTdsHz
psect	text36
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	364
	global	__size_of_GetCurTdsHz
	__size_of_GetCurTdsHz	equ	__end_of_GetCurTdsHz-_GetCurTdsHz
	
_GetCurTdsHz:	
;incstack = 0
	opt	stack 6
; Regs used in _GetCurTdsHz: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
;GetCurTdsHz@AdPtr stored from wreg
	movwf	(GetCurTdsHz@AdPtr)
	line	367
	
l9129:	
;main.c: 366: U16_T tmp, i;
;main.c: 367: tmp=0x00;
	clrf	(GetCurTdsHz@tmp)
	clrf	(GetCurTdsHz@tmp+1)
	line	369
	
l9131:	
;main.c: 369: if(AdPtr->TdsHz<Tab[0])
	movf	(GetCurTdsHz@Tab+1),w
	movwf	btemp+1
	movf	(GetCurTdsHz@Tab),w
	movwf	fsr0
	fcall	stringtab
	movwf	(??_GetCurTdsHz+0)+0
	fcall	stringtab
	movwf	(??_GetCurTdsHz+0)+0+1
	movf	(GetCurTdsHz@AdPtr),w
	addlw	0Bh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_GetCurTdsHz+2)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_GetCurTdsHz+2)+0+1
	movf	1+(??_GetCurTdsHz+0)+0,w
	subwf	1+(??_GetCurTdsHz+2)+0,w
	skipz
	goto	u7345
	movf	0+(??_GetCurTdsHz+0)+0,w
	subwf	0+(??_GetCurTdsHz+2)+0,w
u7345:
	skipnc
	goto	u7341
	goto	u7340
u7341:
	goto	l9135
u7340:
	goto	l1014
	line	372
	
l9135:	
;main.c: 372: else if(AdPtr->TdsHz>=Tab[index]){tmp=index;}
	movf	(GetCurTdsHz@index+1),w
	movwf	(??_GetCurTdsHz+0)+0+1
	movf	(GetCurTdsHz@index),w
	movwf	(??_GetCurTdsHz+0)+0
	clrc
	rlf	(??_GetCurTdsHz+0)+0,f
	rlf	(??_GetCurTdsHz+0)+1,f
	movf	0+(??_GetCurTdsHz+0)+0,w
	addwf	(GetCurTdsHz@Tab),w
	movwf	fsr0
	movf	1+(??_GetCurTdsHz+0)+0,w
	skipnc
	incf	1+(??_GetCurTdsHz+0)+0,w
	addwf	(GetCurTdsHz@Tab+1),w
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_GetCurTdsHz+2)+0
	fcall	stringtab
	movwf	(??_GetCurTdsHz+2)+0+1
	movf	(GetCurTdsHz@AdPtr),w
	addlw	0Bh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_GetCurTdsHz+4)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_GetCurTdsHz+4)+0+1
	movf	1+(??_GetCurTdsHz+2)+0,w
	subwf	1+(??_GetCurTdsHz+4)+0,w
	skipz
	goto	u7355
	movf	0+(??_GetCurTdsHz+2)+0,w
	subwf	0+(??_GetCurTdsHz+4)+0,w
u7355:
	skipc
	goto	u7351
	goto	u7350
u7351:
	goto	l9139
u7350:
	
l9137:	
	movf	(GetCurTdsHz@index+1),w
	movwf	(GetCurTdsHz@tmp+1)
	movf	(GetCurTdsHz@index),w
	movwf	(GetCurTdsHz@tmp)
	goto	l1014
	line	375
	
l9139:	
;main.c: 373: else
;main.c: 374: {
;main.c: 375: for(i = 10; i < index; )
	movlw	0Ah
	movwf	(GetCurTdsHz@i)
	clrf	(GetCurTdsHz@i+1)
	goto	l1017
	line	377
	
l9141:	
;main.c: 376: {
;main.c: 377: if(AdPtr->TdsHz >= Tab[i]){tmp = i;}
	movf	(GetCurTdsHz@i+1),w
	movwf	(??_GetCurTdsHz+0)+0+1
	movf	(GetCurTdsHz@i),w
	movwf	(??_GetCurTdsHz+0)+0
	clrc
	rlf	(??_GetCurTdsHz+0)+0,f
	rlf	(??_GetCurTdsHz+0)+1,f
	movf	0+(??_GetCurTdsHz+0)+0,w
	addwf	(GetCurTdsHz@Tab),w
	movwf	fsr0
	movf	1+(??_GetCurTdsHz+0)+0,w
	skipnc
	incf	1+(??_GetCurTdsHz+0)+0,w
	addwf	(GetCurTdsHz@Tab+1),w
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_GetCurTdsHz+2)+0
	fcall	stringtab
	movwf	(??_GetCurTdsHz+2)+0+1
	movf	(GetCurTdsHz@AdPtr),w
	addlw	0Bh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_GetCurTdsHz+4)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_GetCurTdsHz+4)+0+1
	movf	1+(??_GetCurTdsHz+2)+0,w
	subwf	1+(??_GetCurTdsHz+4)+0,w
	skipz
	goto	u7365
	movf	0+(??_GetCurTdsHz+2)+0,w
	subwf	0+(??_GetCurTdsHz+4)+0,w
u7365:
	skipc
	goto	u7361
	goto	u7360
u7361:
	goto	l1019
u7360:
	
l9143:	
	movf	(GetCurTdsHz@i+1),w
	movwf	(GetCurTdsHz@tmp+1)
	movf	(GetCurTdsHz@i),w
	movwf	(GetCurTdsHz@tmp)
	
l1019:	
	line	378
;main.c: 378: i += 10;
	movlw	0Ah
	addwf	(GetCurTdsHz@i),f
	skipnc
	incf	(GetCurTdsHz@i+1),f
	line	375
	
l1017:	
	movf	(GetCurTdsHz@index+1),w
	subwf	(GetCurTdsHz@i+1),w
	skipz
	goto	u7375
	movf	(GetCurTdsHz@index),w
	subwf	(GetCurTdsHz@i),w
u7375:
	skipc
	goto	u7371
	goto	u7370
u7371:
	goto	l9141
u7370:
	line	380
	
l9145:	
	movf	(GetCurTdsHz@AdPtr),w
	addlw	0Bh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_GetCurTdsHz+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_GetCurTdsHz+0)+0+1
	movf	(GetCurTdsHz@tmp+1),w
	movwf	(??_GetCurTdsHz+2)+0+1
	movf	(GetCurTdsHz@tmp),w
	movwf	(??_GetCurTdsHz+2)+0
	incf	(GetCurTdsHz@tmp),f
	skipnz
	incf	(GetCurTdsHz@tmp+1),f
	clrc
	rlf	(??_GetCurTdsHz+2)+0,f
	rlf	(??_GetCurTdsHz+2)+1,f
	movf	0+(??_GetCurTdsHz+2)+0,w
	addwf	(GetCurTdsHz@Tab),w
	movwf	fsr0
	movf	1+(??_GetCurTdsHz+2)+0,w
	skipnc
	incf	1+(??_GetCurTdsHz+2)+0,w
	addwf	(GetCurTdsHz@Tab+1),w
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_GetCurTdsHz+4)+0
	fcall	stringtab
	movwf	(??_GetCurTdsHz+4)+0+1
	movf	1+(??_GetCurTdsHz+0)+0,w
	subwf	1+(??_GetCurTdsHz+4)+0,w
	skipz
	goto	u7385
	movf	0+(??_GetCurTdsHz+0)+0,w
	subwf	0+(??_GetCurTdsHz+4)+0,w
u7385:
	skipc
	goto	u7381
	goto	u7380
u7381:
	goto	l9145
u7380:
	line	381
	
l9147:	
;main.c: 381: if(tmp){tmp--;}
	movf	((GetCurTdsHz@tmp)),w
iorwf	((GetCurTdsHz@tmp+1)),w
	btfsc	status,2
	goto	u7391
	goto	u7390
u7391:
	goto	l1014
u7390:
	
l9149:	
	movlw	01h
	subwf	(GetCurTdsHz@tmp),f
	movlw	0
	skipc
	decf	(GetCurTdsHz@tmp+1),f
	subwf	(GetCurTdsHz@tmp+1),f
	line	382
	
l1014:	
	line	383
;main.c: 382: }
;main.c: 383: return(tmp);
	movf	(GetCurTdsHz@tmp+1),w
	movwf	(?_GetCurTdsHz+1)
	movf	(GetCurTdsHz@tmp),w
	movwf	(?_GetCurTdsHz)
	line	385
	
l1025:	
	return
	opt stack 0
GLOBAL	__end_of_GetCurTdsHz
	__end_of_GetCurTdsHz:
	signat	_GetCurTdsHz,12410
	global	_Page_ProgramData

;; *************** function _Page_ProgramData *****************
;; Defined at:
;;		line 2676 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               2    3[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       2       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Memory_Write
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text37,local,class=CODE,delta=2,merge=1,group=0
	line	2676
global __ptext37
__ptext37:	;psect for function _Page_ProgramData
psect	text37
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	2676
	global	__size_of_Page_ProgramData
	__size_of_Page_ProgramData	equ	__end_of_Page_ProgramData-_Page_ProgramData
	
_Page_ProgramData:	
;incstack = 0
	opt	stack 6
; Regs used in _Page_ProgramData: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	2677
	
l10671:	
;main.c: 2677: unsigned int i=0;
	clrf	(Page_ProgramData@i)
	clrf	(Page_ProgramData@i+1)
	line	2678
;main.c: 2678: for(i=0;i<12;i++){
	clrf	(Page_ProgramData@i)
	clrf	(Page_ProgramData@i+1)
	line	2679
	
l10677:	
;main.c: 2679: Memory_Write(i,Read_Word_Buff[i]);
	movf	(Page_ProgramData@i+1),w
	movwf	(Memory_Write@Addr+1)
	movf	(Page_ProgramData@i),w
	movwf	(Memory_Write@Addr)
	movf	(Page_ProgramData@i),w
	addlw	low(_Read_Word_Buff|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(Memory_Write@Value)
	fcall	_Memory_Write
	line	2678
	
l10679:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(Page_ProgramData@i),f
	skipnz
	incf	(Page_ProgramData@i+1),f
	
l10681:	
	movlw	0
	subwf	(Page_ProgramData@i+1),w
	movlw	0Ch
	skipnz
	subwf	(Page_ProgramData@i),w
	skipc
	goto	u9911
	goto	u9910
u9911:
	goto	l10677
u9910:
	line	2681
	
l1499:	
	return
	opt stack 0
GLOBAL	__end_of_Page_ProgramData
	__end_of_Page_ProgramData:
	signat	_Page_ProgramData,89
	global	_Memory_Write

;; *************** function _Memory_Write *****************
;; Defined at:
;;		line 1763 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Addr            2    0[BANK0 ] unsigned int 
;;  Value           1    2[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  i               1    4[COMMON] volatile unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       3       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       3       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Page_ProgramData
;; This function uses a non-reentrant model
;;
psect	text38,local,class=CODE,delta=2,merge=1,group=0
	line	1763
global __ptext38
__ptext38:	;psect for function _Memory_Write
psect	text38
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	1763
	global	__size_of_Memory_Write
	__size_of_Memory_Write	equ	__end_of_Memory_Write-_Memory_Write
	
_Memory_Write:	
;incstack = 0
	opt	stack 6
; Regs used in _Memory_Write: [wreg+status,2]
	line	1766
	
l9357:	
;main.c: 1766: volatile unsigned char i = 0;
	clrf	(Memory_Write@i)	;volatile
	line	1769
	
l9359:	
;main.c: 1769: EEADR = Addr;
	movf	(Memory_Write@Addr),w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(391)^0180h	;volatile
	line	1770
	
l9361:	
;main.c: 1770: EEDAT= Value;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Memory_Write@Value),w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(390)^0180h	;volatile
	line	1771
;main.c: 1771: EECON1 = 0;
	clrf	(396)^0180h	;volsfr
	line	1772
	
l9363:	
;main.c: 1772: EEPGD = 0;
	bcf	(3175/8)^0180h,(3175)&7	;volsfr
	line	1773
	
l9365:	
;main.c: 1773: EECON1 | = 0x10;
	bsf	(396)^0180h+(4/8),(4)&7	;volsfr
	line	1774
# 1774 "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text38
	line	1777
	
l9367:	
;main.c: 1777: WREN = 1;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	bsf	(3170/8)^0180h,(3170)&7	;volsfr
	line	1778
	
l9369:	
;main.c: 1778: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	1779
	
l9371:	
;main.c: 1779: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	1780
	
l9373:	
;main.c: 1780: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	1781
;main.c: 1781: while(GIE)
	goto	l1347
	
l1348:	
	line	1783
;main.c: 1782: {
;main.c: 1783: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	1784
;main.c: 1784: if(0 == --i)
	decfsz	(Memory_Write@i),f	;volatile
	goto	u7771
	goto	u7770
u7771:
	goto	l1347
u7770:
	line	1787
	
l9375:	
;main.c: 1785: {
;main.c: 1787: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	1788
;main.c: 1788: return 0;
;	Return value of _Memory_Write is never used
	goto	l1350
	line	1790
	
l1347:	
	line	1781
	btfsc	(95/8),(95)&7	;volatile
	goto	u7781
	goto	u7780
u7781:
	goto	l1348
u7780:
	
l1351:	
	line	1791
# 1791 "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text38
	line	1793
	
l9377:	
;main.c: 1793: EECON2 = 0x55;
	movlw	low(055h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(397)^0180h	;volsfr
	line	1794
;main.c: 1794: EECON2 = 0xaa;
	movlw	low(0AAh)
	movwf	(397)^0180h	;volsfr
	line	1795
	
l9379:	
;main.c: 1795: WR = 1;
	bsf	(3169/8)^0180h,(3169)&7	;volsfr
	line	1796
# 1796 "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	1797
# 1797 "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	1798
# 1798 "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text38
	line	1799
	
l9381:	
;main.c: 1799: WREN = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	bcf	(3170/8)^0180h,(3170)&7	;volsfr
	line	1801
	
l9383:	
;main.c: 1801: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	1803
	
l9385:	
;main.c: 1803: if(WRERR) return 0;
	line	1805
	
l1350:	
	return
	opt stack 0
GLOBAL	__end_of_Memory_Write
	__end_of_Memory_Write:
	signat	_Memory_Write,8313
	global	_Led_Handle

;; *************** function _Led_Handle *****************
;; Defined at:
;;		line 970 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               2    4[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       2       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_LedControlSt
;;		___bmul
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text39,local,class=CODE,delta=2,merge=1,group=0
	line	970
global __ptext39
__ptext39:	;psect for function _Led_Handle
psect	text39
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	970
	global	__size_of_Led_Handle
	__size_of_Led_Handle	equ	__end_of_Led_Handle-_Led_Handle
	
_Led_Handle:	
;incstack = 0
	opt	stack 6
; Regs used in _Led_Handle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	971
	
l10433:	
;main.c: 971: unsigned int i=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(Led_Handle@i)
	clrf	(Led_Handle@i+1)
	line	973
;main.c: 973: for(i=0;i<6;i++){
	clrf	(Led_Handle@i)
	clrf	(Led_Handle@i+1)
	line	974
	
l10439:	
;main.c: 974: LedMod[i].LedTime++;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	bsf	status, 7	;select IRP bank2
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	975
;main.c: 975: switch(LedMod[i].LedState){
	goto	l10483
	line	977
	
l10441:	
;main.c: 977: LedControlSt(i,0);
	clrf	(LedControlSt@Sta)
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	978
;main.c: 978: break;
	goto	l10485
	line	980
	
l10443:	
;main.c: 980: LedControlSt(i,1);
	clrf	(LedControlSt@Sta)
	incf	(LedControlSt@Sta),f
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	981
;main.c: 981: break;
	goto	l10485
	line	983
	
l10445:	
;main.c: 983: if(LedMod[i].LedFlashNum){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movf	((??_Led_Handle+0)+0),w
iorwf	((??_Led_Handle+0)+1),w
	btfsc	status,2
	goto	u9551
	goto	u9550
u9551:
	goto	l1159
u9550:
	line	984
	
l10447:	
;main.c: 984: if(LedMod[i].LedTime<=25){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	01Ah
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9561
	goto	u9560
u9561:
	goto	l10451
u9560:
	line	985
	
l10449:	
;main.c: 985: LedControlSt(i,0);
	clrf	(LedControlSt@Sta)
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	986
;main.c: 986: }
	goto	l10485
	line	987
	
l10451:	
;main.c: 987: else if(LedMod[i].LedTime<=25*2)
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	033h
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9571
	goto	u9570
u9571:
	goto	l10455
u9570:
	line	989
	
l10453:	
;main.c: 988: {
;main.c: 989: LedControlSt(i,1);
	clrf	(LedControlSt@Sta)
	incf	(LedControlSt@Sta),f
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	990
;main.c: 990: }
	goto	l10485
	line	993
	
l10455:	
;main.c: 991: else
;main.c: 992: {
;main.c: 993: LedMod[i].LedFlashNum--;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	movlw	low(01h)
	bsf	status, 7	;select IRP bank2
	subwf	indf,f
	incfsz	fsr0,f
	movlw	high(01h)
	skipc
	decf	indf,f
	subwf	indf,f
	decf	fsr0,f
	line	994
;main.c: 994: LedMod[i].LedTime=0;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l10485
	line	997
	
l1159:	
	line	999
;main.c: 997: else
;main.c: 998: {
;main.c: 999: _BITS.Bits.bit_0=0;
	bcf	(__BITS),0
	goto	l10485
	line	1003
	
l10457:	
;main.c: 1003: if(LedMod[i].LedTime<=100){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	065h
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9581
	goto	u9580
u9581:
	goto	l10461
u9580:
	line	1004
	
l10459:	
;main.c: 1004: LedControlSt(i,1);
	clrf	(LedControlSt@Sta)
	incf	(LedControlSt@Sta),f
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	1005
;main.c: 1005: }
	goto	l10485
	line	1006
	
l10461:	
;main.c: 1006: else if(LedMod[i].LedTime<=100*2)
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	0C9h
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9591
	goto	u9590
u9591:
	goto	l10465
u9590:
	line	1008
	
l10463:	
;main.c: 1007: {
;main.c: 1008: LedControlSt(i,0);
	clrf	(LedControlSt@Sta)
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	1009
;main.c: 1009: }
	goto	l10485
	line	1012
	
l10465:	
;main.c: 1010: else
;main.c: 1011: {
;main.c: 1012: LedMod[i].LedTime=0;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l10485
	line	1017
	
l10467:	
;main.c: 1017: if(LedMod[i].LedFlashNum){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movf	((??_Led_Handle+0)+0),w
iorwf	((??_Led_Handle+0)+1),w
	btfsc	status,2
	goto	u9601
	goto	u9600
u9601:
	goto	l1171
u9600:
	line	1018
	
l10469:	
;main.c: 1018: if(LedMod[i].LedTime<=100){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	065h
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9611
	goto	u9610
u9611:
	goto	l10473
u9610:
	line	1019
	
l10471:	
;main.c: 1019: LedControlSt(i,0);
	clrf	(LedControlSt@Sta)
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	1020
;main.c: 1020: }
	goto	l10485
	line	1021
	
l10473:	
;main.c: 1021: else if(LedMod[i].LedTime<=100*2)
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	0C9h
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9621
	goto	u9620
u9621:
	goto	l10477
u9620:
	line	1023
	
l10475:	
;main.c: 1022: {
;main.c: 1023: LedControlSt(i,1);
	clrf	(LedControlSt@Sta)
	incf	(LedControlSt@Sta),f
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	1024
;main.c: 1024: }
	goto	l10485
	line	1027
	
l10477:	
;main.c: 1025: else
;main.c: 1026: {
;main.c: 1027: LedMod[i].LedFlashNum--;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	movlw	low(01h)
	bsf	status, 7	;select IRP bank2
	subwf	indf,f
	incfsz	fsr0,f
	movlw	high(01h)
	skipc
	decf	indf,f
	subwf	indf,f
	decf	fsr0,f
	line	1028
;main.c: 1028: LedMod[i].LedTime=0;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l10485
	line	1031
	
l1171:	
	line	1033
;main.c: 1031: else
;main.c: 1032: {
;main.c: 1033: _BITS.Bits.bit_0=0;
	bcf	(__BITS),0
	line	1034
	
l10479:	
;main.c: 1034: LedControlSt(i,0);
	clrf	(LedControlSt@Sta)
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	1035
;main.c: 1035: LedMod[i].LedState=0;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	goto	l10485
	line	975
	
l10483:	
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	; Switch size 1, requested type "space"
; Number of cases is 5, Range of values is 0 to 5
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           16     9 (average)
; direct_byte           26     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l10441
	xorlw	1^0	; case 1
	skipnz
	goto	l10443
	xorlw	2^1	; case 2
	skipnz
	goto	l10445
	xorlw	3^2	; case 3
	skipnz
	goto	l10457
	xorlw	5^3	; case 5
	skipnz
	goto	l10467
	goto	l10485
	opt asmopt_pop

	line	973
	
l10485:	
	incf	(Led_Handle@i),f
	skipnz
	incf	(Led_Handle@i+1),f
	
l10487:	
	movlw	0
	subwf	(Led_Handle@i+1),w
	movlw	06h
	skipnz
	subwf	(Led_Handle@i),w
	skipc
	goto	u9631
	goto	u9630
u9631:
	goto	l10439
u9630:
	line	1045
	
l1177:	
	return
	opt stack 0
GLOBAL	__end_of_Led_Handle
	__end_of_Led_Handle:
	signat	_Led_Handle,89
	global	_LedControlSt

;; *************** function _LedControlSt *****************
;; Defined at:
;;		line 888 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Num             1    wreg     unsigned char 
;;  Sta             1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  Num             1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Led_Handle
;; This function uses a non-reentrant model
;;
psect	text40,local,class=CODE,delta=2,merge=1,group=0
	line	888
global __ptext40
__ptext40:	;psect for function _LedControlSt
psect	text40
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	888
	global	__size_of_LedControlSt
	__size_of_LedControlSt	equ	__end_of_LedControlSt-_LedControlSt
	
_LedControlSt:	
;incstack = 0
	opt	stack 6
; Regs used in _LedControlSt: [wreg-fsr0h+status,2+status,0]
;LedControlSt@Num stored from wreg
	movwf	(LedControlSt@Num)
	line	890
	
l9197:	
;main.c: 890: switch(Num){
	goto	l9233
	line	892
	
l9199:	
;main.c: 892: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7431
	goto	u7430
u7431:
	goto	l1125
u7430:
	line	893
	
l9201:	
;main.c: 893: RB6=0;
	bcf	(54/8),(54)&7	;volatile
	line	894
;main.c: 894: }
	goto	l1149
	line	895
	
l1125:	
	line	897
;main.c: 895: else
;main.c: 896: {
;main.c: 897: RB6=1;
	bsf	(54/8),(54)&7	;volatile
	goto	l1149
	line	901
	
l9203:	
;main.c: 901: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7441
	goto	u7440
u7441:
	goto	l1129
u7440:
	line	902
	
l9205:	
;main.c: 902: RB3=0;
	bcf	(51/8),(51)&7	;volatile
	line	903
;main.c: 903: }
	goto	l1149
	line	904
	
l1129:	
	line	906
;main.c: 904: else
;main.c: 905: {
;main.c: 906: RB3=1;
	bsf	(51/8),(51)&7	;volatile
	goto	l1149
	line	910
	
l9207:	
;main.c: 910: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7451
	goto	u7450
u7451:
	goto	l1132
u7450:
	line	911
	
l9209:	
;main.c: 911: RA6=0;
	bcf	(46/8),(46)&7	;volatile
	line	912
;main.c: 912: }
	goto	l1149
	line	913
	
l1132:	
	line	915
;main.c: 913: else
;main.c: 914: {
;main.c: 915: RA6=1;
	bsf	(46/8),(46)&7	;volatile
	goto	l1149
	line	919
	
l9211:	
;main.c: 919: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7461
	goto	u7460
u7461:
	goto	l1135
u7460:
	line	920
	
l9213:	
;main.c: 920: RA7=0;
	bcf	(47/8),(47)&7	;volatile
	line	921
;main.c: 921: }
	goto	l1149
	line	922
	
l1135:	
	line	924
;main.c: 922: else
;main.c: 923: {
;main.c: 924: RA7=1;
	bsf	(47/8),(47)&7	;volatile
	goto	l1149
	line	928
	
l9215:	
;main.c: 928: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7471
	goto	u7470
u7471:
	goto	l1138
u7470:
	line	929
	
l9217:	
;main.c: 929: RB0=0;
	bcf	(48/8),(48)&7	;volatile
	line	930
;main.c: 930: }
	goto	l1149
	line	931
	
l1138:	
	line	933
;main.c: 931: else
;main.c: 932: {
;main.c: 933: RB0=1;
	bsf	(48/8),(48)&7	;volatile
	goto	l1149
	line	937
	
l9219:	
;main.c: 937: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7481
	goto	u7480
u7481:
	goto	l1141
u7480:
	line	938
	
l9221:	
;main.c: 938: RB2=0;
	bcf	(50/8),(50)&7	;volatile
	line	939
;main.c: 939: }
	goto	l1149
	line	940
	
l1141:	
	line	942
;main.c: 940: else
;main.c: 941: {
;main.c: 942: RB2=1;
	bsf	(50/8),(50)&7	;volatile
	goto	l1149
	line	946
	
l9223:	
;main.c: 946: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7491
	goto	u7490
u7491:
	goto	l1144
u7490:
	line	947
	
l9225:	
;main.c: 947: RB5=0;
	bcf	(53/8),(53)&7	;volatile
	line	948
;main.c: 948: }
	goto	l1149
	line	949
	
l1144:	
	line	951
;main.c: 949: else
;main.c: 950: {
;main.c: 951: RB5=1;
	bsf	(53/8),(53)&7	;volatile
	goto	l1149
	line	955
	
l9227:	
;main.c: 955: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7501
	goto	u7500
u7501:
	goto	l1147
u7500:
	line	956
	
l9229:	
;main.c: 956: RB4=0;
	bcf	(52/8),(52)&7	;volatile
	line	957
;main.c: 957: }
	goto	l1149
	line	958
	
l1147:	
	line	960
;main.c: 958: else
;main.c: 959: {
;main.c: 960: RB4=1;
	bsf	(52/8),(52)&7	;volatile
	goto	l1149
	line	890
	
l9233:	
	movf	(LedControlSt@Num),w
	; Switch size 1, requested type "space"
; Number of cases is 8, Range of values is 0 to 7
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           25    13 (average)
; direct_byte           32     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l9199
	xorlw	1^0	; case 1
	skipnz
	goto	l9203
	xorlw	2^1	; case 2
	skipnz
	goto	l9207
	xorlw	3^2	; case 3
	skipnz
	goto	l9211
	xorlw	4^3	; case 4
	skipnz
	goto	l9215
	xorlw	5^4	; case 5
	skipnz
	goto	l9219
	xorlw	6^5	; case 6
	skipnz
	goto	l9223
	xorlw	7^6	; case 7
	skipnz
	goto	l9227
	goto	l1149
	opt asmopt_pop

	line	966
	
l1149:	
	return
	opt stack 0
GLOBAL	__end_of_LedControlSt
	__end_of_LedControlSt:
	signat	_LedControlSt,8313
	global	_GetDelayFilterFlag

;; *************** function _GetDelayFilterFlag *****************
;; Defined at:
;;		line 412 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  PtrMin          1    wreg     PTR struct .
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;; Auto vars:     Size  Location     Type
;;  PtrMin          1    5[BANK0 ] PTR struct .
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0       3       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Dec
;;		_DecF
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text41,local,class=CODE,delta=2,merge=1,group=0
	line	412
global __ptext41
__ptext41:	;psect for function _GetDelayFilterFlag
psect	text41
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	412
	global	__size_of_GetDelayFilterFlag
	__size_of_GetDelayFilterFlag	equ	__end_of_GetDelayFilterFlag-_GetDelayFilterFlag
	
_GetDelayFilterFlag:	
;incstack = 0
	opt	stack 6
; Regs used in _GetDelayFilterFlag: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;GetDelayFilterFlag@PtrMin stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(GetDelayFilterFlag@PtrMin)
	line	415
	
l10103:	
;main.c: 415: if(Dec(&PtrMin->u8Second,59))
	movlw	low(03Bh)
	movwf	(Dec@max)
	movf	(GetDelayFilterFlag@PtrMin),w
	fcall	_Dec
	xorlw	0
	skipnz
	goto	u8901
	goto	u8900
u8901:
	goto	l10113
u8900:
	line	417
	
l10105:	
;main.c: 416: {
;main.c: 417: if(Dec(&PtrMin->u8Minute,59))
	movlw	low(03Bh)
	movwf	(Dec@max)
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	01h
	fcall	_Dec
	xorlw	0
	skipnz
	goto	u8911
	goto	u8910
u8911:
	goto	l10113
u8910:
	line	419
	
l10107:	
;main.c: 418: {
;main.c: 419: if(Dec(&PtrMin->u8Hour,23))
	movlw	low(017h)
	movwf	(Dec@max)
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	02h
	fcall	_Dec
	xorlw	0
	skipnz
	goto	u8921
	goto	u8920
u8921:
	goto	l10113
u8920:
	line	421
	
l10109:	
;main.c: 420: {
;main.c: 421: if(DecF(&PtrMin->u16Day,65535))
	movlw	0FFh
	movwf	(DecF@max)
	movlw	0FFh
	movwf	((DecF@max))+1
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	03h
	fcall	_DecF
	xorlw	0
	skipnz
	goto	u8931
	goto	u8930
u8931:
	goto	l1042
u8930:
	goto	l1045
	line	426
	
l1042:	
	line	428
	
l10113:	
;main.c: 424: }
;main.c: 425: }
;main.c: 426: }
;main.c: 427: }
;main.c: 428: if(FilterFastCheck==1){
		decf	((_FilterFastCheck)),w
	btfss	status,2
	goto	u8941
	goto	u8940
u8941:
	goto	l1045
u8940:
	line	429
	
l10115:	
;main.c: 429: if(PtrMin->u16Day>=1)
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	03h
	movwf	fsr0
	movf	indf,w
	movwf	(??_GetDelayFilterFlag+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_GetDelayFilterFlag+0)+0+1
	movf	((??_GetDelayFilterFlag+0)+0),w
iorwf	((??_GetDelayFilterFlag+0)+1),w
	btfsc	status,2
	goto	u8951
	goto	u8950
u8951:
	goto	l10119
u8950:
	line	430
	
l10117:	
;main.c: 430: PtrMin->u16Day-=1;
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	03h
	movwf	fsr0
	movlw	low(01h)
	subwf	indf,f
	incfsz	fsr0,f
	movlw	high(01h)
	skipc
	decf	indf,f
	subwf	indf,f
	decf	fsr0,f
	goto	l1045
	line	432
	
l10119:	
;main.c: 431: else
;main.c: 432: PtrMin->u16Day=0;
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	03h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	436
	
l1045:	
	return
	opt stack 0
GLOBAL	__end_of_GetDelayFilterFlag
	__end_of_GetDelayFilterFlag:
	signat	_GetDelayFilterFlag,4217
	global	_DecF

;; *************** function _DecF *****************
;; Defined at:
;;		line 396 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  var             1    wreg     PTR unsigned int 
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;;  max             2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  var             1    2[BANK0 ] PTR unsigned int 
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       2       0       0
;;      Totals:         2       3       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_GetDelayFilterFlag
;; This function uses a non-reentrant model
;;
psect	text42,local,class=CODE,delta=2,merge=1,group=0
	line	396
global __ptext42
__ptext42:	;psect for function _DecF
psect	text42
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	396
	global	__size_of_DecF
	__size_of_DecF	equ	__end_of_DecF-_DecF
	
_DecF:	
;incstack = 0
	opt	stack 6
; Regs used in _DecF: [wreg-fsr0h+status,2+status,0]
;DecF@var stored from wreg
	movwf	(DecF@var)
	line	398
	
l9167:	
;main.c: 398: if((*var)){(*var)--;}
	movf	(DecF@var),w
	movwf	fsr0
	movf	indf,w
	movwf	(??_DecF+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_DecF+0)+0+1
	movf	((??_DecF+0)+0),w
iorwf	((??_DecF+0)+1),w
	btfsc	status,2
	goto	u7411
	goto	u7410
u7411:
	goto	l9171
u7410:
	
l9169:	
	movf	(DecF@var),w
	movwf	fsr0
	movlw	low(01h)
	subwf	indf,f
	incfsz	fsr0,f
	movlw	high(01h)
	skipc
	decf	indf,f
	subwf	indf,f
	decf	fsr0,f
	goto	l9175
	line	399
	
l9171:	
;main.c: 399: else{return(1);}
	movlw	low(01h)
	goto	l1035
	line	401
	
l9175:	
;main.c: 401: return(0);
	movlw	low(0)
	line	402
	
l1035:	
	return
	opt stack 0
GLOBAL	__end_of_DecF
	__end_of_DecF:
	signat	_DecF,8313
	global	_Dec

;; *************** function _Dec *****************
;; Defined at:
;;		line 388 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  var             1    wreg     PTR unsigned char 
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;;  max             1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  var             1    5[COMMON] PTR unsigned char 
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : B00/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_GetDelayFilterFlag
;; This function uses a non-reentrant model
;;
psect	text43,local,class=CODE,delta=2,merge=1,group=0
	line	388
global __ptext43
__ptext43:	;psect for function _Dec
psect	text43
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	388
	global	__size_of_Dec
	__size_of_Dec	equ	__end_of_Dec-_Dec
	
_Dec:	
;incstack = 0
	opt	stack 6
; Regs used in _Dec: [wreg-fsr0h+status,2+status,0]
;Dec@var stored from wreg
	movwf	(Dec@var)
	line	390
	
l9153:	
;main.c: 390: if((*var)){(*var)--;}
	movf	(Dec@var),w
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	(indf),w
	btfsc	status,2
	goto	u7401
	goto	u7400
u7401:
	goto	l9157
u7400:
	
l9155:	
	movf	(Dec@var),w
	movwf	fsr0
	decf	indf,f
	goto	l9163
	line	391
	
l9157:	
;main.c: 391: else{(*var)=max;return(1);}
	movf	(Dec@var),w
	movwf	fsr0
	movf	(Dec@max),w
	movwf	indf
	
l9159:	
	movlw	low(01h)
	goto	l1030
	line	393
	
l9163:	
;main.c: 393: return(0);
	movlw	low(0)
	line	394
	
l1030:	
	return
	opt stack 0
GLOBAL	__end_of_Dec
	__end_of_Dec:
	signat	_Dec,8313
	global	_FilterLifeFunc

;; *************** function _FilterLifeFunc *****************
;; Defined at:
;;		line 1257 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_BuzzerSet
;;		_FilterTimeHandle
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text44,local,class=CODE,delta=2,merge=1,group=0
	line	1257
global __ptext44
__ptext44:	;psect for function _FilterLifeFunc
psect	text44
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	1257
	global	__size_of_FilterLifeFunc
	__size_of_FilterLifeFunc	equ	__end_of_FilterLifeFunc-_FilterLifeFunc
	
_FilterLifeFunc:	
;incstack = 0
	opt	stack 4
; Regs used in _FilterLifeFunc: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1261
	
l10401:	
;main.c: 1261: if((Mode!=0)&&(Mode!=3)&&(_BITS.Bits.bit_0==0)){
	movf	((_Mode)),w
	btfsc	status,2
	goto	u9461
	goto	u9460
u9461:
	goto	l1221
u9460:
	
l10403:	
		movlw	3
	xorwf	((_Mode)),w
	btfsc	status,2
	goto	u9471
	goto	u9470
u9471:
	goto	l1221
u9470:
	
l10405:	
	btfsc	(__BITS),0
	goto	u9481
	goto	u9480
u9481:
	goto	l1221
u9480:
	line	1262
	
l10407:	
;main.c: 1262: FilterTimeHandle(FilterRO_time,&FilterROState,1,&FilterROGetWater);
	movlw	(FilterTimeHandle@Filter_time)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_FilterRO_time)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterRO_time)^080h+1,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterRO_time)^080h+2,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterRO_time)^080h+3,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterRO_time)^080h+4,w
	movwf	indf
	movlw	(low(_FilterROState|((0x0)<<8)))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	movwf	(FilterTimeHandle@FilterState)
	clrf	(FilterTimeHandle@Type)
	incf	(FilterTimeHandle@Type),f
	movlw	(low(_FilterROGetWater|((0x0)<<8)))&0ffh
	movwf	(FilterTimeHandle@FilterGetWater)
	fcall	_FilterTimeHandle
	line	1265
;main.c: 1265: FilterTimeHandle(FilterPCF_time,&FilterPCFState,0,&FilterPCFGetWater);
	movlw	(FilterTimeHandle@Filter_time)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_FilterPCF_time)^080h,w
	bcf	status, 7	;select IRP bank0
	movwf	indf
	incf	fsr0,f
	movf	(_FilterPCF_time)^080h+1,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterPCF_time)^080h+2,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterPCF_time)^080h+3,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterPCF_time)^080h+4,w
	movwf	indf
	movlw	(low(_FilterPCFState|((0x0)<<8)))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	movwf	(FilterTimeHandle@FilterState)
	clrf	(FilterTimeHandle@Type)
	movlw	(low(_FilterPCFGetWater|((0x0)<<8)))&0ffh
	movwf	(FilterTimeHandle@FilterGetWater)
	fcall	_FilterTimeHandle
	line	1266
	
l10409:	
;main.c: 1266: if(FilterFastCheck==1)
	bcf	status, 5	;RP0=0, select bank0
		decf	((_FilterFastCheck)),w
	btfss	status,2
	goto	u9491
	goto	u9490
u9491:
	goto	l1221
u9490:
	line	1268
	
l10411:	
;main.c: 1267: {
;main.c: 1268: if((FilterPCFState==3)&&(FilterROState==3)){
		movlw	3
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u9501
	goto	u9500
u9501:
	goto	l1221
u9500:
	
l10413:	
		movlw	3
	xorwf	((_FilterROState)),w
	btfss	status,2
	goto	u9511
	goto	u9510
u9511:
	goto	l1221
u9510:
	line	1269
	
l10415:	
;main.c: 1269: FilterFastCheck=2;
	movlw	low(02h)
	movwf	(_FilterFastCheck)
	line	1270
	
l10417:	
;main.c: 1270: BuzzerSet(3, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(03h)
	fcall	_BuzzerSet
	line	1277
	
l1221:	
	return
	opt stack 0
GLOBAL	__end_of_FilterLifeFunc
	__end_of_FilterLifeFunc:
	signat	_FilterLifeFunc,89
	global	_FilterTimeHandle

;; *************** function _FilterTimeHandle *****************
;; Defined at:
;;		line 1147 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Filter_time     5    3[BANK0 ] struct .
;;  FilterState     1    8[BANK0 ] PTR unsigned char 
;;		 -> FilterPCFState(1), FilterROState(1), 
;;  Type            1    9[BANK0 ] unsigned char 
;;  FilterGetWat    1   10[BANK0 ] PTR unsigned int 
;;		 -> FilterPCFGetWater(2), FilterROGetWater(2), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       8       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       4       0       0
;;      Totals:         0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_LedSetSt
;; This function is called by:
;;		_FilterLifeFunc
;; This function uses a non-reentrant model
;;
psect	text45,local,class=CODE,delta=2,merge=1,group=0
	line	1147
global __ptext45
__ptext45:	;psect for function _FilterTimeHandle
psect	text45
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	1147
	global	__size_of_FilterTimeHandle
	__size_of_FilterTimeHandle	equ	__end_of_FilterTimeHandle-_FilterTimeHandle
	
_FilterTimeHandle:	
;incstack = 0
	opt	stack 4
; Regs used in _FilterTimeHandle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1150
	
l9235:	
;main.c: 1150: Date_Temp=14;
	movlw	0Eh
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Date_Temp)^080h
	clrf	(_Date_Temp+1)^080h
	line	1151
	
l9237:	
;main.c: 1151: if(_BITS.Bits.bit_1==1) return;
	btfss	(__BITS),1
	goto	u7511
	goto	u7510
u7511:
	goto	l9241
u7510:
	goto	l1185
	line	1152
	
l9241:	
;main.c: 1152: if(Type==0){
	bcf	status, 5	;RP0=0, select bank0
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7521
	goto	u7520
u7521:
	goto	l9245
u7520:
	line	1153
	
l9243:	
;main.c: 1153: ML_Temp=3650;
	movlw	042h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_ML_Temp)^080h
	movlw	0Eh
	movwf	((_ML_Temp)^080h)+1
	line	1154
;main.c: 1154: }
	goto	l9247
	line	1157
	
l9245:	
;main.c: 1155: else
;main.c: 1156: {
;main.c: 1157: ML_Temp=10950;
	movlw	0C6h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_ML_Temp)^080h
	movlw	02Ah
	movwf	((_ML_Temp)^080h)+1
	line	1160
	
l9247:	
;main.c: 1158: }
;main.c: 1160: if(Filter_time.u16Day<=0){
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(FilterTimeHandle@Filter_time)+03h),w
iorwf	(1+(FilterTimeHandle@Filter_time)+03h),w
	btfss	status,2
	goto	u7531
	goto	u7530
u7531:
	goto	l9257
u7530:
	line	1162
	
l9249:	
;main.c: 1162: *FilterState=3;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(03h)
	movwf	indf
	line	1163
	
l9251:	
;main.c: 1163: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7541
	goto	u7540
u7541:
	goto	l9255
u7540:
	line	1164
	
l9253:	
;main.c: 1164: LedSetSt(4,1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(04h)
	fcall	_LedSetSt
	line	1165
;main.c: 1165: LedSetSt(5, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1166
;main.c: 1166: }
	goto	l1191
	line	1169
	
l9255:	
;main.c: 1167: else
;main.c: 1168: {
;main.c: 1169: LedSetSt(2, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(02h)
	fcall	_LedSetSt
	line	1170
;main.c: 1170: LedSetSt(3, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	goto	l1191
	line	1173
	
l9257:	
;main.c: 1173: else if(Filter_time.u16Day<=Date_Temp)
	movlw	0
	subwf	1+(FilterTimeHandle@Filter_time)+03h,w
	movlw	0Fh
	skipnz
	subwf	0+(FilterTimeHandle@Filter_time)+03h,w
	skipnc
	goto	u7551
	goto	u7550
u7551:
	goto	l9271
u7550:
	line	1175
	
l9259:	
;main.c: 1174: {
;main.c: 1175: if(*FilterState!=2){
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
		movlw	2
	xorwf	(indf),w
	btfsc	status,2
	goto	u7561
	goto	u7560
u7561:
	goto	l9267
u7560:
	line	1176
	
l9261:	
;main.c: 1176: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7571
	goto	u7570
u7571:
	goto	l9265
u7570:
	line	1177
	
l9263:	
;main.c: 1177: LedSetSt(4, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1178
;main.c: 1178: LedSetSt(5, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1179
;main.c: 1179: }
	goto	l9267
	line	1182
	
l9265:	
;main.c: 1180: else
;main.c: 1181: {
;main.c: 1182: LedSetSt(2, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1183
;main.c: 1183: LedSetSt(3, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1186
	
l9267:	
;main.c: 1184: }
;main.c: 1185: }
;main.c: 1186: if(*FilterState<=2)
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(03h)
	bcf	status, 7	;select IRP bank0
	subwf	indf,w
	skipnc
	goto	u7581
	goto	u7580
u7581:
	goto	l1191
u7580:
	line	1187
	
l9269:	
;main.c: 1187: *FilterState=2;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(02h)
	movwf	indf
	goto	l1191
	line	1191
	
l9271:	
;main.c: 1189: else
;main.c: 1190: {
;main.c: 1191: if(*FilterState==1){
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
		decf	(indf),w
	btfss	status,2
	goto	u7591
	goto	u7590
u7591:
	goto	l9279
u7590:
	line	1192
	
l9273:	
;main.c: 1192: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7601
	goto	u7600
u7601:
	goto	l9277
u7600:
	line	1193
	
l9275:	
;main.c: 1193: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1194
;main.c: 1194: LedSetSt(5, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(05h)
	fcall	_LedSetSt
	line	1195
;main.c: 1195: }
	goto	l9279
	line	1198
	
l9277:	
;main.c: 1196: else
;main.c: 1197: {
;main.c: 1198: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1199
;main.c: 1199: LedSetSt(3, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(03h)
	fcall	_LedSetSt
	line	1202
	
l9279:	
;main.c: 1200: }
;main.c: 1201: }
;main.c: 1202: if(*FilterState<=1)
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(02h)
	bcf	status, 7	;select IRP bank0
	subwf	indf,w
	skipnc
	goto	u7611
	goto	u7610
u7611:
	goto	l1191
u7610:
	line	1203
	
l9281:	
;main.c: 1203: *FilterState=1;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	1204
	
l1191:	
	line	1207
;main.c: 1204: }
;main.c: 1207: if(*FilterGetWater>=ML_Temp){
	movf	(FilterTimeHandle@FilterGetWater),w
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	movwf	(??_FilterTimeHandle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_FilterTimeHandle+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(_ML_Temp+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_FilterTimeHandle+0)+0,w
	skipz
	goto	u7625
	bsf	status, 5	;RP0=1, select bank1
	movf	(_ML_Temp)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_FilterTimeHandle+0)+0,w
u7625:
	skipc
	goto	u7621
	goto	u7620
u7621:
	goto	l9291
u7620:
	line	1209
	
l9283:	
;main.c: 1209: *FilterState=3;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(03h)
	movwf	indf
	line	1210
	
l9285:	
;main.c: 1210: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7631
	goto	u7630
u7631:
	goto	l9289
u7630:
	line	1211
	
l9287:	
;main.c: 1211: LedSetSt(4, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(04h)
	fcall	_LedSetSt
	line	1212
;main.c: 1212: LedSetSt(5, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1213
;main.c: 1213: }
	goto	l1185
	line	1216
	
l9289:	
;main.c: 1214: else
;main.c: 1215: {
;main.c: 1216: LedSetSt(2, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(02h)
	fcall	_LedSetSt
	line	1217
;main.c: 1217: LedSetSt(3, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	goto	l1185
	line	1220
	
l9291:	
;main.c: 1220: else if(*FilterGetWater>=ML_Temp-140)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_ML_Temp)^080h,w
	addlw	low(0FF74h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_FilterTimeHandle+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_ML_Temp+1)^080h,w
	skipnc
	addlw	1
	addlw	high(0FF74h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_FilterTimeHandle+0)+0
	movf	(FilterTimeHandle@FilterGetWater),w
	movwf	fsr0
	movf	indf,w
	movwf	(??_FilterTimeHandle+2)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_FilterTimeHandle+2)+0+1
	movf	1+(??_FilterTimeHandle+0)+0,w
	subwf	1+(??_FilterTimeHandle+2)+0,w
	skipz
	goto	u7645
	movf	0+(??_FilterTimeHandle+0)+0,w
	subwf	0+(??_FilterTimeHandle+2)+0,w
u7645:
	skipc
	goto	u7641
	goto	u7640
u7641:
	goto	l9305
u7640:
	line	1223
	
l9293:	
;main.c: 1222: {
;main.c: 1223: if(*FilterState!=2){
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
		movlw	2
	xorwf	(indf),w
	btfsc	status,2
	goto	u7651
	goto	u7650
u7651:
	goto	l9301
u7650:
	line	1224
	
l9295:	
;main.c: 1224: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7661
	goto	u7660
u7661:
	goto	l9299
u7660:
	line	1225
	
l9297:	
;main.c: 1225: LedSetSt(4, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1226
;main.c: 1226: LedSetSt(5, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1227
;main.c: 1227: }
	goto	l9301
	line	1230
	
l9299:	
;main.c: 1228: else
;main.c: 1229: {
;main.c: 1230: LedSetSt(2, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1231
;main.c: 1231: LedSetSt(3, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1234
	
l9301:	
;main.c: 1232: }
;main.c: 1233: }
;main.c: 1234: if(*FilterState<=2)
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(03h)
	bcf	status, 7	;select IRP bank0
	subwf	indf,w
	skipnc
	goto	u7671
	goto	u7670
u7671:
	goto	l1185
u7670:
	line	1235
	
l9303:	
;main.c: 1235: *FilterState=2;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(02h)
	movwf	indf
	goto	l1185
	line	1239
	
l9305:	
;main.c: 1237: else
;main.c: 1238: {
;main.c: 1239: if(*FilterState==1){
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
		decf	(indf),w
	btfss	status,2
	goto	u7681
	goto	u7680
u7681:
	goto	l9313
u7680:
	line	1240
	
l9307:	
;main.c: 1240: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7691
	goto	u7690
u7691:
	goto	l9311
u7690:
	line	1241
	
l9309:	
;main.c: 1241: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1242
;main.c: 1242: LedSetSt(5, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(05h)
	fcall	_LedSetSt
	line	1243
;main.c: 1243: }
	goto	l9313
	line	1246
	
l9311:	
;main.c: 1244: else
;main.c: 1245: {
;main.c: 1246: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1247
;main.c: 1247: LedSetSt(3, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(03h)
	fcall	_LedSetSt
	line	1250
	
l9313:	
;main.c: 1248: }
;main.c: 1249: }
;main.c: 1250: if(*FilterState<=1)
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(02h)
	bcf	status, 7	;select IRP bank0
	subwf	indf,w
	skipnc
	goto	u7701
	goto	u7700
u7701:
	goto	l1185
u7700:
	line	1251
	
l9315:	
;main.c: 1251: *FilterState=1;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	1254
	
l1185:	
	return
	opt stack 0
GLOBAL	__end_of_FilterTimeHandle
	__end_of_FilterTimeHandle:
	signat	_FilterTimeHandle,16505
	global	_FilterKeyInputRest

;; *************** function _FilterKeyInputRest *****************
;; Defined at:
;;		line 1619 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_BuzzerSet
;;		_LedSetSt
;;		_SetFilterDelayReset
;;		_ShiftMode_Handle
;;		_WrterEEP
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text46,local,class=CODE,delta=2,merge=1,group=0
	line	1619
global __ptext46
__ptext46:	;psect for function _FilterKeyInputRest
psect	text46
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	1619
	global	__size_of_FilterKeyInputRest
	__size_of_FilterKeyInputRest	equ	__end_of_FilterKeyInputRest-_FilterKeyInputRest
	
_FilterKeyInputRest:	
;incstack = 0
	opt	stack 4
; Regs used in _FilterKeyInputRest: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1621
	
l10489:	
;main.c: 1620: static U16_T FilterSelect_10ms;
;main.c: 1621: if((Mode==0)||(Mode==3)) return;
	movf	((_Mode)),w
	btfsc	status,2
	goto	u9641
	goto	u9640
u9641:
	goto	l1318
u9640:
	
l10491:	
		movlw	3
	xorwf	((_Mode)),w
	btfss	status,2
	goto	u9651
	goto	u9650
u9651:
	goto	l10493
u9650:
	goto	l1318
	
l1317:	
	goto	l1318
	line	1623
	
l10493:	
;main.c: 1622: if((KeyPacket_y[1].KeyState==LongPressDown)
;main.c: 1623: &&(KeyPacket_y[2].KeyState==NotPress))
		movlw	2
	xorwf	(0+(_KeyPacket_y)+03h),w
	btfss	status,2
	goto	u9661
	goto	u9660
u9661:
	goto	l10547
u9660:
	
l10495:	
	movf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u9671
	goto	u9670
u9671:
	goto	l10547
u9670:
	line	1625
	
l10497:	
;main.c: 1624: {
;main.c: 1625: KeyPacket_y[1].KeyState=SuperPressDown;
	movlw	low(03h)
	movwf	0+(_KeyPacket_y)+03h
	line	1626
;main.c: 1626: if(Time_Power_1s<=10){
	movlw	low(0Bh)
	subwf	(_Time_Power_1s),w
	skipnc
	goto	u9681
	goto	u9680
u9681:
	goto	l10503
u9680:
	line	1627
	
l10499:	
;main.c: 1627: ShiftMode_Handle(5);
	movlw	low(05h)
	fcall	_ShiftMode_Handle
	line	1628
	
l10501:	
;main.c: 1628: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1629
;main.c: 1629: }
	goto	l10545
	line	1632
	
l10503:	
;main.c: 1630: else
;main.c: 1631: {
;main.c: 1632: _BITS.Bits.bit_1^=1;
	movlw	1<<1
	xorwf	(__BITS),f
	line	1633
	
l10505:	
;main.c: 1633: if(_BITS.Bits.bit_1==0){
	btfsc	(__BITS),1
	goto	u9691
	goto	u9690
u9691:
	goto	l1322
u9690:
	line	1634
	
l10507:	
;main.c: 1634: FilterSelect_10ms=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(FilterKeyInputRest@FilterSelect_10ms)^080h
	clrf	(FilterKeyInputRest@FilterSelect_10ms+1)^080h
	line	1635
	
l10509:	
;main.c: 1635: if(_BITS.Bits.bit_3==0)
	btfsc	(__BITS),3
	goto	u9701
	goto	u9700
u9701:
	goto	l10525
u9700:
	line	1637
	
l10511:	
;main.c: 1636: {
;main.c: 1637: PrePCFu16Day=FilterPCF_time.u16Day;
	movf	1+(_FilterPCF_time)^080h+03h,w
	movwf	(_PrePCFu16Day+1)^080h
	movf	0+(_FilterPCF_time)^080h+03h,w
	movwf	(_PrePCFu16Day)^080h
	line	1638
	
l10513:	
;main.c: 1638: SetFilterDelayReset(&FilterPCF_time, 365, 0, 0, 0);
	movlw	06Dh
	bcf	status, 5	;RP0=0, select bank0
	movwf	(SetFilterDelayReset@Day)
	movlw	01h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterPCF_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	1639
	
l10515:	
;main.c: 1639: FilterPCFGetWater=0;
	clrf	(_FilterPCFGetWater)
	clrf	(_FilterPCFGetWater+1)
	line	1640
	
l10517:	
;main.c: 1640: FilterPCFState=1;
	clrf	(_FilterPCFState)
	incf	(_FilterPCFState),f
	line	1641
	
l10519:	
;main.c: 1641: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1642
	
l10521:	
;main.c: 1642: LedSetSt(5, 2);
	movlw	low(02h)
	movwf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1643
	
l10523:	
;main.c: 1643: _BITS1.Bits.bit_3=1;
	bsf	(__BITS1),3
	line	1644
;main.c: 1644: }
	goto	l10539
	line	1647
	
l10525:	
;main.c: 1645: else
;main.c: 1646: {
;main.c: 1647: PreROu16Day=FilterRO_time.u16Day;
	movf	1+(_FilterRO_time)^080h+03h,w
	movwf	(_PreROu16Day+1)^080h
	movf	0+(_FilterRO_time)^080h+03h,w
	movwf	(_PreROu16Day)^080h
	line	1648
	
l10527:	
;main.c: 1648: SetFilterDelayReset(&FilterRO_time, 1095, 0, 0, 0);
	movlw	047h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(SetFilterDelayReset@Day)
	movlw	04h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterRO_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	1649
	
l10529:	
;main.c: 1649: FilterROGetWater=0;
	clrf	(_FilterROGetWater)
	clrf	(_FilterROGetWater+1)
	line	1650
	
l10531:	
;main.c: 1650: FilterROState=1;
	clrf	(_FilterROState)
	incf	(_FilterROState),f
	line	1651
	
l10533:	
;main.c: 1651: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1652
	
l10535:	
;main.c: 1652: LedSetSt(3, 2);
	movlw	low(02h)
	movwf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1653
	
l10537:	
;main.c: 1653: _BITS1.Bits.bit_2=1;
	bsf	(__BITS1),2
	line	1655
	
l10539:	
;main.c: 1654: }
;main.c: 1655: _BITS1.Bits.bit_7=0;
	bcf	(__BITS1),7
	line	1656
	
l10541:	
;main.c: 1656: FilterRst_1s=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_FilterRst_1s)^080h
	clrf	(_FilterRst_1s+1)^080h
	line	1657
	
l10543:	
;main.c: 1657: WrterEEP();
	fcall	_WrterEEP
	line	1658
;main.c: 1658: }
	goto	l10545
	line	1659
	
l1322:	
	line	1661
;main.c: 1659: else
;main.c: 1660: {
;main.c: 1661: _BITS.Bits.bit_3=1;
	bsf	(__BITS),3
	line	1664
	
l10545:	
;main.c: 1662: }
;main.c: 1663: }
;main.c: 1664: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1666
	
l10547:	
;main.c: 1665: }
;main.c: 1666: if(_BITS.Bits.bit_1==1){
	btfss	(__BITS),1
	goto	u9711
	goto	u9710
u9711:
	goto	l10585
u9710:
	line	1667
	
l10549:	
;main.c: 1667: if(++FilterSelect_10ms>=1000){
	bsf	status, 5	;RP0=1, select bank1
	incf	(FilterKeyInputRest@FilterSelect_10ms)^080h,f
	skipnz
	incf	(FilterKeyInputRest@FilterSelect_10ms+1)^080h,f
	movlw	03h
	subwf	((FilterKeyInputRest@FilterSelect_10ms+1)^080h),w
	movlw	0E8h
	skipnz
	subwf	((FilterKeyInputRest@FilterSelect_10ms)^080h),w
	skipc
	goto	u9721
	goto	u9720
u9721:
	goto	l10559
u9720:
	line	1668
	
l10551:	
;main.c: 1668: FilterSelect_10ms=0;
	clrf	(FilterKeyInputRest@FilterSelect_10ms)^080h
	clrf	(FilterKeyInputRest@FilterSelect_10ms+1)^080h
	line	1669
	
l10553:	
;main.c: 1669: BuzzerSet(1, 50);
	movlw	032h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1670
	
l10555:	
;main.c: 1670: _BITS.Bits.bit_1=0;
	bcf	(__BITS),1
	goto	l1318
	line	1674
	
l10559:	
;main.c: 1673: }
;main.c: 1674: if(KeyPacket_y[1].KeyState==ShortRelease)
		movlw	6
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(0+(_KeyPacket_y)+03h),w
	btfss	status,2
	goto	u9731
	goto	u9730
u9731:
	goto	l10567
u9730:
	line	1677
	
l10561:	
;main.c: 1677: BuzzerSet(1, 50);
	movlw	032h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1678
	
l10563:	
;main.c: 1678: FilterSelect_10ms=0;
	clrf	(FilterKeyInputRest@FilterSelect_10ms)^080h
	clrf	(FilterKeyInputRest@FilterSelect_10ms+1)^080h
	line	1679
	
l10565:	
;main.c: 1679: _BITS.Bits.bit_3^=1;
	movlw	1<<3
	xorwf	(__BITS),f
	line	1682
	
l10567:	
;main.c: 1680: }
;main.c: 1682: if(_BITS.Bits.bit_3==0){
	btfsc	(__BITS),3
	goto	u9741
	goto	u9740
u9741:
	goto	l10577
u9740:
	line	1683
	
l10569:	
;main.c: 1683: LedSetSt(3,0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1684
;main.c: 1684: LedSetSt(2,0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1685
	
l10571:	
;main.c: 1685: if(FilterPCFState==1){
		decf	((_FilterPCFState)),w
	btfss	status,2
	goto	u9751
	goto	u9750
u9751:
	goto	l10575
u9750:
	line	1686
	
l10573:	
;main.c: 1686: LedSetSt(5, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1687
;main.c: 1687: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1688
;main.c: 1688: }
	goto	l10585
	line	1691
	
l10575:	
;main.c: 1689: else
;main.c: 1690: {
;main.c: 1691: LedSetSt(4, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1692
;main.c: 1692: LedSetSt(5, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	goto	l10585
	line	1697
	
l10577:	
;main.c: 1695: else
;main.c: 1696: {
;main.c: 1697: LedSetSt(5,0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1698
;main.c: 1698: LedSetSt(4,0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1699
	
l10579:	
;main.c: 1699: if(FilterROState==1){
		decf	((_FilterROState)),w
	btfss	status,2
	goto	u9761
	goto	u9760
u9761:
	goto	l10583
u9760:
	line	1700
	
l10581:	
;main.c: 1700: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1701
;main.c: 1701: LedSetSt(3, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1702
;main.c: 1702: }
	goto	l10585
	line	1705
	
l10583:	
;main.c: 1703: else
;main.c: 1704: {
;main.c: 1705: LedSetSt(3, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1706
;main.c: 1706: LedSetSt(2, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1712
	
l10585:	
;main.c: 1707: }
;main.c: 1708: }
;main.c: 1709: }
;main.c: 1711: if((KeyPacket_y[2].KeyState==LongPressDown)
;main.c: 1712: &&(KeyPacket_y[1].KeyState==LongPressDown))
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u9771
	goto	u9770
u9771:
	goto	l1318
u9770:
	
l10587:	
		movlw	2
	xorwf	(0+(_KeyPacket_y)+03h),w
	btfss	status,2
	goto	u9781
	goto	u9780
u9781:
	goto	l1318
u9780:
	line	1714
	
l10589:	
;main.c: 1713: {
;main.c: 1714: KeyPacket_y[2].KeyState=SuperPressDown;
	movlw	low(03h)
	movwf	0+(_KeyPacket_y)+06h
	line	1715
;main.c: 1715: KeyPacket_y[1].KeyState=SuperPressDown;
	movlw	low(03h)
	movwf	0+(_KeyPacket_y)+03h
	line	1717
;main.c: 1717: if(Time_Power_1s<=10){
	movlw	low(0Bh)
	subwf	(_Time_Power_1s),w
	skipnc
	goto	u9791
	goto	u9790
u9791:
	goto	l10611
u9790:
	line	1718
	
l10591:	
;main.c: 1718: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1720
	
l10593:	
;main.c: 1720: ShiftMode_Handle(0);
	movlw	low(0)
	fcall	_ShiftMode_Handle
	line	1721
	
l10595:	
;main.c: 1721: PowerStep=3;
	movlw	low(03h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_PowerStep)
	line	1722
	
l10597:	
;main.c: 1722: SetFilterDelayReset(&FilterPCF_time, 365, 0, 0, 0);
	movlw	06Dh
	movwf	(SetFilterDelayReset@Day)
	movlw	01h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterPCF_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	1723
	
l10599:	
;main.c: 1723: SetFilterDelayReset(&FilterRO_time, 1095, 0, 0, 0);
	movlw	047h
	movwf	(SetFilterDelayReset@Day)
	movlw	04h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterRO_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	1724
	
l10601:	
;main.c: 1724: FilterROGetWater=0;
	clrf	(_FilterROGetWater)
	clrf	(_FilterROGetWater+1)
	line	1725
	
l10603:	
;main.c: 1725: FilterPCFGetWater=0;
	clrf	(_FilterPCFGetWater)
	clrf	(_FilterPCFGetWater+1)
	line	1726
	
l10605:	
;main.c: 1726: _BITS1.Bits.bit_7=0;
	bcf	(__BITS1),7
	line	1727
	
l10607:	
;main.c: 1727: Read_Word_Buff[11]=1;
	bsf	status, 5	;RP0=1, select bank1
	clrf	0+(_Read_Word_Buff)^080h+0Bh
	incf	0+(_Read_Word_Buff)^080h+0Bh,f
	line	1728
	
l10609:	
;main.c: 1728: WrterEEP();
	fcall	_WrterEEP
	line	1729
;main.c: 1729: }
	goto	l1318
	line	1733
	
l10611:	
;main.c: 1730: else
;main.c: 1731: {
;main.c: 1733: if((FilterRst_1s<300)&&((_BITS1.Bits.bit_3)||(_BITS1.Bits.bit_2))){
	movlw	01h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_FilterRst_1s+1)^080h,w
	movlw	02Ch
	skipnz
	subwf	(_FilterRst_1s)^080h,w
	skipnc
	goto	u9801
	goto	u9800
u9801:
	goto	l1338
u9800:
	
l10613:	
	bcf	status, 5	;RP0=0, select bank0
	btfsc	(__BITS1),3
	goto	u9811
	goto	u9810
u9811:
	goto	l1340
u9810:
	
l10615:	
	btfss	(__BITS1),2
	goto	u9821
	goto	u9820
u9821:
	goto	l1338
u9820:
	
l1340:	
	line	1734
;main.c: 1734: if(_BITS.Bits.bit_1==0){
	btfsc	(__BITS),1
	goto	u9831
	goto	u9830
u9831:
	goto	l1317
u9830:
	line	1736
	
l10617:	
;main.c: 1736: BuzzerSet(3, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(03h)
	fcall	_BuzzerSet
	line	1739
	
l10619:	
;main.c: 1739: if(_BITS1.Bits.bit_3){
	bcf	status, 5	;RP0=0, select bank0
	btfss	(__BITS1),3
	goto	u9841
	goto	u9840
u9841:
	goto	l10629
u9840:
	line	1740
	
l10621:	
;main.c: 1740: _BITS1.Bits.bit_3=0;
	bcf	(__BITS1),3
	line	1741
	
l10623:	
;main.c: 1741: FilterPCF_time.u16Day=PrePCFu16Day;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_PrePCFu16Day+1)^080h,w
	movwf	1+(_FilterPCF_time)^080h+03h
	movf	(_PrePCFu16Day)^080h,w
	movwf	0+(_FilterPCF_time)^080h+03h
	line	1742
	
l10625:	
;main.c: 1742: LedSetSt(5, 5);
	movlw	low(05h)
	movwf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1743
	
l10627:	
;main.c: 1743: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1745
	
l10629:	
;main.c: 1744: }
;main.c: 1745: if(_BITS1.Bits.bit_2){
	btfss	(__BITS1),2
	goto	u9851
	goto	u9850
u9851:
	goto	l10609
u9850:
	line	1746
	
l10631:	
;main.c: 1746: _BITS1.Bits.bit_2=0;
	bcf	(__BITS1),2
	line	1747
	
l10633:	
;main.c: 1747: FilterRO_time.u16Day=PreROu16Day;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_PreROu16Day+1)^080h,w
	movwf	1+(_FilterRO_time)^080h+03h
	movf	(_PreROu16Day)^080h,w
	movwf	0+(_FilterRO_time)^080h+03h
	line	1748
	
l10635:	
;main.c: 1748: LedSetSt(3, 5);
	movlw	low(05h)
	movwf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1749
	
l10637:	
;main.c: 1749: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	goto	l10609
	line	1754
	
l1338:	
	line	1756
;main.c: 1754: else
;main.c: 1755: {
;main.c: 1756: _BITS1.Bits.bit_3=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(__BITS1),3
	line	1757
;main.c: 1757: _BITS1.Bits.bit_2=0;
	bcf	(__BITS1),2
	line	1761
	
l1318:	
	return
	opt stack 0
GLOBAL	__end_of_FilterKeyInputRest
	__end_of_FilterKeyInputRest:
	signat	_FilterKeyInputRest,89
	global	_ErrorHandle

;; *************** function _ErrorHandle *****************
;; Defined at:
;;		line 2158 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_AllLedFlash
;;		_BuzzerSet
;;		_GetStop
;;		_LedSetSt
;;		_ShiftMode_Handle
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text47,local,class=CODE,delta=2,merge=1,group=0
	line	2158
global __ptext47
__ptext47:	;psect for function _ErrorHandle
psect	text47
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	2158
	global	__size_of_ErrorHandle
	__size_of_ErrorHandle	equ	__end_of_ErrorHandle-_ErrorHandle
	
_ErrorHandle:	
;incstack = 0
	opt	stack 4
; Regs used in _ErrorHandle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	2163
	
l10641:	
;main.c: 2163: if(Timer_LongGetWater_1s>=1800){
	movlw	07h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_LongGetWater_1s+1)^080h,w
	movlw	08h
	skipnz
	subwf	(_Timer_LongGetWater_1s)^080h,w
	skipc
	goto	u9861
	goto	u9860
u9861:
	goto	l10661
u9860:
	line	2166
	
l10643:	
;main.c: 2166: ShiftMode_Handle(3);
	movlw	low(03h)
	fcall	_ShiftMode_Handle
	line	2169
	
l10645:	
;main.c: 2169: if(ErrorVar==0x00){
	bcf	status, 5	;RP0=0, select bank0
	movf	((_ErrorVar)),w
	btfss	status,2
	goto	u9871
	goto	u9870
u9871:
	goto	l10657
u9870:
	line	2170
	
l10647:	
;main.c: 2170: Timer_ErrorLong_1s=0;
	clrf	(_Timer_ErrorLong_1s)
	line	2171
	
l10649:	
;main.c: 2171: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	2172
	
l10651:	
;main.c: 2172: LedSetSt(4, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	2173
	
l10653:	
;main.c: 2173: LedSetSt(2, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	2174
	
l10655:	
;main.c: 2174: LedSetSt(0, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(0)
	fcall	_LedSetSt
	line	2176
	
l10657:	
;main.c: 2175: }
;main.c: 2176: ErrorVar=0x02;
	movlw	low(02h)
	movwf	(_ErrorVar)
	line	2177
	
l10659:	
;main.c: 2177: GetStop();
	fcall	_GetStop
	line	2180
	
l10661:	
;main.c: 2178: }
;main.c: 2180: if((Timer_ErrorLong_1s<=30)&&(Mode==3)){
	movlw	low(01Fh)
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_Timer_ErrorLong_1s),w
	skipnc
	goto	u9881
	goto	u9880
u9881:
	goto	l1428
u9880:
	
l10663:	
		movlw	3
	xorwf	((_Mode)),w
	btfss	status,2
	goto	u9891
	goto	u9890
u9891:
	goto	l1428
u9890:
	line	2181
	
l10665:	
;main.c: 2181: Timer_ErrorLong_1s++;
	incf	(_Timer_ErrorLong_1s),f
	line	2182
	
l10667:	
;main.c: 2182: if(Timer_ErrorLong_1s%2==0){
	btfsc	(_Timer_ErrorLong_1s),(0)&7
	goto	u9901
	goto	u9900
u9901:
	goto	l1428
u9900:
	line	2183
	
l10669:	
;main.c: 2183: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	2189
	
l1428:	
	return
	opt stack 0
GLOBAL	__end_of_ErrorHandle
	__end_of_ErrorHandle:
	signat	_ErrorHandle,89
	global	_ShiftMode_Handle

;; *************** function _ShiftMode_Handle *****************
;; Defined at:
;;		line 1292 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Mod             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  Mod             1    3[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       1       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_BuzzerSet
;;		_LedSetSt
;;		_SetStandbyState
;; This function is called by:
;;		_GetMode_Handle
;;		_FilterKeyInputRest
;;		_StandbyMode_Handle
;;		_Run_Mode
;;		_ErrorHandle
;; This function uses a non-reentrant model
;;
psect	text48,local,class=CODE,delta=2,merge=1,group=0
	line	1292
global __ptext48
__ptext48:	;psect for function _ShiftMode_Handle
psect	text48
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	1292
	global	__size_of_ShiftMode_Handle
	__size_of_ShiftMode_Handle	equ	__end_of_ShiftMode_Handle-_ShiftMode_Handle
	
_ShiftMode_Handle:	
;incstack = 0
	opt	stack 4
; Regs used in _ShiftMode_Handle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;ShiftMode_Handle@Mod stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ShiftMode_Handle@Mod)
	line	1294
	
l9319:	
;main.c: 1294: Mode=Mod;
	movf	(ShiftMode_Handle@Mod),w
	movwf	(_Mode)
	line	1295
	
l9321:	
;main.c: 1295: RA1=0;
	bcf	(41/8),(41)&7	;volatile
	line	1296
	
l9323:	
;main.c: 1296: RC2=0;
	bcf	(58/8),(58)&7	;volatile
	line	1297
;main.c: 1297: switch(Mod){
	goto	l9347
	line	1299
;main.c: 1299: case 2:
	
l1228:	
	line	1300
;main.c: 1300: RC3=0;
	bcf	(59/8),(59)&7	;volatile
	line	1301
;main.c: 1301: {RA2=0;_BITS2.Bits.bit_1=0;};
	bcf	(42/8),(42)&7	;volatile
	bcf	(__BITS2),1
	line	1304
;main.c: 1304: _BITS.Bits.bit_5=0x00;
	bcf	(__BITS),5
	line	1305
	
l9325:	
;main.c: 1305: LedSetSt(1, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1306
	
l9327:	
;main.c: 1306: if(StandByStatus==WashState){
		decf	((_StandByStatus)),w
	btfss	status,2
	goto	u7711
	goto	u7710
u7711:
	goto	l1239
u7710:
	line	1307
	
l9329:	
;main.c: 1307: LedSetSt(1, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1308
;main.c: 1308: SetStandbyState(WashState,&WashRunTime, WashRunTime-Timer_WashRun_1s);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_Timer_WashRun_1s)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_WashRunTime),w
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	goto	l1239
	line	1311
;main.c: 1311: case 4:
	
l1231:	
	line	1312
;main.c: 1312: _BITS.Bits.bit_5=0x01;
	bsf	(__BITS),5
	line	1315
;main.c: 1315: RC3=1;
	bsf	(59/8),(59)&7	;volatile
	line	1316
;main.c: 1316: {RA2=1;_BITS2.Bits.bit_1=1;};
	bsf	(42/8),(42)&7	;volatile
	bsf	(__BITS2),1
	line	1317
	
l9331:	
;main.c: 1317: LedSetSt(1, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(01h)
	fcall	_LedSetSt
	line	1318
	
l9333:	
;main.c: 1318: if((FilterROState==3)||(FilterPCFState==3)){
		movlw	3
	xorwf	((_FilterROState)),w
	btfsc	status,2
	goto	u7721
	goto	u7720
u7721:
	goto	l9337
u7720:
	
l9335:	
		movlw	3
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u7731
	goto	u7730
u7731:
	goto	l9339
u7730:
	line	1319
	
l9337:	
;main.c: 1319: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1320
;main.c: 1320: }
	goto	l1239
	line	1321
	
l9339:	
;main.c: 1321: else if((FilterROState==2)||(FilterPCFState==2)){
		movlw	2
	xorwf	((_FilterROState)),w
	btfsc	status,2
	goto	u7741
	goto	u7740
u7741:
	goto	l9343
u7740:
	
l9341:	
		movlw	2
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u7751
	goto	u7750
u7751:
	goto	l1239
u7750:
	line	1322
	
l9343:	
;main.c: 1322: BuzzerSet(1, 1200);
	movlw	0B0h
	movwf	(BuzzerSet@filter)
	movlw	04h
	movwf	((BuzzerSet@filter))+1
	movlw	low(01h)
	fcall	_BuzzerSet
	goto	l1239
	line	1297
	
l9347:	
	movf	(ShiftMode_Handle@Mod),w
	; Switch size 1, requested type "space"
; Number of cases is 2, Range of values is 2 to 4
; switch strategies available:
; Name         Instructions Cycles
; simple_byte            7     4 (average)
; direct_byte           20    11 (fixed)
; jumptable            263     9 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	2^0	; case 2
	skipnz
	goto	l1228
	xorlw	4^2	; case 4
	skipnz
	goto	l1231
	goto	l1239
	opt asmopt_pop

	line	1329
	
l1239:	
	return
	opt stack 0
GLOBAL	__end_of_ShiftMode_Handle
	__end_of_ShiftMode_Handle:
	signat	_ShiftMode_Handle,4217
	global	_SetStandbyState

;; *************** function _SetStandbyState *****************
;; Defined at:
;;		line 1393 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  STY             1    wreg     enum E897
;;  Time            1    4[COMMON] PTR unsigned char 
;;		 -> WashRunTime(1), 
;;  Da              1    5[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  STY             1    0[BANK0 ] enum E897
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : B00/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       1       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_Count_Func
;;		_ShiftMode_Handle
;;		_WashHandle
;;		_StatusFun_Handle
;;		_StandbyMode_Handle
;;		_Run_Mode
;; This function uses a non-reentrant model
;;
psect	text49,local,class=CODE,delta=2,merge=1,group=0
	line	1393
global __ptext49
__ptext49:	;psect for function _SetStandbyState
psect	text49
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	1393
	global	__size_of_SetStandbyState
	__size_of_SetStandbyState	equ	__end_of_SetStandbyState-_SetStandbyState
	
_SetStandbyState:	
;incstack = 0
	opt	stack 7
; Regs used in _SetStandbyState: [wreg-fsr0h+status,2+status,0]
;SetStandbyState@STY stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(SetStandbyState@STY)
	line	1394
	
l8913:	
;main.c: 1394: *Time=Da;
	movf	(SetStandbyState@Time),w
	movwf	fsr0
	movf	(SetStandbyState@Da),w
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	1395
	
l8915:	
;main.c: 1395: StandByStatus=STY;
	movf	(SetStandbyState@STY),w
	movwf	(_StandByStatus)
	line	1401
	
l8917:	
;main.c: 1401: if(STY==WashState){
		decf	((SetStandbyState@STY)),w
	btfss	status,2
	goto	u7151
	goto	u7150
u7151:
	goto	l8921
u7150:
	line	1403
	
l8919:	
;main.c: 1403: {RA2=1;_BITS2.Bits.bit_1=1;};
	bsf	(42/8),(42)&7	;volatile
	bsf	(__BITS2),1
	line	1404
;main.c: 1404: RC3=1;
	bsf	(59/8),(59)&7	;volatile
	line	1405
;main.c: 1405: RC2=1;
	bsf	(58/8),(58)&7	;volatile
	line	1407
;main.c: 1407: }
	goto	l8925
	line	1408
	
l8921:	
;main.c: 1408: else if(STY==BackState){
		movlw	3
	xorwf	((SetStandbyState@STY)),w
	btfss	status,2
	goto	u7161
	goto	u7160
u7161:
	goto	l1254
u7160:
	line	1410
	
l8923:	
;main.c: 1410: {RA2=1;_BITS2.Bits.bit_1=1;};
	bsf	(42/8),(42)&7	;volatile
	bsf	(__BITS2),1
	line	1411
;main.c: 1411: RC3=1;
	bsf	(59/8),(59)&7	;volatile
	line	1412
;main.c: 1412: RA1=1;
	bsf	(41/8),(41)&7	;volatile
	line	1414
;main.c: 1414: }
	goto	l8925
	line	1415
	
l1254:	
	line	1417
;main.c: 1415: else
;main.c: 1416: {
;main.c: 1417: RC2=0;
	bcf	(58/8),(58)&7	;volatile
	line	1418
;main.c: 1418: {RA2=0;_BITS2.Bits.bit_1=0;};
	bcf	(42/8),(42)&7	;volatile
	bcf	(__BITS2),1
	line	1419
;main.c: 1419: RC3=0;
	bcf	(59/8),(59)&7	;volatile
	line	1420
;main.c: 1420: RA1=0;
	bcf	(41/8),(41)&7	;volatile
	line	1425
	
l8925:	
;main.c: 1424: }
;main.c: 1425: Timer_WashRun_1s=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_Timer_WashRun_1s)^080h
	clrf	(_Timer_WashRun_1s+1)^080h
	line	1428
	
l1256:	
	return
	opt stack 0
GLOBAL	__end_of_SetStandbyState
	__end_of_SetStandbyState:
	signat	_SetStandbyState,12409
	global	_GetStop

;; *************** function _GetStop *****************
;; Defined at:
;;		line 1287 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ErrorHandle
;; This function uses a non-reentrant model
;;
psect	text50,local,class=CODE,delta=2,merge=1,group=0
	line	1287
global __ptext50
__ptext50:	;psect for function _GetStop
psect	text50
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	1287
	global	__size_of_GetStop
	__size_of_GetStop	equ	__end_of_GetStop-_GetStop
	
_GetStop:	
;incstack = 0
	opt	stack 6
; Regs used in _GetStop: []
	line	1288
	
l9317:	
;main.c: 1288: _BITS.Bits.bit_5=0x00;
	bcf	(__BITS),5
	line	1290
	
l1224:	
	return
	opt stack 0
GLOBAL	__end_of_GetStop
	__end_of_GetStop:
	signat	_GetStop,89
	global	_AllLedFlash

;; *************** function _AllLedFlash *****************
;; Defined at:
;;		line 837 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Type            1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  Type            1    3[BANK0 ] unsigned char 
;;  i               2    4[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       3       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       3       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_LedSetSt
;; This function is called by:
;;		_FactoryMode_Handle
;;		_Run_Mode
;;		_ErrorHandle
;; This function uses a non-reentrant model
;;
psect	text51,local,class=CODE,delta=2,merge=1,group=0
	line	837
global __ptext51
__ptext51:	;psect for function _AllLedFlash
psect	text51
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	837
	global	__size_of_AllLedFlash
	__size_of_AllLedFlash	equ	__end_of_AllLedFlash-_AllLedFlash
	
_AllLedFlash:	
;incstack = 0
	opt	stack 4
; Regs used in _AllLedFlash: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;AllLedFlash@Type stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(AllLedFlash@Type)
	line	839
	
l9185:	
;main.c: 838: unsigned int i;
;main.c: 839: for(i=0;i<6;i++){
	clrf	(AllLedFlash@i)
	clrf	(AllLedFlash@i+1)
	line	840
	
l9191:	
;main.c: 840: LedSetSt(i, Type);
	movf	(AllLedFlash@Type),w
	movwf	(LedSetSt@Sta)
	movf	(AllLedFlash@i),w
	fcall	_LedSetSt
	line	839
	
l9193:	
	incf	(AllLedFlash@i),f
	skipnz
	incf	(AllLedFlash@i+1),f
	
l9195:	
	movlw	0
	subwf	(AllLedFlash@i+1),w
	movlw	06h
	skipnz
	subwf	(AllLedFlash@i),w
	skipc
	goto	u7421
	goto	u7420
u7421:
	goto	l9191
u7420:
	line	842
	
l1113:	
	return
	opt stack 0
GLOBAL	__end_of_AllLedFlash
	__end_of_AllLedFlash:
	signat	_AllLedFlash,4217
	global	_LedSetSt

;; *************** function _LedSetSt *****************
;; Defined at:
;;		line 872 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Num             1    wreg     unsigned char 
;;  Sta             1    5[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  Num             1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       1       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___bmul
;; This function is called by:
;;		_AllLedFlash
;;		_FilterTimeHandle
;;		_ShiftMode_Handle
;;		_WashHandle
;;		_FactoryMode_Handle
;;		_FilterKeyInputRest
;;		_StandbyMode_Handle
;;		_Run_Mode
;;		_ErrorHandle
;; This function uses a non-reentrant model
;;
psect	text52,local,class=CODE,delta=2,merge=1,group=0
	line	872
global __ptext52
__ptext52:	;psect for function _LedSetSt
psect	text52
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	872
	global	__size_of_LedSetSt
	__size_of_LedSetSt	equ	__end_of_LedSetSt-_LedSetSt
	
_LedSetSt:	
;incstack = 0
	opt	stack 4
; Regs used in _LedSetSt: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;LedSetSt@Num stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(LedSetSt@Num)
	line	874
	
l8927:	
;main.c: 874: if(LedMod[Num].LedState!=Sta){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	xorwf	(LedSetSt@Sta),w
	skipnz
	goto	u7171
	goto	u7170
u7171:
	goto	l1120
u7170:
	line	875
	
l8929:	
;main.c: 875: LedMod[Num].LedState=Sta;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(LedSetSt@Sta),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	line	876
;main.c: 876: if(LedMod[Num].LedState==2){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
		movlw	2
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfss	status,2
	goto	u7181
	goto	u7180
u7181:
	goto	l8935
u7180:
	line	877
	
l8931:	
;main.c: 877: LedMod[Num].LedFlashNum=2;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	movlw	02h
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movlw	0
	movwf	indf
	line	878
	
l8933:	
;main.c: 878: _BITS.Bits.bit_0=1;
	bsf	(__BITS),0
	line	879
;main.c: 879: }
	goto	l1118
	line	880
	
l8935:	
;main.c: 880: else if(LedMod[Num].LedState==5){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
		movlw	5
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfss	status,2
	goto	u7191
	goto	u7190
u7191:
	goto	l1118
u7190:
	line	881
	
l8937:	
;main.c: 881: LedMod[Num].LedFlashNum=3;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	movlw	03h
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movlw	0
	movwf	indf
	goto	l8933
	line	884
	
l1118:	
;main.c: 883: }
;main.c: 884: LedMod[Num].LedTime=0;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	886
	
l1120:	
	return
	opt stack 0
GLOBAL	__end_of_LedSetSt
	__end_of_LedSetSt:
	signat	_LedSetSt,8313
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    1[BANK0 ] unsigned char 
;;  product         1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         0       2       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       2       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_LedSetSt
;;		_Led_Handle
;; This function uses a non-reentrant model
;;
psect	text53,local,class=CODE,delta=2,merge=1,group=2
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul8.c"
	line	4
global __ptext53
__ptext53:	;psect for function ___bmul
psect	text53
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 6
; Regs used in ___bmul: [wreg+status,2+status,0]
;___bmul@multiplier stored from wreg
	movwf	(___bmul@multiplier)
	line	6
	
l8897:	
	clrf	(___bmul@product)
	line	43
	
l8899:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u7131
	goto	u7130
u7131:
	goto	l8903
u7130:
	line	44
	
l8901:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l8903:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l8905:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u7141
	goto	u7140
u7141:
	goto	l8899
u7140:
	line	50
	
l8907:	
	movf	(___bmul@product),w
	line	51
	
l3695:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	_CheckKey

;; *************** function _CheckKey *****************
;; Defined at:
;;		line 2067 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               2    7[BANK0 ] unsigned int 
;;  St              1    6[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       3       0       0
;;      Temps:          0       1       0       0
;;      Totals:         0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_KeyScan
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text54,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	2067
global __ptext54
__ptext54:	;psect for function _CheckKey
psect	text54
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	2067
	global	__size_of_CheckKey
	__size_of_CheckKey	equ	__end_of_CheckKey-_CheckKey
	
_CheckKey:	
;incstack = 0
	opt	stack 5
; Regs used in _CheckKey: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	2069
	
l10363:	
	line	2075
	
l10365:	
;main.c: 2070: static U8_T temp;
;main.c: 2073: static unsigned int KeyOldFlag = 0;
;main.c: 2075: unsigned int i = (unsigned int)((g_KeyFlag[1]<<8) | g_KeyFlag[0]);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	0+(_g_KeyFlag)+01h,w	;volatile
	movwf	(CheckKey@i+1)
	movf	(_g_KeyFlag),w	;volatile
	movwf	(CheckKey@i)
	line	2077
	
l10367:	
;main.c: 2077: if(i)
	movf	((CheckKey@i)),w
iorwf	((CheckKey@i+1)),w
	btfsc	status,2
	goto	u9391
	goto	u9390
u9391:
	goto	l10379
u9390:
	line	2079
	
l10369:	
;main.c: 2078: {
;main.c: 2079: if(i != KeyOldFlag)
	bsf	status, 5	;RP0=1, select bank1
	movf	(CheckKey@KeyOldFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(CheckKey@i+1),w
	skipz
	goto	u9405
	bsf	status, 5	;RP0=1, select bank1
	movf	(CheckKey@KeyOldFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(CheckKey@i),w
u9405:

	skipnz
	goto	u9401
	goto	u9400
u9401:
	goto	l10383
u9400:
	line	2081
	
l10371:	
;main.c: 2080: {
;main.c: 2081: KeyOldFlag = i;
	movf	(CheckKey@i+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(CheckKey@KeyOldFlag+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(CheckKey@i),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(CheckKey@KeyOldFlag)^080h
	line	2083
	
l10373:	
;main.c: 2083: if(0x01 & i){temp |= 0x02;}
	bcf	status, 5	;RP0=0, select bank0
	btfss	(CheckKey@i),(0)&7
	goto	u9411
	goto	u9410
u9411:
	goto	l1414
u9410:
	
l10375:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(CheckKey@temp)^080h+(1/8),(1)&7
	
l1414:	
	line	2084
;main.c: 2084: if(0x02 & i){temp |= 0x04;}
	bcf	status, 5	;RP0=0, select bank0
	btfss	(CheckKey@i),(1)&7
	goto	u9421
	goto	u9420
u9421:
	goto	l10383
u9420:
	
l10377:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(CheckKey@temp)^080h+(2/8),(2)&7
	goto	l10383
	line	2089
	
l10379:	
;main.c: 2087: else
;main.c: 2088: {
;main.c: 2089: KeyOldFlag = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(CheckKey@KeyOldFlag)^080h
	clrf	(CheckKey@KeyOldFlag+1)^080h
	line	2091
	
l10381:	
;main.c: 2091: temp&=0x01;
	movlw	low(01h)
	andwf	(CheckKey@temp)^080h,f
	line	2135
	
l10383:	
;main.c: 2092: }
;main.c: 2135: if(RC1==0){
	bcf	status, 5	;RP0=0, select bank0
	btfsc	(57/8),(57)&7	;volatile
	goto	u9431
	goto	u9430
u9431:
	goto	l1417
u9430:
	line	2138
	
l10385:	
;main.c: 2138: temp |= 0x01;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(CheckKey@temp)^080h+(0/8),(0)&7
	line	2140
;main.c: 2140: }
	goto	l10387
	line	2141
	
l1417:	
	line	2145
;main.c: 2141: else
;main.c: 2142: {
;main.c: 2145: temp &= ~(0x01);
	bsf	status, 5	;RP0=1, select bank1
	bcf	(CheckKey@temp)^080h+(0/8),(0)&7
	line	2150
	
l10387:	
;main.c: 2147: }
;main.c: 2150: for(i=0;i<3;i++){
	bcf	status, 5	;RP0=0, select bank0
	clrf	(CheckKey@i)
	clrf	(CheckKey@i+1)
	line	2151
	
l10393:	
;main.c: 2151: St=(U8_T)(temp>>i);
	bsf	status, 5	;RP0=1, select bank1
	movf	(CheckKey@temp)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_CheckKey+0)+0
	incf	(CheckKey@i),w
	goto	u9444
u9445:
	clrc
	rrf	(??_CheckKey+0)+0,f
u9444:
	addlw	-1
	skipz
	goto	u9445
	movf	0+(??_CheckKey+0)+0,w
	movwf	(CheckKey@St)
	line	2152
;main.c: 2152: St&=0x01;
	movlw	low(01h)
	andwf	(CheckKey@St),f
	line	2153
	
l10395:	
;main.c: 2153: KeyScan(St,i);
	movf	(CheckKey@i),w
	movwf	(KeyScan@num)
	movf	(CheckKey@St),w
	fcall	_KeyScan
	line	2150
	
l10397:	
	incf	(CheckKey@i),f
	skipnz
	incf	(CheckKey@i+1),f
	
l10399:	
	movlw	0
	subwf	(CheckKey@i+1),w
	movlw	03h
	skipnz
	subwf	(CheckKey@i),w
	skipc
	goto	u9451
	goto	u9450
u9451:
	goto	l10393
u9450:
	line	2155
	
l1421:	
	return
	opt stack 0
GLOBAL	__end_of_CheckKey
	__end_of_CheckKey:
	signat	_CheckKey,89
	global	_KeyScan

;; *************** function _KeyScan *****************
;; Defined at:
;;		line 8 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\KeyFunc.c"
;; Parameters:    Size  Location     Type
;;  sw_port         1    wreg     unsigned char 
;;  num             1    1[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  sw_port         1    4[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       1       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_BuzzerSet
;; This function is called by:
;;		_CheckKey
;; This function uses a non-reentrant model
;;
psect	text55,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\KeyFunc.c"
	line	8
global __ptext55
__ptext55:	;psect for function _KeyScan
psect	text55
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\KeyFunc.c"
	line	8
	global	__size_of_KeyScan
	__size_of_KeyScan	equ	__end_of_KeyScan-_KeyScan
	
_KeyScan:	
;incstack = 0
	opt	stack 5
; Regs used in _KeyScan: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;KeyScan@sw_port stored from wreg
	movwf	(KeyScan@sw_port)
	line	10
	
l9391:	
;KeyFunc.c: 10: if(sw_port)
	movf	((KeyScan@sw_port)),w
	btfsc	status,2
	goto	u7791
	goto	u7790
u7791:
	goto	l9465
u7790:
	goto	l9427
	line	16
	
l9395:	
;KeyFunc.c: 16: if(KeyPacket_y[num].KeyTime<2200){KeyPacket_y[num].KeyTime++;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	098h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipnc
	goto	u7801
	goto	u7800
u7801:
	goto	l2395
u7800:
	
l9397:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	
l2395:	
	line	17
;KeyFunc.c: 17: if(KeyPacket_y[num].KeyTime>=3){KeyPacket_y[num].KeyState=ShortPressDown;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	0
	subwf	1+(??_KeyScan+0)+0,w
	movlw	03h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipc
	goto	u7811
	goto	u7810
u7811:
	goto	l2417
u7810:
	
l9399:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	goto	l2417
	line	22
	
l9401:	
;KeyFunc.c: 22: if(KeyPacket_y[num].KeyTime<2200){KeyPacket_y[num].KeyTime++;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	098h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipnc
	goto	u7821
	goto	u7820
u7821:
	goto	l2399
u7820:
	
l9403:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	
l2399:	
	line	23
;KeyFunc.c: 23: if(KeyPacket_y[num].KeyTime>=300) {KeyPacket_y[num].KeyState=LongPressDown;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	01h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	02Ch
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipc
	goto	u7831
	goto	u7830
u7831:
	goto	l2417
u7830:
	
l9405:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	movwf	indf
	goto	l2417
	line	28
	
l9407:	
;KeyFunc.c: 28: if(KeyPacket_y[num].KeyTime<2200){KeyPacket_y[num].KeyTime++;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	098h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipnc
	goto	u7841
	goto	u7840
u7841:
	goto	l2402
u7840:
	
l9409:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	
l2402:	
	line	29
;KeyFunc.c: 29: if(KeyPacket_y[num].KeyTime>=1000) {KeyPacket_y[num].KeyState=SuperPressDown;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	03h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	0E8h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipc
	goto	u7851
	goto	u7850
u7851:
	goto	l2417
u7850:
	
l9411:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(03h)
	movwf	indf
	goto	l2417
	line	32
	
l9413:	
;KeyFunc.c: 32: if(KeyPacket_y[num].KeyTime<2200){KeyPacket_y[num].KeyTime++;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	098h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipnc
	goto	u7861
	goto	u7860
u7861:
	goto	l2405
u7860:
	
l9415:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	
l2405:	
	line	33
;KeyFunc.c: 33: if(KeyPacket_y[num].KeyTime>=2100) {KeyPacket_y[num].KeyState=SuperLongPressDown;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	034h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipc
	goto	u7871
	goto	u7870
u7871:
	goto	l2417
u7870:
	
l9417:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(04h)
	movwf	indf
	goto	l2417
	line	36
	
l9419:	
;KeyFunc.c: 36: if(KeyPacket_y[num].KeyTime<2200){KeyPacket_y[num].KeyTime++;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	098h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipnc
	goto	u7881
	goto	u7880
u7881:
	goto	l2417
u7880:
	
l9421:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	goto	l2417
	line	44
	
l9423:	
;KeyFunc.c: 44: KeyPacket_y[num].KeyTime=0;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	45
;KeyFunc.c: 45: KeyPacket_y[num].KeyState=NotPress;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	46
;KeyFunc.c: 46: break;
	goto	l2417
	line	13
	
l9427:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	; Switch size 1, requested type "space"
; Number of cases is 5, Range of values is 0 to 4
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           16     9 (average)
; direct_byte           23     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l9395
	xorlw	1^0	; case 1
	skipnz
	goto	l9401
	xorlw	2^1	; case 2
	skipnz
	goto	l9407
	xorlw	3^2	; case 3
	skipnz
	goto	l9413
	xorlw	4^3	; case 4
	skipnz
	goto	l9419
	goto	l9423
	opt asmopt_pop

	line	55
	
l9429:	
;KeyFunc.c: 55: KeyPacket_y[num].KeyTime=0;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	56
;KeyFunc.c: 56: break;
	goto	l2417
	line	59
	
l9431:	
;KeyFunc.c: 59: KeyPacket_y[num].KeyState=ShortRelease;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(06h)
	movwf	indf
	line	60
	
l9433:	
;KeyFunc.c: 60: if(num!=1)
		decf	((KeyScan@num)),w
	btfsc	status,2
	goto	u7891
	goto	u7890
u7891:
	goto	l9445
u7890:
	line	62
	
l9435:	
;KeyFunc.c: 61: {
;KeyFunc.c: 62: if(_BITS.Bits.bit_1==1){
	btfss	(__BITS),1
	goto	u7901
	goto	u7900
u7901:
	goto	l9445
u7900:
	line	63
	
l9437:	
;KeyFunc.c: 63: _BITS.Bits.bit_1=0;
	bcf	(__BITS),1
	line	65
	
l9439:	
;KeyFunc.c: 65: BuzzerSet(1, 50);
	movlw	032h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	66
	
l9441:	
;KeyFunc.c: 66: KeyPacket_y[num].KeyState=NotPress;
	bcf	status, 5	;RP0=0, select bank0
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	clrf	indf
	goto	l2417
	line	70
	
l9445:	
;KeyFunc.c: 68: }
;KeyFunc.c: 69: }
;KeyFunc.c: 70: if((FilterFastCheck==1)&&(num!=0)){
		decf	((_FilterFastCheck)),w
	btfss	status,2
	goto	u7911
	goto	u7910
u7911:
	goto	l2417
u7910:
	
l9447:	
	movf	((KeyScan@num)),w
	btfsc	status,2
	goto	u7921
	goto	u7920
u7921:
	goto	l2417
u7920:
	line	71
	
l9449:	
;KeyFunc.c: 71: FilterFastCheck=2;
	movlw	low(02h)
	movwf	(_FilterFastCheck)
	line	72
	
l9451:	
;KeyFunc.c: 72: BuzzerSet(3, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(03h)
	fcall	_BuzzerSet
	goto	l9441
	line	78
	
l9457:	
;KeyFunc.c: 78: KeyPacket_y[num].KeyState=LongRelease;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	79
;KeyFunc.c: 79: break;
	goto	l2417
	line	81
	
l9459:	
;KeyFunc.c: 81: KeyPacket_y[num].KeyState=SuperRelease;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(08h)
	movwf	indf
	line	82
;KeyFunc.c: 82: break;
	goto	l2417
	line	52
	
l9465:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	; Switch size 1, requested type "space"
; Number of cases is 4, Range of values is 0 to 3
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           13     7 (average)
; direct_byte           20     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l9429
	xorlw	1^0	; case 1
	skipnz
	goto	l9431
	xorlw	2^1	; case 2
	skipnz
	goto	l9457
	xorlw	3^2	; case 3
	skipnz
	goto	l9459
	goto	l9423
	opt asmopt_pop

	line	90
	
l2417:	
	return
	opt stack 0
GLOBAL	__end_of_KeyScan
	__end_of_KeyScan:
	signat	_KeyScan,8313
	global	_BuzzerSet

;; *************** function _BuzzerSet *****************
;; Defined at:
;;		line 1585 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  cnt             1    wreg     unsigned char 
;;  filter          2    4[COMMON] unsigned short 
;; Auto vars:     Size  Location     Type
;;  cnt             1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       1       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_Count_Func
;;		_FilterLifeFunc
;;		_ShiftMode_Handle
;;		_FactoryMode_Handle
;;		_FilterKeyInputRest
;;		_StandbyMode_Handle
;;		_Run_Mode
;;		_ErrorHandle
;;		_KeyScan
;; This function uses a non-reentrant model
;;
psect	text56,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	1585
global __ptext56
__ptext56:	;psect for function _BuzzerSet
psect	text56
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	1585
	global	__size_of_BuzzerSet
	__size_of_BuzzerSet	equ	__end_of_BuzzerSet-_BuzzerSet
	
_BuzzerSet:	
;incstack = 0
	opt	stack 6
; Regs used in _BuzzerSet: [wreg]
;BuzzerSet@cnt stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(BuzzerSet@cnt)
	line	1587
	
l8911:	
;main.c: 1587: BeepAlmCnt = cnt;
	movf	(BuzzerSet@cnt),w
	movwf	(_BeepAlmCnt)
	line	1588
;main.c: 1588: BuzzerFilter = filter;
	movf	(BuzzerSet@filter+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_BuzzerFilter+1)^080h
	movf	(BuzzerSet@filter),w
	movwf	(_BuzzerFilter)^080h
	line	1589
;main.c: 1589: BeepOnTimeCnt=BuzzerFilter;
	movf	(_BuzzerFilter+1)^080h,w
	movwf	(_BeepOnTimeCnt+1)^080h
	movf	(_BuzzerFilter)^080h,w
	movwf	(_BeepOnTimeCnt)^080h
	line	1590
	
l1301:	
	return
	opt stack 0
GLOBAL	__end_of_BuzzerSet
	__end_of_BuzzerSet:
	signat	_BuzzerSet,8313
	global	_AD_Testing

;; *************** function _AD_Testing *****************
;; Defined at:
;;		line 2430 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  ad_fd           1    wreg     unsigned char 
;;  ad_ch           1    4[COMMON] unsigned char 
;;  ad_lr           1    5[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  ad_fd           1    2[BANK0 ] unsigned char 
;;  data            2    6[BANK0 ] volatile unsigned int 
;;  AD_Result       2    3[BANK0 ] volatile unsigned int 
;;  i               1    5[BANK0 ] volatile unsigned char 
;; Return value:  Size  Location     Type
;;                  2    4[COMMON] unsigned int 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       6       0       0
;;      Temps:          0       2       0       0
;;      Totals:         2       8       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text57,local,class=CODE,delta=2,merge=1,group=0
	line	2430
global __ptext57
__ptext57:	;psect for function _AD_Testing
psect	text57
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	2430
	global	__size_of_AD_Testing
	__size_of_AD_Testing	equ	__end_of_AD_Testing-_AD_Testing
	
_AD_Testing:	
;incstack = 0
	opt	stack 7
; Regs used in _AD_Testing: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
;AD_Testing@ad_fd stored from wreg
	movwf	(AD_Testing@ad_fd)
	line	2438
	
l10223:	
;main.c: 2433: static volatile unsigned char adtimes;
;main.c: 2434: static volatile unsigned int admin,admax, adsum;
;main.c: 2435: volatile unsigned int data;
;main.c: 2436: volatile unsigned int AD_Result;
;main.c: 2438: volatile unsigned char i = 0;
	clrf	(AD_Testing@i)	;volatile
	line	2440
	
l10225:	
;main.c: 2440: if(!ad_lr)
	movf	((AD_Testing@ad_lr)),w
	btfss	status,2
	goto	u9161
	goto	u9160
u9161:
	goto	l10229
u9160:
	line	2441
	
l10227:	
;main.c: 2441: ADCON1 = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(159)^080h	;volatile
	goto	l10231
	line	2443
	
l10229:	
;main.c: 2442: else
;main.c: 2443: ADCON1 = 0x80;
	movlw	low(080h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(159)^080h	;volatile
	line	2445
	
l10231:	
;main.c: 2445: if(ad_ch & 0x10)
	btfss	(AD_Testing@ad_ch),(4)&7
	goto	u9171
	goto	u9170
u9171:
	goto	l10235
u9170:
	line	2446
	
l10233:	
;main.c: 2446: ADCON1 |= 0x40;
	bsf	(159)^080h+(6/8),(6)&7	;volatile
	line	2448
	
l10235:	
;main.c: 2448: ADCON0 = 0;
	clrf	(158)^080h	;volatile
	line	2449
	
l10237:	
;main.c: 2449: ad_ch &= 0x0f;
	movlw	low(0Fh)
	andwf	(AD_Testing@ad_ch),f
	line	2450
	
l10239:	
;main.c: 2450: ADCON0 |= (unsigned char)(ad_fd << 6);
	bcf	status, 5	;RP0=0, select bank0
	movf	(AD_Testing@ad_fd),w
	movwf	(??_AD_Testing+0)+0
	rrf	(??_AD_Testing+0)+0,f
	rrf	(??_AD_Testing+0)+0,f
	rrf	(??_AD_Testing+0)+0,w
	andlw	0c0h
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(158)^080h,f	;volatile
	line	2451
	
l10241:	
;main.c: 2451: ADCON0 |= (unsigned char)(ad_ch << 2);
	movf	(AD_Testing@ad_ch),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_AD_Testing+0)+0
	movlw	(02h)-1
u9185:
	clrc
	rlf	(??_AD_Testing+0)+0,f
	addlw	-1
	skipz
	goto	u9185
	clrc
	rlf	(??_AD_Testing+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(158)^080h,f	;volatile
	line	2452
	
l10243:	
;main.c: 2452: ADCON0 |= 0x01;
	bsf	(158)^080h+(0/8),(0)&7	;volatile
	line	2454
# 2454 "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	2455
# 2455 "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
nop ;# 
psect	text57
	line	2456
	
l10245:	
;main.c: 2456: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1265/8)^080h,(1265)&7	;volatile
	line	2458
;main.c: 2458: while(GODONE)
	goto	l1460
	
l1461:	
	line	2460
# 2460 "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	2461
# 2461 "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
nop ;# 
psect	text57
	line	2462
;main.c: 2462: if((--i) == 0)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(AD_Testing@i),f	;volatile
	goto	u9191
	goto	u9190
u9191:
	goto	l1460
u9190:
	goto	l1463
	line	2464
	
l1460:	
	line	2458
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1265/8)^080h,(1265)&7	;volatile
	goto	u9201
	goto	u9200
u9201:
	goto	l1461
u9200:
	line	2466
	
l10249:	
;main.c: 2464: }
;main.c: 2466: if(!ad_lr)
	movf	((AD_Testing@ad_lr)),w
	btfss	status,2
	goto	u9211
	goto	u9210
u9211:
	goto	l10255
u9210:
	line	2468
	
l10251:	
;main.c: 2467: {
;main.c: 2468: data = (unsigned int)(ADRESH<<4);
	movf	(157)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(AD_Testing@data)	;volatile
	clrf	(AD_Testing@data+1)	;volatile
	swapf	(AD_Testing@data),f	;volatile
	swapf	(AD_Testing@data+1),f	;volatile
	movlw	0f0h
	andwf	(AD_Testing@data+1),f	;volatile
	movf	(AD_Testing@data),w	;volatile
	andlw	0fh
	iorwf	(AD_Testing@data+1),f	;volatile
	movlw	0f0h
	andwf	(AD_Testing@data),f	;volatile
	line	2469
	
l10253:	
;main.c: 2469: data |= (unsigned int)(ADRESL>>4);
	bsf	status, 5	;RP0=1, select bank1
	swapf	(156)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(AD_Testing@data),f	;volatile
	line	2470
;main.c: 2470: }
	goto	l10257
	line	2473
	
l10255:	
;main.c: 2471: else
;main.c: 2472: {
;main.c: 2473: data = (unsigned int)(ADRESH<<8);
	movf	(157)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(AD_Testing@data+1)	;volatile
	clrf	(AD_Testing@data)	;volatile
	line	2474
;main.c: 2474: data |= (unsigned int)ADRESL;
	bsf	status, 5	;RP0=1, select bank1
	movf	(156)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(AD_Testing@data),f	;volatile
	line	2477
	
l10257:	
;main.c: 2475: }
;main.c: 2477: if(adtimes == 0)
	movf	((AD_Testing@adtimes)),w	;volatile
	btfss	status,2
	goto	u9221
	goto	u9220
u9221:
	goto	l10261
u9220:
	line	2479
	
l10259:	
;main.c: 2478: {
;main.c: 2479: admax = data;
	movf	(AD_Testing@data+1),w	;volatile
	movwf	(AD_Testing@admax+1)	;volatile
	movf	(AD_Testing@data),w	;volatile
	movwf	(AD_Testing@admax)	;volatile
	line	2480
;main.c: 2480: admin = data;
	movf	(AD_Testing@data+1),w	;volatile
	movwf	(AD_Testing@admin+1)	;volatile
	movf	(AD_Testing@data),w	;volatile
	movwf	(AD_Testing@admin)	;volatile
	line	2481
;main.c: 2481: }
	goto	l1468
	line	2482
	
l10261:	
;main.c: 2482: else if(data > admax)
	movf	(AD_Testing@data+1),w	;volatile
	subwf	(AD_Testing@admax+1),w	;volatile
	skipz
	goto	u9235
	movf	(AD_Testing@data),w	;volatile
	subwf	(AD_Testing@admax),w	;volatile
u9235:
	skipnc
	goto	u9231
	goto	u9230
u9231:
	goto	l10265
u9230:
	line	2484
	
l10263:	
;main.c: 2483: {
;main.c: 2484: admax = data;
	movf	(AD_Testing@data+1),w	;volatile
	movwf	(AD_Testing@admax+1)	;volatile
	movf	(AD_Testing@data),w	;volatile
	movwf	(AD_Testing@admax)	;volatile
	line	2485
;main.c: 2485: }
	goto	l1468
	line	2486
	
l10265:	
;main.c: 2486: else if(data < admin)
	movf	(AD_Testing@admin+1),w	;volatile
	subwf	(AD_Testing@data+1),w	;volatile
	skipz
	goto	u9245
	movf	(AD_Testing@admin),w	;volatile
	subwf	(AD_Testing@data),w	;volatile
u9245:
	skipnc
	goto	u9241
	goto	u9240
u9241:
	goto	l1468
u9240:
	line	2488
	
l10267:	
;main.c: 2487: {
;main.c: 2488: admin = data;
	movf	(AD_Testing@data+1),w	;volatile
	movwf	(AD_Testing@admin+1)	;volatile
	movf	(AD_Testing@data),w	;volatile
	movwf	(AD_Testing@admin)	;volatile
	line	2491
	
l1468:	
;main.c: 2489: }
;main.c: 2491: adsum += data;
	movf	(AD_Testing@data),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	addwf	(AD_Testing@adsum)^080h,f	;volatile
	skipnc
	incf	(AD_Testing@adsum+1)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(AD_Testing@data+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	addwf	(AD_Testing@adsum+1)^080h,f	;volatile
	line	2492
	
l10269:	
;main.c: 2492: if(++adtimes >= 10)
	movlw	low(0Ah)
	bcf	status, 5	;RP0=0, select bank0
	incf	(AD_Testing@adtimes),f	;volatile
	subwf	((AD_Testing@adtimes)),w	;volatile
	skipc
	goto	u9251
	goto	u9250
u9251:
	goto	l1463
u9250:
	line	2494
	
l10271:	
;main.c: 2493: {
;main.c: 2494: adsum -= admax;
	movf	(AD_Testing@admax),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	subwf	(AD_Testing@adsum)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(AD_Testing@admax+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	skipc
	decf	(AD_Testing@adsum+1)^080h,f	;volatile
	subwf	(AD_Testing@adsum+1)^080h,f	;volatile
	line	2495
;main.c: 2495: adsum -= admin;
	bcf	status, 5	;RP0=0, select bank0
	movf	(AD_Testing@admin),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	subwf	(AD_Testing@adsum)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(AD_Testing@admin+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	skipc
	decf	(AD_Testing@adsum+1)^080h,f	;volatile
	subwf	(AD_Testing@adsum+1)^080h,f	;volatile
	line	2497
	
l10273:	
;main.c: 2497: AD_Result = adsum >> 3;
	movf	(AD_Testing@adsum+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_AD_Testing+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(AD_Testing@adsum)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_AD_Testing+0)+0
	clrc
	rrf	(??_AD_Testing+0)+1,f
	rrf	(??_AD_Testing+0)+0,f
	clrc
	rrf	(??_AD_Testing+0)+1,f
	rrf	(??_AD_Testing+0)+0,f
	clrc
	rrf	(??_AD_Testing+0)+1,f
	rrf	(??_AD_Testing+0)+0,f
	movf	0+(??_AD_Testing+0)+0,w
	movwf	(AD_Testing@AD_Result)	;volatile
	movf	1+(??_AD_Testing+0)+0,w
	movwf	(AD_Testing@AD_Result+1)	;volatile
	line	2499
	
l10275:	
;main.c: 2499: adsum = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(AD_Testing@adsum)^080h	;volatile
	clrf	(AD_Testing@adsum+1)^080h	;volatile
	line	2500
	
l10277:	
;main.c: 2500: admin = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(AD_Testing@admin)	;volatile
	clrf	(AD_Testing@admin+1)	;volatile
	line	2501
	
l10279:	
;main.c: 2501: admax = 0;
	clrf	(AD_Testing@admax)	;volatile
	clrf	(AD_Testing@admax+1)	;volatile
	line	2502
	
l10281:	
;main.c: 2502: adtimes = 0;
	clrf	(AD_Testing@adtimes)	;volatile
	line	2503
	
l10283:	
;main.c: 2503: for(i=0;i<50;i++){
	clrf	(AD_Testing@i)	;volatile
	
l10285:	
	movlw	low(032h)
	subwf	(AD_Testing@i),w	;volatile
	skipc
	goto	u9261
	goto	u9260
u9261:
	goto	l10289
u9260:
	goto	l1463
	line	2504
	
l10289:	
;main.c: 2504: if(NTC_Tab[i]<=AD_Result){
	clrc
	rlf	(AD_Testing@i),w	;volatile
	addlw	low(((_NTC_Tab)|8000h))
	movwf	fsr0
	movlw	high(((_NTC_Tab)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_AD_Testing+0)+0
	fcall	stringtab
	movwf	(??_AD_Testing+0)+0+1
	movf	1+(??_AD_Testing+0)+0,w
	subwf	(AD_Testing@AD_Result+1),w	;volatile
	skipz
	goto	u9275
	movf	0+(??_AD_Testing+0)+0,w
	subwf	(AD_Testing@AD_Result),w	;volatile
u9275:
	skipc
	goto	u9271
	goto	u9270
u9271:
	goto	l10293
u9270:
	line	2505
	
l10291:	
;main.c: 2505: Temp_Ntc=i;
	movf	(AD_Testing@i),w	;volatile
	movwf	(_Temp_Ntc)
	line	2506
;main.c: 2506: break;
	goto	l1463
	line	2503
	
l10293:	
	incf	(AD_Testing@i),f	;volatile
	
l10295:	
	movlw	low(032h)
	subwf	(AD_Testing@i),w	;volatile
	skipc
	goto	u9281
	goto	u9280
u9281:
	goto	l10289
u9280:
	line	2513
	
l1463:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Testing
	__end_of_AD_Testing:
	signat	_AD_Testing,12410
	global	_Initialize

;; *************** function _Initialize *****************
;; Defined at:
;;		line 2585 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Init_ram
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text58,local,class=CODE,delta=2,merge=1,group=0
	line	2585
global __ptext58
__ptext58:	;psect for function _Initialize
psect	text58
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	2585
	global	__size_of_Initialize
	__size_of_Initialize	equ	__end_of_Initialize-_Initialize
	
_Initialize:	
;incstack = 0
	opt	stack 7
; Regs used in _Initialize: [wreg+status,2+status,0+pclath+cstack]
	line	2587
	
l8741:	
# 2587 "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	2588
# 2588 "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text58
	line	2591
	
l8743:	
;main.c: 2591: OSCCON = 0X70;
	movlw	low(070h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(143)^080h	;volatile
	line	2595
;main.c: 2595: PORTA=0B11111111;
	movlw	low(0FFh)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	line	2596
;main.c: 2596: PORTB=0B11111111;
	movlw	low(0FFh)
	movwf	(6)	;volatile
	line	2597
;main.c: 2597: PORTC=0x01;
	movlw	low(01h)
	movwf	(7)	;volatile
	line	2599
;main.c: 2599: TRISA = 0B00111000;
	movlw	low(038h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	line	2600
;main.c: 2600: TRISB = 0B00000010;
	movlw	low(02h)
	movwf	(134)^080h	;volatile
	line	2601
;main.c: 2601: TRISC = 0B00100011;
	movlw	low(023h)
	movwf	(135)^080h	;volatile
	line	2602
;main.c: 2602: TRISD = 0B00000100;
	movlw	low(04h)
	movwf	(136)^080h	;volatile
	line	2604
;main.c: 2604: WPUA = 0B00000001;
	movlw	low(01h)
	movwf	(153)^080h	;volatile
	line	2605
;main.c: 2605: WPUB = 0B00000010;
	movlw	low(02h)
	movwf	(149)^080h	;volatile
	line	2606
;main.c: 2606: WPUC = 0B00000001;
	movlw	low(01h)
	movwf	(154)^080h	;volatile
	line	2608
;main.c: 2608: OPTION_REG = 0x02;
	movlw	low(02h)
	movwf	(129)^080h	;volatile
	line	2609
;main.c: 2609: TMR0 = 255-125;
	movlw	low(082h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(1)	;volatile
	line	2611
;main.c: 2611: TMR1L = (65535-32000)%256;
	movlw	low(0FFh)
	movwf	(14)	;volatile
	line	2612
;main.c: 2612: TMR1H = (65535-32000)/256;
	movlw	low(082h)
	movwf	(15)	;volatile
	line	2613
	
l8745:	
;main.c: 2613: TMR1IF = 0;
	bcf	(96/8),(96)&7	;volatile
	line	2614
	
l8747:	
;main.c: 2614: TMR1IE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1120/8)^080h,(1120)&7	;volatile
	line	2615
;main.c: 2615: T1CON = 0x01;
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(16)	;volatile
	line	2616
;main.c: 2616: ANSEL1 = 0B10000000;
	movlw	low(080h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(137)^080h	;volatile
	line	2618
	
l8749:	
;main.c: 2618: Init_ram();
	fcall	_Init_ram
	line	2619
	
l8751:	
;main.c: 2619: INTEDG = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1038/8)^080h,(1038)&7	;volatile
	line	2620
	
l8753:	
;main.c: 2620: INTCON = 0xe0;
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	2623
	
l1481:	
	return
	opt stack 0
GLOBAL	__end_of_Initialize
	__end_of_Initialize:
	signat	_Initialize,89
	global	_Init_ram

;; *************** function _Init_ram *****************
;; Defined at:
;;		line 2571 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Initialize
;; This function uses a non-reentrant model
;;
psect	text59,local,class=CODE,delta=2,merge=1,group=0
	line	2571
global __ptext59
__ptext59:	;psect for function _Init_ram
psect	text59
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	2571
	global	__size_of_Init_ram
	__size_of_Init_ram	equ	__end_of_Init_ram-_Init_ram
	
_Init_ram:	
;incstack = 0
	opt	stack 7
; Regs used in _Init_ram: [wreg+status,2]
	line	2573
	
l8637:	
# 2573 "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text59
	line	2574
	
l8639:	
;main.c: 2574: PIE2 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(141)^080h	;volatile
	line	2575
	
l8641:	
;main.c: 2575: PIE1 = 0B00000010;
	movlw	low(02h)
	movwf	(140)^080h	;volatile
	line	2576
	
l8643:	
;main.c: 2576: PR2 = 125;
	movlw	low(07Dh)
	movwf	(146)^080h	;volatile
	line	2577
	
l8645:	
;main.c: 2577: T2CON = 5;
	movlw	low(05h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(18)	;volatile
	line	2580
	
l1478:	
	return
	opt stack 0
GLOBAL	__end_of_Init_ram
	__end_of_Init_ram:
	signat	_Init_ram,89
	global	_EEPROM_Page

;; *************** function _EEPROM_Page *****************
;; Defined at:
;;		line 2375 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_ReadDataArry
;;		_SetFilterDelayReset
;;		_WrterEEP
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text60,local,class=CODE,delta=2,merge=1,group=0
	line	2375
global __ptext60
__ptext60:	;psect for function _EEPROM_Page
psect	text60
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	2375
	global	__size_of_EEPROM_Page
	__size_of_EEPROM_Page	equ	__end_of_EEPROM_Page-_EEPROM_Page
	
_EEPROM_Page:	
;incstack = 0
	opt	stack 6
; Regs used in _EEPROM_Page: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	2377
	
l11121:	
;main.c: 2377: ReadDataArry();
	fcall	_ReadDataArry
	line	2379
	
l11123:	
;main.c: 2379: if(Read_Word_Buff[0]==0xA5){
		movlw	165
	bsf	status, 5	;RP0=1, select bank1
	xorwf	((_Read_Word_Buff)^080h),w
	btfss	status,2
	goto	u10561
	goto	u10560
u10561:
	goto	l1443
u10560:
	line	2380
	
l11125:	
;main.c: 2380: FilterPCF_time.u8Hour=Read_Word_Buff[1];
	movf	0+(_Read_Word_Buff)^080h+01h,w
	movwf	0+(_FilterPCF_time)^080h+02h
	line	2381
;main.c: 2381: FilterPCF_time.u16Day=(U16_T)Read_Word_Buff[2]<<8;
	movf	0+(_Read_Word_Buff)^080h+02h,w
	movwf	1+(_FilterPCF_time)^080h+03h
	clrf	0+(_FilterPCF_time)^080h+03h
	line	2382
;main.c: 2382: FilterPCF_time.u16Day|=Read_Word_Buff[3];
	movf	0+(_Read_Word_Buff)^080h+03h,w
	iorwf	0+(_FilterPCF_time)^080h+03h,f
	line	2384
;main.c: 2384: FilterRO_time.u8Hour=Read_Word_Buff[4];
	movf	0+(_Read_Word_Buff)^080h+04h,w
	movwf	0+(_FilterRO_time)^080h+02h
	line	2385
;main.c: 2385: FilterRO_time.u16Day=(U16_T)Read_Word_Buff[5]<<8;
	movf	0+(_Read_Word_Buff)^080h+05h,w
	movwf	1+(_FilterRO_time)^080h+03h
	clrf	0+(_FilterRO_time)^080h+03h
	line	2386
;main.c: 2386: FilterRO_time.u16Day|=Read_Word_Buff[6];
	movf	0+(_Read_Word_Buff)^080h+06h,w
	iorwf	0+(_FilterRO_time)^080h+03h,f
	line	2388
;main.c: 2388: FilterPCFGetWater=Read_Word_Buff[7];
	movf	0+(_Read_Word_Buff)^080h+07h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_FilterPCFGetWater)
	clrf	(_FilterPCFGetWater+1)
	line	2389
;main.c: 2389: FilterPCFGetWater=FilterPCFGetWater<<8;
	movf	(_FilterPCFGetWater),w
	movwf	(_FilterPCFGetWater+1)
	clrf	(_FilterPCFGetWater)
	line	2390
;main.c: 2390: FilterPCFGetWater|=Read_Word_Buff[8];
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_Read_Word_Buff)^080h+08h,w
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(_FilterPCFGetWater),f
	line	2392
;main.c: 2392: FilterROGetWater=Read_Word_Buff[9];
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_Read_Word_Buff)^080h+09h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_FilterROGetWater)
	clrf	(_FilterROGetWater+1)
	line	2393
;main.c: 2393: FilterROGetWater=FilterROGetWater<<8;
	movf	(_FilterROGetWater),w
	movwf	(_FilterROGetWater+1)
	clrf	(_FilterROGetWater)
	line	2394
;main.c: 2394: FilterROGetWater|=Read_Word_Buff[10];
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_Read_Word_Buff)^080h+0Ah,w
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(_FilterROGetWater),f
	line	2399
;main.c: 2399: }
	goto	l11141
	line	2400
	
l1443:	
	line	2402
;main.c: 2400: else
;main.c: 2401: {
;main.c: 2402: _BITS1.Bits.bit_1=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(__BITS1),1
	line	2403
	
l11127:	
;main.c: 2403: Read_Word_Buff[0]=0xA5;
	movlw	low(0A5h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Read_Word_Buff)^080h
	line	2405
	
l11129:	
;main.c: 2405: Read_Word_Buff[11]=1;
	clrf	0+(_Read_Word_Buff)^080h+0Bh
	incf	0+(_Read_Word_Buff)^080h+0Bh,f
	line	2406
	
l11131:	
;main.c: 2406: SetFilterDelayReset(&FilterPCF_time, 365, 0, 0, 0);
	movlw	06Dh
	bcf	status, 5	;RP0=0, select bank0
	movwf	(SetFilterDelayReset@Day)
	movlw	01h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterPCF_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	2407
	
l11133:	
;main.c: 2407: SetFilterDelayReset(&FilterRO_time, 1095, 0, 0, 0);
	movlw	047h
	movwf	(SetFilterDelayReset@Day)
	movlw	04h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterRO_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	2408
	
l11135:	
;main.c: 2408: FilterROGetWater=0;
	clrf	(_FilterROGetWater)
	clrf	(_FilterROGetWater+1)
	line	2409
	
l11137:	
;main.c: 2409: FilterPCFGetWater=0;
	clrf	(_FilterPCFGetWater)
	clrf	(_FilterPCFGetWater+1)
	line	2410
	
l11139:	
;main.c: 2410: WrterEEP();
	fcall	_WrterEEP
	line	2412
	
l11141:	
;main.c: 2411: }
;main.c: 2412: _BITS1.Bits.bit_0=1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(__BITS1),0
	line	2413
	
l11143:	
;main.c: 2413: PreROu16Day=FilterRO_time.u16Day;
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_FilterRO_time)^080h+03h,w
	movwf	(_PreROu16Day+1)^080h
	movf	0+(_FilterRO_time)^080h+03h,w
	movwf	(_PreROu16Day)^080h
	line	2414
	
l11145:	
;main.c: 2414: PrePCFu16Day=FilterPCF_time.u16Day;
	movf	1+(_FilterPCF_time)^080h+03h,w
	movwf	(_PrePCFu16Day+1)^080h
	movf	0+(_FilterPCF_time)^080h+03h,w
	movwf	(_PrePCFu16Day)^080h
	line	2415
	
l11147:	
;main.c: 2415: _BITS1.Bits.bit_7=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(__BITS1),7
	line	2423
	
l11149:	
;main.c: 2422: if((FilterROGetWater>=(11*2))
;main.c: 2423: &&(FilterPCFGetWater>=(11*2))){
	movlw	0
	subwf	(_FilterROGetWater+1),w
	movlw	016h
	skipnz
	subwf	(_FilterROGetWater),w
	skipc
	goto	u10571
	goto	u10570
u10571:
	goto	l1446
u10570:
	
l11151:	
	movlw	0
	subwf	(_FilterPCFGetWater+1),w
	movlw	016h
	skipnz
	subwf	(_FilterPCFGetWater),w
	skipc
	goto	u10581
	goto	u10580
u10581:
	goto	l1446
u10580:
	line	2426
	
l11153:	
;main.c: 2426: _BITS1.Bits.bit_7=1;
	bsf	(__BITS1),7
	line	2428
	
l1446:	
	return
	opt stack 0
GLOBAL	__end_of_EEPROM_Page
	__end_of_EEPROM_Page:
	signat	_EEPROM_Page,89
	global	_WrterEEP

;; *************** function _WrterEEP *****************
;; Defined at:
;;		line 2349 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_GetMode_Handle
;;		_FilterKeyInputRest
;;		_StandbyMode_Handle
;;		_EEPROM_Page
;; This function uses a non-reentrant model
;;
psect	text61,local,class=CODE,delta=2,merge=1,group=0
	line	2349
global __ptext61
__ptext61:	;psect for function _WrterEEP
psect	text61
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	2349
	global	__size_of_WrterEEP
	__size_of_WrterEEP	equ	__end_of_WrterEEP-_WrterEEP
	
_WrterEEP:	
;incstack = 0
	opt	stack 6
; Regs used in _WrterEEP: [wreg+status,2+status,0]
	line	2350
	
l9349:	
;main.c: 2350: if(FilterFastCheck) return;
	bcf	status, 5	;RP0=0, select bank0
	movf	((_FilterFastCheck)),w
	btfsc	status,2
	goto	u7761
	goto	u7760
u7761:
	goto	l9353
u7760:
	goto	l1435
	line	2352
	
l9353:	
;main.c: 2352: Read_Word_Buff[1]=FilterPCF_time.u8Hour;
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_FilterPCF_time)^080h+02h,w
	movwf	0+(_Read_Word_Buff)^080h+01h
	line	2353
;main.c: 2353: Read_Word_Buff[2]=FilterPCF_time.u16Day>>8;
	movf	1+(_FilterPCF_time)^080h+03h,w
	movwf	0+(_Read_Word_Buff)^080h+02h
	line	2354
;main.c: 2354: Read_Word_Buff[3]=FilterPCF_time.u16Day&0X00FF;
	movf	0+(_FilterPCF_time)^080h+03h,w
	movwf	0+(_Read_Word_Buff)^080h+03h
	line	2356
;main.c: 2356: Read_Word_Buff[4]=FilterRO_time.u8Hour;
	movf	0+(_FilterRO_time)^080h+02h,w
	movwf	0+(_Read_Word_Buff)^080h+04h
	line	2357
;main.c: 2357: Read_Word_Buff[5]=FilterRO_time.u16Day>>8;
	movf	1+(_FilterRO_time)^080h+03h,w
	movwf	0+(_Read_Word_Buff)^080h+05h
	line	2358
;main.c: 2358: Read_Word_Buff[6]=FilterRO_time.u16Day&0X00FF;
	movf	0+(_FilterRO_time)^080h+03h,w
	movwf	0+(_Read_Word_Buff)^080h+06h
	line	2360
;main.c: 2360: Read_Word_Buff[7]=FilterPCFGetWater>>8;
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(_FilterPCFGetWater)+01h,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_Read_Word_Buff)^080h+07h
	line	2361
;main.c: 2361: Read_Word_Buff[8]=FilterPCFGetWater&0X00FF;
	bcf	status, 5	;RP0=0, select bank0
	movf	(_FilterPCFGetWater),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_Read_Word_Buff)^080h+08h
	line	2363
;main.c: 2363: Read_Word_Buff[9]=FilterROGetWater>>8;
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(_FilterROGetWater)+01h,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_Read_Word_Buff)^080h+09h
	line	2364
;main.c: 2364: Read_Word_Buff[10]=FilterROGetWater&0X00FF;
	bcf	status, 5	;RP0=0, select bank0
	movf	(_FilterROGetWater),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_Read_Word_Buff)^080h+0Ah
	line	2366
	
l9355:	
;main.c: 2366: _BITS.Bits.bit_4=1;
	bsf	(__BITS),4
	line	2367
	
l1435:	
	return
	opt stack 0
GLOBAL	__end_of_WrterEEP
	__end_of_WrterEEP:
	signat	_WrterEEP,89
	global	_SetFilterDelayReset

;; *************** function _SetFilterDelayReset *****************
;; Defined at:
;;		line 404 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  TimPtr          1    wreg     PTR struct .
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;;  Day             2    0[BANK0 ] unsigned int 
;;  hour            1    2[BANK0 ] unsigned char 
;;  min             1    3[BANK0 ] unsigned char 
;;  sec             2    4[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  TimPtr          1    4[COMMON] PTR struct .
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       6       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       6       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_FilterKeyInputRest
;;		_EEPROM_Page
;; This function uses a non-reentrant model
;;
psect	text62,local,class=CODE,delta=2,merge=1,group=0
	line	404
global __ptext62
__ptext62:	;psect for function _SetFilterDelayReset
psect	text62
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	404
	global	__size_of_SetFilterDelayReset
	__size_of_SetFilterDelayReset	equ	__end_of_SetFilterDelayReset-_SetFilterDelayReset
	
_SetFilterDelayReset:	
;incstack = 0
	opt	stack 6
; Regs used in _SetFilterDelayReset: [wreg-fsr0h+status,2+status,0]
;SetFilterDelayReset@TimPtr stored from wreg
	movwf	(SetFilterDelayReset@TimPtr)
	line	406
	
l9179:	
;main.c: 406: TimPtr->u16Day=Day;
	movf	(SetFilterDelayReset@TimPtr),w
	addlw	03h
	movwf	fsr0
	movf	(SetFilterDelayReset@Day),w
	bcf	status, 7	;select IRP bank0
	movwf	indf
	incf	fsr0,f
	movf	(SetFilterDelayReset@Day+1),w
	movwf	indf
	line	407
;main.c: 407: TimPtr->u8Hour=hour;
	movf	(SetFilterDelayReset@TimPtr),w
	addlw	02h
	movwf	fsr0
	movf	(SetFilterDelayReset@hour),w
	movwf	indf
	line	408
	
l9181:	
;main.c: 408: TimPtr->u8Minute=min;
	incf	(SetFilterDelayReset@TimPtr),w
	movwf	fsr0
	movf	(SetFilterDelayReset@min),w
	movwf	indf
	line	409
	
l9183:	
;main.c: 409: TimPtr->u8Second=sec;
	movf	(SetFilterDelayReset@TimPtr),w
	movwf	fsr0
	movf	(SetFilterDelayReset@sec),w
	movwf	indf
	line	410
	
l1038:	
	return
	opt stack 0
GLOBAL	__end_of_SetFilterDelayReset
	__end_of_SetFilterDelayReset:
	signat	_SetFilterDelayReset,20601
	global	_ReadDataArry

;; *************** function _ReadDataArry *****************
;; Defined at:
;;		line 2368 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               2    0[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       2       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Memory_Read
;; This function is called by:
;;		_EEPROM_Page
;; This function uses a non-reentrant model
;;
psect	text63,local,class=CODE,delta=2,merge=1,group=0
	line	2368
global __ptext63
__ptext63:	;psect for function _ReadDataArry
psect	text63
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	2368
	global	__size_of_ReadDataArry
	__size_of_ReadDataArry	equ	__end_of_ReadDataArry-_ReadDataArry
	
_ReadDataArry:	
;incstack = 0
	opt	stack 6
; Regs used in _ReadDataArry: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	2370
	
l11049:	
;main.c: 2370: unsigned int i=0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ReadDataArry@i)
	clrf	(ReadDataArry@i+1)
	line	2371
;main.c: 2371: for(i=0;i<12;i++){
	clrf	(ReadDataArry@i)
	clrf	(ReadDataArry@i+1)
	line	2372
	
l11055:	
;main.c: 2372: Read_Word_Buff[i]=Memory_Read(i);
	movf	(ReadDataArry@i),w
	addlw	low(_Read_Word_Buff|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(ReadDataArry@i+1),w
	movwf	(Memory_Read@Addr+1)
	movf	(ReadDataArry@i),w
	movwf	(Memory_Read@Addr)
	fcall	_Memory_Read
	movf	(0+(?_Memory_Read)),w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	line	2371
	
l11057:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(ReadDataArry@i),f
	skipnz
	incf	(ReadDataArry@i+1),f
	
l11059:	
	movlw	0
	subwf	(ReadDataArry@i+1),w
	movlw	0Ch
	skipnz
	subwf	(ReadDataArry@i),w
	skipc
	goto	u10511
	goto	u10510
u10511:
	goto	l11055
u10510:
	line	2374
	
l1440:	
	return
	opt stack 0
GLOBAL	__end_of_ReadDataArry
	__end_of_ReadDataArry:
	signat	_ReadDataArry,89
	global	_Memory_Read

;; *************** function _Memory_Read *****************
;; Defined at:
;;		line 1816 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Addr            2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  2    4[COMMON] unsigned int 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/300
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ReadDataArry
;; This function uses a non-reentrant model
;;
psect	text64,local,class=CODE,delta=2,merge=1,group=0
	line	1816
global __ptext64
__ptext64:	;psect for function _Memory_Read
psect	text64
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	1816
	global	__size_of_Memory_Read
	__size_of_Memory_Read	equ	__end_of_Memory_Read-_Memory_Read
	
_Memory_Read:	
;incstack = 0
	opt	stack 6
; Regs used in _Memory_Read: [wreg]
	line	1819
	
l10835:	
;main.c: 1819: EEADR = Addr;
	movf	(Memory_Read@Addr),w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(391)^0180h	;volatile
	line	1820
	
l10837:	
;main.c: 1820: EEPGD = 0;
	bcf	(3175/8)^0180h,(3175)&7	;volsfr
	line	1827
	
l10839:	
;main.c: 1827: RD=1;
	bsf	(3168/8)^0180h,(3168)&7	;volsfr
	line	1828
# 1828 "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	1829
# 1829 "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
nop ;# 
psect	text64
	line	1832
;main.c: 1832: return (EEDAT);
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(390)^0180h,w	;volatile
	movwf	(?_Memory_Read)
	clrf	(?_Memory_Read+1)
	line	1836
	
l1356:	
	return
	opt stack 0
GLOBAL	__end_of_Memory_Read
	__end_of_Memory_Read:
	signat	_Memory_Read,4218
	global	_Timer1_Isr

;; *************** function _Timer1_Isr *****************
;; Defined at:
;;		line 2626 in file "E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          4       0       0       0
;;      Totals:         4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		___CMS_TouchKeyValue
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text65,local,class=CODE,delta=2,merge=1,group=0
	line	2626
global __ptext65
__ptext65:	;psect for function _Timer1_Isr
psect	text65
	file	"E:\Project\Sbaak_AoZ\Sbaak_738B\Sbaake\main.c"
	line	2626
	global	__size_of_Timer1_Isr
	__size_of_Timer1_Isr	equ	__end_of_Timer1_Isr-_Timer1_Isr
	
_Timer1_Isr:	
;incstack = 0
	opt	stack 2
; Regs used in _Timer1_Isr: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	movwf	(??_Timer1_Isr+0)
	movf	fsr0,w
	movwf	(??_Timer1_Isr+1)
	movf	pclath,w
	movwf	(??_Timer1_Isr+2)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	btemp+1,w
	movwf	(??_Timer1_Isr+3)
	ljmp	_Timer1_Isr
psect	text65
	line	2629
	
i1l8843:	
;main.c: 2628: static U8_T T1_1ms=0;
;main.c: 2629: if(T0IF)
	btfss	(90/8),(90)&7	;volatile
	goto	u707_21
	goto	u707_20
u707_21:
	goto	i1l8849
u707_20:
	line	2632
	
i1l8845:	
;main.c: 2630: {
;main.c: 2632: TMR0 += 255-125;
	movlw	low(082h)
	addwf	(1),f	;volatile
	line	2635
	
i1l8847:	
;main.c: 2635: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	2646
	
i1l8849:	
;main.c: 2644: }
;main.c: 2646: if(TMR1IF)
	btfss	(96/8),(96)&7	;volatile
	goto	u708_21
	goto	u708_20
u708_21:
	goto	i1l8859
u708_20:
	line	2649
	
i1l8851:	
;main.c: 2647: {
;main.c: 2649: TMR1L += (65535-32000)%256;
	movlw	low(0FFh)
	addwf	(14),f	;volatile
	line	2650
;main.c: 2650: TMR1H += (65535-32000)/256;
	movlw	low(082h)
	addwf	(15),f	;volatile
	line	2654
;main.c: 2654: if(++T1_1ms>=10){
	movlw	low(0Ah)
	bsf	status, 5	;RP0=1, select bank1
	incf	(Timer1_Isr@T1_1ms)^080h,f
	subwf	((Timer1_Isr@T1_1ms)^080h),w
	skipc
	goto	u709_21
	goto	u709_20
u709_21:
	goto	i1l8857
u709_20:
	line	2655
	
i1l8853:	
;main.c: 2655: T1_1ms=0;
	clrf	(Timer1_Isr@T1_1ms)^080h
	line	2656
	
i1l8855:	
;main.c: 2656: _BITS2.Bits.bit_0=1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(__BITS2),0
	line	2659
	
i1l8857:	
;main.c: 2657: }
;main.c: 2659: TMR1IF = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(96/8),(96)&7	;volatile
	line	2661
	
i1l8859:	
;main.c: 2660: }
;main.c: 2661: if(TMR2IF)
	btfss	(97/8),(97)&7	;volatile
	goto	u710_21
	goto	u710_20
u710_21:
	goto	i1l8865
u710_20:
	line	2663
	
i1l8861:	
;main.c: 2662: {
;main.c: 2663: TMR2IF = 0;
	bcf	(97/8),(97)&7	;volatile
	line	2665
	
i1l8863:	
;main.c: 2665: __CMS_TouchKeyValue();
	fcall	___CMS_TouchKeyValue
	line	2667
	
i1l8865:	
;main.c: 2666: }
;main.c: 2667: if(INTF)
	btfss	(89/8),(89)&7	;volatile
	goto	u711_21
	goto	u711_20
u711_21:
	goto	i1l1494
u711_20:
	line	2669
	
i1l8867:	
;main.c: 2668: {
;main.c: 2669: INTF = 0;
	bcf	(89/8),(89)&7	;volatile
	line	2670
	
i1l8869:	
;main.c: 2670: if(PureTDSTyp.HzCount<0xfff0)
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	1+(_PureTDSTyp)^0100h+0Dh,w
	movlw	0F0h
	skipnz
	subwf	0+(_PureTDSTyp)^0100h+0Dh,w
	skipnc
	goto	u712_21
	goto	u712_20
u712_21:
	goto	i1l1494
u712_20:
	line	2671
	
i1l8871:	
;main.c: 2671: PureTDSTyp.HzCount++;
	incf	0+(_PureTDSTyp)^0100h+0Dh,f
	skipnz
	incf	1+(_PureTDSTyp)^0100h+0Dh,f
	line	2674
	
i1l1494:	
	movf	(??_Timer1_Isr+3),w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	movf	(??_Timer1_Isr+2),w
	movwf	pclath
	movf	(??_Timer1_Isr+1),w
	movwf	fsr0
	swapf	(??_Timer1_Isr+0)^0FFFFFF80h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Timer1_Isr
	__end_of_Timer1_Isr:
	signat	_Timer1_Isr,89
	global	___CMS_TouchKeyValue

;; *************** function ___CMS_TouchKeyValue *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Timer1_Isr
;; This function uses a non-reentrant model
;;
psect	text66,local,class=CODE,delta=2,merge=1,group=1
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
global __ptext66
__ptext66:	;psect for function ___CMS_TouchKeyValue
psect	text66
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_TouchKeyValue
	__size_of___CMS_TouchKeyValue	equ	__end_of___CMS_TouchKeyValue-___CMS_TouchKeyValue
	
___CMS_TouchKeyValue:	
;incstack = 0
	opt	stack 2
; Regs used in ___CMS_TouchKeyValue: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
	
i1l8755:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text66
	btfss	(_926/8),(_926)&7	;volatile
	goto	u702_21
	goto	u702_20
u702_21:
	goto	i1l3662
u702_20:
	
i1l8757:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(13),(6)&7	;volatile
	goto	u703_21
	goto	u703_20
u703_21:
	goto	i1l3662
u703_20:
	
i1l8759:	
	bcf	(13)+(6/8),(6)&7	;volatile
	
i1l8761:	
	movf	((_918)),w	;volatile
	btfss	status,2
	goto	u704_21
	goto	u704_20
u704_21:
	goto	i1l3662
u704_20:
	
i1l8763:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(415)^0180h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_922)	;volatile
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
i1l8765:	
	clrc
	rlf	(_919),w	;volatile
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(411)^0180h,w	;volatile
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(412)^0180h,w	;volatile
	movwf	indf
	
i1l8767:	
	clrc
	rlf	(_919),w	;volatile
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(409)^0180h,w	;volatile
	movwf	indf
	incf	fsr0,f
	movf	(410)^0180h,w	;volatile
	movwf	indf
	movlw	low(08h)
	movwf	(415)^0180h	;volatile
	
i1l8769:	
	clrc
	rlf	(_919),w	;volatile
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(413)^0180h,w	;volatile
	movwf	indf
	incf	fsr0,f
	movf	(414)^0180h,w	;volatile
	movwf	indf
	
i1l8771:	
	movlw	low(02h)
	incf	(_919),f	;volatile
	subwf	((_919)),w	;volatile
	skipc
	goto	u705_21
	goto	u705_20
u705_21:
	goto	i1l8777
u705_20:
	
i1l8773:	
	clrf	(_919)	;volatile
	
i1l8775:	
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_918)	;volatile
	goto	i1l8811
	
i1l8777:	
	movlw	low(0C2h)
	andwf	(400)^0180h,f	;volatile
	movlw	low(0E0h)
	andwf	(401)^0180h,f	;volatile
	
i1l8779:	
	movf	(_919),w
	addlw	low(((_gc_Table_KeyChannel)|8000h))
	movwf	fsr0
	movlw	high(((_gc_Table_KeyChannel)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	andlw	01Fh
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(401)^0180h,f	;volatile
	
i1l8781:	
	movlw	low(010h)
	movwf	(415)^0180h	;volatile
	
i1l8783:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u706_21
	goto	u706_20
u706_21:
	goto	i1l8795
u706_20:
	
i1l8785:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(_923)	;volatile
	
i1l8787:	
	movlw	low(0Fh)
	andwf	(_923),f	;volatile
	
i1l8789:	
	movlw	low(0F1h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(405)^0180h,f	;volatile
	
i1l8791:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_923),w
	addlw	low(((_sc_CurStep_Table)|8000h))
	movwf	fsr0
	movlw	high(((_sc_CurStep_Table)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(405)^0180h,f	;volatile
	
i1l8793:	
	movf	(_919),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(406)^0180h	;volatile
	goto	i1l8805
	
i1l8795:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	swapf	indf,w
	andlw	(0ffh shr 4) & 0ffh
	movwf	(_923)	;volatile
	
i1l8797:	
	movlw	low(0Fh)
	andwf	(_923),f	;volatile
	
i1l8799:	
	movlw	low(0F1h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(405)^0180h,f	;volatile
	
i1l8801:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_923),w
	addlw	low(((_sc_CurStep_Table)|8000h))
	movwf	fsr0
	movlw	high(((_sc_CurStep_Table)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(405)^0180h,f	;volatile
	
i1l8803:	
	movf	(_919),w
	addlw	low(432|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(406)^0180h	;volatile
	
i1l8805:	
	movf	(406)^0180h,w	;volatile
	movwf	(407)^0180h	;volatile
	
i1l8809:	
	bsf	(400)^0180h+(0/8),(0)&7	;volatile
	
i1l8811:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_922),w	;volatile
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
i1l3662:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text66
	
i1l3671:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_TouchKeyValue
	__end_of___CMS_TouchKeyValue:
	signat	___CMS_TouchKeyValue,89
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end


#include "Func.h"
#include "KeyFunc.h"

//KeyType KeyPacket_y[Max_Key_Num];


 void KeyScan(uint8_t sw_port,uint8_t num)
{
    if(sw_port)	    //key press
    {	

		switch(KeyPacket_y[num].KeyState)
		{
		    case NotPress: 
		                if(KeyPacket_y[num].KeyTime<K_MAX_VALUE){KeyPacket_y[num].KeyTime++;}
				        if(KeyPacket_y[num].KeyTime>=K_SHORT_VALUE){KeyPacket_y[num].KeyState=ShortPressDown;} 
				        break;
				 
		    case ShortPressDown:

		                        if(KeyPacket_y[num].KeyTime<K_MAX_VALUE){KeyPacket_y[num].KeyTime++;}
				                if(KeyPacket_y[num].KeyTime>=K_LONG_VALUE) {KeyPacket_y[num].KeyState=LongPressDown;}
				               
				                break;
				 
		    case LongPressDown: 
		    				if(KeyPacket_y[num].KeyTime<K_MAX_VALUE){KeyPacket_y[num].KeyTime++;}
				                if(KeyPacket_y[num].KeyTime>=K_SUPER_VALUE) {KeyPacket_y[num].KeyState=SuperPressDown;}
				        break;
			case SuperPressDown: 
							if(KeyPacket_y[num].KeyTime<K_MAX_VALUE){KeyPacket_y[num].KeyTime++;}
							 if(KeyPacket_y[num].KeyTime>=K_SUPER_LONG_VALUE) {KeyPacket_y[num].KeyState=SuperLongPressDown;}
							 break;
			case SuperLongPressDown: 
							if(KeyPacket_y[num].KeyTime<K_MAX_VALUE){KeyPacket_y[num].KeyTime++;}	
		//					 if(KeyPacket_y[num].KeyTime>=K_SUPER_LONG_VALUE) {KeyPacket_y[num].KeyState=SuperLongPressDown;}
							 break;
		//	case SuperLongPressDown_Standby: 
		//					if(KeyPacket_y[num].KeyTime<K_MAX_VALUE){KeyPacket_y[num].KeyTime++;}	

		//		break;					
		    default:
				    KeyPacket_y[num].KeyTime=0;
				    KeyPacket_y[num].KeyState=NotPress;
				    break;
		}
    }
    else             //key free
    {			
   
		switch(KeyPacket_y[num].KeyState)
		{
		    case NotPress: 
					KeyPacket_y[num].KeyTime=0;
					break;
		    case ShortPressDown:		
		    			
					KeyPacket_y[num].KeyState=ShortRelease; 
		    			if(num!=KeyFilter)
		    			{
		    				if(FilterRstState==RstSelect){
			    				FilterRstState=RstSty;
			    		//		KeyPacket_y[num].KeyState=NotPress;
			    				BuzzerSet(1, bu_250ms);
			    				KeyPacket_y[num].KeyState=NotPress; 
			    				return;
		    				} 
		    			}			
					 if((FilterFastCheck==1)&&(num!=HiVSwitch)){
				                	FilterFastCheck=2;
				                	BuzzerSet(3, Bu_1s);	
				                	KeyPacket_y[num].KeyState=NotPress; 
				                	return;
				                }		    			
					break;
		    case LongPressDown:
					KeyPacket_y[num].KeyState=LongRelease;					
					break;
			case SuperPressDown:
					KeyPacket_y[num].KeyState=SuperRelease;				
					break;
		    default:
					KeyPacket_y[num].KeyTime=0;
					KeyPacket_y[num].KeyState=NotPress;
					break;
		}	

    }	
}



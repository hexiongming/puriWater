#ifndef KeyFunc_H
#define KeyFunc_H

#include <cms.h>					//о?????????????????????????????????
#include "Func.h"

#define IFC_Parallel_Mode






#define Max_Key_Num 3

typedef enum 
{
	NotPress=0,	
	ShortPressDown=1,	
	LongPressDown=2,
	SuperPressDown=3,
	SuperLongPressDown=4,
	SuperLongPressDown_Standby=5,
	ShortRelease=6,
	LongRelease=7,
	SuperRelease=8,
	ReleaseOver=9,
}KeyStat;

typedef struct 
{	
	KeyStat KeyState;					
	U16_T   KeyTime; 
//	U16_T   KeyPressCount; 
//	U16_T   KeyPressTime; 
}KeyType;


exter KeyType KeyPacket_y[Max_Key_Num];



 void KeyScan(uint8_t sw_port,uint8_t num);
  void CheckKey(void);
void DisplayLed_Func(void);
void BuzzerSet(uint8_t cnt,uint16_t filter);
void WrterEEP();
#endif

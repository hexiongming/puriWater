opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	79F738B
opt include "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\include\79f738b.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
	FNCALL	_main,_EEPROM_Page
	FNCALL	_main,_Initialize
	FNCALL	_main,_Run_Mode
	FNCALL	_main,_Set_PWM
	FNCALL	_main,_Set_Usart_Async
	FNCALL	_main,_Time_Count_Func
	FNCALL	_Run_Mode,_AllLedFlash
	FNCALL	_Run_Mode,_BuzzerSet
	FNCALL	_Run_Mode,_FactoryMode_Handle
	FNCALL	_Run_Mode,_GetMode_Handle
	FNCALL	_Run_Mode,_LedSetSt
	FNCALL	_Run_Mode,_SetStandbyState
	FNCALL	_Run_Mode,_ShiftMode_Handle
	FNCALL	_Run_Mode,_StandbyMode_Handle
	FNCALL	_StandbyMode_Handle,_BuzzerSet
	FNCALL	_StandbyMode_Handle,_LedSetSt
	FNCALL	_StandbyMode_Handle,_SetStandbyState
	FNCALL	_StandbyMode_Handle,_ShiftMode_Handle
	FNCALL	_StandbyMode_Handle,_StatusFun_Handle
	FNCALL	_StandbyMode_Handle,_WrterEEP
	FNCALL	_StatusFun_Handle,_SetStandbyState
	FNCALL	_StatusFun_Handle,_WashHandle
	FNCALL	_WashHandle,_LedSetSt
	FNCALL	_WashHandle,_SetStandbyState
	FNCALL	_GetMode_Handle,_ShiftMode_Handle
	FNCALL	_GetMode_Handle,_WrterEEP
	FNCALL	_FactoryMode_Handle,_AllLedFlash
	FNCALL	_FactoryMode_Handle,_BuzzerSet
	FNCALL	_FactoryMode_Handle,_LedSetSt
	FNCALL	_FactoryMode_Handle,_Time_Count_Func
	FNCALL	_Time_Count_Func,_AD_Testing
	FNCALL	_Time_Count_Func,_BuzzerSet
	FNCALL	_Time_Count_Func,_CheckKey
	FNCALL	_Time_Count_Func,_ErrorHandle
	FNCALL	_Time_Count_Func,_FilterKeyInputRest
	FNCALL	_Time_Count_Func,_FilterLifeFunc
	FNCALL	_Time_Count_Func,_GetDelayFilterFlag
	FNCALL	_Time_Count_Func,_Led_Handle
	FNCALL	_Time_Count_Func,_Page_ProgramData
	FNCALL	_Time_Count_Func,_SetStandbyState
	FNCALL	_Time_Count_Func,_TDS_Handle
	FNCALL	_Time_Count_Func,_TaskAlarmHandle
	FNCALL	_Time_Count_Func,_Tx_Display
	FNCALL	_Time_Count_Func,___CMS_CheckTouchKey
	FNCALL	___CMS_CheckTouchKey,___CMS_CheckKeyOldValue
	FNCALL	___CMS_CheckTouchKey,___CMS_CheckOnceResult
	FNCALL	___CMS_CheckTouchKey,___CMS_CheckValidTime
	FNCALL	___CMS_CheckTouchKey,___CMS_CurAdjust
	FNCALL	___CMS_CheckTouchKey,___CMS_KeyDatIIR
	FNCALL	___CMS_CheckTouchKey,___CMS_KeyModeSet
	FNCALL	___CMS_CheckTouchKey,___CMS_KeyStart
	FNCALL	___CMS_CheckTouchKey,___CMS_KeyStopClear
	FNCALL	___CMS_CheckTouchKey,___CMS_Key_UNNOL_Check
	FNCALL	___CMS_CheckTouchKey,___CMS_NewRAMClr
	FNCALL	___CMS_CheckTouchKey,___CMS_Noise_check
	FNCALL	___CMS_CheckTouchKey,___GET_32M_FREDAT
	FNCALL	___CMS_KeyStopClear,___CMS_KeyClearOne
	FNCALL	___CMS_CurAdjust,___CMS_CurAdjMode
	FNCALL	___CMS_CurAdjust,___CMS_CurJudge
	FNCALL	___CMS_CurAdjust,___CMS_KeyModeSet
	FNCALL	___CMS_CurAdjust,___CMS_KeyStart
	FNCALL	___CMS_CheckOnceResult,___CMS_KeyHaveDown
	FNCALL	___CMS_CheckOnceResult,___CMS_KeyIsIn
	FNCALL	___CMS_CheckOnceResult,___CMS_KeyOpen
	FNCALL	___CMS_CheckKeyOldValue,___CMS_KeyIsIn
	FNCALL	___CMS_CheckKeyOldValue,_abs
	FNCALL	_TDS_Handle,_GetCurTdsHz
	FNCALL	_TDS_Handle,___lldiv
	FNCALL	_TDS_Handle,___lmul
	FNCALL	_TDS_Handle,___lwdiv
	FNCALL	_Page_ProgramData,_Memory_Write
	FNCALL	_Led_Handle,_LedControlSt
	FNCALL	_Led_Handle,___bmul
	FNCALL	_GetDelayFilterFlag,_Dec
	FNCALL	_GetDelayFilterFlag,_DecF
	FNCALL	_FilterLifeFunc,_BuzzerSet
	FNCALL	_FilterLifeFunc,_FilterTimeHandle
	FNCALL	_FilterTimeHandle,_LedSetSt
	FNCALL	_FilterKeyInputRest,_BuzzerSet
	FNCALL	_FilterKeyInputRest,_LedSetSt
	FNCALL	_FilterKeyInputRest,_SetFilterDelayReset
	FNCALL	_FilterKeyInputRest,_ShiftMode_Handle
	FNCALL	_FilterKeyInputRest,_WrterEEP
	FNCALL	_ErrorHandle,_AllLedFlash
	FNCALL	_ErrorHandle,_BuzzerSet
	FNCALL	_ErrorHandle,_GetStop
	FNCALL	_ErrorHandle,_LedSetSt
	FNCALL	_ErrorHandle,_ShiftMode_Handle
	FNCALL	_ShiftMode_Handle,_BuzzerSet
	FNCALL	_ShiftMode_Handle,_LedSetSt
	FNCALL	_ShiftMode_Handle,_SetStandbyState
	FNCALL	_AllLedFlash,_LedSetSt
	FNCALL	_LedSetSt,___bmul
	FNCALL	_CheckKey,_KeyScan
	FNCALL	_KeyScan,_BuzzerSet
	FNCALL	_Initialize,_Init_ram
	FNCALL	_EEPROM_Page,_ReadDataArry
	FNCALL	_EEPROM_Page,_SetFilterDelayReset
	FNCALL	_EEPROM_Page,_WrterEEP
	FNCALL	_ReadDataArry,_Memory_Read
	FNROOT	_main
	FNCALL	_Timer1_Isr,___CMS_TouchKeyValue
	FNCALL	intlevel1,_Timer1_Isr
	global	intlevel1
	FNROOT	intlevel1
	global	_NTC_Tab
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	136
_NTC_Tab:
	retlw	0BCh
	retlw	0Bh

	retlw	098h
	retlw	0Bh

	retlw	075h
	retlw	0Bh

	retlw	051h
	retlw	0Bh

	retlw	02Ch
	retlw	0Bh

	retlw	07h
	retlw	0Bh

	retlw	0E2h
	retlw	0Ah

	retlw	0BCh
	retlw	0Ah

	retlw	097h
	retlw	0Ah

	retlw	070h
	retlw	0Ah

	retlw	04Ah
	retlw	0Ah

	retlw	023h
	retlw	0Ah

	retlw	0FCh
	retlw	09h

	retlw	0D5h
	retlw	09h

	retlw	0AEh
	retlw	09h

	retlw	087h
	retlw	09h

	retlw	060h
	retlw	09h

	retlw	038h
	retlw	09h

	retlw	011h
	retlw	09h

	retlw	0EAh
	retlw	08h

	retlw	0C3h
	retlw	08h

	retlw	09Bh
	retlw	08h

	retlw	074h
	retlw	08h

	retlw	04Dh
	retlw	08h

	retlw	027h
	retlw	08h

	retlw	0
	retlw	08h

	retlw	0DAh
	retlw	07h

	retlw	0B4h
	retlw	07h

	retlw	08Eh
	retlw	07h

	retlw	068h
	retlw	07h

	retlw	043h
	retlw	07h

	retlw	01Eh
	retlw	07h

	retlw	0F9h
	retlw	06h

	retlw	0D5h
	retlw	06h

	retlw	0B1h
	retlw	06h

	retlw	08Eh
	retlw	06h

	retlw	06Bh
	retlw	06h

	retlw	049h
	retlw	06h

	retlw	026h
	retlw	06h

	retlw	05h
	retlw	06h

	retlw	0E4h
	retlw	05h

	retlw	0C3h
	retlw	05h

	retlw	0A3h
	retlw	05h

	retlw	083h
	retlw	05h

	retlw	064h
	retlw	05h

	retlw	045h
	retlw	05h

	retlw	027h
	retlw	05h

	retlw	09h
	retlw	05h

	retlw	0ECh
	retlw	04h

	retlw	low(0)
	retlw	high(0)

	global __end_of_NTC_Tab
__end_of_NTC_Tab:
	global	_sc_FreScanTable1
psect	stringtext
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
_sc_FreScanTable1:
	retlw	low(0)
	retlw	01h
	retlw	low(0)
	retlw	01h
	retlw	low(0)
	retlw	01h
	retlw	low(0)
	retlw	01h
	global __end_of_sc_FreScanTable1
__end_of_sc_FreScanTable1:
	global	_sc_FreScanTable
psect	stringtext
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
_sc_FreScanTable:
	retlw	low(0)
	retlw	01h
	retlw	01h
	retlw	01h
	retlw	01h
	retlw	01h
	retlw	01h
	retlw	01h
	global __end_of_sc_FreScanTable
__end_of_sc_FreScanTable:
	global	_sc_Table_KeyFalg
psect	stringtext
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
_sc_Table_KeyFalg:
	retlw	01h
	retlw	02h
	retlw	04h
	retlw	08h
	retlw	010h
	retlw	020h
	retlw	040h
	retlw	080h
	global __end_of_sc_Table_KeyFalg
__end_of_sc_Table_KeyFalg:
	global	_sc_CurStep_Table
psect	stringtext
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
_sc_CurStep_Table:
	retlw	low(0)
	retlw	02h
	retlw	04h
	retlw	06h
	retlw	08h
	retlw	0Ah
	global __end_of_sc_CurStep_Table
__end_of_sc_CurStep_Table:
	global	_gc_Table_KeyDown
psect	stringtext
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	36
_gc_Table_KeyDown:
	retlw	03Ch
	retlw	0

	retlw	03Ch
	retlw	0

	global __end_of_gc_Table_KeyDown
__end_of_gc_Table_KeyDown:
	global	_gc_Table_KeyChannel
psect	stringtext
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	28
_gc_Table_KeyChannel:
	retlw	04h
	retlw	05h
	global __end_of_gc_Table_KeyChannel
__end_of_gc_Table_KeyChannel:
	global	_PureHz_Tab
psect	stringtext
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	60
_PureHz_Tab:
	retlw	01Ch
	retlw	0

	retlw	026h
	retlw	0

	retlw	030h
	retlw	0

	retlw	03Ah
	retlw	0

	retlw	044h
	retlw	0

	retlw	04Eh
	retlw	0

	retlw	058h
	retlw	0

	retlw	062h
	retlw	0

	retlw	06Ch
	retlw	0

	retlw	076h
	retlw	0

	retlw	083h
	retlw	0

	retlw	090h
	retlw	0

	retlw	09Ch
	retlw	0

	retlw	0A9h
	retlw	0

	retlw	0B6h
	retlw	0

	retlw	0C3h
	retlw	0

	retlw	0D0h
	retlw	0

	retlw	0DDh
	retlw	0

	retlw	0EAh
	retlw	0

	retlw	0F7h
	retlw	0

	retlw	0FFh
	retlw	0

	retlw	07h
	retlw	01h

	retlw	0Fh
	retlw	01h

	retlw	019h
	retlw	01h

	retlw	023h
	retlw	01h

	retlw	02Dh
	retlw	01h

	retlw	037h
	retlw	01h

	retlw	041h
	retlw	01h

	retlw	04Bh
	retlw	01h

	retlw	055h
	retlw	01h

	retlw	05Eh
	retlw	01h

	retlw	06Bh
	retlw	01h

	retlw	077h
	retlw	01h

	retlw	081h
	retlw	01h

	retlw	08Bh
	retlw	01h

	retlw	095h
	retlw	01h

	retlw	09Fh
	retlw	01h

	retlw	0A9h
	retlw	01h

	retlw	0B3h
	retlw	01h

	retlw	0BDh
	retlw	01h

	retlw	0C9h
	retlw	01h

	retlw	0D6h
	retlw	01h

	retlw	0E2h
	retlw	01h

	retlw	0EDh
	retlw	01h

	retlw	0F7h
	retlw	01h

	retlw	01h
	retlw	02h

	retlw	0Bh
	retlw	02h

	retlw	015h
	retlw	02h

	retlw	01Fh
	retlw	02h

	retlw	029h
	retlw	02h

	retlw	033h
	retlw	02h

	retlw	03Ah
	retlw	02h

	retlw	044h
	retlw	02h

	retlw	04Eh
	retlw	02h

	retlw	058h
	retlw	02h

	retlw	062h
	retlw	02h

	retlw	06Ch
	retlw	02h

	retlw	077h
	retlw	02h

	retlw	082h
	retlw	02h

	retlw	08Dh
	retlw	02h

	retlw	09Bh
	retlw	02h

	retlw	0A9h
	retlw	02h

	retlw	0B7h
	retlw	02h

	retlw	0C6h
	retlw	02h

	retlw	0D3h
	retlw	02h

	retlw	0E1h
	retlw	02h

	retlw	0EBh
	retlw	02h

	retlw	0F5h
	retlw	02h

	retlw	0FFh
	retlw	02h

	retlw	09h
	retlw	03h

	retlw	013h
	retlw	03h

	retlw	01Dh
	retlw	03h

	retlw	027h
	retlw	03h

	retlw	031h
	retlw	03h

	retlw	03Bh
	retlw	03h

	retlw	043h
	retlw	03h

	retlw	04Bh
	retlw	03h

	retlw	053h
	retlw	03h

	retlw	057h
	retlw	03h

	retlw	05Ch
	retlw	03h

	retlw	05Fh
	retlw	03h

	retlw	064h
	retlw	03h

	retlw	06Ch
	retlw	03h

	retlw	074h
	retlw	03h

	retlw	07Ch
	retlw	03h

	retlw	084h
	retlw	03h

	retlw	08Ch
	retlw	03h

	retlw	094h
	retlw	03h

	retlw	09Ch
	retlw	03h

	retlw	0A4h
	retlw	03h

	retlw	0ACh
	retlw	03h

	retlw	0B4h
	retlw	03h

	retlw	0BCh
	retlw	03h

	retlw	0C4h
	retlw	03h

	retlw	0CCh
	retlw	03h

	retlw	0D4h
	retlw	03h

	retlw	0DCh
	retlw	03h

	retlw	0E4h
	retlw	03h

	retlw	0ECh
	retlw	03h

	retlw	0F4h
	retlw	03h

	retlw	0FCh
	retlw	03h

	retlw	0Bh
	retlw	04h

	retlw	01Ah
	retlw	04h

	retlw	022h
	retlw	04h

	retlw	029h
	retlw	04h

	retlw	031h
	retlw	04h

	retlw	038h
	retlw	04h

	retlw	040h
	retlw	04h

	retlw	048h
	retlw	04h

	retlw	04Fh
	retlw	04h

	retlw	057h
	retlw	04h

	retlw	05Eh
	retlw	04h

	retlw	066h
	retlw	04h

	retlw	06Eh
	retlw	04h

	retlw	075h
	retlw	04h

	retlw	07Dh
	retlw	04h

	retlw	084h
	retlw	04h

	retlw	08Ch
	retlw	04h

	retlw	094h
	retlw	04h

	retlw	09Bh
	retlw	04h

	retlw	0A3h
	retlw	04h

	retlw	0AAh
	retlw	04h

	retlw	0B2h
	retlw	04h

	retlw	0BAh
	retlw	04h

	retlw	0C1h
	retlw	04h

	retlw	0C9h
	retlw	04h

	retlw	0D0h
	retlw	04h

	retlw	0D8h
	retlw	04h

	retlw	0E0h
	retlw	04h

	retlw	0E7h
	retlw	04h

	retlw	0EFh
	retlw	04h

	retlw	0F6h
	retlw	04h

	retlw	0FEh
	retlw	04h

	retlw	06h
	retlw	05h

	retlw	0Dh
	retlw	05h

	retlw	015h
	retlw	05h

	retlw	01Ch
	retlw	05h

	retlw	024h
	retlw	05h

	retlw	02Ch
	retlw	05h

	retlw	033h
	retlw	05h

	retlw	03Bh
	retlw	05h

	retlw	042h
	retlw	05h

	retlw	04Ah
	retlw	05h

	retlw	052h
	retlw	05h

	retlw	059h
	retlw	05h

	retlw	061h
	retlw	05h

	retlw	068h
	retlw	05h

	retlw	06Ch
	retlw	05h

	retlw	070h
	retlw	05h

	retlw	074h
	retlw	05h

	retlw	078h
	retlw	05h

	retlw	07Ch
	retlw	05h

	retlw	080h
	retlw	05h

	retlw	084h
	retlw	05h

	retlw	088h
	retlw	05h

	retlw	08Ch
	retlw	05h

	retlw	090h
	retlw	05h

	retlw	094h
	retlw	05h

	retlw	098h
	retlw	05h

	retlw	09Ch
	retlw	05h

	retlw	0A0h
	retlw	05h

	retlw	0A4h
	retlw	05h

	retlw	0A8h
	retlw	05h

	retlw	0ACh
	retlw	05h

	retlw	0B0h
	retlw	05h

	retlw	0B4h
	retlw	05h

	retlw	0B8h
	retlw	05h

	retlw	0BCh
	retlw	05h

	retlw	0C0h
	retlw	05h

	retlw	0C4h
	retlw	05h

	retlw	0C8h
	retlw	05h

	retlw	0CCh
	retlw	05h

	retlw	0D0h
	retlw	05h

	retlw	0D4h
	retlw	05h

	retlw	0D8h
	retlw	05h

	retlw	0DCh
	retlw	05h

	retlw	0E0h
	retlw	05h

	retlw	0E4h
	retlw	05h

	retlw	0E8h
	retlw	05h

	retlw	0ECh
	retlw	05h

	retlw	0F0h
	retlw	05h

	retlw	0F4h
	retlw	05h

	retlw	0F8h
	retlw	05h

	retlw	0FCh
	retlw	05h

	retlw	0
	retlw	06h

	retlw	04h
	retlw	06h

	retlw	08h
	retlw	06h

	retlw	0Ch
	retlw	06h

	retlw	010h
	retlw	06h

	retlw	014h
	retlw	06h

	global __end_of_PureHz_Tab
__end_of_PureHz_Tab:
psect	stringtext
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	124
_gc_KeyLDOSel:
	retlw	03h
	global __end_of_gc_KeyLDOSel
__end_of_gc_KeyLDOSel:
psect	stringtext
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	122
_gc_LMDValue:
	retlw	01h
	global __end_of_gc_LMDValue
__end_of_gc_LMDValue:
psect	stringtext
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	116
_gc_CmBase:
	retlw	06h
	global __end_of_gc_CmBase
__end_of_gc_CmBase:
psect	stringtext
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
_gc_VolValue:
	retlw	032h
	global __end_of_gc_VolValue
__end_of_gc_VolValue:
	global	_NTC_Tab
	global	_sc_FreScanTable1
	global	_sc_FreScanTable
	global	_sc_Table_KeyFalg
	global	_sc_CurStep_Table
	global	_gc_Table_KeyDown
	global	_gc_Table_KeyChannel
	global	_PureHz_Tab
	global	_919
	global	_Mode
	global	__BITS
	global	_927
	global	_926
	global	_925
	global	_924
	global	_gf_kerr
	global	_KeyPacket_y
	global	AD_Testing@admax
	global	AD_Testing@admin
	global	_PreTdsData
	global	_g_KeyFlag
	global	_923
	global	_922
	global	_921
	global	_920
	global	_918
	global	_917
	global	_916
	global	AD_Testing@adtimes
	global	StandbyMode_Handle@Ti_1h
	global	_BeepAlmCnt
	global	_ErrorVar
	global	_Time_Power_1s
	global	_Temp_Ntc
	global	_FilterBuzzer_1s
	global	_TdsCk60sFlag
	global	_PowerStep
	global	_Time_100ms
	global	_Time_GetWater_1s
	global	_Time_1s
	global	_Timer_Power_100ms
	global	_StandByStatus
	global	_Timer_TdsMake_1s
	global	_FilterFastCheck
	global	_Timer_ErrorLong_1s
	global	__BITS2
	global	__BITS1
	global	_FilterROGetWater
	global	_FilterPCFGetWater
	global	_FilterROState
	global	_FilterPCFState
	global	_WashRunTime
	global	_Read_Word_Buff
	global	___CMS_CheckValidTime@F1029
	global	___CMS_Noise_check@F969
	global	___CMS_Noise_check@F968
	global	AD_Testing@adsum
	global	CheckKey@KeyOldFlag
	global	FilterKeyInputRest@FilterSelect_10ms
	global	_BeepOnTimeCnt
	global	_BuzzerFilter
	global	_ML_Temp
	global	_Date_Temp
	global	_Timer_Standby_1H
	global	_Timer_BackT_1H
	global	_Timer_Standby_1s
	global	_Timer_WashRun_1s
	global	_FilterRst_1s
	global	_PreROu16Day
	global	_PrePCFu16Day
	global	_Timer_LongGetWater_1s
	global	_GetWater_ML
	global	_Time_made_1s
	global	___CMS_CheckTouchKey@F1073
	global	___CMS_CurAdjust@F1044
	global	___CMS_Key_UNNOL_Check@F1016
	global	___CMS_Noise_check@F967
	global	___CMS_Noise_check@F966
	global	___CMS_Noise_check@F965
	global	___CMS_Noise_check@F964
	global	Timer1_Isr@T1_1ms
	global	CheckKey@temp
	global	_FilterRO_time
	global	_FilterPCF_time
	global	_LedMod
	global	_Tx_Type
	global	_PureTDSTyp
	global	_887
_887	set	13
	global	_T2CON
_T2CON	set	18
	global	_T1CON
_T1CON	set	16
	global	_TMR1H
_TMR1H	set	15
	global	_TMR1L
_TMR1L	set	14
	global	_INTCON
_INTCON	set	11
	global	_PORTC
_PORTC	set	7
	global	_PORTB
_PORTB	set	6
	global	_PORTA
_PORTA	set	5
	global	_TMR0
_TMR0	set	1
	global	_TMR1IF
_TMR1IF	set	96
	global	_TMR2IF
_TMR2IF	set	97
	global	_INTF
_INTF	set	89
	global	_T0IF
_T0IF	set	90
	global	_GIE
_GIE	set	95
	global	_RC1
_RC1	set	57
	global	_RC2
_RC2	set	58
	global	_RC3
_RC3	set	59
	global	_RB0
_RB0	set	48
	global	_RB2
_RB2	set	50
	global	_RB3
_RB3	set	51
	global	_RB4
_RB4	set	52
	global	_RB5
_RB5	set	53
	global	_RB6
_RB6	set	54
	global	_RA0
_RA0	set	40
	global	_RA1
_RA1	set	41
	global	_RA2
_RA2	set	42
	global	_RA6
_RA6	set	46
	global	_RA7
_RA7	set	47
	global	_ADCON1
_ADCON1	set	159
	global	_ADCON0
_ADCON0	set	158
	global	_ADRESH
_ADRESH	set	157
	global	_ADRESL
_ADRESL	set	156
	global	_WPUC
_WPUC	set	154
	global	_WPUA
_WPUA	set	153
	global	_SPBRG1
_SPBRG1	set	152
	global	_WPUB
_WPUB	set	149
	global	_PR2
_PR2	set	146
	global	_OSCCON
_OSCCON	set	143
	global	_PIE2
_PIE2	set	141
	global	_PIE1
_PIE1	set	140
	global	_ANSEL1
_ANSEL1	set	137
	global	_TRISD
_TRISD	set	136
	global	_TRISC
_TRISC	set	135
	global	_TRISB
_TRISB	set	134
	global	_TRISA
_TRISA	set	133
	global	_OPTION_REG
_OPTION_REG	set	129
	global	_GODONE
_GODONE	set	1265
	global	_RC1IE
_RC1IE	set	1129
	global	_TX1IE
_TX1IE	set	1130
	global	_TMR1IE
_TMR1IE	set	1120
	global	_INTEDG
_INTEDG	set	1038
	global	_TXREG1
_TXREG1	set	285
	global	_PWMTH
_PWMTH	set	284
	global	_PWMTL
_PWMTL	set	283
	global	_PWMD01H
_PWMD01H	set	273
	global	_PWMD1L
_PWMD1L	set	269
	global	_PWMCON1
_PWMCON1	set	263
	global	_PWMCON0
_PWMCON0	set	262
	global	_TRMT1
_TRMT1	set	2297
	global	_SCKP1
_SCKP1	set	2299
	global	_SYNC1
_SYNC1	set	2300
	global	_TXEN1
_TXEN1	set	2301
	global	_TX9EN1
_TX9EN1	set	2302
	global	_PWM1EN
_PWM1EN	set	2097
	global	_CREN1
_CREN1	set	2092
	global	_RX9EN1
_RX9EN1	set	2094
	global	_SPEN1
_SPEN1	set	2095
	global	_914
_914	set	416
	global	_905
_905	set	416
	global	_903
_903	set	448
	global	_902
_902	set	416
	global	_900
_900	set	448
	global	_899
_899	set	416
	global	_897
_897	set	448
	global	_896
_896	set	416
	global	_913
_913	set	480
	global	_912
_912	set	464
	global	_911
_911	set	448
	global	_910
_910	set	432
	global	_909
_909	set	416
	global	_904
_904	set	480
	global	_901
_901	set	480
	global	_898
_898	set	480
	global	_886
_886	set	415
	global	_885
_885	set	412
	global	_884
_884	set	411
	global	_883
_883	set	414
	global	_882
_882	set	413
	global	_881
_881	set	410
	global	_880
_880	set	409
	global	_879
_879	set	408
	global	_878
_878	set	407
	global	_877
_877	set	406
	global	_876
_876	set	405
	global	_875
_875	set	404
	global	_874
_874	set	403
	global	_873
_873	set	402
	global	_872
_872	set	401
	global	_871
_871	set	400
	global	_EECON2
_EECON2	set	397
	global	_EECON1
_EECON1	set	396
	global	_EEADR
_EEADR	set	391
	global	_EEDAT
_EEDAT	set	390
	global	_RD
_RD	set	3168
	global	_WR
_WR	set	3169
	global	_WREN
_WREN	set	3170
	global	_WRERR
_WRERR	set	3171
	global	_EEPGD
_EEPGD	set	3175
; #config settings
	file	"Sbaake.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_927:
       ds      1

_926:
       ds      1

_925:
       ds      1

_924:
       ds      1

_gf_kerr:
       ds      1

psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_919:
       ds      1

_Mode:
       ds      1

__BITS:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_KeyPacket_y:
       ds      9

AD_Testing@admax:
       ds      2

AD_Testing@admin:
       ds      2

_PreTdsData:
       ds      2

_g_KeyFlag:
       ds      2

_923:
       ds      1

_922:
       ds      1

_921:
       ds      1

_920:
       ds      1

_918:
       ds      1

_917:
       ds      1

_916:
       ds      1

AD_Testing@adtimes:
       ds      1

StandbyMode_Handle@Ti_1h:
       ds      1

_BeepAlmCnt:
       ds      1

_ErrorVar:
       ds      1

_Time_Power_1s:
       ds      1

_Temp_Ntc:
       ds      1

_FilterBuzzer_1s:
       ds      1

_TdsCk60sFlag:
       ds      1

_PowerStep:
       ds      1

_Time_100ms:
       ds      1

_Time_GetWater_1s:
       ds      1

_Time_1s:
       ds      1

_Timer_Power_100ms:
       ds      1

_StandByStatus:
       ds      1

_Timer_TdsMake_1s:
       ds      1

_FilterFastCheck:
       ds      1

_Timer_ErrorLong_1s:
       ds      1

__BITS2:
       ds      1

__BITS1:
       ds      1

_FilterROGetWater:
       ds      2

_FilterPCFGetWater:
       ds      2

_FilterROState:
       ds      1

_FilterPCFState:
       ds      1

_WashRunTime:
       ds      1

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_Read_Word_Buff:
       ds      12

___CMS_CheckValidTime@F1029:
       ds      2

___CMS_Noise_check@F969:
       ds      2

___CMS_Noise_check@F968:
       ds      2

AD_Testing@adsum:
       ds      2

CheckKey@KeyOldFlag:
       ds      2

FilterKeyInputRest@FilterSelect_10ms:
       ds      2

_BeepOnTimeCnt:
       ds      2

_BuzzerFilter:
       ds      2

_ML_Temp:
       ds      2

_Date_Temp:
       ds      2

_Timer_Standby_1H:
       ds      2

_Timer_BackT_1H:
       ds      2

_Timer_Standby_1s:
       ds      2

_Timer_WashRun_1s:
       ds      2

_FilterRst_1s:
       ds      2

_PreROu16Day:
       ds      2

_PrePCFu16Day:
       ds      2

_Timer_LongGetWater_1s:
       ds      2

_GetWater_ML:
       ds      2

_Time_made_1s:
       ds      2

___CMS_CheckTouchKey@F1073:
       ds      1

___CMS_CurAdjust@F1044:
       ds      1

___CMS_Key_UNNOL_Check@F1016:
       ds      1

___CMS_Noise_check@F967:
       ds      1

___CMS_Noise_check@F966:
       ds      1

___CMS_Noise_check@F965:
       ds      1

___CMS_Noise_check@F964:
       ds      1

Timer1_Isr@T1_1ms:
       ds      1

CheckKey@temp:
       ds      1

_FilterRO_time:
       ds      5

_FilterPCF_time:
       ds      5

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_LedMod:
       ds      30

_Tx_Type:
       ds      17

_PureTDSTyp:
       ds      17

	file	"Sbaake.as"
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
	clrf	((__pbssCOMMON)+1)&07Fh
	clrf	((__pbssCOMMON)+2)&07Fh
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+032h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+047h)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+040h)
	fcall	clear_ram0
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
??_Time_Count_Func:	; 1 bytes @ 0x0
	ds	3
	global	FactoryMode_Handle@Step
FactoryMode_Handle@Step:	; 1 bytes @ 0x3
	ds	1
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?___CMS_CheckTouchKey:	; 1 bytes @ 0x0
?_CheckKey:	; 1 bytes @ 0x0
?_FilterLifeFunc:	; 1 bytes @ 0x0
?_TaskAlarmHandle:	; 1 bytes @ 0x0
?_Led_Handle:	; 1 bytes @ 0x0
?_FilterKeyInputRest:	; 1 bytes @ 0x0
?_Tx_Display:	; 1 bytes @ 0x0
?_ErrorHandle:	; 1 bytes @ 0x0
?_Page_ProgramData:	; 1 bytes @ 0x0
?_WrterEEP:	; 1 bytes @ 0x0
?___CMS_TouchKeyValue:	; 1 bytes @ 0x0
??___CMS_TouchKeyValue:	; 1 bytes @ 0x0
?_GetDelayFilterFlag:	; 1 bytes @ 0x0
?_Time_Count_Func:	; 1 bytes @ 0x0
?_AllLedFlash:	; 1 bytes @ 0x0
?_GetStop:	; 1 bytes @ 0x0
?_ShiftMode_Handle:	; 1 bytes @ 0x0
?_GetMode_Handle:	; 1 bytes @ 0x0
?_WashHandle:	; 1 bytes @ 0x0
?_StatusFun_Handle:	; 1 bytes @ 0x0
?_FactoryMode_Handle:	; 1 bytes @ 0x0
?_StandbyMode_Handle:	; 1 bytes @ 0x0
?_Run_Mode:	; 1 bytes @ 0x0
?_ReadDataArry:	; 1 bytes @ 0x0
?_EEPROM_Page:	; 1 bytes @ 0x0
?_Init_ram:	; 1 bytes @ 0x0
?_Initialize:	; 1 bytes @ 0x0
?_Timer1_Isr:	; 1 bytes @ 0x0
??_Timer1_Isr:	; 1 bytes @ 0x0
?_Set_Usart_Async:	; 1 bytes @ 0x0
?_Set_PWM:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?___CMS_KeyIsIn:	; 1 bytes @ 0x0
?___CMS_KeyClearOne:	; 1 bytes @ 0x0
?___CMS_KeyStopClear:	; 1 bytes @ 0x0
?___CMS_Noise_check:	; 1 bytes @ 0x0
?___CMS_CheckOnceResult:	; 1 bytes @ 0x0
?___CMS_CheckKeyOldValue:	; 1 bytes @ 0x0
?___CMS_Key_UNNOL_Check:	; 1 bytes @ 0x0
?___CMS_KeyDatIIR:	; 1 bytes @ 0x0
?___CMS_CheckValidTime:	; 1 bytes @ 0x0
?___CMS_CurAdjMode:	; 1 bytes @ 0x0
?___CMS_KeyModeSet:	; 1 bytes @ 0x0
?___CMS_KeyStart:	; 1 bytes @ 0x0
?___CMS_CurJudge:	; 1 bytes @ 0x0
?___CMS_CurAdjust:	; 1 bytes @ 0x0
?___CMS_NewRAMClr:	; 1 bytes @ 0x0
?___GET_32M_FREDAT:	; 1 bytes @ 0x0
	ds	4
??_TaskAlarmHandle:	; 1 bytes @ 0x4
??_Tx_Display:	; 1 bytes @ 0x4
?_BuzzerSet:	; 1 bytes @ 0x4
?_SetStandbyState:	; 1 bytes @ 0x4
??_WrterEEP:	; 1 bytes @ 0x4
?_Dec:	; 1 bytes @ 0x4
?_DecF:	; 1 bytes @ 0x4
??_SetFilterDelayReset:	; 1 bytes @ 0x4
?_TDS_Handle:	; 1 bytes @ 0x4
?_LedControlSt:	; 1 bytes @ 0x4
??_GetStop:	; 1 bytes @ 0x4
??_Memory_Write:	; 1 bytes @ 0x4
??_Init_ram:	; 1 bytes @ 0x4
??_Initialize:	; 1 bytes @ 0x4
??_Set_Usart_Async:	; 1 bytes @ 0x4
??_Set_PWM:	; 1 bytes @ 0x4
??___CMS_KeyIsIn:	; 1 bytes @ 0x4
?___CMS_KeyOpen:	; 1 bytes @ 0x4
?___CMS_KeyHaveDown:	; 1 bytes @ 0x4
??___CMS_KeyClearOne:	; 1 bytes @ 0x4
??___CMS_Key_UNNOL_Check:	; 1 bytes @ 0x4
??___CMS_KeyDatIIR:	; 1 bytes @ 0x4
??___CMS_CheckValidTime:	; 1 bytes @ 0x4
??___CMS_CurAdjMode:	; 1 bytes @ 0x4
??___CMS_KeyModeSet:	; 1 bytes @ 0x4
??___CMS_KeyStart:	; 1 bytes @ 0x4
??___CMS_CurJudge:	; 1 bytes @ 0x4
??___CMS_NewRAMClr:	; 1 bytes @ 0x4
??___GET_32M_FREDAT:	; 1 bytes @ 0x4
??___lmul:	; 1 bytes @ 0x4
?___bmul:	; 1 bytes @ 0x4
??___lldiv:	; 1 bytes @ 0x4
??___lwdiv:	; 1 bytes @ 0x4
?_AD_Testing:	; 2 bytes @ 0x4
	global	?_abs
?_abs:	; 2 bytes @ 0x4
	global	?_Memory_Read
?_Memory_Read:	; 2 bytes @ 0x4
	global	Dec@max
Dec@max:	; 1 bytes @ 0x4
	global	SetFilterDelayReset@TimPtr
SetFilterDelayReset@TimPtr:	; 1 bytes @ 0x4
	global	TDS_Handle@Type
TDS_Handle@Type:	; 1 bytes @ 0x4
	global	LedControlSt@Sta
LedControlSt@Sta:	; 1 bytes @ 0x4
	global	SetStandbyState@Time
SetStandbyState@Time:	; 1 bytes @ 0x4
	global	Memory_Write@i
Memory_Write@i:	; 1 bytes @ 0x4
	global	AD_Testing@ad_ch
AD_Testing@ad_ch:	; 1 bytes @ 0x4
	global	___CMS_KeyIsIn@947
___CMS_KeyIsIn@947:	; 1 bytes @ 0x4
	global	___CMS_KeyOpen@952
___CMS_KeyOpen@952:	; 1 bytes @ 0x4
	global	___CMS_KeyHaveDown@956
___CMS_KeyHaveDown@956:	; 1 bytes @ 0x4
	global	___CMS_CurAdjMode@1032
___CMS_CurAdjMode@1032:	; 1 bytes @ 0x4
	global	___CMS_KeyModeSet@1035
___CMS_KeyModeSet@1035:	; 1 bytes @ 0x4
	global	___CMS_KeyStart@1038
___CMS_KeyStart@1038:	; 1 bytes @ 0x4
	global	___CMS_NewRAMClr@1051
___CMS_NewRAMClr@1051:	; 1 bytes @ 0x4
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x4
	global	DecF@max
DecF@max:	; 2 bytes @ 0x4
	global	BuzzerSet@filter
BuzzerSet@filter:	; 2 bytes @ 0x4
	global	Memory_Read@Addr
Memory_Read@Addr:	; 2 bytes @ 0x4
	global	abs@a
abs@a:	; 2 bytes @ 0x4
	ds	1
??_Page_ProgramData:	; 1 bytes @ 0x5
?_LedSetSt:	; 1 bytes @ 0x5
??_Dec:	; 1 bytes @ 0x5
??_LedControlSt:	; 1 bytes @ 0x5
??___CMS_KeyOpen:	; 1 bytes @ 0x5
??___CMS_KeyHaveDown:	; 1 bytes @ 0x5
??___bmul:	; 1 bytes @ 0x5
	global	Dec@var
Dec@var:	; 1 bytes @ 0x5
	global	LedSetSt@Sta
LedSetSt@Sta:	; 1 bytes @ 0x5
	global	LedControlSt@Num
LedControlSt@Num:	; 1 bytes @ 0x5
	global	SetStandbyState@Da
SetStandbyState@Da:	; 1 bytes @ 0x5
	global	AD_Testing@ad_lr
AD_Testing@ad_lr:	; 1 bytes @ 0x5
	global	___CMS_KeyIsIn@946
___CMS_KeyIsIn@946:	; 1 bytes @ 0x5
	global	___CMS_KeyOpen@951
___CMS_KeyOpen@951:	; 1 bytes @ 0x5
	global	___CMS_KeyHaveDown@955
___CMS_KeyHaveDown@955:	; 1 bytes @ 0x5
	ds	1
??___CMS_CheckTouchKey:	; 1 bytes @ 0x6
??_FilterLifeFunc:	; 1 bytes @ 0x6
??_FilterKeyInputRest:	; 1 bytes @ 0x6
??_ErrorHandle:	; 1 bytes @ 0x6
??_BuzzerSet:	; 1 bytes @ 0x6
??_SetStandbyState:	; 1 bytes @ 0x6
??_LedSetSt:	; 1 bytes @ 0x6
??_AllLedFlash:	; 1 bytes @ 0x6
??_ShiftMode_Handle:	; 1 bytes @ 0x6
??_GetMode_Handle:	; 1 bytes @ 0x6
??_StatusFun_Handle:	; 1 bytes @ 0x6
??_FactoryMode_Handle:	; 1 bytes @ 0x6
??_Memory_Read:	; 1 bytes @ 0x6
??_StandbyMode_Handle:	; 1 bytes @ 0x6
??_Run_Mode:	; 1 bytes @ 0x6
??_ReadDataArry:	; 1 bytes @ 0x6
??_EEPROM_Page:	; 1 bytes @ 0x6
??_main:	; 1 bytes @ 0x6
??___CMS_KeyStopClear:	; 1 bytes @ 0x6
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
??_AD_Testing:	; 1 bytes @ 0x0
??_abs:	; 1 bytes @ 0x0
??_DecF:	; 1 bytes @ 0x0
?_SetFilterDelayReset:	; 1 bytes @ 0x0
?_Memory_Write:	; 1 bytes @ 0x0
??___CMS_Noise_check:	; 1 bytes @ 0x0
??___CMS_CheckOnceResult:	; 1 bytes @ 0x0
??___CMS_CurAdjust:	; 1 bytes @ 0x0
	global	?_GetCurTdsHz
?_GetCurTdsHz:	; 2 bytes @ 0x0
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x0
	global	?___lmul
?___lmul:	; 4 bytes @ 0x0
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x0
	global	SetStandbyState@STY
SetStandbyState@STY:	; 1 bytes @ 0x0
	global	BuzzerSet@cnt
BuzzerSet@cnt:	; 1 bytes @ 0x0
	global	Tx_Display@Sum_Tot
Tx_Display@Sum_Tot:	; 1 bytes @ 0x0
	global	___CMS_KeyClearOne@958
___CMS_KeyClearOne@958:	; 1 bytes @ 0x0
	global	___CMS_Key_UNNOL_Check@1018
___CMS_Key_UNNOL_Check@1018:	; 1 bytes @ 0x0
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x0
	global	GetCurTdsHz@Tab
GetCurTdsHz@Tab:	; 2 bytes @ 0x0
	global	SetFilterDelayReset@Day
SetFilterDelayReset@Day:	; 2 bytes @ 0x0
	global	Memory_Write@Addr
Memory_Write@Addr:	; 2 bytes @ 0x0
	global	ReadDataArry@i
ReadDataArry@i:	; 2 bytes @ 0x0
	global	___CMS_KeyDatIIR@1023
___CMS_KeyDatIIR@1023:	; 2 bytes @ 0x0
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x0
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x0
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x0
	ds	1
?_KeyScan:	; 1 bytes @ 0x1
	global	Tx_Display@Temp1
Tx_Display@Temp1:	; 1 bytes @ 0x1
	global	KeyScan@num
KeyScan@num:	; 1 bytes @ 0x1
	global	___CMS_KeyStopClear@961
___CMS_KeyStopClear@961:	; 1 bytes @ 0x1
	global	___CMS_Key_UNNOL_Check@1017
___CMS_Key_UNNOL_Check@1017:	; 1 bytes @ 0x1
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x1
	ds	1
??_Led_Handle:	; 1 bytes @ 0x2
??_KeyScan:	; 1 bytes @ 0x2
??___CMS_CheckKeyOldValue:	; 1 bytes @ 0x2
	global	DecF@var
DecF@var:	; 1 bytes @ 0x2
	global	SetFilterDelayReset@hour
SetFilterDelayReset@hour:	; 1 bytes @ 0x2
	global	LedSetSt@Num
LedSetSt@Num:	; 1 bytes @ 0x2
	global	Memory_Write@Value
Memory_Write@Value:	; 1 bytes @ 0x2
	global	AD_Testing@ad_fd
AD_Testing@ad_fd:	; 1 bytes @ 0x2
	global	___CMS_CurAdjust@1046
___CMS_CurAdjust@1046:	; 1 bytes @ 0x2
	global	GetCurTdsHz@index
GetCurTdsHz@index:	; 2 bytes @ 0x2
	global	Tx_Display@i
Tx_Display@i:	; 2 bytes @ 0x2
	global	___CMS_KeyDatIIR@1024
___CMS_KeyDatIIR@1024:	; 2 bytes @ 0x2
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x2
	ds	1
??_GetDelayFilterFlag:	; 1 bytes @ 0x3
?_FilterTimeHandle:	; 1 bytes @ 0x3
??_WashHandle:	; 1 bytes @ 0x3
	global	SetFilterDelayReset@min
SetFilterDelayReset@min:	; 1 bytes @ 0x3
	global	AllLedFlash@Type
AllLedFlash@Type:	; 1 bytes @ 0x3
	global	ShiftMode_Handle@Mod
ShiftMode_Handle@Mod:	; 1 bytes @ 0x3
	global	___CMS_CurAdjust@1045
___CMS_CurAdjust@1045:	; 1 bytes @ 0x3
	global	AD_Testing@AD_Result
AD_Testing@AD_Result:	; 2 bytes @ 0x3
	global	Page_ProgramData@i
Page_ProgramData@i:	; 2 bytes @ 0x3
	global	___CMS_Noise_check@974
___CMS_Noise_check@974:	; 2 bytes @ 0x3
	global	FilterTimeHandle@Filter_time
FilterTimeHandle@Filter_time:	; 5 bytes @ 0x3
	ds	1
??_GetCurTdsHz:	; 1 bytes @ 0x4
	global	KeyScan@sw_port
KeyScan@sw_port:	; 1 bytes @ 0x4
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x4
	global	SetFilterDelayReset@sec
SetFilterDelayReset@sec:	; 2 bytes @ 0x4
	global	AllLedFlash@i
AllLedFlash@i:	; 2 bytes @ 0x4
	global	Led_Handle@i
Led_Handle@i:	; 2 bytes @ 0x4
	global	___CMS_CheckKeyOldValue@1006
___CMS_CheckKeyOldValue@1006:	; 2 bytes @ 0x4
	global	___CMS_KeyDatIIR@1022
___CMS_KeyDatIIR@1022:	; 2 bytes @ 0x4
	global	___CMS_CurAdjust@1047
___CMS_CurAdjust@1047:	; 2 bytes @ 0x4
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x4
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x4
	ds	1
??_CheckKey:	; 1 bytes @ 0x5
	global	GetDelayFilterFlag@PtrMin
GetDelayFilterFlag@PtrMin:	; 1 bytes @ 0x5
	global	AD_Testing@i
AD_Testing@i:	; 1 bytes @ 0x5
	global	___CMS_Noise_check@971
___CMS_Noise_check@971:	; 1 bytes @ 0x5
	global	___CMS_CheckOnceResult@989
___CMS_CheckOnceResult@989:	; 2 bytes @ 0x5
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x5
	ds	1
	global	CheckKey@St
CheckKey@St:	; 1 bytes @ 0x6
	global	___CMS_Noise_check@972
___CMS_Noise_check@972:	; 1 bytes @ 0x6
	global	___CMS_CheckKeyOldValue@1004
___CMS_CheckKeyOldValue@1004:	; 1 bytes @ 0x6
	global	AD_Testing@data
AD_Testing@data:	; 2 bytes @ 0x6
	global	___CMS_KeyDatIIR@1025
___CMS_KeyDatIIR@1025:	; 2 bytes @ 0x6
	ds	1
	global	___CMS_CheckOnceResult@980
___CMS_CheckOnceResult@980:	; 1 bytes @ 0x7
	global	CheckKey@i
CheckKey@i:	; 2 bytes @ 0x7
	global	___CMS_Noise_check@975
___CMS_Noise_check@975:	; 2 bytes @ 0x7
	global	___CMS_CheckKeyOldValue@1007
___CMS_CheckKeyOldValue@1007:	; 2 bytes @ 0x7
	ds	1
	global	FilterTimeHandle@FilterState
FilterTimeHandle@FilterState:	; 1 bytes @ 0x8
	global	___CMS_CheckOnceResult@981
___CMS_CheckOnceResult@981:	; 1 bytes @ 0x8
	global	___CMS_KeyDatIIR@1026
___CMS_KeyDatIIR@1026:	; 2 bytes @ 0x8
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x8
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x8
	ds	1
	global	FilterTimeHandle@Type
FilterTimeHandle@Type:	; 1 bytes @ 0x9
	global	___CMS_CheckOnceResult@985
___CMS_CheckOnceResult@985:	; 1 bytes @ 0x9
	global	___CMS_Noise_check@973
___CMS_Noise_check@973:	; 2 bytes @ 0x9
	global	___CMS_CheckKeyOldValue@1008
___CMS_CheckKeyOldValue@1008:	; 2 bytes @ 0x9
	ds	1
	global	FilterTimeHandle@FilterGetWater
FilterTimeHandle@FilterGetWater:	; 1 bytes @ 0xA
	global	___CMS_CheckOnceResult@986
___CMS_CheckOnceResult@986:	; 1 bytes @ 0xA
	global	___CMS_KeyDatIIR@1021
___CMS_KeyDatIIR@1021:	; 1 bytes @ 0xA
	global	GetCurTdsHz@i
GetCurTdsHz@i:	; 2 bytes @ 0xA
	ds	1
??_FilterTimeHandle:	; 1 bytes @ 0xB
	global	___CMS_Noise_check@970
___CMS_Noise_check@970:	; 1 bytes @ 0xB
	global	___CMS_CheckOnceResult@982
___CMS_CheckOnceResult@982:	; 1 bytes @ 0xB
	global	___CMS_CheckKeyOldValue@1009
___CMS_CheckKeyOldValue@1009:	; 2 bytes @ 0xB
	ds	1
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0xC
	global	GetCurTdsHz@tmp
GetCurTdsHz@tmp:	; 2 bytes @ 0xC
	global	___CMS_CheckOnceResult@990
___CMS_CheckOnceResult@990:	; 2 bytes @ 0xC
	ds	1
	global	___CMS_CheckKeyOldValue@1005
___CMS_CheckKeyOldValue@1005:	; 1 bytes @ 0xD
	ds	1
	global	GetCurTdsHz@AdPtr
GetCurTdsHz@AdPtr:	; 1 bytes @ 0xE
	global	___CMS_CheckKeyOldValue@1003
___CMS_CheckKeyOldValue@1003:	; 1 bytes @ 0xE
	global	___CMS_CheckOnceResult@991
___CMS_CheckOnceResult@991:	; 2 bytes @ 0xE
	ds	1
??_TDS_Handle:	; 1 bytes @ 0xF
	ds	1
	global	___CMS_CheckOnceResult@983
___CMS_CheckOnceResult@983:	; 1 bytes @ 0x10
	ds	1
	global	___CMS_CheckOnceResult@984
___CMS_CheckOnceResult@984:	; 1 bytes @ 0x11
	ds	1
	global	___CMS_CheckOnceResult@988
___CMS_CheckOnceResult@988:	; 1 bytes @ 0x12
	ds	1
	global	___CMS_CheckOnceResult@987
___CMS_CheckOnceResult@987:	; 1 bytes @ 0x13
	global	TDS_Handle@NTC_
TDS_Handle@NTC_:	; 4 bytes @ 0x13
	ds	1
	global	___CMS_CheckOnceResult@979
___CMS_CheckOnceResult@979:	; 1 bytes @ 0x14
	ds	3
	global	TDS_Handle@i
TDS_Handle@i:	; 2 bytes @ 0x17
	ds	2
	global	TDS_Handle@Muni_c
TDS_Handle@Muni_c:	; 4 bytes @ 0x19
	ds	4
	global	TDS_Handle@TDSTyp
TDS_Handle@TDSTyp:	; 1 bytes @ 0x1D
	ds	1
;!
;!Data Sizes:
;!    Strings     0
;!    Constant    520
;!    Data        0
;!    BSS         188
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14      6      10
;!    BANK0            80     30      80
;!    BANK1            80      4      75
;!    BANK2            80      0      64

;!
;!Pointer List with Targets:
;!
;!    SetStandbyState@Time	PTR unsigned char  size(1) Largest target is 1
;!		 -> WashRunTime(BANK0[1]), 
;!
;!    FilterTimeHandle@FilterGetWater	PTR unsigned int  size(1) Largest target is 2
;!		 -> FilterPCFGetWater(BANK0[2]), FilterROGetWater(BANK0[2]), 
;!
;!    FilterTimeHandle@FilterState	PTR unsigned char  size(1) Largest target is 1
;!		 -> FilterPCFState(BANK0[1]), FilterROState(BANK0[1]), 
;!
;!    TDS_Handle@TDSTyp	PTR struct . size(1) Largest target is 17
;!		 -> PureTDSTyp(BANK2[17]), 
;!
;!    GetDelayFilterFlag@PtrMin	PTR struct . size(1) Largest target is 5
;!		 -> FilterRO_time(BANK1[5]), FilterPCF_time(BANK1[5]), 
;!
;!    SetFilterDelayReset@TimPtr	PTR struct . size(1) Largest target is 5
;!		 -> FilterRO_time(BANK1[5]), FilterPCF_time(BANK1[5]), 
;!
;!    DecF@var	PTR unsigned int  size(1) Largest target is 5
;!		 -> FilterRO_time(BANK1[5]), FilterPCF_time(BANK1[5]), 
;!
;!    Dec@var	PTR unsigned char  size(1) Largest target is 5
;!		 -> FilterRO_time(BANK1[5]), FilterPCF_time(BANK1[5]), 
;!
;!    GetCurTdsHz@Tab	PTR unsigned int  size(2) Largest target is 380
;!		 -> PureHz_Tab(CODE[380]), 
;!
;!    GetCurTdsHz@AdPtr	PTR struct . size(1) Largest target is 17
;!		 -> PureTDSTyp(BANK2[17]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    _Run_Mode->_BuzzerSet
;!    _Run_Mode->_LedSetSt
;!    _Run_Mode->_SetStandbyState
;!    _StandbyMode_Handle->_BuzzerSet
;!    _StandbyMode_Handle->_LedSetSt
;!    _StandbyMode_Handle->_SetStandbyState
;!    _StatusFun_Handle->_SetStandbyState
;!    _WashHandle->_LedSetSt
;!    _WashHandle->_SetStandbyState
;!    _FactoryMode_Handle->_BuzzerSet
;!    _FactoryMode_Handle->_LedSetSt
;!    _Time_Count_Func->_AD_Testing
;!    _Time_Count_Func->_BuzzerSet
;!    _Time_Count_Func->_SetStandbyState
;!    _Time_Count_Func->_TaskAlarmHandle
;!    ___CMS_CheckTouchKey->___CMS_Key_UNNOL_Check
;!    ___CMS_KeyStopClear->___CMS_KeyClearOne
;!    ___CMS_CurAdjust->___CMS_CurJudge
;!    ___CMS_CheckOnceResult->___CMS_KeyHaveDown
;!    ___CMS_CheckOnceResult->___CMS_KeyIsIn
;!    ___CMS_CheckOnceResult->___CMS_KeyOpen
;!    ___CMS_CheckKeyOldValue->___CMS_KeyIsIn
;!    ___CMS_CheckKeyOldValue->_abs
;!    _Page_ProgramData->_Memory_Write
;!    _Led_Handle->_LedControlSt
;!    _GetDelayFilterFlag->_Dec
;!    _GetDelayFilterFlag->_DecF
;!    _FilterLifeFunc->_BuzzerSet
;!    _FilterTimeHandle->_LedSetSt
;!    _FilterKeyInputRest->_BuzzerSet
;!    _FilterKeyInputRest->_LedSetSt
;!    _ErrorHandle->_BuzzerSet
;!    _ErrorHandle->_LedSetSt
;!    _ShiftMode_Handle->_BuzzerSet
;!    _ShiftMode_Handle->_LedSetSt
;!    _ShiftMode_Handle->_SetStandbyState
;!    _AllLedFlash->_LedSetSt
;!    _LedSetSt->___bmul
;!    _KeyScan->_BuzzerSet
;!    _ReadDataArry->_Memory_Read
;!
;!Critical Paths under _Timer1_Isr in COMMON
;!
;!    None.
;!
;!Critical Paths under _main in BANK0
;!
;!    _StatusFun_Handle->_WashHandle
;!    _WashHandle->_LedSetSt
;!    _GetMode_Handle->_ShiftMode_Handle
;!    _Time_Count_Func->_TDS_Handle
;!    ___CMS_CheckTouchKey->___CMS_CheckOnceResult
;!    ___CMS_KeyStopClear->___CMS_KeyClearOne
;!    ___CMS_CheckKeyOldValue->_abs
;!    _TDS_Handle->_GetCurTdsHz
;!    _Page_ProgramData->_Memory_Write
;!    _Led_Handle->___bmul
;!    _GetDelayFilterFlag->_DecF
;!    _FilterLifeFunc->_FilterTimeHandle
;!    _FilterTimeHandle->_LedSetSt
;!    _FilterKeyInputRest->_SetFilterDelayReset
;!    _ErrorHandle->_AllLedFlash
;!    _ShiftMode_Handle->_LedSetSt
;!    _AllLedFlash->_LedSetSt
;!    _LedSetSt->___bmul
;!    _CheckKey->_KeyScan
;!    _KeyScan->_BuzzerSet
;!    _EEPROM_Page->_SetFilterDelayReset
;!
;!Critical Paths under _Timer1_Isr in BANK0
;!
;!    None.
;!
;!Critical Paths under _main in BANK1
;!
;!    _Run_Mode->_FactoryMode_Handle
;!    _FactoryMode_Handle->_Time_Count_Func
;!
;!Critical Paths under _Timer1_Isr in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Timer1_Isr in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 0, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 0     0      0  261361
;!                        _EEPROM_Page
;!                         _Initialize
;!                           _Run_Mode
;!                            _Set_PWM
;!                    _Set_Usart_Async
;!                    _Time_Count_Func
;! ---------------------------------------------------------------------------------
;! (1) _Set_Usart_Async                                      0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Set_PWM                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Run_Mode                                             0     0      0  175263
;!                        _AllLedFlash
;!                          _BuzzerSet
;!                 _FactoryMode_Handle
;!                     _GetMode_Handle
;!                           _LedSetSt
;!                    _SetStandbyState
;!                   _ShiftMode_Handle
;!                 _StandbyMode_Handle
;! ---------------------------------------------------------------------------------
;! (2) _StandbyMode_Handle                                   0     0      0   33803
;!                          _BuzzerSet
;!                           _LedSetSt
;!                    _SetStandbyState
;!                   _ShiftMode_Handle
;!                   _StatusFun_Handle
;!                           _WrterEEP
;! ---------------------------------------------------------------------------------
;! (3) _StatusFun_Handle                                     0     0      0   11463
;!                    _SetStandbyState
;!                         _WashHandle
;! ---------------------------------------------------------------------------------
;! (4) _WashHandle                                           2     2      0    9460
;!                                              3 BANK0      2     2      0
;!                           _LedSetSt
;!                    _SetStandbyState
;! ---------------------------------------------------------------------------------
;! (2) _GetMode_Handle                                       0     0      0   11201
;!                   _ShiftMode_Handle
;!                           _WrterEEP
;! ---------------------------------------------------------------------------------
;! (2) _FactoryMode_Handle                                   1     1      0  100332
;!                                              3 BANK1      1     1      0
;!                        _AllLedFlash
;!                          _BuzzerSet
;!                           _LedSetSt
;!                    _Time_Count_Func
;! ---------------------------------------------------------------------------------
;! (1) _Time_Count_Func                                      3     3      0   83563
;!                                              0 BANK1      3     3      0
;!                         _AD_Testing
;!                          _BuzzerSet
;!                           _CheckKey
;!                        _ErrorHandle
;!                 _FilterKeyInputRest
;!                     _FilterLifeFunc
;!                 _GetDelayFilterFlag
;!                         _Led_Handle
;!                   _Page_ProgramData
;!                    _SetStandbyState
;!                         _TDS_Handle
;!                    _TaskAlarmHandle
;!                         _Tx_Display
;!                ___CMS_CheckTouchKey
;! ---------------------------------------------------------------------------------
;! (2) ___CMS_CheckTouchKey                                  1     1      0    7129
;!             ___CMS_CheckKeyOldValue
;!              ___CMS_CheckOnceResult
;!               ___CMS_CheckValidTime
;!                    ___CMS_CurAdjust
;!                    ___CMS_KeyDatIIR
;!                   ___CMS_KeyModeSet
;!                     ___CMS_KeyStart
;!                 ___CMS_KeyStopClear
;!              ___CMS_Key_UNNOL_Check
;!                    ___CMS_NewRAMClr
;!                  ___CMS_Noise_check
;!                   ___GET_32M_FREDAT
;! ---------------------------------------------------------------------------------
;! (3) ___GET_32M_FREDAT                                     0     0      0       0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_Noise_check                                   12    12      0     380
;!                                              0 BANK0     12    12      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_NewRAMClr                                      1     1      0     223
;!                                              4 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_Key_UNNOL_Check                                4     4      0     359
;!                                              4 COMMON     2     2      0
;!                                              0 BANK0      2     2      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_KeyStopClear                                   1     1      0     347
;!                                              1 BANK0      1     1      0
;!                  ___CMS_KeyClearOne
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_KeyClearOne                                    3     3      0     248
;!                                              4 COMMON     2     2      0
;!                                              0 BANK0      1     1      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_KeyDatIIR                                     11    11      0     656
;!                                              0 BANK0     11    11      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_CurAdjust                                      6     6      0     528
;!                                              0 BANK0      6     6      0
;!                   ___CMS_CurAdjMode
;!                     ___CMS_CurJudge
;!                   ___CMS_KeyModeSet
;!                     ___CMS_KeyStart
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_KeyStart                                       1     1      0      74
;!                                              4 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_KeyModeSet                                     1     1      0      34
;!                                              4 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_CurJudge                                       2     2      0       0
;!                                              4 COMMON     2     2      0
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_CurAdjMode                                     1     1      0     145
;!                                              4 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_CheckValidTime                                 0     0      0       0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_CheckOnceResult                               21    21      0    2549
;!                                              0 BANK0     21    21      0
;!                  ___CMS_KeyHaveDown
;!                      ___CMS_KeyIsIn
;!                      ___CMS_KeyOpen
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_KeyOpen                                        2     1      1     173
;!                                              4 COMMON     2     1      1
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_KeyHaveDown                                    2     1      1     401
;!                                              4 COMMON     2     1      1
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_CheckKeyOldValue                              13    13      0    1979
;!                                              2 BANK0     13    13      0
;!                      ___CMS_KeyIsIn
;!                                _abs
;! ---------------------------------------------------------------------------------
;! (4) _abs                                                  4     2      2     537
;!                                              4 COMMON     2     0      2
;!                                              0 BANK0      2     2      0
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_KeyIsIn                                        2     2      0     102
;!                                              4 COMMON     2     2      0
;! ---------------------------------------------------------------------------------
;! (2) _Tx_Display                                           4     4      0     278
;!                                              0 BANK0      4     4      0
;! ---------------------------------------------------------------------------------
;! (2) _TaskAlarmHandle                                      2     2      0       0
;!                                              4 COMMON     2     2      0
;! ---------------------------------------------------------------------------------
;! (2) _TDS_Handle                                          16    15      1    3479
;!                                              4 COMMON     1     0      1
;!                                             15 BANK0     15    15      0
;!                        _GetCurTdsHz
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (3) ___lwdiv                                              7     3      4     580
;!                                              0 BANK0      7     3      4
;! ---------------------------------------------------------------------------------
;! (3) ___lmul                                              12     4      8     290
;!                                              0 BANK0     12     4      8
;! ---------------------------------------------------------------------------------
;! (3) ___lldiv                                             13     5      8     395
;!                                              0 BANK0     13     5      8
;! ---------------------------------------------------------------------------------
;! (3) _GetCurTdsHz                                         15    11      4     732
;!                                              0 BANK0     15    11      4
;! ---------------------------------------------------------------------------------
;! (2) _Page_ProgramData                                     2     2      0     383
;!                                              3 BANK0      2     2      0
;!                       _Memory_Write
;! ---------------------------------------------------------------------------------
;! (3) _Memory_Write                                         4     1      3     250
;!                                              4 COMMON     1     1      0
;!                                              0 BANK0      3     0      3
;! ---------------------------------------------------------------------------------
;! (2) _Led_Handle                                           4     4      0    2759
;!                                              2 BANK0      4     4      0
;!                       _LedControlSt
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (3) _LedControlSt                                         2     1      1     972
;!                                              4 COMMON     2     1      1
;! ---------------------------------------------------------------------------------
;! (2) _GetDelayFilterFlag                                   3     3      0     909
;!                                              3 BANK0      3     3      0
;!                                _Dec
;!                               _DecF
;! ---------------------------------------------------------------------------------
;! (3) _DecF                                                 5     3      2     172
;!                                              4 COMMON     2     0      2
;!                                              0 BANK0      3     3      0
;! ---------------------------------------------------------------------------------
;! (3) _Dec                                                  2     1      1     454
;!                                              4 COMMON     2     1      1
;! ---------------------------------------------------------------------------------
;! (2) _FilterLifeFunc                                       0     0      0   10533
;!                          _BuzzerSet
;!                   _FilterTimeHandle
;! ---------------------------------------------------------------------------------
;! (3) _FilterTimeHandle                                    12     4      8    8854
;!                                              3 BANK0     12     4      8
;!                           _LedSetSt
;! ---------------------------------------------------------------------------------
;! (2) _FilterKeyInputRest                                   0     0      0   22631
;!                          _BuzzerSet
;!                           _LedSetSt
;!                _SetFilterDelayReset
;!                   _ShiftMode_Handle
;!                           _WrterEEP
;! ---------------------------------------------------------------------------------
;! (2) _ErrorHandle                                          0     0      0   27924
;!                        _AllLedFlash
;!                          _BuzzerSet
;!                            _GetStop
;!                           _LedSetSt
;!                   _ShiftMode_Handle
;! ---------------------------------------------------------------------------------
;! (3) _ShiftMode_Handle                                     1     1      0   11201
;!                                              3 BANK0      1     1      0
;!                          _BuzzerSet
;!                           _LedSetSt
;!                    _SetStandbyState
;! ---------------------------------------------------------------------------------
;! (2) _SetStandbyState                                      3     1      2    2003
;!                                              4 COMMON     2     0      2
;!                                              0 BANK0      1     1      0
;! ---------------------------------------------------------------------------------
;! (3) _GetStop                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (3) _AllLedFlash                                          3     3      0    7587
;!                                              3 BANK0      3     3      0
;!                           _LedSetSt
;! ---------------------------------------------------------------------------------
;! (4) _LedSetSt                                             2     1      1    7457
;!                                              5 COMMON     1     0      1
;!                                              2 BANK0      1     1      0
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (3) ___bmul                                               3     2      1     941
;!                                              4 COMMON     1     0      1
;!                                              0 BANK0      2     2      0
;! ---------------------------------------------------------------------------------
;! (2) _CheckKey                                             4     4      0    3107
;!                                              5 BANK0      4     4      0
;!                            _KeyScan
;! ---------------------------------------------------------------------------------
;! (3) _KeyScan                                              4     3      1    2779
;!                                              1 BANK0      4     3      1
;!                          _BuzzerSet
;! ---------------------------------------------------------------------------------
;! (3) _BuzzerSet                                            3     1      2    1679
;!                                              4 COMMON     2     0      2
;!                                              0 BANK0      1     1      0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Testing                                          10     8      2     749
;!                                              4 COMMON     2     0      2
;!                                              0 BANK0      8     8      0
;! ---------------------------------------------------------------------------------
;! (1) _Initialize                                           0     0      0       0
;!                           _Init_ram
;! ---------------------------------------------------------------------------------
;! (2) _Init_ram                                             0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _EEPROM_Page                                          0     0      0    2535
;!                       _ReadDataArry
;!                _SetFilterDelayReset
;!                           _WrterEEP
;! ---------------------------------------------------------------------------------
;! (3) _WrterEEP                                             0     0      0       0
;! ---------------------------------------------------------------------------------
;! (3) _SetFilterDelayReset                                  7     1      6    2294
;!                                              4 COMMON     1     1      0
;!                                              0 BANK0      6     0      6
;! ---------------------------------------------------------------------------------
;! (2) _ReadDataArry                                         2     2      0     241
;!                                              0 BANK0      2     2      0
;!                        _Memory_Read
;! ---------------------------------------------------------------------------------
;! (3) _Memory_Read                                          2     0      2     108
;!                                              4 COMMON     2     0      2
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 4
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (8) _Timer1_Isr                                           4     4      0       0
;!                                              0 COMMON     4     4      0
;!                ___CMS_TouchKeyValue
;! ---------------------------------------------------------------------------------
;! (10) ___CMS_TouchKeyValue                                 0     0      0       0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 10
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _EEPROM_Page
;!     _ReadDataArry
;!       _Memory_Read
;!     _SetFilterDelayReset
;!     _WrterEEP
;!   _Initialize
;!     _Init_ram
;!   _Run_Mode
;!     _AllLedFlash
;!       _LedSetSt
;!         ___bmul
;!     _BuzzerSet
;!     _FactoryMode_Handle
;!       _AllLedFlash
;!         _LedSetSt
;!           ___bmul
;!       _BuzzerSet
;!       _LedSetSt
;!         ___bmul
;!       _Time_Count_Func
;!         _AD_Testing
;!         _BuzzerSet
;!         _CheckKey
;!           _KeyScan
;!             _BuzzerSet
;!         _ErrorHandle
;!           _AllLedFlash
;!             _LedSetSt
;!               ___bmul
;!           _BuzzerSet
;!           _GetStop
;!           _LedSetSt
;!             ___bmul
;!           _ShiftMode_Handle
;!             _BuzzerSet
;!             _LedSetSt
;!               ___bmul
;!             _SetStandbyState
;!         _FilterKeyInputRest
;!           _BuzzerSet
;!           _LedSetSt
;!             ___bmul
;!           _SetFilterDelayReset
;!           _ShiftMode_Handle
;!             _BuzzerSet
;!             _LedSetSt
;!               ___bmul
;!             _SetStandbyState
;!           _WrterEEP
;!         _FilterLifeFunc
;!           _BuzzerSet
;!           _FilterTimeHandle
;!             _LedSetSt
;!               ___bmul
;!         _GetDelayFilterFlag
;!           _Dec
;!           _DecF
;!         _Led_Handle
;!           _LedControlSt
;!           ___bmul
;!         _Page_ProgramData
;!           _Memory_Write
;!         _SetStandbyState
;!         _TDS_Handle
;!           _GetCurTdsHz
;!           ___lldiv
;!           ___lmul
;!           ___lwdiv
;!         _TaskAlarmHandle
;!         _Tx_Display
;!         ___CMS_CheckTouchKey
;!           ___CMS_CheckKeyOldValue
;!             ___CMS_KeyIsIn
;!             _abs
;!           ___CMS_CheckOnceResult
;!             ___CMS_KeyHaveDown
;!             ___CMS_KeyIsIn
;!             ___CMS_KeyOpen
;!           ___CMS_CheckValidTime
;!           ___CMS_CurAdjust
;!             ___CMS_CurAdjMode
;!             ___CMS_CurJudge
;!             ___CMS_KeyModeSet
;!             ___CMS_KeyStart
;!           ___CMS_KeyDatIIR
;!           ___CMS_KeyModeSet
;!           ___CMS_KeyStart
;!           ___CMS_KeyStopClear
;!             ___CMS_KeyClearOne
;!           ___CMS_Key_UNNOL_Check
;!           ___CMS_NewRAMClr
;!           ___CMS_Noise_check
;!           ___GET_32M_FREDAT
;!     _GetMode_Handle
;!       _ShiftMode_Handle
;!         _BuzzerSet
;!         _LedSetSt
;!           ___bmul
;!         _SetStandbyState
;!       _WrterEEP
;!     _LedSetSt
;!       ___bmul
;!     _SetStandbyState
;!     _ShiftMode_Handle
;!       _BuzzerSet
;!       _LedSetSt
;!         ___bmul
;!       _SetStandbyState
;!     _StandbyMode_Handle
;!       _BuzzerSet
;!       _LedSetSt
;!         ___bmul
;!       _SetStandbyState
;!       _ShiftMode_Handle
;!         _BuzzerSet
;!         _LedSetSt
;!           ___bmul
;!         _SetStandbyState
;!       _StatusFun_Handle
;!         _SetStandbyState
;!         _WashHandle
;!           _LedSetSt
;!             ___bmul
;!           _SetStandbyState
;!       _WrterEEP
;!   _Set_PWM
;!   _Set_Usart_Async
;!   _Time_Count_Func
;!     _AD_Testing
;!     _BuzzerSet
;!     _CheckKey
;!       _KeyScan
;!         _BuzzerSet
;!     _ErrorHandle
;!       _AllLedFlash
;!         _LedSetSt
;!           ___bmul
;!       _BuzzerSet
;!       _GetStop
;!       _LedSetSt
;!         ___bmul
;!       _ShiftMode_Handle
;!         _BuzzerSet
;!         _LedSetSt
;!           ___bmul
;!         _SetStandbyState
;!     _FilterKeyInputRest
;!       _BuzzerSet
;!       _LedSetSt
;!         ___bmul
;!       _SetFilterDelayReset
;!       _ShiftMode_Handle
;!         _BuzzerSet
;!         _LedSetSt
;!           ___bmul
;!         _SetStandbyState
;!       _WrterEEP
;!     _FilterLifeFunc
;!       _BuzzerSet
;!       _FilterTimeHandle
;!         _LedSetSt
;!           ___bmul
;!     _GetDelayFilterFlag
;!       _Dec
;!       _DecF
;!     _Led_Handle
;!       _LedControlSt
;!       ___bmul
;!     _Page_ProgramData
;!       _Memory_Write
;!     _SetStandbyState
;!     _TDS_Handle
;!       _GetCurTdsHz
;!       ___lldiv
;!       ___lmul
;!       ___lwdiv
;!     _TaskAlarmHandle
;!     _Tx_Display
;!     ___CMS_CheckTouchKey
;!       ___CMS_CheckKeyOldValue
;!         ___CMS_KeyIsIn
;!         _abs
;!       ___CMS_CheckOnceResult
;!         ___CMS_KeyHaveDown
;!         ___CMS_KeyIsIn
;!         ___CMS_KeyOpen
;!       ___CMS_CheckValidTime
;!       ___CMS_CurAdjust
;!         ___CMS_CurAdjMode
;!         ___CMS_CurJudge
;!         ___CMS_KeyModeSet
;!         ___CMS_KeyStart
;!       ___CMS_KeyDatIIR
;!       ___CMS_KeyModeSet
;!       ___CMS_KeyStart
;!       ___CMS_KeyStopClear
;!         ___CMS_KeyClearOne
;!       ___CMS_Key_UNNOL_Check
;!       ___CMS_NewRAMClr
;!       ___CMS_Noise_check
;!       ___GET_32M_FREDAT
;!
;! _Timer1_Isr (ROOT)
;!   ___CMS_TouchKeyValue
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BITCOMMON            E      0       1       0        7.1%
;!NULL                 0      0       0       0        0.0%
;!CODE                 0      0       0       0        0.0%
;!COMMON               E      6       A       1       71.4%
;!BITSFR0              0      0       0       1        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!SFR1                 0      0       0       2        0.0%
;!STACK                0      0       0       2        0.0%
;!BITBANK0            50      0       0       3        0.0%
;!BANK0               50     1E      50       4      100.0%
;!BITSFR3              0      0       0       4        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITBANK1            50      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BANK1               50      4      4B       6       93.8%
;!BANK2               50      0      40       7       80.0%
;!ABS                  0      0      E5       8        0.0%
;!DATA                 0      0      E5       9        0.0%
;!BITBANK2            50      0       0      10        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 2742 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels required when called:   10
;; This function calls:
;;		_EEPROM_Page
;;		_Initialize
;;		_Run_Mode
;;		_Set_PWM
;;		_Set_Usart_Async
;;		_Time_Count_Func
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	2742
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	2742
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	2745
	
l11462:	
# 2745 "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	2746
# 2746 "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	maintext
	line	2747
	
l11464:	
;main.c: 2747: Initialize();
	fcall	_Initialize
	line	2748
	
l11466:	
;main.c: 2748: EEPROM_Page();
	fcall	_EEPROM_Page
	line	2750
	
l11468:	
;main.c: 2750: Set_PWM();
	fcall	_Set_PWM
	line	2751
	
l11470:	
;main.c: 2751: Set_Usart_Async();
	fcall	_Set_Usart_Async
	line	2753
	
l11472:	
;main.c: 2753: Tx_Type.TxType.Tx_FH1=0xa5;
	movlw	low(0A5h)
	movwf	(_Tx_Type)^0100h
	line	2754
	
l11474:	
;main.c: 2754: Tx_Type.TxType.Tx_FH2=0xa6;
	movlw	low(0A6h)
	movwf	0+(_Tx_Type)^0100h+01h
	line	2755
	
l11476:	
;main.c: 2755: Tx_Type.TxType.Tx_TotalLength=0x11U;
	movlw	low(011h)
	movwf	0+(_Tx_Type)^0100h+02h
	line	2758
	
l11478:	
;main.c: 2758: PreTdsData=PureTDSTyp.TdsData=0x03;
	movlw	low(0Fh)
	addlw	low(_PureTDSTyp|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	03h
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movlw	0
	movwf	indf
	movlw	03h
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_PreTdsData)
	movlw	0
	movwf	((_PreTdsData))+1
	line	2765
	
l11480:	
;main.c: 2765: RC2=0;
	bcf	(58/8),(58)&7	;volatile
	line	2766
	
l11482:	
;main.c: 2766: {RA2=0;_BITS2.Bits.bit_1=0;};
	bcf	(42/8),(42)&7	;volatile
	
l11484:	
	bcf	(__BITS2),1
	line	2767
	
l11486:	
;main.c: 2767: RC3=0;
	bcf	(59/8),(59)&7	;volatile
	line	2775
;main.c: 2775: while(1)
	
l1537:	
	line	2779
# 2779 "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	maintext
	line	2781
	
l11488:	
;main.c: 2781: Time_Count_Func();
	fcall	_Time_Count_Func
	line	2784
	
l11490:	
;main.c: 2784: Run_Mode();
	fcall	_Run_Mode
	goto	l1537
	global	start
	ljmp	start
	opt stack 0
	line	2792
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_Set_Usart_Async

;; *************** function _Set_Usart_Async *****************
;; Defined at:
;;		line 2685 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/200
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	2685
global __ptext1
__ptext1:	;psect for function _Set_Usart_Async
psect	text1
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	2685
	global	__size_of_Set_Usart_Async
	__size_of_Set_Usart_Async	equ	__end_of_Set_Usart_Async-_Set_Usart_Async
	
_Set_Usart_Async:	
;incstack = 0
	opt	stack 8
; Regs used in _Set_Usart_Async: [wreg]
	line	2701
	
l9026:	
;main.c: 2701: SPBRG1 = 103;
	movlw	low(067h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(152)^080h	;volatile
	line	2702
	
l9028:	
;main.c: 2702: SYNC1 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2300/8)^0100h,(2300)&7	;volatile
	line	2703
	
l9030:	
;main.c: 2703: SCKP1 = 0;
	bcf	(2299/8)^0100h,(2299)&7	;volatile
	line	2705
	
l9032:	
;main.c: 2705: SPEN1 = 1;
	bsf	(2095/8)^0100h,(2095)&7	;volatile
	line	2706
	
l9034:	
;main.c: 2706: RC1IE = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1129/8)^080h,(1129)&7	;volatile
	line	2707
	
l9036:	
;main.c: 2707: TX1IE = 0;
	bcf	(1130/8)^080h,(1130)&7	;volatile
	line	2708
	
l9038:	
;main.c: 2708: RX9EN1 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2094/8)^0100h,(2094)&7	;volatile
	line	2709
	
l9040:	
;main.c: 2709: TX9EN1 = 0;
	bcf	(2302/8)^0100h,(2302)&7	;volatile
	line	2710
	
l9042:	
;main.c: 2710: CREN1 = 0;
	bcf	(2092/8)^0100h,(2092)&7	;volatile
	line	2711
	
l9044:	
;main.c: 2711: TXEN1 = 1;
	bsf	(2301/8)^0100h,(2301)&7	;volatile
	line	2712
	
l1529:	
	return
	opt stack 0
GLOBAL	__end_of_Set_Usart_Async
	__end_of_Set_Usart_Async:
	signat	_Set_Usart_Async,89
	global	_Set_PWM

;; *************** function _Set_PWM *****************
;; Defined at:
;;		line 2713 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	line	2713
global __ptext2
__ptext2:	;psect for function _Set_PWM
psect	text2
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	2713
	global	__size_of_Set_PWM
	__size_of_Set_PWM	equ	__end_of_Set_PWM-_Set_PWM
	
_Set_PWM:	
;incstack = 0
	opt	stack 8
; Regs used in _Set_PWM: [wreg+status,2]
	line	2715
	
l9046:	
;main.c: 2715: PWMTL = 0xfa;
	movlw	low(0FAh)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(283)^0100h	;volatile
	line	2717
;main.c: 2717: PWMTH = 0B00000100;
	movlw	low(04h)
	movwf	(284)^0100h	;volatile
	line	2722
	
l9048:	
;main.c: 2722: PWMD01H = 0x00;
	clrf	(273)^0100h	;volatile
	line	2726
	
l9050:	
;main.c: 2726: PWMD1L = 0x7d;
	movlw	low(07Dh)
	movwf	(269)^0100h	;volatile
	line	2738
	
l9052:	
;main.c: 2738: PWMCON1 = 0B01000000;
	movlw	low(040h)
	movwf	(263)^0100h	;volatile
	line	2739
	
l9054:	
;main.c: 2739: PWMCON0 = 0B10100000;
	movlw	low(0A0h)
	movwf	(262)^0100h	;volatile
	line	2741
	
l1532:	
	return
	opt stack 0
GLOBAL	__end_of_Set_PWM
	__end_of_Set_PWM:
	signat	_Set_PWM,89
	global	_Run_Mode

;; *************** function _Run_Mode *****************
;; Defined at:
;;		line 1976 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    9
;; This function calls:
;;		_AllLedFlash
;;		_BuzzerSet
;;		_FactoryMode_Handle
;;		_GetMode_Handle
;;		_LedSetSt
;;		_SetStandbyState
;;		_ShiftMode_Handle
;;		_StandbyMode_Handle
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	line	1976
global __ptext3
__ptext3:	;psect for function _Run_Mode
psect	text3
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	1976
	global	__size_of_Run_Mode
	__size_of_Run_Mode	equ	__end_of_Run_Mode-_Run_Mode
	
_Run_Mode:	
;incstack = 0
	opt	stack 2
; Regs used in _Run_Mode: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1978
	
l11368:	
;main.c: 1978: switch(Mode){
	goto	l11426
	line	1982
	
l11370:	
;main.c: 1982: AllLedFlash(1);
	movlw	low(01h)
	fcall	_AllLedFlash
	line	1983
	
l11372:	
;main.c: 1983: _BITS.Bits.bit_5=0x01;
	bsf	(__BITS),5
	line	1984
	
l11374:	
;main.c: 1984: Timer_Power_100ms=0;
	clrf	(_Timer_Power_100ms)
	line	1985
	
l11376:	
;main.c: 1985: PowerStep=1;
	clrf	(_PowerStep)
	incf	(_PowerStep),f
	line	1986
	
l11378:	
;main.c: 1986: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	line	1987
	
l11380:	
;main.c: 1987: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1989
;main.c: 1989: break;
	goto	l1410
	line	1991
	
l11382:	
;main.c: 1991: if(Timer_Power_100ms>=30){
	movlw	low(01Eh)
	subwf	(_Timer_Power_100ms),w
	skipc
	goto	u11001
	goto	u11000
u11001:
	goto	l1410
u11000:
	line	1992
	
l11384:	
;main.c: 1992: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1993
	
l11386:	
;main.c: 1993: PowerStep=2;
	movlw	low(02h)
	movwf	(_PowerStep)
	goto	l1410
	line	1999
	
l11388:	
;main.c: 1999: if(Timer_Power_100ms>=31){
	movlw	low(01Fh)
	subwf	(_Timer_Power_100ms),w
	skipc
	goto	u11011
	goto	u11010
u11011:
	goto	l1410
u11010:
	line	2000
	
l11390:	
;main.c: 2000: ShiftMode_Handle(2);
	movlw	low(02h)
	fcall	_ShiftMode_Handle
	line	2002
;main.c: 2002: SetStandbyState(WashState,&WashRunTime, 18);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(012h)
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	goto	l1410
	line	2006
	
l11392:	
;main.c: 2006: Timer_Power_100ms=0;
	clrf	(_Timer_Power_100ms)
	line	2007
	
l11394:	
;main.c: 2007: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	2011
	
l11396:	
;main.c: 2011: LedSetSt(1, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(01h)
	fcall	_LedSetSt
	line	2012
	
l11398:	
;main.c: 2012: LedSetSt(5, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(05h)
	fcall	_LedSetSt
	line	2013
	
l11400:	
;main.c: 2013: LedSetSt(3, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(03h)
	fcall	_LedSetSt
	line	2020
	
l11402:	
;main.c: 2020: PowerStep=4;
	movlw	low(04h)
	movwf	(_PowerStep)
	line	2021
;main.c: 2021: break;
	goto	l1410
	line	2023
	
l11404:	
;main.c: 2023: if(Timer_Power_100ms>=10){
	movlw	low(0Ah)
	subwf	(_Timer_Power_100ms),w
	skipc
	goto	u11021
	goto	u11020
u11021:
	goto	l1410
u11020:
	line	2024
	
l11406:	
;main.c: 2024: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	2025
;main.c: 2025: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	line	2026
;main.c: 2026: LedSetSt(4, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(04h)
	fcall	_LedSetSt
	line	2027
;main.c: 2027: LedSetSt(2, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(02h)
	fcall	_LedSetSt
	line	2038
	
l11408:	
;main.c: 2038: PowerStep=5;
	movlw	low(05h)
	movwf	(_PowerStep)
	goto	l1410
	line	2044
	
l11410:	
;main.c: 2044: if(Timer_Power_100ms>=20){
	movlw	low(014h)
	subwf	(_Timer_Power_100ms),w
	skipc
	goto	u11031
	goto	u11030
u11031:
	goto	l1410
u11030:
	line	2045
	
l11412:	
;main.c: 2045: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	2046
;main.c: 2046: ShiftMode_Handle(2);
	movlw	low(02h)
	fcall	_ShiftMode_Handle
	goto	l1410
	line	1980
	
l11416:	
	movf	(_PowerStep),w
	; Switch size 1, requested type "space"
; Number of cases is 6, Range of values is 0 to 5
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           19    10 (average)
; direct_byte           26     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l11370
	xorlw	1^0	; case 1
	skipnz
	goto	l11382
	xorlw	2^1	; case 2
	skipnz
	goto	l11388
	xorlw	3^2	; case 3
	skipnz
	goto	l11392
	xorlw	4^3	; case 4
	skipnz
	goto	l11404
	xorlw	5^4	; case 5
	skipnz
	goto	l11410
	goto	l1410
	opt asmopt_pop

	line	2054
	
l11418:	
;main.c: 2054: StandbyMode_Handle();
	fcall	_StandbyMode_Handle
	line	2055
;main.c: 2055: break;
	goto	l1410
	line	2057
	
l11420:	
;main.c: 2057: GetMode_Handle();
	fcall	_GetMode_Handle
	line	2058
;main.c: 2058: break;
	goto	l1410
	line	2060
	
l11422:	
;main.c: 2060: FactoryMode_Handle();
	fcall	_FactoryMode_Handle
	line	2061
;main.c: 2061: break;
	goto	l1410
	line	2062
;main.c: 2062: case 3:
	
l1409:	
	line	2063
;main.c: 2063: {RA2=0;_BITS2.Bits.bit_1=0;};
	bcf	(42/8),(42)&7	;volatile
	bcf	(__BITS2),1
	line	2064
;main.c: 2064: RC3=0;
	bcf	(59/8),(59)&7	;volatile
	line	2065
;main.c: 2065: RC2=0;
	bcf	(58/8),(58)&7	;volatile
	line	2066
;main.c: 2066: break;
	goto	l1410
	line	1978
	
l11426:	
	movf	(_Mode),w
	; Switch size 1, requested type "space"
; Number of cases is 5, Range of values is 0 to 5
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           16     9 (average)
; direct_byte           26     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l11416
	xorlw	2^0	; case 2
	skipnz
	goto	l11418
	xorlw	3^2	; case 3
	skipnz
	goto	l1409
	xorlw	4^3	; case 4
	skipnz
	goto	l11420
	xorlw	5^4	; case 5
	skipnz
	goto	l11422
	goto	l1410
	opt asmopt_pop

	line	2068
	
l1410:	
	return
	opt stack 0
GLOBAL	__end_of_Run_Mode
	__end_of_Run_Mode:
	signat	_Run_Mode,89
	global	_StandbyMode_Handle

;; *************** function _StandbyMode_Handle *****************
;; Defined at:
;;		line 1838 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    7
;; This function calls:
;;		_BuzzerSet
;;		_LedSetSt
;;		_SetStandbyState
;;		_ShiftMode_Handle
;;		_StatusFun_Handle
;;		_WrterEEP
;; This function is called by:
;;		_Run_Mode
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	line	1838
global __ptext4
__ptext4:	;psect for function _StandbyMode_Handle
psect	text4
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	1838
	global	__size_of_StandbyMode_Handle
	__size_of_StandbyMode_Handle	equ	__end_of_StandbyMode_Handle-_StandbyMode_Handle
	
_StandbyMode_Handle:	
;incstack = 0
	opt	stack 3
; Regs used in _StandbyMode_Handle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1843
	
l11254:	
;main.c: 1842: static U8_T Ti_1h=0;
;main.c: 1843: if(Read_Word_Buff[11]==2)
		movlw	2
	bsf	status, 5	;RP0=1, select bank1
	xorwf	(0+(_Read_Word_Buff)^080h+0Bh),w
	btfss	status,2
	goto	u10781
	goto	u10780
u10781:
	goto	l11274
u10780:
	line	1846
	
l11256:	
;main.c: 1844: {
;main.c: 1846: if(Timer_Standby_1s>=300)
	movlw	01h
	subwf	(_Timer_Standby_1s+1)^080h,w
	movlw	02Ch
	skipnz
	subwf	(_Timer_Standby_1s)^080h,w
	skipc
	goto	u10791
	goto	u10790
u10791:
	goto	l11264
u10790:
	line	1849
	
l11258:	
;main.c: 1847: {
;main.c: 1849: if(_BITS1.Bits.bit_4==0){
	bcf	status, 5	;RP0=0, select bank0
	btfsc	(__BITS1),4
	goto	u10801
	goto	u10800
u10801:
	goto	l11264
u10800:
	line	1850
	
l11260:	
;main.c: 1850: _BITS1.Bits.bit_4=1;
	bsf	(__BITS1),4
	line	1851
	
l11262:	
;main.c: 1851: SetStandbyState(BackState,&WashRunTime, 30);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(01Eh)
	movwf	(SetStandbyState@Da)
	movlw	low(03h)
	fcall	_SetStandbyState
	line	1857
	
l11264:	
;main.c: 1852: }
;main.c: 1853: }
;main.c: 1857: if(Timer_BackT_1H>=12)
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_BackT_1H+1)^080h,w
	movlw	0Ch
	skipnz
	subwf	(_Timer_BackT_1H)^080h,w
	skipc
	goto	u10811
	goto	u10810
u10811:
	goto	l11274
u10810:
	line	1861
	
l11266:	
;main.c: 1859: {
;main.c: 1861: if(_BITS1.Bits.bit_6==0)
	bcf	status, 5	;RP0=0, select bank0
	btfsc	(__BITS1),6
	goto	u10821
	goto	u10820
u10821:
	goto	l11274
u10820:
	line	1863
	
l11268:	
;main.c: 1862: {
;main.c: 1863: _BITS1.Bits.bit_6=1;
	bsf	(__BITS1),6
	line	1864
	
l11270:	
;main.c: 1864: SetStandbyState(BackState,&WashRunTime, 30);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(01Eh)
	movwf	(SetStandbyState@Da)
	movlw	low(03h)
	fcall	_SetStandbyState
	line	1865
	
l11272:	
;main.c: 1865: Read_Word_Buff[11]=3;
	movlw	low(03h)
	movwf	0+(_Read_Word_Buff)^080h+0Bh
	line	1872
	
l11274:	
;main.c: 1866: }
;main.c: 1867: }
;main.c: 1868: }
;main.c: 1872: if(Timer_Standby_1s>=3600)
	movlw	0Eh
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_Standby_1s+1)^080h,w
	movlw	010h
	skipnz
	subwf	(_Timer_Standby_1s)^080h,w
	skipc
	goto	u10831
	goto	u10830
u10831:
	goto	l11288
u10830:
	line	1875
	
l11276:	
;main.c: 1874: {
;main.c: 1875: Timer_Standby_1s=0;
	clrf	(_Timer_Standby_1s)^080h
	clrf	(_Timer_Standby_1s+1)^080h
	line	1876
	
l11278:	
;main.c: 1876: if(Timer_Standby_1H<0xf0)
	movlw	0
	subwf	(_Timer_Standby_1H+1)^080h,w
	movlw	0F0h
	skipnz
	subwf	(_Timer_Standby_1H)^080h,w
	skipnc
	goto	u10841
	goto	u10840
u10841:
	goto	l1369
u10840:
	line	1877
	
l11280:	
;main.c: 1877: Timer_Standby_1H++;
	incf	(_Timer_Standby_1H)^080h,f
	skipnz
	incf	(_Timer_Standby_1H+1)^080h,f
	
l1369:	
	line	1878
;main.c: 1878: Timer_BackT_1H++;
	incf	(_Timer_BackT_1H)^080h,f
	skipnz
	incf	(_Timer_BackT_1H+1)^080h,f
	line	1879
	
l11282:	
;main.c: 1879: if(++Ti_1h>=10){
	movlw	low(0Ah)
	bcf	status, 5	;RP0=0, select bank0
	incf	(StandbyMode_Handle@Ti_1h),f
	subwf	((StandbyMode_Handle@Ti_1h)),w
	skipc
	goto	u10851
	goto	u10850
u10851:
	goto	l11288
u10850:
	line	1880
	
l11284:	
;main.c: 1880: Ti_1h=0;
	clrf	(StandbyMode_Handle@Ti_1h)
	line	1881
	
l11286:	
;main.c: 1881: WrterEEP();
	fcall	_WrterEEP
	line	1887
	
l11288:	
;main.c: 1882: }
;main.c: 1883: }
;main.c: 1887: if(Timer_Standby_1H>=72)
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_Standby_1H+1)^080h,w
	movlw	048h
	skipnz
	subwf	(_Timer_Standby_1H)^080h,w
	skipc
	goto	u10861
	goto	u10860
u10861:
	goto	l11298
u10860:
	line	1891
	
l11290:	
;main.c: 1889: {
;main.c: 1891: Timer_Standby_1H=0;
	clrf	(_Timer_Standby_1H)^080h
	clrf	(_Timer_Standby_1H+1)^080h
	line	1892
	
l11292:	
;main.c: 1892: if(_BITS2.Bits.bit_2==0){
	bcf	status, 5	;RP0=0, select bank0
	btfsc	(__BITS2),2
	goto	u10871
	goto	u10870
u10871:
	goto	l11298
u10870:
	line	1894
	
l11294:	
;main.c: 1894: if(StandByStatus==NornalStopState){
	movf	((_StandByStatus)),w
	btfss	status,2
	goto	u10881
	goto	u10880
u10881:
	goto	l11298
u10880:
	line	1895
	
l11296:	
;main.c: 1895: SetStandbyState(WashState,&WashRunTime, 30);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(01Eh)
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	line	1905
	
l11298:	
;main.c: 1896: }
;main.c: 1897: }
;main.c: 1898: }
;main.c: 1904: if((KeyPacket_y[2].KeyState==LongPressDown)
;main.c: 1905: &&(KeyPacket_y[1].KeyState==NotPress))
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u10891
	goto	u10890
u10891:
	goto	l11334
u10890:
	
l11300:	
	movf	(0+(_KeyPacket_y)+03h),w
	btfss	status,2
	goto	u10901
	goto	u10900
u10901:
	goto	l11334
u10900:
	line	1907
	
l11302:	
;main.c: 1906: {
;main.c: 1907: KeyPacket_y[2].KeyState=SuperPressDown;
	movlw	low(03h)
	movwf	0+(_KeyPacket_y)+06h
	line	1908
;main.c: 1908: if(Time_Power_1s<=10){
	movlw	low(0Bh)
	subwf	(_Time_Power_1s),w
	skipnc
	goto	u10911
	goto	u10910
u10911:
	goto	l11308
u10910:
	line	1909
	
l11304:	
;main.c: 1909: BuzzerSet(3, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(03h)
	fcall	_BuzzerSet
	line	1910
	
l11306:	
;main.c: 1910: FilterFastCheck=1;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_FilterFastCheck)
	incf	(_FilterFastCheck),f
	line	1911
;main.c: 1911: }
	goto	l11334
	line	1914
	
l11308:	
;main.c: 1912: else
;main.c: 1913: {
;main.c: 1914: if(Read_Word_Buff[11]==0){
	bsf	status, 5	;RP0=1, select bank1
	movf	(0+(_Read_Word_Buff)^080h+0Bh),w
	btfss	status,2
	goto	u10921
	goto	u10920
u10921:
	goto	l11312
u10920:
	line	1915
	
l11310:	
;main.c: 1915: Read_Word_Buff[11]=3;
	movlw	low(03h)
	movwf	0+(_Read_Word_Buff)^080h+0Bh
	line	1916
;main.c: 1916: }
	goto	l11314
	line	1919
	
l11312:	
;main.c: 1917: else
;main.c: 1918: {
;main.c: 1919: Read_Word_Buff[11]=0;
	clrf	0+(_Read_Word_Buff)^080h+0Bh
	line	1923
	
l11314:	
;main.c: 1920: }
;main.c: 1923: WrterEEP();
	fcall	_WrterEEP
	line	1924
	
l11316:	
;main.c: 1924: if(Read_Word_Buff[11])
	bsf	status, 5	;RP0=1, select bank1
	movf	(0+(_Read_Word_Buff)^080h+0Bh),w
	btfsc	status,2
	goto	u10931
	goto	u10930
u10931:
	goto	l11330
u10930:
	line	1926
	
l11318:	
;main.c: 1925: {
;main.c: 1926: Read_Word_Buff[11]=3;
	movlw	low(03h)
	movwf	0+(_Read_Word_Buff)^080h+0Bh
	line	1927
	
l11320:	
;main.c: 1927: Timer_Standby_1s=0;
	clrf	(_Timer_Standby_1s)^080h
	clrf	(_Timer_Standby_1s+1)^080h
	line	1928
	
l11322:	
;main.c: 1928: Timer_BackT_1H=0;
	clrf	(_Timer_BackT_1H)^080h
	clrf	(_Timer_BackT_1H+1)^080h
	line	1929
	
l11324:	
;main.c: 1929: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1930
	
l11326:	
;main.c: 1930: LedSetSt(1, 5);
	movlw	low(05h)
	movwf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1931
	
l11328:	
;main.c: 1931: LedMod[1].LedFlashNum=1;
	bsf	status, 6	;RP1=1, select bank2
	clrf	0+(_LedMod)^0100h+08h
	incf	0+(_LedMod)^0100h+08h,f
	clrf	1+(_LedMod)^0100h+08h
	line	1932
;main.c: 1932: }
	goto	l11334
	line	1935
	
l11330:	
;main.c: 1933: else
;main.c: 1934: {
;main.c: 1935: LedSetSt(1, 5);
	movlw	low(05h)
	movwf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1936
	
l11332:	
;main.c: 1936: BuzzerSet(3, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(03h)
	fcall	_BuzzerSet
	line	1942
	
l11334:	
;main.c: 1937: }
;main.c: 1939: }
;main.c: 1940: }
;main.c: 1942: if(KeyPacket_y[2].KeyState==ShortRelease)
		movlw	6
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	xorwf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u10941
	goto	u10940
u10941:
	goto	l11348
u10940:
	line	1944
	
l11336:	
;main.c: 1943: {
;main.c: 1944: KeyPacket_y[2].KeyState=NotPress;
	clrf	0+(_KeyPacket_y)+06h
	line	1945
	
l11338:	
;main.c: 1945: if(_BITS1.Bits.bit_0==0){
	btfsc	(__BITS1),0
	goto	u10951
	goto	u10950
u10951:
	goto	l11348
u10950:
	line	1946
	
l11340:	
;main.c: 1946: BuzzerSet(1, 50);
	movlw	032h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1947
	
l11342:	
;main.c: 1947: if(StandByStatus==WashState)
	bcf	status, 5	;RP0=0, select bank0
		decf	((_StandByStatus)),w
	btfss	status,2
	goto	u10961
	goto	u10960
u10961:
	goto	l11346
u10960:
	line	1949
	
l11344:	
;main.c: 1948: {
;main.c: 1949: LedSetSt(1, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1950
;main.c: 1950: SetStandbyState(NornalStopState,&WashRunTime, 0);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	clrf	(SetStandbyState@Da)
	movlw	low(0)
	fcall	_SetStandbyState
	line	1951
;main.c: 1951: }
	goto	l11348
	line	1954
	
l11346:	
;main.c: 1952: else
;main.c: 1953: {
;main.c: 1954: SetStandbyState(WashState,&WashRunTime, 180);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(0B4h)
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	line	1963
	
l11348:	
;main.c: 1955: }
;main.c: 1956: }
;main.c: 1958: }
;main.c: 1963: if(KeyPacket_y[0].KeyState==NotPress){
	bcf	status, 5	;RP0=0, select bank0
	movf	((_KeyPacket_y)),w
	btfss	status,2
	goto	u10971
	goto	u10970
u10971:
	goto	l11352
u10970:
	line	1964
	
l11350:	
;main.c: 1964: StatusFun_Handle();
	fcall	_StatusFun_Handle
	line	1965
;main.c: 1965: }
	goto	l1388
	line	1968
	
l11352:	
;main.c: 1966: else
;main.c: 1967: {
;main.c: 1968: if(StandByStatus==BackState)
		movlw	3
	xorwf	((_StandByStatus)),w
	btfss	status,2
	goto	u10981
	goto	u10980
u10981:
	goto	l1387
u10980:
	line	1970
	
l11354:	
;main.c: 1969: {
;main.c: 1970: SetStandbyState(NornalStopState,&WashRunTime, 0);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	clrf	(SetStandbyState@Da)
	movlw	low(0)
	fcall	_SetStandbyState
	line	1971
	
l1387:	
	line	1972
;main.c: 1971: }
;main.c: 1972: ShiftMode_Handle(4);
	movlw	low(04h)
	fcall	_ShiftMode_Handle
	line	1975
	
l1388:	
	return
	opt stack 0
GLOBAL	__end_of_StandbyMode_Handle
	__end_of_StandbyMode_Handle:
	signat	_StandbyMode_Handle,89
	global	_StatusFun_Handle

;; *************** function _StatusFun_Handle *****************
;; Defined at:
;;		line 1450 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_SetStandbyState
;;		_WashHandle
;; This function is called by:
;;		_StandbyMode_Handle
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	line	1450
global __ptext5
__ptext5:	;psect for function _StatusFun_Handle
psect	text5
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	1450
	global	__size_of_StatusFun_Handle
	__size_of_StatusFun_Handle	equ	__end_of_StatusFun_Handle-_StatusFun_Handle
	
_StatusFun_Handle:	
;incstack = 0
	opt	stack 3
; Regs used in _StatusFun_Handle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1452
	
l11122:	
;main.c: 1452: switch(StandByStatus){
	goto	l11130
	line	1456
	
l11124:	
;main.c: 1455: case BackState:
;main.c: 1456: WashHandle();
	fcall	_WashHandle
	line	1457
;main.c: 1457: break;
	goto	l1271
	line	1459
	
l11126:	
;main.c: 1459: SetStandbyState(NornalStopState,&WashRunTime, 0);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	clrf	(SetStandbyState@Da)
	movlw	low(0)
	fcall	_SetStandbyState
	line	1460
;main.c: 1460: break;
	goto	l1271
	line	1452
	
l11130:	
	movf	(_StandByStatus),w
	; Switch size 1, requested type "space"
; Number of cases is 3, Range of values is 0 to 3
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           10     6 (average)
; direct_byte           20     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l11126
	xorlw	1^0	; case 1
	skipnz
	goto	l11124
	xorlw	3^1	; case 3
	skipnz
	goto	l11124
	goto	l1271
	opt asmopt_pop

	line	1462
	
l1271:	
	return
	opt stack 0
GLOBAL	__end_of_StatusFun_Handle
	__end_of_StatusFun_Handle:
	signat	_StatusFun_Handle,89
	global	_WashHandle

;; *************** function _WashHandle *****************
;; Defined at:
;;		line 1430 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_LedSetSt
;;		_SetStandbyState
;; This function is called by:
;;		_StatusFun_Handle
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	line	1430
global __ptext6
__ptext6:	;psect for function _WashHandle
psect	text6
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	1430
	global	__size_of_WashHandle
	__size_of_WashHandle	equ	__end_of_WashHandle-_WashHandle
	
_WashHandle:	
;incstack = 0
	opt	stack 3
; Regs used in _WashHandle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1431
	
l10982:	
;main.c: 1431: if((LedMod[1].LedState==0)&&(StandByStatus==WashState)){
	bsf	status, 6	;RP1=1, select bank2
	movf	(0+(_LedMod)^0100h+05h),w
	btfss	status,2
	goto	u10371
	goto	u10370
u10371:
	goto	l10988
u10370:
	
l10984:	
	bcf	status, 6	;RP1=0, select bank0
		decf	((_StandByStatus)),w
	btfss	status,2
	goto	u10381
	goto	u10380
u10381:
	goto	l10988
u10380:
	line	1432
	
l10986:	
;main.c: 1432: LedSetSt(1, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1434
	
l10988:	
;main.c: 1433: }
;main.c: 1434: if(Timer_WashRun_1s>=WashRunTime){
	bcf	status, 6	;RP1=0, select bank0
	movf	(_WashRunTime),w
	movwf	(??_WashHandle+0)+0
	clrf	(??_WashHandle+0)+0+1
	movf	1+(??_WashHandle+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_WashRun_1s+1)^080h,w
	skipz
	goto	u10395
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_WashHandle+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_WashRun_1s)^080h,w
u10395:
	skipc
	goto	u10391
	goto	u10390
u10391:
	goto	l1263
u10390:
	line	1440
	
l10990:	
;main.c: 1440: Time_made_1s=0;
	clrf	(_Time_made_1s)^080h
	clrf	(_Time_made_1s+1)^080h
	line	1443
	
l10992:	
;main.c: 1443: _BITS1.Bits.bit_0=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(__BITS1),0
	line	1444
	
l10994:	
;main.c: 1444: LedSetSt(1, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1445
	
l10996:	
;main.c: 1445: SetStandbyState(NornalStopState,&WashRunTime, 0);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	clrf	(SetStandbyState@Da)
	movlw	low(0)
	fcall	_SetStandbyState
	line	1447
	
l1263:	
	return
	opt stack 0
GLOBAL	__end_of_WashHandle
	__end_of_WashHandle:
	signat	_WashHandle,89
	global	_GetMode_Handle

;; *************** function _GetMode_Handle *****************
;; Defined at:
;;		line 1334 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_ShiftMode_Handle
;;		_WrterEEP
;; This function is called by:
;;		_Run_Mode
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	line	1334
global __ptext7
__ptext7:	;psect for function _GetMode_Handle
psect	text7
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	1334
	global	__size_of_GetMode_Handle
	__size_of_GetMode_Handle	equ	__end_of_GetMode_Handle-_GetMode_Handle
	
_GetMode_Handle:	
;incstack = 0
	opt	stack 4
; Regs used in _GetMode_Handle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1338
	
l11140:	
;main.c: 1338: if(KeyPacket_y[0].KeyState==NotPress)
	movf	((_KeyPacket_y)),w
	btfss	status,2
	goto	u10611
	goto	u10610
u10611:
	goto	l11146
u10610:
	line	1340
	
l11142:	
;main.c: 1339: {
;main.c: 1340: ShiftMode_Handle(2);
	movlw	low(02h)
	fcall	_ShiftMode_Handle
	line	1341
	
l11144:	
;main.c: 1341: Timer_Standby_1H=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_Timer_Standby_1H)^080h
	clrf	(_Timer_Standby_1H+1)^080h
	line	1345
	
l11146:	
;main.c: 1342: }
;main.c: 1345: if(Time_GetWater_1s>=60){
	movlw	low(03Ch)
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_Time_GetWater_1s),w
	skipc
	goto	u10621
	goto	u10620
u10621:
	goto	l11164
u10620:
	line	1346
	
l11148:	
;main.c: 1346: Time_GetWater_1s=0;
	clrf	(_Time_GetWater_1s)
	line	1347
	
l11150:	
;main.c: 1347: GetWater_ML+=21;
	movlw	015h
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_GetWater_ML)^080h,f
	skipnc
	incf	(_GetWater_ML+1)^080h,f
	line	1364
	
l11152:	
;main.c: 1364: if(GetWater_ML>=(21*10)){
	movlw	0
	subwf	(_GetWater_ML+1)^080h,w
	movlw	0D2h
	skipnz
	subwf	(_GetWater_ML)^080h,w
	skipc
	goto	u10631
	goto	u10630
u10631:
	goto	l11164
u10630:
	line	1365
	
l11154:	
;main.c: 1365: GetWater_ML=0;
	clrf	(_GetWater_ML)^080h
	clrf	(_GetWater_ML+1)^080h
	line	1366
	
l11156:	
;main.c: 1366: if(FilterROGetWater<0xfff0)
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_FilterROGetWater+1),w
	movlw	0F0h
	skipnz
	subwf	(_FilterROGetWater),w
	skipnc
	goto	u10641
	goto	u10640
u10641:
	goto	l1247
u10640:
	line	1367
	
l11158:	
;main.c: 1367: FilterROGetWater+=21;
	movlw	015h
	addwf	(_FilterROGetWater),f
	skipnc
	incf	(_FilterROGetWater+1),f
	
l1247:	
	line	1368
;main.c: 1368: if(FilterPCFGetWater<0xfff0)
	movlw	0FFh
	subwf	(_FilterPCFGetWater+1),w
	movlw	0F0h
	skipnz
	subwf	(_FilterPCFGetWater),w
	skipnc
	goto	u10651
	goto	u10650
u10651:
	goto	l11162
u10650:
	line	1369
	
l11160:	
;main.c: 1369: FilterPCFGetWater+=21;
	movlw	015h
	addwf	(_FilterPCFGetWater),f
	skipnc
	incf	(_FilterPCFGetWater+1),f
	line	1370
	
l11162:	
;main.c: 1370: WrterEEP();
	fcall	_WrterEEP
	line	1380
	
l11164:	
;main.c: 1371: }
;main.c: 1373: }
;main.c: 1379: if((FilterROGetWater>=(21*2))
;main.c: 1380: &&(FilterPCFGetWater>=(21*2))){
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_FilterROGetWater+1),w
	movlw	02Ah
	skipnz
	subwf	(_FilterROGetWater),w
	skipc
	goto	u10661
	goto	u10660
u10661:
	goto	l11170
u10660:
	
l11166:	
	movlw	0
	subwf	(_FilterPCFGetWater+1),w
	movlw	02Ah
	skipnz
	subwf	(_FilterPCFGetWater),w
	skipc
	goto	u10671
	goto	u10670
u10671:
	goto	l11170
u10670:
	line	1382
	
l11168:	
;main.c: 1382: _BITS1.Bits.bit_7=1;
	bsf	(__BITS1),7
	line	1384
	
l11170:	
;main.c: 1383: }
;main.c: 1384: if(Read_Word_Buff[11]!=0)
	bsf	status, 5	;RP0=1, select bank1
	movf	(0+(_Read_Word_Buff)^080h+0Bh),w
	btfsc	status,2
	goto	u10681
	goto	u10680
u10681:
	goto	l1251
u10680:
	line	1385
	
l11172:	
;main.c: 1385: Read_Word_Buff[11]=2;
	movlw	low(02h)
	movwf	0+(_Read_Word_Buff)^080h+0Bh
	line	1387
	
l1251:	
	return
	opt stack 0
GLOBAL	__end_of_GetMode_Handle
	__end_of_GetMode_Handle:
	signat	_GetMode_Handle,89
	global	_FactoryMode_Handle

;; *************** function _FactoryMode_Handle *****************
;; Defined at:
;;		line 1464 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  Step            1    3[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       1       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       1       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    8
;; This function calls:
;;		_AllLedFlash
;;		_BuzzerSet
;;		_LedSetSt
;;		_Time_Count_Func
;; This function is called by:
;;		_Run_Mode
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	1464
global __ptext8
__ptext8:	;psect for function _FactoryMode_Handle
psect	text8
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	1464
	global	__size_of_FactoryMode_Handle
	__size_of_FactoryMode_Handle	equ	__end_of_FactoryMode_Handle-_FactoryMode_Handle
	
_FactoryMode_Handle:	
;incstack = 0
	opt	stack 2
; Regs used in _FactoryMode_Handle: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1465
	
l11174:	
;main.c: 1465: U8_T Step=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(FactoryMode_Handle@Step)^080h
	line	1466
;main.c: 1466: Timer_Power_100ms=0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_Timer_Power_100ms)
	line	1467
	
l11176:	
;main.c: 1467: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1468
;main.c: 1468: while(1){
	
l1274:	
	line	1469
# 1469 "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text8
	line	1470
	
l11178:	
;main.c: 1470: _BITS.Bits.bit_5=0x01;
	bsf	(__BITS),5
	line	1471
;main.c: 1471: switch(Step){
	goto	l11250
	line	1486
	
l11180:	
;main.c: 1486: LedSetSt(3, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(03h)
	fcall	_LedSetSt
	line	1487
;main.c: 1487: LedSetSt(5, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(05h)
	fcall	_LedSetSt
	line	1488
;main.c: 1488: LedSetSt(2, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(02h)
	fcall	_LedSetSt
	line	1489
;main.c: 1489: LedSetSt(4, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(04h)
	fcall	_LedSetSt
	line	1492
	
l11182:	
;main.c: 1492: if(Timer_Power_100ms>=10){
	movlw	low(0Ah)
	subwf	(_Timer_Power_100ms),w
	skipc
	goto	u10691
	goto	u10690
u10691:
	goto	l11252
u10690:
	line	1494
	
l11184:	
;main.c: 1494: Step=1;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(FactoryMode_Handle@Step)^080h
	incf	(FactoryMode_Handle@Step)^080h,f
	goto	l11252
	line	1497
;main.c: 1497: case 1:
	
l1279:	
	line	1498
;main.c: 1498: RC2=1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(58/8),(58)&7	;volatile
	line	1499
;main.c: 1499: {RA2=1;_BITS2.Bits.bit_1=1;};
	bsf	(42/8),(42)&7	;volatile
	bsf	(__BITS2),1
	line	1500
;main.c: 1500: RC3=1;
	bsf	(59/8),(59)&7	;volatile
	line	1501
;main.c: 1501: RA1=1;
	bsf	(41/8),(41)&7	;volatile
	line	1502
	
l11186:	
;main.c: 1502: if(KeyPacket_y[1].KeyState==ShortRelease)
		movlw	6
	xorwf	(0+(_KeyPacket_y)+03h),w
	btfss	status,2
	goto	u10701
	goto	u10700
u10701:
	goto	l11252
u10700:
	line	1504
	
l11188:	
;main.c: 1503: {
;main.c: 1504: KeyPacket_y[1].KeyState=NotPress;
	clrf	0+(_KeyPacket_y)+03h
	line	1505
	
l11190:	
;main.c: 1505: RC2=0;
	bcf	(58/8),(58)&7	;volatile
	line	1506
	
l11192:	
;main.c: 1506: {RA2=0;_BITS2.Bits.bit_1=0;};
	bcf	(42/8),(42)&7	;volatile
	
l11194:	
	bcf	(__BITS2),1
	line	1507
	
l11196:	
;main.c: 1507: RC3=0;
	bcf	(59/8),(59)&7	;volatile
	line	1508
	
l11198:	
;main.c: 1508: RA1=0;
	bcf	(41/8),(41)&7	;volatile
	line	1509
	
l11200:	
;main.c: 1509: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1510
	
l11202:	
;main.c: 1510: Step=2;
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(FactoryMode_Handle@Step)^080h
	line	1511
	
l11204:	
;main.c: 1511: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	goto	l11252
	line	1515
	
l11206:	
;main.c: 1515: if(KeyPacket_y[0].KeyState==NotPress)
	bcf	status, 5	;RP0=0, select bank0
	movf	((_KeyPacket_y)),w
	btfss	status,2
	goto	u10711
	goto	u10710
u10711:
	goto	l11210
u10710:
	line	1517
	
l11208:	
;main.c: 1516: {
;main.c: 1517: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1518
;main.c: 1518: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1519
;main.c: 1519: LedSetSt(0, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(0)
	fcall	_LedSetSt
	line	1520
;main.c: 1520: }
	goto	l11212
	line	1523
	
l11210:	
;main.c: 1521: else
;main.c: 1522: {
;main.c: 1523: LedSetSt(4, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(04h)
	fcall	_LedSetSt
	line	1524
;main.c: 1524: LedSetSt(2, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(02h)
	fcall	_LedSetSt
	line	1525
;main.c: 1525: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	line	1527
	
l11212:	
;main.c: 1526: }
;main.c: 1527: if(KeyPacket_y[2].KeyState==ShortRelease)
		movlw	6
	xorwf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u10721
	goto	u10720
u10721:
	goto	l11252
u10720:
	line	1529
	
l11214:	
;main.c: 1528: {
;main.c: 1529: KeyPacket_y[2].KeyState=NotPress;
	clrf	0+(_KeyPacket_y)+06h
	line	1530
	
l11216:	
;main.c: 1530: Step=3;
	movlw	low(03h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(FactoryMode_Handle@Step)^080h
	line	1531
	
l11218:	
;main.c: 1531: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1532
	
l11220:	
;main.c: 1532: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	goto	l11252
	line	1537
	
l11222:	
;main.c: 1537: if(PureTDSTyp.TdsData>10&&PureTDSTyp.TdsData<50){
	movlw	0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	1+(_PureTDSTyp)^0100h+0Fh,w
	movlw	0Bh
	skipnz
	subwf	0+(_PureTDSTyp)^0100h+0Fh,w
	skipc
	goto	u10731
	goto	u10730
u10731:
	goto	l11228
u10730:
	
l11224:	
	movlw	0
	subwf	1+(_PureTDSTyp)^0100h+0Fh,w
	movlw	032h
	skipnz
	subwf	0+(_PureTDSTyp)^0100h+0Fh,w
	skipnc
	goto	u10741
	goto	u10740
u10741:
	goto	l11228
u10740:
	line	1538
	
l11226:	
;main.c: 1538: LedSetSt(5, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(05h)
	fcall	_LedSetSt
	line	1539
;main.c: 1539: LedSetSt(3, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(03h)
	fcall	_LedSetSt
	line	1540
;main.c: 1540: LedSetSt(1, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(01h)
	fcall	_LedSetSt
	line	1541
;main.c: 1541: }
	goto	l11230
	line	1544
	
l11228:	
;main.c: 1542: else
;main.c: 1543: {
;main.c: 1544: LedSetSt(4, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(04h)
	fcall	_LedSetSt
	line	1545
;main.c: 1545: LedSetSt(2, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(02h)
	fcall	_LedSetSt
	line	1546
;main.c: 1546: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	line	1548
	
l11230:	
;main.c: 1547: }
;main.c: 1548: if(KeyPacket_y[2].KeyState==ShortPressDown)
		decf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u10751
	goto	u10750
u10751:
	goto	l11252
u10750:
	line	1550
	
l11232:	
;main.c: 1549: {
;main.c: 1550: KeyPacket_y[2].KeyState=NotPress;
	clrf	0+(_KeyPacket_y)+06h
	line	1551
	
l11234:	
;main.c: 1551: Step=4;
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(FactoryMode_Handle@Step)^080h
	line	1552
	
l11236:	
;main.c: 1552: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1553
	
l11238:	
;main.c: 1553: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	goto	l11252
	line	1557
	
l11240:	
;main.c: 1557: if(Temp_Ntc>15&&PureTDSTyp.TdsData<45){
	movlw	low(010h)
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_Temp_Ntc),w
	skipc
	goto	u10761
	goto	u10760
u10761:
	goto	l11246
u10760:
	
l11242:	
	movlw	0
	bsf	status, 6	;RP1=1, select bank2
	subwf	1+(_PureTDSTyp)^0100h+0Fh,w
	movlw	02Dh
	skipnz
	subwf	0+(_PureTDSTyp)^0100h+0Fh,w
	skipnc
	goto	u10771
	goto	u10770
u10771:
	goto	l11246
u10770:
	line	1559
	
l11244:	
;main.c: 1559: LedSetSt(1, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(01h)
	fcall	_LedSetSt
	line	1560
;main.c: 1560: }
	goto	l11252
	line	1563
	
l11246:	
;main.c: 1561: else
;main.c: 1562: {
;main.c: 1563: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	goto	l11252
	line	1471
	
l11250:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(FactoryMode_Handle@Step)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 5, Range of values is 0 to 4
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           16     9 (average)
; direct_byte           23     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l11180
	xorlw	1^0	; case 1
	skipnz
	goto	l1279
	xorlw	2^1	; case 2
	skipnz
	goto	l11206
	xorlw	3^2	; case 3
	skipnz
	goto	l11222
	xorlw	4^3	; case 4
	skipnz
	goto	l11240
	goto	l11252
	opt asmopt_pop

	line	1567
	
l11252:	
;main.c: 1567: Time_Count_Func();
	fcall	_Time_Count_Func
	goto	l1274
	return
	opt stack 0
	line	1571
GLOBAL	__end_of_FactoryMode_Handle
	__end_of_FactoryMode_Handle:
	signat	_FactoryMode_Handle,89
	global	_Time_Count_Func

;; *************** function _Time_Count_Func *****************
;; Defined at:
;;		line 604 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       3       0
;;      Totals:         0       0       3       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    7
;; This function calls:
;;		_AD_Testing
;;		_BuzzerSet
;;		_CheckKey
;;		_ErrorHandle
;;		_FilterKeyInputRest
;;		_FilterLifeFunc
;;		_GetDelayFilterFlag
;;		_Led_Handle
;;		_Page_ProgramData
;;		_SetStandbyState
;;		_TDS_Handle
;;		_TaskAlarmHandle
;;		_Tx_Display
;;		___CMS_CheckTouchKey
;; This function is called by:
;;		_FactoryMode_Handle
;;		_main
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	604
global __ptext9
__ptext9:	;psect for function _Time_Count_Func
psect	text9
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	604
	global	__size_of_Time_Count_Func
	__size_of_Time_Count_Func	equ	__end_of_Time_Count_Func-_Time_Count_Func
	
_Time_Count_Func:	
;incstack = 0
	opt	stack 4
; Regs used in _Time_Count_Func: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	606
	
l10998:	
;main.c: 606: if(_BITS2.Bits.bit_0){
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(__BITS2),0
	goto	u10401
	goto	u10400
u10401:
	goto	l1110
u10400:
	line	607
	
l11000:	
;main.c: 607: _BITS2.Bits.bit_0=0;
	bcf	(__BITS2),0
	line	609
	
l11002:	
;main.c: 609: AD_Testing(1,15,0);
	movlw	low(0Fh)
	movwf	(AD_Testing@ad_ch)
	clrf	(AD_Testing@ad_lr)
	movlw	low(01h)
	fcall	_AD_Testing
	line	610
;main.c: 610: __CMS_CheckTouchKey();
	fcall	___CMS_CheckTouchKey
	line	611
	
l11004:	
;main.c: 611: CheckKey();
	fcall	_CheckKey
	line	613
	
l11006:	
;main.c: 613: if(Mode!=5)
		movlw	5
	xorwf	((_Mode)),w
	btfsc	status,2
	goto	u10411
	goto	u10410
u10411:
	goto	l11010
u10410:
	line	614
	
l11008:	
;main.c: 614: FilterLifeFunc();
	fcall	_FilterLifeFunc
	line	615
	
l11010:	
;main.c: 615: TaskAlarmHandle();
	fcall	_TaskAlarmHandle
	line	616
	
l11012:	
;main.c: 616: Led_Handle();
	fcall	_Led_Handle
	line	620
	
l11014:	
;main.c: 620: FilterKeyInputRest();
	fcall	_FilterKeyInputRest
	line	621
	
l11016:	
;main.c: 621: Time_100ms++;
	bcf	status, 5	;RP0=0, select bank0
	incf	(_Time_100ms),f
	line	622
	
l11018:	
;main.c: 622: if(Time_100ms>=10){
	movlw	low(0Ah)
	subwf	(_Time_100ms),w
	skipc
	goto	u10421
	goto	u10420
u10421:
	goto	l1110
u10420:
	line	623
	
l11020:	
;main.c: 623: Time_100ms=0;
	clrf	(_Time_100ms)
	line	624
	
l11022:	
;main.c: 624: Timer_Power_100ms++;
	incf	(_Timer_Power_100ms),f
	line	626
	
l11024:	
;main.c: 626: Time_1s++;
	incf	(_Time_1s),f
	line	627
	
l11026:	
;main.c: 627: if(Time_1s>=10){
	movlw	low(0Ah)
	subwf	(_Time_1s),w
	skipc
	goto	u10431
	goto	u10430
u10431:
	goto	l1110
u10430:
	line	628
	
l11028:	
;main.c: 628: Time_1s=0;
	clrf	(_Time_1s)
	line	629
	
l11030:	
;main.c: 629: if(Mode!=0){
	movf	((_Mode)),w
	btfsc	status,2
	goto	u10441
	goto	u10440
u10441:
	goto	l11034
u10440:
	line	630
	
l11032:	
;main.c: 630: Tx_Display();
	fcall	_Tx_Display
	line	632
	
l11034:	
;main.c: 631: }
;main.c: 632: if(Mode!=0)
	movf	((_Mode)),w
	btfsc	status,2
	goto	u10451
	goto	u10450
u10451:
	goto	l11038
u10450:
	line	633
	
l11036:	
;main.c: 633: ErrorHandle();
	fcall	_ErrorHandle
	line	635
	
l11038:	
;main.c: 635: if(Time_Power_1s<0xf0)
	movlw	low(0F0h)
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_Time_Power_1s),w
	skipnc
	goto	u10461
	goto	u10460
u10461:
	goto	l11042
u10460:
	line	636
	
l11040:	
;main.c: 636: Time_Power_1s++;
	incf	(_Time_Power_1s),f
	line	637
	
l11042:	
;main.c: 637: if(_BITS.Bits.bit_4==1){
	btfss	(__BITS),4
	goto	u10471
	goto	u10470
u10471:
	goto	l11048
u10470:
	line	638
	
l11044:	
;main.c: 638: _BITS.Bits.bit_4=0;
	bcf	(__BITS),4
	line	639
	
l11046:	
;main.c: 639: Page_ProgramData();
	fcall	_Page_ProgramData
	line	641
	
l11048:	
;main.c: 640: }
;main.c: 641: if(FilterRst_1s<0xfff0)
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_FilterRst_1s+1)^080h,w
	movlw	0F0h
	skipnz
	subwf	(_FilterRst_1s)^080h,w
	skipnc
	goto	u10481
	goto	u10480
u10481:
	goto	l11052
u10480:
	line	642
	
l11050:	
;main.c: 642: FilterRst_1s++;
	incf	(_FilterRst_1s)^080h,f
	skipnz
	incf	(_FilterRst_1s+1)^080h,f
	line	645
	
l11052:	
;main.c: 645: if(_BITS2.Bits.bit_1==1){
	bcf	status, 5	;RP0=0, select bank0
	btfss	(__BITS2),1
	goto	u10491
	goto	u10490
u10491:
	goto	l11056
u10490:
	line	646
	
l11054:	
;main.c: 646: Timer_LongGetWater_1s++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_Timer_LongGetWater_1s)^080h,f
	skipnz
	incf	(_Timer_LongGetWater_1s+1)^080h,f
	line	647
;main.c: 647: }
	goto	l11058
	line	650
	
l11056:	
;main.c: 648: else
;main.c: 649: {
;main.c: 650: Timer_LongGetWater_1s=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_Timer_LongGetWater_1s)^080h
	clrf	(_Timer_LongGetWater_1s+1)^080h
	line	653
	
l11058:	
;main.c: 651: }
;main.c: 653: if(_BITS.Bits.bit_5==0x01){
	btfss	(__BITS),5
	goto	u10501
	goto	u10500
u10501:
	goto	l11092
u10500:
	line	654
	
l11060:	
;main.c: 654: _BITS1.Bits.bit_4=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(__BITS1),4
	line	655
;main.c: 655: _BITS1.Bits.bit_6=0;
	bcf	(__BITS1),6
	line	656
;main.c: 656: _BITS2.Bits.bit_2=0;
	bcf	(__BITS2),2
	line	657
	
l11062:	
;main.c: 657: Time_GetWater_1s++;
	incf	(_Time_GetWater_1s),f
	line	658
	
l11064:	
;main.c: 658: Timer_Standby_1s=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_Timer_Standby_1s)^080h
	clrf	(_Timer_Standby_1s+1)^080h
	line	659
	
l11066:	
;main.c: 659: Timer_BackT_1H=0;
	clrf	(_Timer_BackT_1H)^080h
	clrf	(_Timer_BackT_1H+1)^080h
	line	661
	
l11068:	
;main.c: 661: if(FilterFastCheck==1){
	bcf	status, 5	;RP0=0, select bank0
		decf	((_FilterFastCheck)),w
	btfss	status,2
	goto	u10511
	goto	u10510
u10511:
	goto	l11072
u10510:
	line	662
	
l11070:	
;main.c: 662: FilterROGetWater+=21;
	movlw	015h
	addwf	(_FilterROGetWater),f
	skipnc
	incf	(_FilterROGetWater+1),f
	line	663
;main.c: 663: FilterPCFGetWater+=21;
	movlw	015h
	addwf	(_FilterPCFGetWater),f
	skipnc
	incf	(_FilterPCFGetWater+1),f
	line	666
	
l11072:	
;main.c: 664: }
;main.c: 666: Time_made_1s++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_Time_made_1s)^080h,f
	skipnz
	incf	(_Time_made_1s+1)^080h,f
	line	667
	
l11074:	
;main.c: 667: RA0=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(40/8),(40)&7	;volatile
	line	674
;main.c: 674: if(++Timer_TdsMake_1s>=60){
	movlw	low(03Ch)
	incf	(_Timer_TdsMake_1s),f
	subwf	((_Timer_TdsMake_1s)),w
	skipc
	goto	u10521
	goto	u10520
u10521:
	goto	l11078
u10520:
	line	675
	
l11076:	
;main.c: 675: _BITS.Bits.bit_6=1;
	bsf	(__BITS),6
	line	678
	
l11078:	
;main.c: 676: }
;main.c: 678: TDS_Handle(&PureTDSTyp,1);
	clrf	(TDS_Handle@Type)
	incf	(TDS_Handle@Type),f
	movlw	(low(_PureTDSTyp|((0x1)<<8)))&0ffh
	fcall	_TDS_Handle
	line	683
	
l11080:	
;main.c: 683: if((FilterROState==3)||(FilterPCFState==3)){
		movlw	3
	xorwf	((_FilterROState)),w
	btfsc	status,2
	goto	u10531
	goto	u10530
u10531:
	goto	l11084
u10530:
	
l11082:	
		movlw	3
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u10541
	goto	u10540
u10541:
	goto	l1104
u10540:
	line	684
	
l11084:	
;main.c: 684: FilterBuzzer_1s++;
	incf	(_FilterBuzzer_1s),f
	line	685
	
l11086:	
;main.c: 685: if(FilterBuzzer_1s>=2){
	movlw	low(02h)
	subwf	(_FilterBuzzer_1s),w
	skipc
	goto	u10551
	goto	u10550
u10551:
	goto	l1104
u10550:
	line	686
	
l11088:	
;main.c: 686: FilterBuzzer_1s=0;
	clrf	(_FilterBuzzer_1s)
	line	687
	
l11090:	
;main.c: 687: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	goto	l1104
	line	693
	
l11092:	
;main.c: 691: else
;main.c: 692: {
;main.c: 693: FilterBuzzer_1s=0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_FilterBuzzer_1s)
	line	695
	
l11094:	
;main.c: 695: if((Time_made_1s>=300)&&(Mode!=3)){
	movlw	01h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Time_made_1s+1)^080h,w
	movlw	02Ch
	skipnz
	subwf	(_Time_made_1s)^080h,w
	skipc
	goto	u10561
	goto	u10560
u10561:
	goto	l11110
u10560:
	
l11096:	
		movlw	3
	xorwf	((_Mode)),w
	btfsc	status,2
	goto	u10571
	goto	u10570
u10571:
	goto	l11110
u10570:
	line	696
	
l11098:	
;main.c: 696: Time_made_1s=0;
	clrf	(_Time_made_1s)^080h
	clrf	(_Time_made_1s+1)^080h
	line	697
	
l11100:	
;main.c: 697: if(StandByStatus!=WashState){
	bcf	status, 5	;RP0=0, select bank0
		decf	((_StandByStatus)),w
	btfsc	status,2
	goto	u10581
	goto	u10580
u10581:
	goto	l11104
u10580:
	line	698
	
l11102:	
;main.c: 698: SetStandbyState(WashState,&WashRunTime, 6);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(06h)
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	line	699
;main.c: 699: }
	goto	l11110
	line	702
	
l11104:	
;main.c: 700: else
;main.c: 701: {
;main.c: 702: if(StandByStatus!=BackState){
		movlw	3
	xorwf	((_StandByStatus)),w
	btfsc	status,2
	goto	u10591
	goto	u10590
u10591:
	goto	l11110
u10590:
	line	703
	
l11106:	
;main.c: 703: if(WashRunTime-Timer_WashRun_1s<6){
	movf	(_WashRunTime),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(??_Time_Count_Func+0)^080h+0
	movf	(_Timer_WashRun_1s)^080h,w
	subwf	(??_Time_Count_Func+0)^080h+0,w
	movwf	(??_Time_Count_Func+1)^080h+0
	comf	(_Timer_WashRun_1s+1)^080h,w
	skipnc
	addlw	1
	movwf	((??_Time_Count_Func+1)^080h+0)+1
	movlw	0
	subwf	1+(??_Time_Count_Func+1)^080h+0,w
	movlw	06h
	skipnz
	subwf	0+(??_Time_Count_Func+1)^080h+0,w
	skipnc
	goto	u10601
	goto	u10600
u10601:
	goto	l1107
u10600:
	line	704
	
l11108:	
;main.c: 704: SetStandbyState(WashState,&WashRunTime, 6);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(06h)
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	goto	l11110
	line	707
	
l1107:	
	line	710
	
l11110:	
;main.c: 705: }
;main.c: 706: }
;main.c: 707: }
;main.c: 708: }
;main.c: 710: RA0=1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(40/8),(40)&7	;volatile
	line	711
	
l11112:	
;main.c: 711: _BITS.Bits.bit_6=0;
	bcf	(__BITS),6
	line	712
	
l11114:	
;main.c: 712: TdsCk60sFlag=0;
	clrf	(_TdsCk60sFlag)
	line	713
	
l11116:	
;main.c: 713: Timer_TdsMake_1s=0;
	clrf	(_Timer_TdsMake_1s)
	line	714
	
l11118:	
;main.c: 714: Timer_WashRun_1s++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_Timer_WashRun_1s)^080h,f
	skipnz
	incf	(_Timer_WashRun_1s+1)^080h,f
	line	716
	
l11120:	
;main.c: 716: Timer_Standby_1s++;
	incf	(_Timer_Standby_1s)^080h,f
	skipnz
	incf	(_Timer_Standby_1s+1)^080h,f
	line	718
	
l1104:	
	line	724
;main.c: 718: }
;main.c: 724: GetDelayFilterFlag(&FilterPCF_time);
	movlw	(low(_FilterPCF_time|((0x0)<<8)))&0ffh
	fcall	_GetDelayFilterFlag
	line	725
;main.c: 725: GetDelayFilterFlag(&FilterRO_time);
	movlw	(low(_FilterRO_time|((0x0)<<8)))&0ffh
	fcall	_GetDelayFilterFlag
	line	732
	
l1110:	
	return
	opt stack 0
GLOBAL	__end_of_Time_Count_Func
	__end_of_Time_Count_Func:
	signat	_Time_Count_Func,89
	global	___CMS_CheckTouchKey

;; *************** function ___CMS_CheckTouchKey *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1074            1    0        unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		___CMS_CheckKeyOldValue
;;		___CMS_CheckOnceResult
;;		___CMS_CheckValidTime
;;		___CMS_CurAdjust
;;		___CMS_KeyDatIIR
;;		___CMS_KeyModeSet
;;		___CMS_KeyStart
;;		___CMS_KeyStopClear
;;		___CMS_Key_UNNOL_Check
;;		___CMS_NewRAMClr
;;		___CMS_Noise_check
;;		___GET_32M_FREDAT
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=1
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
global __ptext10
__ptext10:	;psect for function ___CMS_CheckTouchKey
psect	text10
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CheckTouchKey
	__size_of___CMS_CheckTouchKey	equ	__end_of___CMS_CheckTouchKey-___CMS_CheckTouchKey
	
___CMS_CheckTouchKey:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CheckTouchKey: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	
l10516:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text10
	btfsc	(_924/8),(_924)&7	;volatile
	goto	u9611
	goto	u9610
u9611:
	goto	l10524
u9610:
	
l10518:	
	bsf	(_924/8),(_924)&7	;volatile
	
l10520:	
	fcall	___CMS_NewRAMClr
	
l10522:	
	fcall	___GET_32M_FREDAT
	
l10524:	
	btfsc	(_926/8),(_926)&7	;volatile
	goto	u9621
	goto	u9620
u9621:
	goto	l10528
u9620:
	
l10526:	
	fcall	___CMS_CurAdjust
	goto	l10580
	
l10528:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_918)),w	;volatile
	btfsc	status,2
	goto	u9631
	goto	u9630
u9631:
	goto	l10572
u9630:
	
l10530:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_CheckTouchKey@F1073)^080h
	
l10532:	
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	xorwf	((_918)),w	;volatile
	btfsc	status,2
	goto	u9641
	goto	u9640
u9641:
	goto	l10538
u9640:
	
l10534:	
	fcall	___CMS_KeyDatIIR
	
l10536:	
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_918)	;volatile
	goto	l10580
	
l10538:	
	fcall	___CMS_Noise_check
	
l10540:	
	fcall	___CMS_CheckKeyOldValue
	
l10542:	
	fcall	___CMS_CheckOnceResult
	
l10544:	
	movlw	low(08h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_920),f	;volatile
	subwf	((_920)),w	;volatile
	skipc
	goto	u9651
	goto	u9650
u9651:
	goto	l10548
u9650:
	
l10546:	
	clrf	(_920)	;volatile
	
l10548:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u9661
	goto	u9660
u9661:
	goto	l10552
u9660:
	
l10550:	
	movf	(_920),w
	addlw	low(((_sc_FreScanTable)|8000h))
	movwf	fsr0
	movlw	high(((_sc_FreScanTable)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(_921)	;volatile
	goto	l10554
	
l10552:	
	movf	(_920),w
	addlw	low(((_sc_FreScanTable1)|8000h))
	movwf	fsr0
	movlw	high(((_sc_FreScanTable1)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(_921)	;volatile
	
l10554:	
	btfsc	(_gf_kerr/8),(_gf_kerr)&7	;volatile
	goto	u9671
	goto	u9670
u9671:
	goto	l10558
u9670:
	
l10556:	
	movlw	low(03h)
	subwf	(_917),w	;volatile
	skipc
	goto	u9681
	goto	u9680
u9681:
	goto	l10562
u9680:
	
l10558:	
	fcall	___CMS_KeyStopClear
	
l10560:	
	bcf	(_gf_kerr/8),(_gf_kerr)&7	;volatile
	
l10562:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_917)	;volatile
	
l10564:	
	fcall	___CMS_Key_UNNOL_Check
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_918)	;volatile
	
l10566:	
	btfss	(_926/8),(_926)&7	;volatile
	goto	u9691
	goto	u9690
u9691:
	goto	l3684
u9690:
	
l10568:	
	fcall	___CMS_KeyModeSet
	
l10570:	
	fcall	___CMS_KeyStart
	goto	l10580
	
l10572:	
	movlw	low(0FAh)
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_CheckTouchKey@F1073)^080h,f
	subwf	((___CMS_CheckTouchKey@F1073)^080h),w
	skipc
	goto	u9701
	goto	u9700
u9701:
	goto	l10580
u9700:
	
l10574:	
	clrf	(___CMS_CheckTouchKey@F1073)^080h
	clrf	(_919)	;volatile
	goto	l10568
	
l3684:	
	
l10580:	
	fcall	___CMS_CheckValidTime
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text10
	
l3686:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CheckTouchKey
	__end_of___CMS_CheckTouchKey:
	signat	___CMS_CheckTouchKey,89
	global	___GET_32M_FREDAT

;; *************** function ___GET_32M_FREDAT *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=1
global __ptext11
__ptext11:	;psect for function ___GET_32M_FREDAT
psect	text11
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___GET_32M_FREDAT
	__size_of___GET_32M_FREDAT	equ	__end_of___GET_32M_FREDAT-___GET_32M_FREDAT
	
___GET_32M_FREDAT:	
;incstack = 0
	opt	stack 6
; Regs used in ___GET_32M_FREDAT: [wreg+status,2+status,0]
	
l10244:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text11
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	bsf	(404)^0180h+(0/8),(0)&7	;volatile
	
l10246:	
	movf	(404)^0180h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_916)	;volatile
	
l10248:	
	movlw	low(070h)
	andwf	(_916),f	;volatile
	
l10250:	
	movlw	low(061h)
	subwf	(_916),w	;volatile
	skipc
	goto	u9091
	goto	u9090
u9091:
	goto	l10254
u9090:
	
l10252:	
	movlw	low(060h)
	movwf	(_916)	;volatile
	goto	l3641
	
l10254:	
	movlw	low(010h)
	subwf	(_916),w	;volatile
	skipnc
	goto	u9101
	goto	u9100
u9101:
	goto	l3641
u9100:
	
l10256:	
	movlw	low(010h)
	movwf	(_916)	;volatile
	
l3641:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text11
	
l3643:	
	return
	opt stack 0
GLOBAL	__end_of___GET_32M_FREDAT
	__end_of___GET_32M_FREDAT:
	signat	___GET_32M_FREDAT,89
	global	___CMS_Noise_check

;; *************** function ___CMS_Noise_check *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  973             2    9[BANK0 ] unsigned short 
;;  975             2    7[BANK0 ] unsigned short 
;;  974             2    3[BANK0 ] unsigned short 
;;  970             1   11[BANK0 ] unsigned char 
;;  972             1    6[BANK0 ] unsigned char 
;;  971             1    5[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       9       0       0
;;      Temps:          0       3       0       0
;;      Totals:         0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=1
global __ptext12
__ptext12:	;psect for function ___CMS_Noise_check
psect	text12
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_Noise_check
	__size_of___CMS_Noise_check	equ	__end_of___CMS_Noise_check-___CMS_Noise_check
	
___CMS_Noise_check:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_Noise_check: [wreg-fsr0h+status,2+status,0]
	
l9700:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text12
	
l9702:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_Noise_check@970)
	clrf	(___CMS_Noise_check@971)
	clrf	(___CMS_Noise_check@972)
	clrf	(___CMS_Noise_check@973)
	clrf	(___CMS_Noise_check@973+1)
	
l9704:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9706:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_Noise_check@970),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_Noise_check@974)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_Noise_check@974+1)
	
l9708:	
	movf	((_921)),w	;volatile
	btfsc	status,2
	goto	u8261
	goto	u8260
u8261:
	goto	l9714
u8260:
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
	
l9710:	
	clrc
	rlf	(___CMS_Noise_check@970),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_Noise_check@975)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_Noise_check@975+1)
	
l9712:	
	movlw	04Bh
	addwf	(___CMS_Noise_check@975),f
	skipnc
	incf	(___CMS_Noise_check@975+1),f
	line	1
	goto	l9718
	line	114
	
l9714:	
	clrc
	rlf	(___CMS_Noise_check@970),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_Noise_check@975)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_Noise_check@975+1)
	
l9716:	
	movlw	064h
	addwf	(___CMS_Noise_check@975),f
	skipnc
	incf	(___CMS_Noise_check@975+1),f
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9718:	
	movf	(___CMS_Noise_check@974+1),w
	subwf	(___CMS_Noise_check@975+1),w
	skipz
	goto	u8275
	movf	(___CMS_Noise_check@974),w
	subwf	(___CMS_Noise_check@975),w
u8275:
	skipnc
	goto	u8271
	goto	u8270
u8271:
	goto	l9724
u8270:
	
l9720:	
	incf	(___CMS_Noise_check@970),w
	movwf	(??___CMS_Noise_check+0)+0
	movlw	01h
	movwf	(??___CMS_Noise_check+1)+0
	movlw	0
	movwf	(??___CMS_Noise_check+1)+0+1
	goto	u8284
u8285:
	clrc
	rlf	(??___CMS_Noise_check+1)+0,f
	rlf	(??___CMS_Noise_check+1)+1,f
u8284:
	decfsz	(??___CMS_Noise_check+0)+0,f
	goto	u8285
	
	movf	0+(??___CMS_Noise_check+1)+0,w
	iorwf	(___CMS_Noise_check@973),f
	movf	1+(??___CMS_Noise_check+1)+0,w
	iorwf	(___CMS_Noise_check@973+1),f
	
l9722:	
	incf	(___CMS_Noise_check@971),f
	
l9724:	
	movlw	low(02h)
	incf	(___CMS_Noise_check@970),f
	subwf	((___CMS_Noise_check@970)),w
	skipc
	goto	u8291
	goto	u8290
u8291:
	goto	l9704
u8290:
	
l9726:	
	movlw	low(02h)
	subwf	(___CMS_Noise_check@971),w
	skipc
	goto	u8301
	goto	u8300
u8301:
	goto	l9738
u8300:
	
l9728:	
	clrf	(___CMS_Noise_check@972)
	incf	(___CMS_Noise_check@972),f
	
l9730:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_Noise_check@F967)^080h
	
l9732:	
	movlw	low(02h)
	incf	(___CMS_Noise_check@F966)^080h,f
	subwf	((___CMS_Noise_check@F966)^080h),w
	skipc
	goto	u8311
	goto	u8310
u8311:
	goto	l9742
u8310:
	
l9734:	
	clrf	(___CMS_Noise_check@F966)^080h
	
l9736:	
	bsf	(_925/8),(_925)&7	;volatile
	goto	l9742
	
l9738:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Noise_check@F967)^080h,f
	subwf	((___CMS_Noise_check@F967)^080h),w
	skipc
	goto	u8321
	goto	u8320
u8321:
	goto	l9742
u8320:
	
l9740:	
	clrf	(___CMS_Noise_check@F967)^080h
	clrf	(___CMS_Noise_check@F966)^080h
	
l9742:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___CMS_Noise_check@973),w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(___CMS_Noise_check@F969)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??___CMS_Noise_check+0)+0
	movf	(___CMS_Noise_check@973+1),w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(___CMS_Noise_check@F969+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??___CMS_Noise_check+0)+0
	movf	((??___CMS_Noise_check+0)+0),w
iorwf	((??___CMS_Noise_check+0)+1),w
	btfsc	status,2
	goto	u8331
	goto	u8330
u8331:
	goto	l9754
u8330:
	
l9744:	
	clrf	(___CMS_Noise_check@972)
	incf	(___CMS_Noise_check@972),f
	
l9746:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_Noise_check@F965)^080h
	
l9748:	
	movlw	low(02h)
	incf	(___CMS_Noise_check@F964)^080h,f
	subwf	((___CMS_Noise_check@F964)^080h),w
	skipc
	goto	u8341
	goto	u8340
u8341:
	goto	l9758
u8340:
	
l9750:	
	clrf	(___CMS_Noise_check@F964)^080h
	
l9752:	
	bsf	(_925/8),(_925)&7	;volatile
	goto	l9758
	
l9754:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Noise_check@F965)^080h,f
	subwf	((___CMS_Noise_check@F965)^080h),w
	skipc
	goto	u8351
	goto	u8350
u8351:
	goto	l9758
u8350:
	
l9756:	
	clrf	(___CMS_Noise_check@F965)^080h
	clrf	(___CMS_Noise_check@F964)^080h
	
l9758:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___CMS_Noise_check@973+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___CMS_Noise_check@F969+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___CMS_Noise_check@973),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___CMS_Noise_check@F969)^080h
	
l9760:	
	btfss	(_925/8),(_925)&7	;volatile
	goto	u8361
	goto	u8360
u8361:
	goto	l9780
u8360:
	
l9762:	
	bcf	status, 5	;RP0=0, select bank0
	movf	((___CMS_Noise_check@972)),w
	btfss	status,2
	goto	u8371
	goto	u8370
u8371:
	goto	l9780
u8370:
	
l9764:	
	movf	((_g_KeyFlag)),w	;volatile
	btfss	status,2
	goto	u8381
	goto	u8380
u8381:
	goto	l9774
u8380:
	
l9766:	
	movf	(0+(_g_KeyFlag)+01h),w	;volatile
	btfss	status,2
	goto	u8391
	goto	u8390
u8391:
	goto	l9774
u8390:
	
l9768:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Noise_check@F968)^080h,f
	skipnz
	incf	(___CMS_Noise_check@F968+1)^080h,f
	movlw	0
	subwf	((___CMS_Noise_check@F968+1)^080h),w
	movlw	064h
	skipnz
	subwf	((___CMS_Noise_check@F968)^080h),w
	skipc
	goto	u8401
	goto	u8400
u8401:
	goto	l3473
u8400:
	
l9770:	
	clrf	(___CMS_Noise_check@F968)^080h
	clrf	(___CMS_Noise_check@F968+1)^080h
	
l9772:	
	bcf	(_925/8),(_925)&7	;volatile
	goto	l3473
	
l9774:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Noise_check@F968)^080h,f
	skipnz
	incf	(___CMS_Noise_check@F968+1)^080h,f
	movlw	01h
	subwf	((___CMS_Noise_check@F968+1)^080h),w
	movlw	02Ch
	skipnz
	subwf	((___CMS_Noise_check@F968)^080h),w
	skipc
	goto	u8411
	goto	u8410
u8411:
	goto	l3473
u8410:
	goto	l9770
	
l9780:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_Noise_check@F968)^080h
	clrf	(___CMS_Noise_check@F968+1)^080h
	
l3473:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text12
	
l3474:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_Noise_check
	__end_of___CMS_Noise_check:
	signat	___CMS_Noise_check,89
	global	___CMS_NewRAMClr

;; *************** function ___CMS_NewRAMClr *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1051            1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=1
global __ptext13
__ptext13:	;psect for function ___CMS_NewRAMClr
psect	text13
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_NewRAMClr
	__size_of___CMS_NewRAMClr	equ	__end_of___CMS_NewRAMClr-___CMS_NewRAMClr
	
___CMS_NewRAMClr:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_NewRAMClr: [wreg-fsr0h+status,2+status,0]
	
l10218:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text13
	
l10220:	
	clrf	(___CMS_NewRAMClr@1051)
	
l10226:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10228:	
	movf	(___CMS_NewRAMClr@1051),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l10230:	
	movlw	low(02h)
	movwf	(415)^0180h	;volatile
	movf	(___CMS_NewRAMClr@1051),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l10232:	
	movlw	low(04h)
	movwf	(415)^0180h	;volatile
	
l10234:	
	movf	(___CMS_NewRAMClr@1051),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	movlw	low(08h)
	movwf	(415)^0180h	;volatile
	
l10236:	
	movf	(___CMS_NewRAMClr@1051),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l10238:	
	movlw	low(010h)
	movwf	(415)^0180h	;volatile
	movf	(___CMS_NewRAMClr@1051),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l10240:	
	incf	(___CMS_NewRAMClr@1051),f
	
l10242:	
	movlw	low(050h)
	subwf	(___CMS_NewRAMClr@1051),w
	skipc
	goto	u9081
	goto	u9080
u9081:
	goto	l10226
u9080:
	
l3636:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text13
	
l3637:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_NewRAMClr
	__end_of___CMS_NewRAMClr:
	signat	___CMS_NewRAMClr,89
	global	___CMS_Key_UNNOL_Check

;; *************** function ___CMS_Key_UNNOL_Check *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1017            1    1[BANK0 ] unsigned char 
;;  1018            1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       2       0       0
;;      Temps:          2       0       0       0
;;      Totals:         2       2       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=1
global __ptext14
__ptext14:	;psect for function ___CMS_Key_UNNOL_Check
psect	text14
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_Key_UNNOL_Check
	__size_of___CMS_Key_UNNOL_Check	equ	__end_of___CMS_Key_UNNOL_Check-___CMS_Key_UNNOL_Check
	
___CMS_Key_UNNOL_Check:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_Key_UNNOL_Check: [wreg-fsr0h+status,2+status,0]
	
l10028:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text14
	
l10030:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_Key_UNNOL_Check@1017)
	clrf	(___CMS_Key_UNNOL_Check@1018)
	
l10032:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u8781
	goto	u8780
u8781:
	goto	l3545
u8780:
	
l10034:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10036:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	movlw	0Ch
	subwf	1+(??___CMS_Key_UNNOL_Check+0)+0,w
	movlw	01h
	skipnz
	subwf	0+(??___CMS_Key_UNNOL_Check+0)+0,w
	skipnc
	goto	u8791
	goto	u8790
u8791:
	goto	l10040
u8790:
	
l10038:	
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	movlw	04h
	subwf	1+(??___CMS_Key_UNNOL_Check+0)+0,w
	movlw	0
	skipnz
	subwf	0+(??___CMS_Key_UNNOL_Check+0)+0,w
	skipnc
	goto	u8801
	goto	u8800
u8801:
	goto	l10044
u8800:
	
l10040:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Key_UNNOL_Check@F1016)^080h,f
	
l10042:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___CMS_Key_UNNOL_Check@1018)
	incf	(___CMS_Key_UNNOL_Check@1018),f
	
l10044:	
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	movlw	0Ch
	subwf	1+(??___CMS_Key_UNNOL_Check+0)+0,w
	movlw	01h
	skipnz
	subwf	0+(??___CMS_Key_UNNOL_Check+0)+0,w
	skipnc
	goto	u8811
	goto	u8810
u8811:
	goto	l10048
u8810:
	
l10046:	
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	movlw	04h
	subwf	1+(??___CMS_Key_UNNOL_Check+0)+0,w
	movlw	0
	skipnz
	subwf	0+(??___CMS_Key_UNNOL_Check+0)+0,w
	skipnc
	goto	u8821
	goto	u8820
u8821:
	goto	l10052
u8820:
	
l10048:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Key_UNNOL_Check@F1016)^080h,f
	
l10050:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___CMS_Key_UNNOL_Check@1018)
	incf	(___CMS_Key_UNNOL_Check@1018),f
	
l10052:	
	movlw	low(02h)
	incf	(___CMS_Key_UNNOL_Check@1017),f
	subwf	((___CMS_Key_UNNOL_Check@1017)),w
	skipc
	goto	u8831
	goto	u8830
u8831:
	goto	l10034
u8830:
	
l10054:	
	movf	((___CMS_Key_UNNOL_Check@1018)),w
	btfss	status,2
	goto	u8841
	goto	u8840
u8841:
	goto	l10058
u8840:
	
l10056:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_Key_UNNOL_Check@F1016)^080h
	goto	l3545
	
l10058:	
	movlw	low(0C8h)
	bsf	status, 5	;RP0=1, select bank1
	subwf	(___CMS_Key_UNNOL_Check@F1016)^080h,w
	skipc
	goto	u8851
	goto	u8850
u8851:
	goto	l3545
u8850:
	
l10060:	
	clrf	(___CMS_Key_UNNOL_Check@F1016)^080h
	
l10062:	
	bcf	(_926/8),(_926)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_920)	;volatile
	clrf	(_921)	;volatile
	
l10064:	
	bcf	(_927/8),(_927)&7	;volatile
	clrf	(___CMS_Key_UNNOL_Check@1017)
	
l10070:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10072:	
	movlw	0
	movwf	(??___CMS_Key_UNNOL_Check+0)+0
	movlw	0Ch
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_Key_UNNOL_Check+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_Key_UNNOL_Check+0)+1,w
	movwf	indf
	
l10074:	
	movlw	0
	movwf	(??___CMS_Key_UNNOL_Check+0)+0
	movlw	0Ch
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_Key_UNNOL_Check+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_Key_UNNOL_Check+0)+1,w
	movwf	indf
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10076:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l10078:	
	incf	(___CMS_Key_UNNOL_Check@1017),f
	
l10080:	
	movlw	low(02h)
	subwf	(___CMS_Key_UNNOL_Check@1017),w
	skipc
	goto	u8861
	goto	u8860
u8861:
	goto	l10070
u8860:
	
l10082:	
	clrf	(_g_KeyFlag)	;volatile
	clrf	0+(_g_KeyFlag)+01h	;volatile
	
l3545:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text14
	
l3559:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_Key_UNNOL_Check
	__end_of___CMS_Key_UNNOL_Check:
	signat	___CMS_Key_UNNOL_Check,89
	global	___CMS_KeyStopClear

;; *************** function ___CMS_KeyStopClear *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  961             1    1[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       1       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___CMS_KeyClearOne
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=1
global __ptext15
__ptext15:	;psect for function ___CMS_KeyStopClear
psect	text15
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyStopClear
	__size_of___CMS_KeyStopClear	equ	__end_of___CMS_KeyStopClear-___CMS_KeyStopClear
	
___CMS_KeyStopClear:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_KeyStopClear: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	
l9686:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text15
	
l9688:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_g_KeyFlag)	;volatile
	clrf	0+(_g_KeyFlag)+01h	;volatile
	clrf	(___CMS_KeyStopClear@961)
	
l9694:	
	movf	(___CMS_KeyStopClear@961),w
	fcall	___CMS_KeyClearOne
	
l9696:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(___CMS_KeyStopClear@961),f
	
l9698:	
	movlw	low(02h)
	subwf	(___CMS_KeyStopClear@961),w
	skipc
	goto	u8251
	goto	u8250
u8251:
	goto	l9694
u8250:
	
l3439:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text15
	
l3440:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyStopClear
	__end_of___CMS_KeyStopClear:
	signat	___CMS_KeyStopClear,89
	global	___CMS_KeyClearOne

;; *************** function ___CMS_KeyClearOne *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;  958             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  958             1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          2       0       0       0
;;      Totals:         2       1       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_KeyStopClear
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=1
global __ptext16
__ptext16:	;psect for function ___CMS_KeyClearOne
psect	text16
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyClearOne
	__size_of___CMS_KeyClearOne	equ	__end_of___CMS_KeyClearOne-___CMS_KeyClearOne
	
___CMS_KeyClearOne:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_KeyClearOne: [wreg-fsr0h+status,2+status,0]
;___CMS_KeyClearOne@958 stored from wreg
	movwf	(___CMS_KeyClearOne@958)
	
l9196:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text16
	
l9198:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9200:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_KeyClearOne@958),w
	addlw	low(464|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l9202:	
	movf	(___CMS_KeyClearOne@958),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9204:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyClearOne@958),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	
l9206:	
	clrc
	rlf	(___CMS_KeyClearOne@958),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9208:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_KeyClearOne@958),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l9210:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_KeyClearOne@958),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l9212:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u7551
	goto	u7550
u7551:
	goto	l3434
u7550:
	
l9214:	
	movlw	0
	movwf	(??___CMS_KeyClearOne+0)+0
	movlw	0Ch
	movwf	(??___CMS_KeyClearOne+0)+0+1
	clrc
	rlf	(___CMS_KeyClearOne@958),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_KeyClearOne+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_KeyClearOne+0)+1,w
	movwf	indf
	movlw	0
	movwf	(??___CMS_KeyClearOne+0)+0
	movlw	0Ch
	movwf	(??___CMS_KeyClearOne+0)+0+1
	clrc
	rlf	(___CMS_KeyClearOne@958),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_KeyClearOne+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_KeyClearOne+0)+1,w
	movwf	indf
	
l3434:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text16
	
l3435:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyClearOne
	__end_of___CMS_KeyClearOne:
	signat	___CMS_KeyClearOne,4217
	global	___CMS_KeyDatIIR

;; *************** function ___CMS_KeyDatIIR *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1026            2    8[BANK0 ] unsigned short 
;;  1025            2    6[BANK0 ] unsigned short 
;;  1022            2    4[BANK0 ] unsigned short 
;;  1024            2    2[BANK0 ] unsigned short 
;;  1023            2    0[BANK0 ] unsigned short 
;;  1021            1   10[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0      11       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0      11       0       0
;;Total ram usage:       11 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=1
global __ptext17
__ptext17:	;psect for function ___CMS_KeyDatIIR
psect	text17
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyDatIIR
	__size_of___CMS_KeyDatIIR	equ	__end_of___CMS_KeyDatIIR-___CMS_KeyDatIIR
	
___CMS_KeyDatIIR:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_KeyDatIIR: [wreg-fsr0h+status,2+status,0]
	
l10084:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text17
	
l10086:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_KeyDatIIR@1021)
	
l10088:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10090:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1023)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1023+1)
	
l10092:	
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1024)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1024+1)
	
l10094:	
	movlw	low(08h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10096:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1022)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1022+1)
	
l10098:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10100:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u8871
	goto	u8870
u8871:
	goto	l10104
u8870:
	
l10102:	
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1025)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1025+1)
	goto	l10106
	
l10104:	
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1025)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1025+1)
	
l10106:	
	movf	((___CMS_KeyDatIIR@1022)),w
iorwf	((___CMS_KeyDatIIR@1022+1)),w
	btfsc	status,2
	goto	u8881
	goto	u8880
u8881:
	goto	l10130
u8880:
	
l10108:	
	movf	((___CMS_KeyDatIIR@1025)),w
iorwf	((___CMS_KeyDatIIR@1025+1)),w
	btfsc	status,2
	goto	u8891
	goto	u8890
u8891:
	goto	l10130
u8890:
	
l10110:	
	movf	(___CMS_KeyDatIIR@1025),w
	addwf	(___CMS_KeyDatIIR@1022),w
	movwf	(___CMS_KeyDatIIR@1026)
	movf	(___CMS_KeyDatIIR@1025+1),w
	skipnc
	incf	(___CMS_KeyDatIIR@1025+1),w
	addwf	(___CMS_KeyDatIIR@1022+1),w
	movwf	1+(___CMS_KeyDatIIR@1026)
	
l10112:	
	clrc
	rrf	(___CMS_KeyDatIIR@1026+1),f
	rrf	(___CMS_KeyDatIIR@1026),f
	movlw	low(08h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10114:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_KeyDatIIR@1026),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_KeyDatIIR@1026+1),w
	movwf	indf
	
l10116:	
	movf	(___CMS_KeyDatIIR@1025),w
	addwf	(___CMS_KeyDatIIR@1024),w
	movwf	(___CMS_KeyDatIIR@1026)
	movf	(___CMS_KeyDatIIR@1025+1),w
	skipnc
	incf	(___CMS_KeyDatIIR@1025+1),w
	addwf	(___CMS_KeyDatIIR@1024+1),w
	movwf	1+(___CMS_KeyDatIIR@1026)
	
l10118:	
	clrc
	rrf	(___CMS_KeyDatIIR@1026+1),f
	rrf	(___CMS_KeyDatIIR@1026),f
	
l10120:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10122:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_KeyDatIIR@1026),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_KeyDatIIR@1026+1),w
	movwf	indf
	
l10124:	
	movf	(___CMS_KeyDatIIR@1025),w
	addwf	(___CMS_KeyDatIIR@1023),w
	movwf	(___CMS_KeyDatIIR@1026)
	movf	(___CMS_KeyDatIIR@1025+1),w
	skipnc
	incf	(___CMS_KeyDatIIR@1025+1),w
	addwf	(___CMS_KeyDatIIR@1023+1),w
	movwf	1+(___CMS_KeyDatIIR@1026)
	clrc
	rrf	(___CMS_KeyDatIIR@1026+1),f
	rrf	(___CMS_KeyDatIIR@1026),f
	
l10126:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10128:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_KeyDatIIR@1026),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_KeyDatIIR@1026+1),w
	movwf	indf
	
l10130:	
	movlw	low(02h)
	incf	(___CMS_KeyDatIIR@1021),f
	subwf	((___CMS_KeyDatIIR@1021)),w
	skipc
	goto	u8901
	goto	u8900
u8901:
	goto	l10088
u8900:
	
l3562:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text17
	
l3568:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyDatIIR
	__end_of___CMS_KeyDatIIR:
	signat	___CMS_KeyDatIIR,89
	global	___CMS_CurAdjust

;; *************** function ___CMS_CurAdjust *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1047            2    4[BANK0 ] unsigned short 
;;  1045            1    3[BANK0 ] unsigned char 
;;  1046            1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       4       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0       6       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___CMS_CurAdjMode
;;		___CMS_CurJudge
;;		___CMS_KeyModeSet
;;		___CMS_KeyStart
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=1
global __ptext18
__ptext18:	;psect for function ___CMS_CurAdjust
psect	text18
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CurAdjust
	__size_of___CMS_CurAdjust	equ	__end_of___CMS_CurAdjust-___CMS_CurAdjust
	
___CMS_CurAdjust:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CurAdjust: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	
l10144:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text18
	
l10146:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_CurAdjust@1046)
	clrf	(___CMS_CurAdjust@1047)
	clrf	(___CMS_CurAdjust@1047+1)
	
l10148:	
	btfsc	(_927/8),(_927)&7	;volatile
	goto	u8931
	goto	u8930
u8931:
	goto	l10156
u8930:
	
l10150:	
	bsf	(_927/8),(_927)&7	;volatile
	
l10152:	
	fcall	___CMS_KeyModeSet
	
l10154:	
	fcall	___CMS_CurAdjMode
	goto	l3613
	
l10156:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10158:	
	btfsc	(402)^0180h,(7)&7	;volatile
	goto	u8941
	goto	u8940
u8941:
	goto	l10202
u8940:
	
l10160:	
	bcf	status, 6	;RP1=0, select bank1
	clrf	(___CMS_CurAdjust@F1044)^080h
	
l10162:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(414)^0180h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___CMS_CurAdjust@1047+1)
	clrf	(___CMS_CurAdjust@1047)
	
l10164:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(413)^0180h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	iorwf	(___CMS_CurAdjust@1047),f
	
l10166:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	btfss	(402)^0180h,(3)&7	;volatile
	goto	u8951
	goto	u8950
u8951:
	goto	l10176
u8950:
	
l10168:	
	movlw	08h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	subwf	(___CMS_CurAdjust@1047+1),w
	movlw	081h
	skipnz
	subwf	(___CMS_CurAdjust@1047),w
	skipnc
	goto	u8961
	goto	u8960
u8961:
	goto	l10194
u8960:
	
l10170:	
	movlw	07h
	subwf	(___CMS_CurAdjust@1047+1),w
	movlw	080h
	skipnz
	subwf	(___CMS_CurAdjust@1047),w
	skipc
	goto	u8971
	goto	u8970
u8971:
	goto	l10194
u8970:
	
l10172:	
	fcall	___CMS_CurJudge
	goto	l10194
	
l10176:	
	
l3619:	
	movlw	0Ch
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	subwf	(___CMS_CurAdjust@1047+1),w
	movlw	0
	skipnz
	subwf	(___CMS_CurAdjust@1047),w
	skipnc
	goto	u8981
	goto	u8980
u8981:
	goto	l10184
u8980:
	
l10178:	
	movlw	04h
	subwf	(___CMS_CurAdjust@1047+1),w
	movlw	01h
	skipnz
	subwf	(___CMS_CurAdjust@1047),w
	skipc
	goto	u8991
	goto	u8990
u8991:
	goto	l10184
u8990:
	
l10180:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
		incf	((406)^0180h),w	;volatile
	btfsc	status,2
	goto	u9001
	goto	u9000
u9001:
	goto	l10184
u9000:
	goto	l10172
	
l10184:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u9011
	goto	u9010
u9011:
	goto	l10190
u9010:
	
l10186:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	movlw	low(0Fh)
	andwf	(indf),w
	movwf	(??___CMS_CurAdjust+0)+0
	movlw	low(06h)
	subwf	0+(??___CMS_CurAdjust+0)+0,w
	skipc
	goto	u9021
	goto	u9020
u9021:
	goto	l10194
u9020:
	
l10188:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	movwf	indf
	goto	l10194
	
l10190:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(010h)
	bsf	status, 7	;select IRP bank3
	addwf	indf,f
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_CurAdjust+0)+0
	movlw	04h
u9035:
	clrc
	rrf	(??___CMS_CurAdjust+0)+0,f
	addlw	-1
	skipz
	goto	u9035
	movlw	low(0Fh)
	andwf	0+(??___CMS_CurAdjust+0)+0,w
	movwf	(??___CMS_CurAdjust+1)+0
	movlw	low(06h)
	subwf	0+(??___CMS_CurAdjust+1)+0,w
	skipc
	goto	u9041
	goto	u9040
u9041:
	goto	l10194
u9040:
	
l10192:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(0Fh)
	andwf	indf,f
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(050h)
	iorwf	indf,f
	
l10194:	
	fcall	___CMS_KeyModeSet
	
l10196:	
	btfsc	(_926/8),(_926)&7	;volatile
	goto	u9051
	goto	u9050
u9051:
	goto	l10200
u9050:
	goto	l10154
	
l10200:	
	fcall	___CMS_KeyStart
	goto	l3613
	
l10202:	
	movlw	low(0C8h)
	bcf	status, 6	;RP1=0, select bank1
	incf	(___CMS_CurAdjust@F1044)^080h,f
	subwf	((___CMS_CurAdjust@F1044)^080h),w
	skipc
	goto	u9061
	goto	u9060
u9061:
	goto	l3613
u9060:
	
l10204:	
	clrf	(___CMS_CurAdjust@F1044)^080h
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_921)	;volatile
	
l10206:	
	bcf	(_927/8),(_927)&7	;volatile
	clrf	(___CMS_CurAdjust@1045)
	
l10212:	
	movf	(___CMS_CurAdjust@1045),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l10214:	
	incf	(___CMS_CurAdjust@1045),f
	
l10216:	
	movlw	low(02h)
	subwf	(___CMS_CurAdjust@1045),w
	skipc
	goto	u9071
	goto	u9070
u9071:
	goto	l10212
u9070:
	
l3613:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text18
	
l3632:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CurAdjust
	__end_of___CMS_CurAdjust:
	signat	___CMS_CurAdjust,89
	global	___CMS_KeyStart

;; *************** function ___CMS_KeyStart *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1038            1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CurAdjust
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=1
global __ptext19
__ptext19:	;psect for function ___CMS_KeyStart
psect	text19
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyStart
	__size_of___CMS_KeyStart	equ	__end_of___CMS_KeyStart-___CMS_KeyStart
	
___CMS_KeyStart:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_KeyStart: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
	
l9286:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text19
	
l9288:	
	movlw	low(0C2h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(400)^0180h,f	;volatile
	movlw	low(0E0h)
	andwf	(401)^0180h,f	;volatile
	
l9290:	
	movf	(_919),w
	addlw	low(((_gc_Table_KeyChannel)|8000h))
	movwf	fsr0
	movlw	high(((_gc_Table_KeyChannel)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	andlw	01Fh
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(401)^0180h,f	;volatile
	
l9292:	
	movlw	low(010h)
	movwf	(415)^0180h	;volatile
	
l9294:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u7621
	goto	u7620
u7621:
	goto	l9306
u7620:
	
l9296:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_KeyStart@1038)
	
l9298:	
	movlw	low(0Fh)
	andwf	(___CMS_KeyStart@1038),f
	
l9300:	
	movlw	low(0F1h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(405)^0180h,f	;volatile
	
l9302:	
	movf	(___CMS_KeyStart@1038),w
	addlw	low(((_sc_CurStep_Table)|8000h))
	movwf	fsr0
	movlw	high(((_sc_CurStep_Table)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(405)^0180h,f	;volatile
	
l9304:	
	movf	(_919),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(406)^0180h	;volatile
	goto	l9316
	
l9306:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	swapf	indf,w
	andlw	(0ffh shr 4) & 0ffh
	movwf	(___CMS_KeyStart@1038)
	
l9308:	
	movlw	low(0Fh)
	andwf	(___CMS_KeyStart@1038),f
	
l9310:	
	movlw	low(0F1h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(405)^0180h,f	;volatile
	
l9312:	
	movf	(___CMS_KeyStart@1038),w
	addlw	low(((_sc_CurStep_Table)|8000h))
	movwf	fsr0
	movlw	high(((_sc_CurStep_Table)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(405)^0180h,f	;volatile
	
l9314:	
	movf	(_919),w
	addlw	low(432|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(406)^0180h	;volatile
	
l9316:	
	movf	(406)^0180h,w	;volatile
	movwf	(407)^0180h	;volatile
	
l9320:	
	bsf	(400)^0180h+(0/8),(0)&7	;volatile
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text19
	
l3599:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyStart
	__end_of___CMS_KeyStart:
	signat	___CMS_KeyStart,89
	global	___CMS_KeyModeSet

;; *************** function ___CMS_KeyModeSet *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1035            1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CurAdjust
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=1
global __ptext20
__ptext20:	;psect for function ___CMS_KeyModeSet
psect	text20
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyModeSet
	__size_of___CMS_KeyModeSet	equ	__end_of___CMS_KeyModeSet-___CMS_KeyModeSet
	
___CMS_KeyModeSet:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_KeyModeSet: [wreg+status,2+status,0]
	
l9260:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text20
	
l9262:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(400)^0180h	;volatile
	movlw	low(0E0h)
	movwf	(403)^0180h	;volatile
	
l9264:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_916),w	;volatile
	addlw	01h
	iorlw	0Ch
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(404)^0180h	;volatile
	
l9266:	
	movlw	low(030h)
	movwf	(405)^0180h	;volatile
	
l9268:	
	movlw	low(099h)
	movwf	(408)^0180h	;volatile
	
l9270:	
	movlw	low(040h)
	movwf	(401)^0180h	;volatile
	
l9272:	
	bsf	(401)^0180h+(5/8),(5)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfsc	status,2
	goto	u7601
	goto	u7600
u7601:
	goto	l9278
u7600:
	
l9274:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	incf	(403)^0180h,f
	incf	(403)^0180h,f	;volatile
	
l9276:	
	movlw	low(010h)
	addwf	(404)^0180h,f	;volatile
	goto	l3588
	
l9278:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	incf	(403)^0180h,f
	incf	(403)^0180h,f	;volatile
	
l9280:	
	movlw	010h
	subwf	(404)^0180h,f	;volatile
	
l9282:	
	bsf	(405)^0180h+(7/8),(7)&7	;volatile
	
l3588:	
	movlw	low(014h)
	movwf	(___CMS_KeyModeSet@1035)
	
l9284:	
	decf	(___CMS_KeyModeSet@1035),f
		incf	(((___CMS_KeyModeSet@1035))),w
	btfss	status,2
	goto	u7611
	goto	u7610
u7611:
	goto	l9284
u7610:
	
l3591:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text20
	
l3592:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyModeSet
	__end_of___CMS_KeyModeSet:
	signat	___CMS_KeyModeSet,89
	global	___CMS_CurJudge

;; *************** function ___CMS_CurJudge *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          2       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CurAdjust
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=1
global __ptext21
__ptext21:	;psect for function ___CMS_CurJudge
psect	text21
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CurJudge
	__size_of___CMS_CurJudge	equ	__end_of___CMS_CurJudge-___CMS_CurJudge
	
___CMS_CurJudge:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CurJudge: [wreg-fsr0h+status,2+status,0]
	
l9322:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text21
	
l9324:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9326:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u7631
	goto	u7630
u7631:
	goto	l9330
u7630:
	
l9328:	
	movf	(_919),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(406)^0180h,w	;volatile
	bsf	status, 7	;select IRP bank3
	movwf	indf
	goto	l9332
	
l9330:	
	movf	(_919),w
	addlw	low(432|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(406)^0180h,w	;volatile
	bsf	status, 7	;select IRP bank3
	movwf	indf
	
l9332:	
	movlw	low(04h)
	movwf	(415)^0180h	;volatile
	
l9334:	
	movlw	0
	movwf	(??___CMS_CurJudge+0)+0
	movlw	0Ch
	movwf	(??___CMS_CurJudge+0)+0+1
	clrc
	rlf	(_919),w	;volatile
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_CurJudge+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_CurJudge+0)+1,w
	movwf	indf
	
l9336:	
	movlw	0
	movwf	(??___CMS_CurJudge+0)+0
	movlw	0Ch
	movwf	(??___CMS_CurJudge+0)+0+1
	clrc
	rlf	(_919),w	;volatile
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_CurJudge+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_CurJudge+0)+1,w
	movwf	indf
	
l9338:	
	movlw	low(02h)
	incf	(_919),f	;volatile
	subwf	((_919)),w	;volatile
	skipc
	goto	u7641
	goto	u7640
u7641:
	goto	l3604
u7640:
	
l9340:	
	clrf	(_919)	;volatile
	
l9342:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u7651
	goto	u7650
u7651:
	goto	l3605
u7650:
	
l9344:	
	movlw	low(01h)
	movwf	(_921)	;volatile
	goto	l3604
	
l3605:	
	bcf	(13)+(6/8),(6)&7	;volatile
	bsf	(_926/8),(_926)&7	;volatile
	
l9346:	
	clrf	(_920)	;volatile
	clrf	(_921)	;volatile
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(402)^0180h	;volatile
	
l3604:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text21
	
l3607:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CurJudge
	__end_of___CMS_CurJudge:
	signat	___CMS_CurJudge,89
	global	___CMS_CurAdjMode

;; *************** function ___CMS_CurAdjMode *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1032            1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CurAdjust
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=1
global __ptext22
__ptext22:	;psect for function ___CMS_CurAdjMode
psect	text22
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CurAdjMode
	__size_of___CMS_CurAdjMode	equ	__end_of___CMS_CurAdjMode-___CMS_CurAdjMode
	
___CMS_CurAdjMode:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CurAdjMode: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
	
l9222:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text22
	
l9224:	
	
l9226:	
	movf	(_919),w
	addlw	low(((_gc_Table_KeyChannel)|8000h))
	movwf	fsr0
	movlw	high(((_gc_Table_KeyChannel)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	andlw	01Fh
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(401)^0180h,f	;volatile
	
l9228:	
	movlw	low(010h)
	movwf	(415)^0180h	;volatile
	
l9230:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u7571
	goto	u7570
u7571:
	goto	l9244
u7570:
	
l9232:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_CurAdjMode@1032)
	
l9234:	
	movlw	low(0Fh)
	andwf	(___CMS_CurAdjMode@1032),f
	
l9236:	
	movlw	low(06h)
	subwf	(___CMS_CurAdjMode@1032),w
	skipc
	goto	u7581
	goto	u7580
u7581:
	goto	l9240
u7580:
	
l9238:	
	movlw	low(05h)
	movwf	(___CMS_CurAdjMode@1032)
	
l9240:	
	movlw	low(0F1h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(405)^0180h,f	;volatile
	
l9242:	
	movf	(___CMS_CurAdjMode@1032),w
	addlw	low(((_sc_CurStep_Table)|8000h))
	movwf	fsr0
	movlw	high(((_sc_CurStep_Table)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(405)^0180h,f	;volatile
	goto	l9256
	
l9244:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	swapf	indf,w
	andlw	(0ffh shr 4) & 0ffh
	movwf	(___CMS_CurAdjMode@1032)
	
l9246:	
	movlw	low(0Fh)
	andwf	(___CMS_CurAdjMode@1032),f
	
l9248:	
	movlw	low(06h)
	subwf	(___CMS_CurAdjMode@1032),w
	skipc
	goto	u7591
	goto	u7590
u7591:
	goto	l9240
u7590:
	goto	l9238
	
l9256:	
	movlw	low(010h)
	movwf	(402)^0180h	;volatile
	
l9258:	
	bsf	(402)^0180h+(7/8),(7)&7	;volatile
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text22
	
l3584:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CurAdjMode
	__end_of___CMS_CurAdjMode:
	signat	___CMS_CurAdjMode,89
	global	___CMS_CheckValidTime

;; *************** function ___CMS_CheckValidTime *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=1
global __ptext23
__ptext23:	;psect for function ___CMS_CheckValidTime
psect	text23
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CheckValidTime
	__size_of___CMS_CheckValidTime	equ	__end_of___CMS_CheckValidTime-___CMS_CheckValidTime
	
___CMS_CheckValidTime:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_CheckValidTime: [wreg+status,2+status,0]
	
l10132:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text23
	
l10134:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	0+(_g_KeyFlag)+01h,w	;volatile
	iorwf	(_g_KeyFlag),w	;volatile
	btfsc	status,2
	goto	u8911
	goto	u8910
u8911:
	goto	l10140
u8910:
	
l10136:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_CheckValidTime@F1029)^080h,f
	skipnz
	incf	(___CMS_CheckValidTime@F1029+1)^080h,f
	movlw	013h
	subwf	((___CMS_CheckValidTime@F1029+1)^080h),w
	movlw	088h
	skipnz
	subwf	((___CMS_CheckValidTime@F1029)^080h),w
	skipc
	goto	u8921
	goto	u8920
u8921:
	goto	l3573
u8920:
	
l10138:	
	bsf	(_gf_kerr/8),(_gf_kerr)&7	;volatile
	
l10140:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_CheckValidTime@F1029)^080h
	clrf	(___CMS_CheckValidTime@F1029+1)^080h
	
l3573:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text23
	
l3577:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CheckValidTime
	__end_of___CMS_CheckValidTime:
	signat	___CMS_CheckValidTime,89
	global	___CMS_CheckOnceResult

;; *************** function ___CMS_CheckOnceResult *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  991             2   14[BANK0 ] unsigned short 
;;  990             2   12[BANK0 ] unsigned short 
;;  989             2    5[BANK0 ] unsigned short 
;;  979             1   20[BANK0 ] unsigned char 
;;  987             1   19[BANK0 ] unsigned char 
;;  988             1   18[BANK0 ] unsigned char 
;;  984             1   17[BANK0 ] unsigned char 
;;  983             1   16[BANK0 ] unsigned char 
;;  982             1   11[BANK0 ] unsigned char 
;;  986             1   10[BANK0 ] unsigned char 
;;  985             1    9[BANK0 ] unsigned char 
;;  981             1    8[BANK0 ] unsigned char 
;;  980             1    7[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0      16       0       0
;;      Temps:          0       5       0       0
;;      Totals:         0      21       0       0
;;Total ram usage:       21 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___CMS_KeyHaveDown
;;		___CMS_KeyIsIn
;;		___CMS_KeyOpen
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=1
global __ptext24
__ptext24:	;psect for function ___CMS_CheckOnceResult
psect	text24
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CheckOnceResult
	__size_of___CMS_CheckOnceResult	equ	__end_of___CMS_CheckOnceResult-___CMS_CheckOnceResult
	
___CMS_CheckOnceResult:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CheckOnceResult: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	
l9782:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text24
	
l9784:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_CheckOnceResult@979)
	
l9786:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u8421
	goto	u8420
u8421:
	goto	l9790
u8420:
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	112
	
l9788:	
	movlw	low(03h)
	movwf	(___CMS_CheckOnceResult@987)
	line	1
	goto	l3479
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9790:	
	movlw	low(04h)
	movwf	(___CMS_CheckOnceResult@987)
	
l3479:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9792:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u8431
	goto	u8430
u8431:
	goto	l9796
u8430:
	
l9794:	
	clrc
	rlf	(___CMS_CheckOnceResult@979),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@991)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@991+1)
	goto	l9798
	
l9796:	
	clrc
	rlf	(___CMS_CheckOnceResult@979),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@991)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@991+1)
	
l9798:	
	clrc
	rlf	(___CMS_CheckOnceResult@979),w
	addlw	low(((_gc_Table_KeyDown)|8000h))
	movwf	fsr0
	movlw	high(((_gc_Table_KeyDown)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(___CMS_CheckOnceResult@989)
	fcall	stringtab
	movwf	(___CMS_CheckOnceResult@989+1)
	
l9800:	
	movf	((___CMS_CheckOnceResult@991)),w
iorwf	((___CMS_CheckOnceResult@991+1)),w
	btfsc	status,2
	goto	u8441
	goto	u8440
u8441:
	goto	l9910
u8440:
	
l9802:	
	movlw	0Ch
	subwf	(___CMS_CheckOnceResult@991+1),w
	movlw	0
	skipnz
	subwf	(___CMS_CheckOnceResult@991),w
	skipnc
	goto	u8451
	goto	u8450
u8451:
	goto	l9910
u8450:
	
l9804:	
	movf	(___CMS_CheckOnceResult@979),w
	andlw	07h
	addlw	low(((_sc_Table_KeyFalg)|8000h))
	movwf	fsr0
	movlw	high(((_sc_Table_KeyFalg)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(___CMS_CheckOnceResult@988)
	
l9806:	
	movf	(___CMS_CheckOnceResult@989),w
	addwf	(___CMS_CheckOnceResult@991),w
	movwf	(___CMS_CheckOnceResult@990)
	movf	(___CMS_CheckOnceResult@989+1),w
	skipnc
	incf	(___CMS_CheckOnceResult@989+1),w
	addwf	(___CMS_CheckOnceResult@991+1),w
	movwf	1+(___CMS_CheckOnceResult@990)
	
l9808:	
	clrf	(___CMS_CheckOnceResult@980)
	
l9810:	
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyIsIn
	xorlw	0
	skipnz
	goto	u8461
	goto	u8460
u8461:
	goto	l9816
u8460:
	
l9812:	
	clrf	(___CMS_CheckOnceResult@980)
	incf	(___CMS_CheckOnceResult@980),f
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	115
	
l9814:	
	movf	(___CMS_CheckOnceResult@990),w
	addlw	low(0FFE7h)
	movwf	(___CMS_CheckOnceResult@990)
	movf	(___CMS_CheckOnceResult@990+1),w
	skipnc
	addlw	1
	addlw	high(0FFE7h)
	movwf	1+(___CMS_CheckOnceResult@990)
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9816:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9818:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrc
	rlf	indf,f
	
l9820:	
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(464|((0x1)<<8))&0ffh
	movwf	fsr0
	clrc
	rlf	indf,f
	
l9822:	
	movlw	low(08h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9824:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckOnceResult@979),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_CheckOnceResult+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_CheckOnceResult+0)+0+1
	movf	(___CMS_CheckOnceResult@990+1),w
	subwf	1+(??___CMS_CheckOnceResult+0)+0,w
	skipz
	goto	u8475
	movf	(___CMS_CheckOnceResult@990),w
	subwf	0+(??___CMS_CheckOnceResult+0)+0,w
u8475:
	skipc
	goto	u8471
	goto	u8470
u8471:
	goto	l9832
u8470:
	
l9826:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9828:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	indf+(0/8),(0)&7
	
l9830:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(464|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	indf+(0/8),(0)&7
	goto	l9840
	
l9832:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9834:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckOnceResult@979),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_CheckOnceResult+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_CheckOnceResult+0)+0+1
	movf	(___CMS_CheckOnceResult@990+1),w
	subwf	1+(??___CMS_CheckOnceResult+0)+0,w
	skipz
	goto	u8485
	movf	(___CMS_CheckOnceResult@990),w
	subwf	0+(??___CMS_CheckOnceResult+0)+0,w
u8485:
	skipc
	goto	u8481
	goto	u8480
u8481:
	goto	l9840
u8480:
	
l9836:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	goto	l9830
	
l9840:	
	clrf	(___CMS_CheckOnceResult@983)
	
l9842:	
	clrf	(___CMS_CheckOnceResult@984)
	
l9844:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(464|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@985)
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@986)
	
l9846:	
	clrf	(___CMS_CheckOnceResult@981)
	goto	l9858
	
l3488:	
	btfss	(___CMS_CheckOnceResult@985),(0)&7
	goto	u8491
	goto	u8490
u8491:
	goto	l9850
u8490:
	
l9848:	
	incf	(___CMS_CheckOnceResult@983),f
	
l9850:	
	clrc
	rrf	(___CMS_CheckOnceResult@985),f
	
l9852:	
	btfss	(___CMS_CheckOnceResult@986),(0)&7
	goto	u8501
	goto	u8500
u8501:
	goto	l9856
u8500:
	
l9854:	
	incf	(___CMS_CheckOnceResult@984),f
	
l9856:	
	clrc
	rrf	(___CMS_CheckOnceResult@986),f
	incf	(___CMS_CheckOnceResult@981),f
	
l9858:	
	clrc
	rlf	(___CMS_CheckOnceResult@987),w
	subwf	(___CMS_CheckOnceResult@981),w
	skipc
	goto	u8511
	goto	u8510
u8511:
	goto	l3488
u8510:
	
l9860:	
	clrf	(___CMS_CheckOnceResult@982)
	
l9862:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9864:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckOnceResult@987),w
	subwf	(___CMS_CheckOnceResult@984),w
	skipc
	goto	u8521
	goto	u8520
u8521:
	goto	l3492
u8520:
	
l9866:	
	movf	(___CMS_CheckOnceResult@988),w
	movwf	(___CMS_KeyHaveDown@956)
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyHaveDown
	
l9868:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_CheckOnceResult@982)
	incf	(___CMS_CheckOnceResult@982),f
	
l9870:	
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l9888
	
l3492:	
	btfss	(_925/8),(_925)&7	;volatile
	goto	u8531
	goto	u8530
u8531:
	goto	l9888
u8530:
	
l9872:	
	clrc
	rlf	(___CMS_CheckOnceResult@987),w
	subwf	(___CMS_CheckOnceResult@983),w
	skipc
	goto	u8541
	goto	u8540
u8541:
	goto	l9880
u8540:
	
l9874:	
	movf	(___CMS_CheckOnceResult@988),w
	movwf	(___CMS_KeyHaveDown@956)
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyHaveDown
	goto	l9868
	
l9880:	
	movf	(___CMS_CheckOnceResult@987),w
	movwf	(??___CMS_CheckOnceResult+0)+0
	clrc
	rlf	(??___CMS_CheckOnceResult+0)+0,f
	movlw	low(01h)
	addwf	0+(??___CMS_CheckOnceResult+0)+0,w
	movwf	(??___CMS_CheckOnceResult+1)+0
	movf	(___CMS_CheckOnceResult@984),w
	addwf	(___CMS_CheckOnceResult@983),w
	movwf	(??___CMS_CheckOnceResult+2)+0
	clrf	(??___CMS_CheckOnceResult+2)+0+1
	rlf	1+(??___CMS_CheckOnceResult+2)+0,f
	
	movf	1+(??___CMS_CheckOnceResult+2)+0,w
	xorlw	80h
	movwf	(??___CMS_CheckOnceResult+4)+0
	movlw	80h
	subwf	(??___CMS_CheckOnceResult+4)+0,w
	skipz
	goto	u8555
	movf	0+(??___CMS_CheckOnceResult+1)+0,w
	subwf	0+(??___CMS_CheckOnceResult+2)+0,w
u8555:

	skipc
	goto	u8551
	goto	u8550
u8551:
	goto	l3494
u8550:
	
l9882:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@988),w
	movwf	(___CMS_KeyHaveDown@956)
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyHaveDown
	goto	l9868
	
l3494:	
	
l9888:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((___CMS_CheckOnceResult@982)),w
	btfss	status,2
	goto	u8561
	goto	u8560
u8561:
	goto	l9910
u8560:
	
l9890:	
	movf	((___CMS_CheckOnceResult@980)),w
	btfsc	status,2
	goto	u8571
	goto	u8570
u8571:
	goto	l9910
u8570:
	
l9892:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9894:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u8581
	goto	u8580
u8581:
	goto	l9900
u8580:
	
l9896:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckOnceResult@987),w
	addlw	0FFh
	subwf	(___CMS_CheckOnceResult@984),w
	skipnc
	goto	u8591
	goto	u8590
u8591:
	goto	l3502
u8590:
	
l9898:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	goto	l3502
	
l9900:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@987),w
	movwf	(??___CMS_CheckOnceResult+0)+0
	clrc
	rlf	(??___CMS_CheckOnceResult+0)+0,f
	movlw	low(0FFh)
	addwf	0+(??___CMS_CheckOnceResult+0)+0,w
	movwf	(??___CMS_CheckOnceResult+1)+0
	movf	(___CMS_CheckOnceResult@984),w
	addwf	(___CMS_CheckOnceResult@983),w
	movwf	(??___CMS_CheckOnceResult+2)+0
	clrf	(??___CMS_CheckOnceResult+2)+0+1
	rlf	1+(??___CMS_CheckOnceResult+2)+0,f
	
	movf	1+(??___CMS_CheckOnceResult+2)+0,w
	xorlw	80h
	movwf	(??___CMS_CheckOnceResult+4)+0
	movlw	80h
	subwf	(??___CMS_CheckOnceResult+4)+0,w
	skipz
	goto	u8605
	movf	0+(??___CMS_CheckOnceResult+1)+0,w
	subwf	0+(??___CMS_CheckOnceResult+2)+0,w
u8605:

	skipnc
	goto	u8601
	goto	u8600
u8601:
	goto	l3502
u8600:
	goto	l9898
	
l3502:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrc
	rlf	(___CMS_CheckOnceResult@987),w
	addlw	0FFh
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u8611
	goto	u8610
u8611:
	goto	l9908
u8610:
	
l9904:	
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l9906:	
	movf	(___CMS_CheckOnceResult@988),w
	movwf	(___CMS_KeyOpen@952)
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyOpen
	goto	l9910
	
l9908:	
	movf	(___CMS_CheckOnceResult@988),w
	movwf	(___CMS_KeyHaveDown@956)
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyHaveDown
	
l9910:	
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(___CMS_CheckOnceResult@979),f
	subwf	((___CMS_CheckOnceResult@979)),w
	skipc
	goto	u8621
	goto	u8620
u8621:
	goto	l3479
u8620:
	
l3506:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text24
	
l3507:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CheckOnceResult
	__end_of___CMS_CheckOnceResult:
	signat	___CMS_CheckOnceResult,89
	global	___CMS_KeyOpen

;; *************** function ___CMS_KeyOpen *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;  951             1    wreg     unsigned char 
;;  952             1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  951             1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckOnceResult
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=1
global __ptext25
__ptext25:	;psect for function ___CMS_KeyOpen
psect	text25
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyOpen
	__size_of___CMS_KeyOpen	equ	__end_of___CMS_KeyOpen-___CMS_KeyOpen
	
___CMS_KeyOpen:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_KeyOpen: [wreg+status,2+status,0]
;___CMS_KeyOpen@951 stored from wreg
	movwf	(___CMS_KeyOpen@951)
	
l9176:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text25
	
l9178:	
	movlw	low(0FFh)
	xorwf	(___CMS_KeyOpen@952),f
	
l9180:	
	btfss	(___CMS_KeyOpen@951),(3)&7
	goto	u7531
	goto	u7530
u7531:
	goto	l9184
u7530:
	
l9182:	
	movf	(___CMS_KeyOpen@952),w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	andwf	0+(_g_KeyFlag)+01h,f	;volatile
	goto	l3425
	
l9184:	
	movf	(___CMS_KeyOpen@952),w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	andwf	(_g_KeyFlag),f	;volatile
	
l3425:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text25
	
l3426:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyOpen
	__end_of___CMS_KeyOpen:
	signat	___CMS_KeyOpen,8313
	global	___CMS_KeyHaveDown

;; *************** function ___CMS_KeyHaveDown *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;  955             1    wreg     unsigned char 
;;  956             1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  955             1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckOnceResult
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=1
global __ptext26
__ptext26:	;psect for function ___CMS_KeyHaveDown
psect	text26
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyHaveDown
	__size_of___CMS_KeyHaveDown	equ	__end_of___CMS_KeyHaveDown-___CMS_KeyHaveDown
	
___CMS_KeyHaveDown:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_KeyHaveDown: [wreg+status,2+status,0]
;___CMS_KeyHaveDown@955 stored from wreg
	movwf	(___CMS_KeyHaveDown@955)
	
l9186:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text26
	
l9188:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_917),f	;volatile
	
l9190:	
	btfss	(___CMS_KeyHaveDown@955),(3)&7
	goto	u7541
	goto	u7540
u7541:
	goto	l9194
u7540:
	
l9192:	
	movf	(___CMS_KeyHaveDown@956),w
	iorwf	0+(_g_KeyFlag)+01h,f	;volatile
	goto	l3430
	
l9194:	
	movf	(___CMS_KeyHaveDown@956),w
	iorwf	(_g_KeyFlag),f	;volatile
	
l3430:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text26
	
l3431:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyHaveDown
	__end_of___CMS_KeyHaveDown:
	signat	___CMS_KeyHaveDown,8313
	global	___CMS_CheckKeyOldValue

;; *************** function ___CMS_CheckKeyOldValue *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1009            2   11[BANK0 ] unsigned short 
;;  1008            2    9[BANK0 ] unsigned short 
;;  1007            2    7[BANK0 ] unsigned short 
;;  1006            2    4[BANK0 ] unsigned short 
;;  1003            1   14[BANK0 ] unsigned char 
;;  1005            1   13[BANK0 ] unsigned char 
;;  1004            1    6[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0      11       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0      13       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___CMS_KeyIsIn
;;		_abs
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=1
global __ptext27
__ptext27:	;psect for function ___CMS_CheckKeyOldValue
psect	text27
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CheckKeyOldValue
	__size_of___CMS_CheckKeyOldValue	equ	__end_of___CMS_CheckKeyOldValue-___CMS_CheckKeyOldValue
	
___CMS_CheckKeyOldValue:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CheckKeyOldValue: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	
l9912:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text27
	
l9914:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_CheckKeyOldValue@1003)
	
l9916:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u8631
	goto	u8630
u8631:
	goto	l9922
u8630:
	
l9918:	
	movlw	low(08h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9920:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1009)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1009+1)
	goto	l9926
	
l9922:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9924:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1009)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1009+1)
	
l9926:	
	movf	((_921)),w	;volatile
	btfsc	status,2
	goto	u8641
	goto	u8640
u8641:
	goto	l9974
u8640:
	
l9928:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9930:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1007)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1007+1)
	
l9932:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1008)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1008+1)
	
l9934:	
	movf	(___CMS_CheckKeyOldValue@1007+1),w
	movwf	(abs@a+1)
	movf	(___CMS_CheckKeyOldValue@1007),w
	movwf	(abs@a)
	movf	(___CMS_CheckKeyOldValue@1009),w
	subwf	(abs@a),f
	movf	(___CMS_CheckKeyOldValue@1009+1),w
	skipc
	decf	(abs@a+1),f
	subwf	(abs@a+1),f
	fcall	_abs
	movf	(1+(?_abs)),w
	movwf	(___CMS_CheckKeyOldValue@1006+1)
	movf	(0+(?_abs)),w
	movwf	(___CMS_CheckKeyOldValue@1006)
	
l9936:	
	movlw	0Ch
	subwf	(___CMS_CheckKeyOldValue@1008+1),w
	movlw	0
	skipnz
	subwf	(___CMS_CheckKeyOldValue@1008),w
	skipnc
	goto	u8651
	goto	u8650
u8651:
	goto	l9940
u8650:
	
l9938:	
	movf	((___CMS_CheckKeyOldValue@1008)),w
iorwf	((___CMS_CheckKeyOldValue@1008+1)),w
	btfss	status,2
	goto	u8661
	goto	u8660
u8661:
	goto	l9946
u8660:
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
	
l9940:	
	movlw	low(04Bh)
	movwf	(___CMS_CheckKeyOldValue@1004)
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9942:	
	
l9944:	
	movlw	low(06h)
	movwf	(___CMS_CheckKeyOldValue@1005)
	goto	l3518
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
	
l9946:	
	movlw	low(032h)
	movwf	(___CMS_CheckKeyOldValue@1004)
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9948:	
	btfss	(_925/8),(_925)&7	;volatile
	goto	u8671
	goto	u8670
u8671:
	goto	l9944
u8670:
	
l9950:	
	movlw	low(0Ch)
	movwf	(___CMS_CheckKeyOldValue@1005)
	
l3518:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9954:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_CheckKeyOldValue@1009),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_CheckKeyOldValue@1009+1),w
	movwf	indf
	
l9956:	
	movf	(___CMS_CheckKeyOldValue@1003),w
	fcall	___CMS_KeyIsIn
	xorlw	0
	skipz
	goto	u8681
	goto	u8680
u8681:
	goto	l9970
u8680:
	
l9958:	
	movf	(___CMS_CheckKeyOldValue@1004),w
	movwf	(??___CMS_CheckKeyOldValue+0)+0
	clrf	(??___CMS_CheckKeyOldValue+0)+0+1
	movf	(___CMS_CheckKeyOldValue@1006+1),w
	subwf	1+(??___CMS_CheckKeyOldValue+0)+0,w
	skipz
	goto	u8695
	movf	(___CMS_CheckKeyOldValue@1006),w
	subwf	0+(??___CMS_CheckKeyOldValue+0)+0,w
u8695:
	skipc
	goto	u8691
	goto	u8690
u8691:
	goto	l9970
u8690:
	
l9960:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9962:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	movf	(___CMS_CheckKeyOldValue@1005),w
	subwf	(indf),w
	skipc
	goto	u8701
	goto	u8700
u8701:
	goto	l10026
u8700:
	
l9964:	
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l9966:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9968:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_CheckKeyOldValue@1007),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_CheckKeyOldValue@1007+1),w
	movwf	indf
	goto	l10026
	
l9970:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9972:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l10026
	
l9974:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9976:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1007)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1007+1)
	
l9978:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1008)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1008+1)
	
l9980:	
	movf	(___CMS_CheckKeyOldValue@1007+1),w
	movwf	(abs@a+1)
	movf	(___CMS_CheckKeyOldValue@1007),w
	movwf	(abs@a)
	movf	(___CMS_CheckKeyOldValue@1009),w
	subwf	(abs@a),f
	movf	(___CMS_CheckKeyOldValue@1009+1),w
	skipc
	decf	(abs@a+1),f
	subwf	(abs@a+1),f
	fcall	_abs
	movf	(1+(?_abs)),w
	movwf	(___CMS_CheckKeyOldValue@1006+1)
	movf	(0+(?_abs)),w
	movwf	(___CMS_CheckKeyOldValue@1006)
	
l9982:	
	movlw	0Ch
	subwf	(___CMS_CheckKeyOldValue@1008+1),w
	movlw	0
	skipnz
	subwf	(___CMS_CheckKeyOldValue@1008),w
	skipnc
	goto	u8711
	goto	u8710
u8711:
	goto	l9986
u8710:
	
l9984:	
	movf	((___CMS_CheckKeyOldValue@1008)),w
iorwf	((___CMS_CheckKeyOldValue@1008+1)),w
	btfss	status,2
	goto	u8721
	goto	u8720
u8721:
	goto	l9996
u8720:
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
	
l9986:	
	movlw	low(064h)
	movwf	(___CMS_CheckKeyOldValue@1004)
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9988:	
	
l9990:	
	movlw	low(04h)
	movwf	(___CMS_CheckKeyOldValue@1005)
	goto	l3532
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
	
l9996:	
	movlw	low(04Bh)
	movwf	(___CMS_CheckKeyOldValue@1004)
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9998:	
	btfss	(_925/8),(_925)&7	;volatile
	goto	u8731
	goto	u8730
u8731:
	goto	l10002
u8730:
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	116
	
l10000:	
	movlw	low(06h)
	movwf	(___CMS_CheckKeyOldValue@1005)
	line	1
	goto	l3532
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l10002:	
	goto	l9990
	
l3532:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10006:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_CheckKeyOldValue@1009),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_CheckKeyOldValue@1009+1),w
	movwf	indf
	
l10008:	
	movf	(___CMS_CheckKeyOldValue@1003),w
	fcall	___CMS_KeyIsIn
	xorlw	0
	skipz
	goto	u8741
	goto	u8740
u8741:
	goto	l10022
u8740:
	
l10010:	
	movf	(___CMS_CheckKeyOldValue@1004),w
	movwf	(??___CMS_CheckKeyOldValue+0)+0
	clrf	(??___CMS_CheckKeyOldValue+0)+0+1
	movf	(___CMS_CheckKeyOldValue@1006+1),w
	subwf	1+(??___CMS_CheckKeyOldValue+0)+0,w
	skipz
	goto	u8755
	movf	(___CMS_CheckKeyOldValue@1006),w
	subwf	0+(??___CMS_CheckKeyOldValue+0)+0,w
u8755:
	skipc
	goto	u8751
	goto	u8750
u8751:
	goto	l10022
u8750:
	
l10012:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10014:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	movf	(___CMS_CheckKeyOldValue@1005),w
	subwf	(indf),w
	skipc
	goto	u8761
	goto	u8760
u8761:
	goto	l10026
u8760:
	
l10016:	
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l10018:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10020:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_CheckKeyOldValue@1007),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_CheckKeyOldValue@1007+1),w
	movwf	indf
	goto	l10026
	
l10022:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10024:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l10026:	
	movlw	low(02h)
	incf	(___CMS_CheckKeyOldValue@1003),f
	subwf	((___CMS_CheckKeyOldValue@1003)),w
	skipc
	goto	u8771
	goto	u8770
u8771:
	goto	l9916
u8770:
	
l3539:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text27
	
l3540:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CheckKeyOldValue
	__end_of___CMS_CheckKeyOldValue:
	signat	___CMS_CheckKeyOldValue,89
	global	_abs

;; *************** function _abs *****************
;; Defined at:
;;		line 4 in file "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\abs.c"
;; Parameters:    Size  Location     Type
;;  a               2    4[COMMON] int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  2    4[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       2       0       0
;;      Totals:         2       2       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckKeyOldValue
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=2
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\abs.c"
	line	4
global __ptext28
__ptext28:	;psect for function _abs
psect	text28
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\abs.c"
	line	4
	global	__size_of_abs
	__size_of_abs	equ	__end_of_abs-_abs
	
_abs:	
;incstack = 0
	opt	stack 5
; Regs used in _abs: [wreg+status,2+status,0]
	line	6
	
l9216:	
	btfss	(abs@a+1),7
	goto	u7561
	goto	u7560
u7561:
	goto	l3751
u7560:
	line	7
	
l9218:	
	comf	(abs@a),w
	movwf	(??_abs+0)+0
	comf	(abs@a+1),w
	movwf	((??_abs+0)+0+1)
	incf	(??_abs+0)+0,f
	skipnz
	incf	((??_abs+0)+0+1),f
	movf	0+(??_abs+0)+0,w
	movwf	(?_abs)
	movf	1+(??_abs+0)+0,w
	movwf	(?_abs+1)
	goto	l3752
	
l3751:	
	line	8
	line	9
	
l3752:	
	return
	opt stack 0
GLOBAL	__end_of_abs
	__end_of_abs:
	signat	_abs,4218
	global	___CMS_KeyIsIn

;; *************** function ___CMS_KeyIsIn *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;  946             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  946             1    5[COMMON] unsigned char 
;;  947             1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         2       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckOnceResult
;;		___CMS_CheckKeyOldValue
;; This function uses a non-reentrant model
;;
psect	text29,local,class=CODE,delta=2,merge=1,group=1
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
global __ptext29
__ptext29:	;psect for function ___CMS_KeyIsIn
psect	text29
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyIsIn
	__size_of___CMS_KeyIsIn	equ	__end_of___CMS_KeyIsIn-___CMS_KeyIsIn
	
___CMS_KeyIsIn:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_KeyIsIn: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
;___CMS_KeyIsIn@946 stored from wreg
	movwf	(___CMS_KeyIsIn@946)
	
l9160:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text29
	
l9162:	
	movf	(___CMS_KeyIsIn@946),w
	andlw	07h
	addlw	low(((_sc_Table_KeyFalg)|8000h))
	movwf	fsr0
	movlw	high(((_sc_Table_KeyFalg)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	movwf	(___CMS_KeyIsIn@947)
	
l9164:	
	btfss	(___CMS_KeyIsIn@946),(3)&7
	goto	u7521
	goto	u7520
u7521:
	goto	l9168
u7520:
	
l9166:	
	movf	0+(_g_KeyFlag)+01h,w	;volatile
	andwf	(___CMS_KeyIsIn@947),f
	goto	l9170
	
l9168:	
	movf	(_g_KeyFlag),w	;volatile
	andwf	(___CMS_KeyIsIn@947),f
	
l9170:	
	movf	(___CMS_KeyIsIn@947),w
	
l3421:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyIsIn
	__end_of___CMS_KeyIsIn:
	signat	___CMS_KeyIsIn,4217
	global	_Tx_Display

;; *************** function _Tx_Display *****************
;; Defined at:
;;		line 2198 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               2    2[BANK0 ] unsigned int 
;;  Temp1           1    1[BANK0 ] unsigned char 
;;  Sum_Tot         1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       4       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text30,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	2198
global __ptext30
__ptext30:	;psect for function _Tx_Display
psect	text30
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	2198
	global	__size_of_Tx_Display
	__size_of_Tx_Display	equ	__end_of_Tx_Display-_Tx_Display
	
_Tx_Display:	
;incstack = 0
	opt	stack 7
; Regs used in _Tx_Display: [wreg-fsr0h+status,2+status,0]
	line	2201
	
l10860:	
;main.c: 2200: unsigned int i;
;main.c: 2201: U8_T Sum_Tot=0;
	clrf	(Tx_Display@Sum_Tot)
	line	2202
;main.c: 2202: U8_T Temp1=0;
	clrf	(Tx_Display@Temp1)
	line	2204
	
l10862:	
;main.c: 2204: if((FilterROState==3)||(FilterPCFState==3))
		movlw	3
	xorwf	((_FilterROState)),w
	btfsc	status,2
	goto	u10181
	goto	u10180
u10181:
	goto	l10866
u10180:
	
l10864:	
		movlw	3
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u10191
	goto	u10190
u10191:
	goto	l10868
u10190:
	line	2206
	
l10866:	
;main.c: 2205: {
;main.c: 2206: Temp1=0x03;
	movlw	low(03h)
	movwf	(Tx_Display@Temp1)
	line	2207
;main.c: 2207: }
	goto	l10880
	line	2208
	
l10868:	
;main.c: 2208: else if((FilterROState==2)||(FilterPCFState==2))
		movlw	2
	xorwf	((_FilterROState)),w
	btfsc	status,2
	goto	u10201
	goto	u10200
u10201:
	goto	l10872
u10200:
	
l10870:	
		movlw	2
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u10211
	goto	u10210
u10211:
	goto	l10874
u10210:
	line	2210
	
l10872:	
;main.c: 2209: {
;main.c: 2210: Temp1=0x07;
	movlw	low(07h)
	movwf	(Tx_Display@Temp1)
	line	2211
;main.c: 2211: }
	goto	l10880
	line	2212
	
l10874:	
;main.c: 2212: else if((FilterROState==1)&&(FilterPCFState==1)){
		decf	((_FilterROState)),w
	btfss	status,2
	goto	u10221
	goto	u10220
u10221:
	goto	l10880
u10220:
	
l10876:	
		decf	((_FilterPCFState)),w
	btfss	status,2
	goto	u10231
	goto	u10230
u10231:
	goto	l10880
u10230:
	line	2213
	
l10878:	
;main.c: 2213: Temp1=0x01;
	clrf	(Tx_Display@Temp1)
	incf	(Tx_Display@Temp1),f
	line	2216
	
l10880:	
;main.c: 2214: }
;main.c: 2216: Tx_Type.TxType.Tx_FilterLed=Temp1;
	movf	(Tx_Display@Temp1),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	0+(_Tx_Type)^0100h+03h
	line	2220
	
l10882:	
;main.c: 2220: if(!_BITS1.Bits.bit_7){
	bcf	status, 6	;RP1=0, select bank0
	btfsc	(__BITS1),7
	goto	u10241
	goto	u10240
u10241:
	goto	l10886
u10240:
	line	2223
	
l10884:	
;main.c: 2223: Tx_Type.TxType.Tx_TdsData_1=0x03;
	movlw	low(03h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	0+(_Tx_Type)^0100h+06h
	line	2224
;main.c: 2224: Tx_Type.TxType.Tx_TdsData_2=0xE7;
	movlw	low(0E7h)
	movwf	0+(_Tx_Type)^0100h+07h
	line	2225
;main.c: 2225: }
	goto	l10888
	line	2228
	
l10886:	
;main.c: 2226: else
;main.c: 2227: {
;main.c: 2228: Tx_Type.TxType.Tx_TdsData_1=PureTDSTyp.TdsData>>8;
	bsf	status, 6	;RP1=1, select bank2
	movf	1+(_PureTDSTyp)^0100h+0Fh,w
	movwf	0+(_Tx_Type)^0100h+06h
	line	2229
;main.c: 2229: Tx_Type.TxType.Tx_TdsData_2=PureTDSTyp.TdsData;
	movf	0+(_PureTDSTyp)^0100h+0Fh,w
	movwf	0+(_Tx_Type)^0100h+07h
	line	2231
	
l10888:	
;main.c: 2230: }
;main.c: 2231: Tx_Type.TxType.Tx_TdsLed=1;
	clrf	0+(_Tx_Type)^0100h+05h
	incf	0+(_Tx_Type)^0100h+05h,f
	line	2232
	
l10890:	
;main.c: 2232: if(_BITS.Bits.bit_5==0x00){
	btfsc	(__BITS),5
	goto	u10251
	goto	u10250
u10251:
	goto	l1447
u10250:
	line	2234
	
l10892:	
;main.c: 2234: Tx_Type.TxType.Tx_TdsLed=0;
	clrf	0+(_Tx_Type)^0100h+05h
	line	2235
	
l10894:	
;main.c: 2235: Tx_Type.TxType.Tx_TdsData_1=0xff;
	movlw	low(0FFh)
	movwf	0+(_Tx_Type)^0100h+06h
	line	2236
	
l10896:	
;main.c: 2236: Tx_Type.TxType.Tx_TdsData_2=0x00;
	clrf	0+(_Tx_Type)^0100h+07h
	line	2238
	
l1447:	
	line	2244
;main.c: 2238: }
;main.c: 2244: Tx_Type.TxType.Tx_ErrorState=ErrorVar;
	bcf	status, 6	;RP1=0, select bank0
	movf	(_ErrorVar),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	0+(_Tx_Type)^0100h+09h
	line	2245
	
l10898:	
;main.c: 2245: if(ErrorVar==0x02){
		movlw	2
	bcf	status, 6	;RP1=0, select bank0
	xorwf	((_ErrorVar)),w
	btfss	status,2
	goto	u10261
	goto	u10260
u10261:
	goto	l10902
u10260:
	line	2246
	
l10900:	
;main.c: 2246: Tx_Type.TxType.Tx_ErrorLed=0x07;
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	0+(_Tx_Type)^0100h+08h
	line	2247
;main.c: 2247: }
	goto	l10904
	line	2250
	
l10902:	
;main.c: 2248: else
;main.c: 2249: {
;main.c: 2250: Tx_Type.TxType.Tx_ErrorLed=0x00;
	bsf	status, 6	;RP1=1, select bank2
	clrf	0+(_Tx_Type)^0100h+08h
	line	2252
	
l10904:	
;main.c: 2251: }
;main.c: 2252: Tx_Type.TxType.Tx_Mode=_BITS.Bits.bit_5;
	movlw	0
	btfsc	(__BITS),5
	movlw	1
	movwf	0+(_Tx_Type)^0100h+0Ah
	line	2253
	
l10906:	
;main.c: 2253: if(Read_Word_Buff[11]==0)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(_Read_Word_Buff)^080h+0Bh),w
	btfss	status,2
	goto	u10271
	goto	u10270
u10271:
	goto	l10914
u10270:
	line	2255
	
l10908:	
;main.c: 2254: {
;main.c: 2255: Tx_Type.TxType.Tx_Wifi=0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrf	0+(_Tx_Type)^0100h+04h
	line	2256
;main.c: 2256: Tx_Type.TxType.Tx_TdsLed=0;
	clrf	0+(_Tx_Type)^0100h+05h
	line	2257
	
l10910:	
;main.c: 2257: Tx_Type.TxType.Tx_TdsData_1=0xff;
	movlw	low(0FFh)
	movwf	0+(_Tx_Type)^0100h+06h
	line	2258
	
l10912:	
;main.c: 2258: Tx_Type.TxType.Tx_TdsData_2=0x00;
	clrf	0+(_Tx_Type)^0100h+07h
	line	2259
;main.c: 2259: }
	goto	l1451
	line	2262
	
l10914:	
;main.c: 2260: else
;main.c: 2261: {
;main.c: 2262: Tx_Type.TxType.Tx_Wifi=2;
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	0+(_Tx_Type)^0100h+04h
	line	2263
	
l1451:	
	line	2266
;main.c: 2263: }
;main.c: 2266: for(i=2;i<0x11U-1;i++){
	movlw	02h
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Tx_Display@i)
	clrf	(Tx_Display@i+1)
	line	2267
	
l10918:	
;main.c: 2267: Sum_Tot+=Tx_Type.Tx_Tab[i];
	movf	(Tx_Display@i),w
	addlw	low(_Tx_Type|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	addwf	(Tx_Display@Sum_Tot),f
	line	2266
	
l10920:	
	incf	(Tx_Display@i),f
	skipnz
	incf	(Tx_Display@i+1),f
	
l10922:	
	movlw	0
	subwf	(Tx_Display@i+1),w
	movlw	010h
	skipnz
	subwf	(Tx_Display@i),w
	skipc
	goto	u10281
	goto	u10280
u10281:
	goto	l10918
u10280:
	line	2269
	
l10924:	
;main.c: 2268: }
;main.c: 2269: Tx_Type.TxType.Tx_Check=Sum_Tot+0x11U;
	movf	(Tx_Display@Sum_Tot),w
	addlw	011h
	bsf	status, 6	;RP1=1, select bank2
	movwf	0+(_Tx_Type)^0100h+010h
	line	2270
	
l10926:	
;main.c: 2270: for(i=0;i<0x11U;i++){
	bcf	status, 6	;RP1=0, select bank0
	clrf	(Tx_Display@i)
	clrf	(Tx_Display@i+1)
	line	2271
	
l10932:	
;main.c: 2271: TXREG1=Tx_Type.Tx_Tab[i];
	movf	(Tx_Display@i),w
	addlw	low(_Tx_Type|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(285)^0100h	;volatile
	line	2272
;main.c: 2272: do{
	
l1456:	
	line	2273
# 2273 "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text30
	line	2275
	
l10934:	
;main.c: 2274: }
;main.c: 2275: while(TRMT1==0);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	btfss	(2297/8)^0100h,(2297)&7	;volatile
	goto	u10291
	goto	u10290
u10291:
	goto	l1456
u10290:
	line	2270
	
l10936:	
	bcf	status, 6	;RP1=0, select bank0
	incf	(Tx_Display@i),f
	skipnz
	incf	(Tx_Display@i+1),f
	
l10938:	
	movlw	0
	subwf	(Tx_Display@i+1),w
	movlw	011h
	skipnz
	subwf	(Tx_Display@i),w
	skipc
	goto	u10301
	goto	u10300
u10301:
	goto	l10932
u10300:
	line	2280
	
l1458:	
	return
	opt stack 0
GLOBAL	__end_of_Tx_Display
	__end_of_Tx_Display:
	signat	_Tx_Display,89
	global	_TaskAlarmHandle

;; *************** function _TaskAlarmHandle *****************
;; Defined at:
;;		line 1592 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          2       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text31,local,class=CODE,delta=2,merge=1,group=0
	line	1592
global __ptext31
__ptext31:	;psect for function _TaskAlarmHandle
psect	text31
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	1592
	global	__size_of_TaskAlarmHandle
	__size_of_TaskAlarmHandle	equ	__end_of_TaskAlarmHandle-_TaskAlarmHandle
	
_TaskAlarmHandle:	
;incstack = 0
	opt	stack 7
; Regs used in _TaskAlarmHandle: [wreg+status,2+status,0]
	line	1596
	
l10638:	
;main.c: 1596: if(BeepAlmCnt)
	bcf	status, 5	;RP0=0, select bank0
	movf	((_BeepAlmCnt)),w
	btfsc	status,2
	goto	u9841
	goto	u9840
u9841:
	goto	l1306
u9840:
	line	1598
	
l10640:	
;main.c: 1597: {
;main.c: 1598: if(BeepOnTimeCnt)
	bsf	status, 5	;RP0=1, select bank1
	movf	((_BeepOnTimeCnt)^080h),w
iorwf	((_BeepOnTimeCnt+1)^080h),w
	btfsc	status,2
	goto	u9851
	goto	u9850
u9851:
	goto	l10648
u9850:
	line	1600
	
l10642:	
;main.c: 1599: {
;main.c: 1600: BeepOnTimeCnt--;
	movlw	01h
	subwf	(_BeepOnTimeCnt)^080h,f
	movlw	0
	skipc
	decf	(_BeepOnTimeCnt+1)^080h,f
	subwf	(_BeepOnTimeCnt+1)^080h,f
	line	1602
	
l10644:	
;main.c: 1602: if(BeepOnTimeCnt>=(BuzzerFilter>>1)){PWM1EN=1;}
	movf	(_BuzzerFilter+1)^080h,w
	movwf	(??_TaskAlarmHandle+0)+0+1
	movf	(_BuzzerFilter)^080h,w
	movwf	(??_TaskAlarmHandle+0)+0
	clrc
	rrf	(??_TaskAlarmHandle+0)+1,f
	rrf	(??_TaskAlarmHandle+0)+0,f
	movf	1+(??_TaskAlarmHandle+0)+0,w
	subwf	(_BeepOnTimeCnt+1)^080h,w
	skipz
	goto	u9865
	movf	0+(??_TaskAlarmHandle+0)+0,w
	subwf	(_BeepOnTimeCnt)^080h,w
u9865:
	skipc
	goto	u9861
	goto	u9860
u9861:
	goto	l1308
u9860:
	
l10646:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2097/8)^0100h,(2097)&7	;volatile
	goto	l1312
	line	1605
	
l1308:	
;main.c: 1605: else {PWM1EN=0;}
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2097/8)^0100h,(2097)&7	;volatile
	goto	l1312
	line	1609
	
l10648:	
;main.c: 1607: else
;main.c: 1608: {
;main.c: 1609: BeepAlmCnt--;
	bcf	status, 5	;RP0=0, select bank0
	decf	(_BeepAlmCnt),f
	line	1610
	
l10650:	
;main.c: 1610: BeepOnTimeCnt=BuzzerFilter;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_BuzzerFilter+1)^080h,w
	movwf	(_BeepOnTimeCnt+1)^080h
	movf	(_BuzzerFilter)^080h,w
	movwf	(_BeepOnTimeCnt)^080h
	goto	l1312
	line	1613
	
l1306:	
	line	1615
;main.c: 1613: else
;main.c: 1614: {
;main.c: 1615: _BITS.Bits.bit_7=0;
	bcf	(__BITS),7
	line	1617
	
l1312:	
	return
	opt stack 0
GLOBAL	__end_of_TaskAlarmHandle
	__end_of_TaskAlarmHandle:
	signat	_TaskAlarmHandle,89
	global	_TDS_Handle

;; *************** function _TDS_Handle *****************
;; Defined at:
;;		line 439 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  TDSTyp          1    wreg     PTR struct .
;;		 -> PureTDSTyp(17), 
;;  Type            1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  TDSTyp          1   29[BANK0 ] PTR struct .
;;		 -> PureTDSTyp(17), 
;;  Muni_c          4   25[BANK0 ] unsigned long 
;;  NTC_            4   19[BANK0 ] unsigned long 
;;  i               2   23[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         0      11       0       0
;;      Temps:          0       4       0       0
;;      Totals:         1      15       0       0
;;Total ram usage:       16 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_GetCurTdsHz
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text32,local,class=CODE,delta=2,merge=1,group=0
	line	439
global __ptext32
__ptext32:	;psect for function _TDS_Handle
psect	text32
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	439
	global	__size_of_TDS_Handle
	__size_of_TDS_Handle	equ	__end_of_TDS_Handle-_TDS_Handle
	
_TDS_Handle:	
;incstack = 0
	opt	stack 6
; Regs used in _TDS_Handle: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
;TDS_Handle@TDSTyp stored from wreg
	movwf	(TDS_Handle@TDSTyp)
	line	442
	
l10342:	
	line	443
;main.c: 443: U32_T Muni_c=0;
	clrf	(TDS_Handle@Muni_c)
	clrf	(TDS_Handle@Muni_c+1)
	clrf	(TDS_Handle@Muni_c+2)
	clrf	(TDS_Handle@Muni_c+3)
	line	447
	
l10344:	
	line	448
	
l10346:	
;main.c: 448: Temp_Ntc=25;
	movlw	low(019h)
	movwf	(_Temp_Ntc)
	line	449
	
l10348:	
;main.c: 449: (TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)])=(TDSTyp->HzCount);
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Dh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+1
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	clrc
	rlf	indf,w
	addwf	(TDS_Handle@TDSTyp),w
	movwf	(??_TDS_Handle+2)+0
	movf	0+(??_TDS_Handle+2)+0,w
	movwf	fsr0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	indf
	line	450
	
l10350:	
;main.c: 450: (TDSTyp->HzCount)=0;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Dh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	452
	
l10352:	
;main.c: 452: if(Mode!=5){
		movlw	5
	xorwf	((_Mode)),w
	btfsc	status,2
	goto	u9281
	goto	u9280
u9281:
	goto	l10370
u9280:
	line	453
	
l10354:	
;main.c: 453: if(Type==1){
		decf	((TDS_Handle@Type)),w
	btfss	status,2
	goto	u9291
	goto	u9290
u9291:
	goto	l1054
u9290:
	line	455
	
l10356:	
;main.c: 455: if(Temp_Ntc >= 25){
	movlw	low(019h)
	subwf	(_Temp_Ntc),w
	skipc
	goto	u9301
	goto	u9300
u9301:
	goto	l10360
u9300:
	line	456
	
l10358:	
;main.c: 456: NTC_ = (U32_T)(Temp_Ntc -25);
	movf	(_Temp_Ntc),w
	addlw	low(-25)
	movwf	(TDS_Handle@NTC_)
	movlw	high(-25)
	skipnc
	movlw	(high(-25)+1)&0ffh
	movwf	((TDS_Handle@NTC_))+1
	clrf	(TDS_Handle@NTC_)+2
	btfsc	(TDS_Handle@NTC_)+1,7
	decf	2+(TDS_Handle@NTC_),f
	movf	(TDS_Handle@NTC_)+2,w
	movwf	3+(TDS_Handle@NTC_)
	line	457
;main.c: 457: NTC_ += 100;
	movlw	064h
	addwf	(TDS_Handle@NTC_),f
	movlw	1
	skipnc
	addwf	(TDS_Handle@NTC_+1),f
	skipnc
	addwf	(TDS_Handle@NTC_+2),f
	skipnc
	addwf	(TDS_Handle@NTC_+3),f
	line	458
;main.c: 458: }
	goto	l10362
	line	460
	
l10360:	
;main.c: 459: else {
;main.c: 460: NTC_ = (U32_T)(25-Temp_Ntc);
	movlw	019h
	movwf	(??_TDS_Handle+0)+0
	movf	(_Temp_Ntc),w
	subwf	(??_TDS_Handle+0)+0,w
	movwf	(TDS_Handle@NTC_)
	clrf	(TDS_Handle@NTC_)+1
	skipc
	decf	1+(TDS_Handle@NTC_),f
	
	clrf	(TDS_Handle@NTC_)+2
	btfsc	(TDS_Handle@NTC_)+1,7
	decf	2+(TDS_Handle@NTC_),f
	movf	(TDS_Handle@NTC_)+2,w
	movwf	3+(TDS_Handle@NTC_)
	line	461
;main.c: 461: NTC_ = 100-NTC_;
	movlw	064h
	movwf	((??_TDS_Handle+0)+0)
	movlw	0
	movwf	((??_TDS_Handle+0)+0+1)
	movlw	0
	movwf	((??_TDS_Handle+0)+0+2)
	movlw	0
	movwf	((??_TDS_Handle+0)+0+3)
	movf	(TDS_Handle@NTC_),w
	subwf	(??_TDS_Handle+0)+0,f
	movf	(TDS_Handle@NTC_+1),w
	skipc
	incfsz	(TDS_Handle@NTC_+1),w
	goto	u9311
	goto	u9312
u9311:
	subwf	(??_TDS_Handle+0)+1,f
u9312:
	movf	(TDS_Handle@NTC_+2),w
	skipc
	incfsz	(TDS_Handle@NTC_+2),w
	goto	u9313
	goto	u9314
u9313:
	subwf	(??_TDS_Handle+0)+2,f
u9314:
	movf	(TDS_Handle@NTC_+3),w
	skipc
	incfsz	(TDS_Handle@NTC_+3),w
	goto	u9315
	goto	u9316
u9315:
	subwf	(??_TDS_Handle+0)+3,f
u9316:

	movf	3+(??_TDS_Handle+0)+0,w
	movwf	(TDS_Handle@NTC_+3)
	movf	2+(??_TDS_Handle+0)+0,w
	movwf	(TDS_Handle@NTC_+2)
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	(TDS_Handle@NTC_+1)
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	(TDS_Handle@NTC_)

	line	464
	
l10362:	
;main.c: 462: }
;main.c: 464: Muni_c = TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)];
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	clrc
	rlf	indf,w
	addwf	(TDS_Handle@TDSTyp),w
	movwf	(??_TDS_Handle+0)+0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+1)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+1)+0+1
	movf	0+(??_TDS_Handle+1)+0,w
	movwf	(TDS_Handle@Muni_c)
	movf	1+(??_TDS_Handle+1)+0,w
	movwf	((TDS_Handle@Muni_c))+1
	clrf	2+((TDS_Handle@Muni_c))
	clrf	3+((TDS_Handle@Muni_c))
	line	465
	
l10364:	
;main.c: 465: Muni_c *= 100;
	movlw	064h
	movwf	(___lmul@multiplier)
	clrf	(___lmul@multiplier+1)
	clrf	(___lmul@multiplier+2)
	clrf	(___lmul@multiplier+3)

	movf	(TDS_Handle@Muni_c+3),w
	movwf	(___lmul@multiplicand+3)
	movf	(TDS_Handle@Muni_c+2),w
	movwf	(___lmul@multiplicand+2)
	movf	(TDS_Handle@Muni_c+1),w
	movwf	(___lmul@multiplicand+1)
	movf	(TDS_Handle@Muni_c),w
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(TDS_Handle@Muni_c+3)
	movf	(2+(?___lmul)),w
	movwf	(TDS_Handle@Muni_c+2)
	movf	(1+(?___lmul)),w
	movwf	(TDS_Handle@Muni_c+1)
	movf	(0+(?___lmul)),w
	movwf	(TDS_Handle@Muni_c)

	line	466
	
l10366:	
;main.c: 466: Muni_c /= NTC_;
	movf	(TDS_Handle@NTC_+3),w
	movwf	(___lldiv@divisor+3)
	movf	(TDS_Handle@NTC_+2),w
	movwf	(___lldiv@divisor+2)
	movf	(TDS_Handle@NTC_+1),w
	movwf	(___lldiv@divisor+1)
	movf	(TDS_Handle@NTC_),w
	movwf	(___lldiv@divisor)

	movf	(TDS_Handle@Muni_c+3),w
	movwf	(___lldiv@dividend+3)
	movf	(TDS_Handle@Muni_c+2),w
	movwf	(___lldiv@dividend+2)
	movf	(TDS_Handle@Muni_c+1),w
	movwf	(___lldiv@dividend+1)
	movf	(TDS_Handle@Muni_c),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(TDS_Handle@Muni_c+3)
	movf	(2+(?___lldiv)),w
	movwf	(TDS_Handle@Muni_c+2)
	movf	(1+(?___lldiv)),w
	movwf	(TDS_Handle@Muni_c+1)
	movf	(0+(?___lldiv)),w
	movwf	(TDS_Handle@Muni_c)

	line	467
	
l10368:	
;main.c: 467: TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)] = Muni_c;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	clrc
	rlf	indf,w
	addwf	(TDS_Handle@TDSTyp),w
	movwf	(??_TDS_Handle+0)+0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	fsr0
	movf	(TDS_Handle@Muni_c),w
	movwf	indf
	incf	fsr0,f
	movf	(TDS_Handle@Muni_c+1),w
	movwf	indf
	line	468
;main.c: 468: }
	goto	l10370
	line	469
	
l1054:	
	line	497
	
l10370:	
;main.c: 472: }
;main.c: 473: }
;main.c: 497: (TDSTyp->TdsTime)++;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	incf	indf,f
	line	498
;main.c: 498: if((TDSTyp->TdsTime)>=5){
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u9321
	goto	u9320
u9321:
	goto	l1083
u9320:
	line	499
	
l10372:	
;main.c: 499: (TDSTyp->TdsTime)=0;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	clrf	indf
	line	501
;main.c: 501: (TDSTyp->TdsHz)=0;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	502
	
l10374:	
;main.c: 502: for(i=0;i<5;i++){
	clrf	(TDS_Handle@i)
	clrf	(TDS_Handle@i+1)
	line	503
	
l10380:	
;main.c: 503: TDSTyp->TdsHz+=TDSTyp->TdsHz_Tab[i];
	clrc
	rlf	(TDS_Handle@i),w
	addwf	(TDS_Handle@TDSTyp),w
	movwf	(??_TDS_Handle+0)+0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+1)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+1)+0+1
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	movf	0+(??_TDS_Handle+1)+0,w
	addwf	indf,f
	incfsz	fsr0,f
	movf	indf,w
	skipnc
	incf	indf,w
	movwf	btemp+1
	movf	1+(??_TDS_Handle+1)+0,w
	addwf	btemp+1,w
	movwf	indf
	decf	fsr0,f
	line	502
	
l10382:	
	incf	(TDS_Handle@i),f
	skipnz
	incf	(TDS_Handle@i+1),f
	
l10384:	
	movlw	0
	subwf	(TDS_Handle@i+1),w
	movlw	05h
	skipnz
	subwf	(TDS_Handle@i),w
	skipc
	goto	u9331
	goto	u9330
u9331:
	goto	l10380
u9330:
	line	505
	
l10386:	
;main.c: 504: }
;main.c: 505: (TDSTyp->TdsHz)/=5;
	movlw	05h
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	movf	indf,w
	movwf	(___lwdiv@dividend)
	incf	fsr0,f
	movf	indf,w
	movwf	(___lwdiv@dividend+1)
	fcall	___lwdiv
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	movf	(0+(?___lwdiv)),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(1+(?___lwdiv)),w
	movwf	indf
	line	511
	
l10388:	
;main.c: 511: PreTdsData=TDSTyp->TdsData;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	indf,w
	movwf	(_PreTdsData)
	incf	fsr0,f
	movf	indf,w
	movwf	(_PreTdsData+1)
	line	512
	
l10390:	
;main.c: 512: if(TDSTyp->TdsHz>PureHz_Tab[189])
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+1
	movlw	low(((_PureHz_Tab+017Ah)|8000h))
	movwf	fsr0
	movlw	high(((_PureHz_Tab+017Ah)|8000h))
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_TDS_Handle+2)+0
	fcall	stringtab
	movwf	(??_TDS_Handle+2)+0+1
	movf	1+(??_TDS_Handle+0)+0,w
	subwf	1+(??_TDS_Handle+2)+0,w
	skipz
	goto	u9345
	movf	0+(??_TDS_Handle+0)+0,w
	subwf	0+(??_TDS_Handle+2)+0,w
u9345:
	skipnc
	goto	u9341
	goto	u9340
u9341:
	goto	l10394
u9340:
	line	514
	
l10392:	
;main.c: 513: {
;main.c: 514: TDSTyp->TdsData=189+(TDSTyp->TdsHz-PureHz_Tab[189])/5;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(___lwdiv@dividend)
	incf	fsr0,f
	movf	indf,w
	movwf	(___lwdiv@dividend+1)
	movlw	low(((_PureHz_Tab+017Ah)|8000h))
	movwf	fsr0
	movlw	high(((_PureHz_Tab+017Ah)|8000h))
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_TDS_Handle+0)+0
	fcall	stringtab
	movwf	(??_TDS_Handle+0)+0+1
	movf	0+(??_TDS_Handle+0)+0,w
	subwf	(___lwdiv@dividend),f
	movf	1+(??_TDS_Handle+0)+0,w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	movlw	05h
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	fcall	___lwdiv
	movf	(0+(?___lwdiv)),w
	addlw	low(0BDh)
	movwf	(??_TDS_Handle+2)+0
	movf	(1+(?___lwdiv)),w
	skipnc
	addlw	1
	addlw	high(0BDh)
	movwf	1+(??_TDS_Handle+2)+0
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	0+(??_TDS_Handle+2)+0,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+2)+0,w
	movwf	indf
	line	515
;main.c: 515: }
	goto	l10396
	line	518
	
l10394:	
;main.c: 516: else
;main.c: 517: {
;main.c: 518: TDSTyp->TdsData=GetCurTdsHz(TDSTyp,(U16_T *)PureHz_Tab,189);
	movlw	low(((_PureHz_Tab)|8000h))
	movwf	(GetCurTdsHz@Tab)
	movlw	high(((_PureHz_Tab)|8000h))
	movwf	((GetCurTdsHz@Tab))+1
	movlw	0BDh
	movwf	(GetCurTdsHz@index)
	clrf	(GetCurTdsHz@index+1)
	movf	(TDS_Handle@TDSTyp),w
	fcall	_GetCurTdsHz
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	(0+(?_GetCurTdsHz)),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(1+(?_GetCurTdsHz)),w
	movwf	indf
	line	521
	
l10396:	
;main.c: 519: }
;main.c: 521: if(TDSTyp->TdsData>999)
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+1
	movlw	03h
	subwf	1+(??_TDS_Handle+0)+0,w
	movlw	0E8h
	skipnz
	subwf	0+(??_TDS_Handle+0)+0,w
	skipc
	goto	u9351
	goto	u9350
u9351:
	goto	l10400
u9350:
	line	523
	
l10398:	
;main.c: 522: {
;main.c: 523: TDSTyp->TdsData=999;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movlw	0E7h
	movwf	indf
	incf	fsr0,f
	movlw	03h
	movwf	indf
	line	524
;main.c: 524: }
	goto	l10404
	line	525
	
l10400:	
;main.c: 525: else if(TDSTyp->TdsData<3)
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+1
	movlw	0
	subwf	1+(??_TDS_Handle+0)+0,w
	movlw	03h
	skipnz
	subwf	0+(??_TDS_Handle+0)+0,w
	skipnc
	goto	u9361
	goto	u9360
u9361:
	goto	l10404
u9360:
	line	527
	
l10402:	
;main.c: 526: {
;main.c: 527: TDSTyp->TdsData=3;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movlw	03h
	movwf	indf
	incf	fsr0,f
	movlw	0
	movwf	indf
	line	530
	
l10404:	
;main.c: 528: }
;main.c: 530: if(Mode!=5)
		movlw	5
	xorwf	((_Mode)),w
	btfsc	status,2
	goto	u9371
	goto	u9370
u9371:
	goto	l1066
u9370:
	line	548
	
l10406:	
;main.c: 531: {
;main.c: 548: if(_BITS.Bits.bit_6==0)
	btfsc	(__BITS),6
	goto	u9381
	goto	u9380
u9381:
	goto	l1066
u9380:
	line	550
	
l10408:	
;main.c: 549: {
;main.c: 550: if(TDSTyp->TdsData>=PreTdsData){
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+1
	movf	(_PreTdsData+1),w
	subwf	1+(??_TDS_Handle+0)+0,w
	skipz
	goto	u9395
	movf	(_PreTdsData),w
	subwf	0+(??_TDS_Handle+0)+0,w
u9395:
	skipc
	goto	u9391
	goto	u9390
u9391:
	goto	l1068
u9390:
	line	551
	
l10410:	
;main.c: 551: TdsCk60sFlag+=1;
	incf	(_TdsCk60sFlag),f
	line	552
	
l10412:	
;main.c: 552: if(TdsCk60sFlag>=4){
	movlw	low(04h)
	subwf	(_TdsCk60sFlag),w
	skipc
	goto	u9401
	goto	u9400
u9401:
	goto	l10416
u9400:
	line	553
	
l10414:	
;main.c: 553: TdsCk60sFlag=0;
	clrf	(_TdsCk60sFlag)
	line	555
	
l10416:	
;main.c: 554: }
;main.c: 555: if(TdsCk60sFlag==1){
		decf	((_TdsCk60sFlag)),w
	btfss	status,2
	goto	u9411
	goto	u9410
u9411:
	goto	l10420
u9410:
	line	556
	
l10418:	
;main.c: 556: TDSTyp->TdsData=PreTdsData+2;
	movf	(_PreTdsData),w
	addlw	low(02h)
	movwf	(??_TDS_Handle+0)+0
	movf	(_PreTdsData+1),w
	skipnc
	addlw	1
	addlw	high(02h)
	movwf	1+(??_TDS_Handle+0)+0
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	indf
	line	557
;main.c: 557: }
	goto	l1066
	line	558
	
l10420:	
;main.c: 558: else if(TdsCk60sFlag==2)
		movlw	2
	xorwf	((_TdsCk60sFlag)),w
	btfss	status,2
	goto	u9421
	goto	u9420
u9421:
	goto	l10428
u9420:
	line	560
	
l10422:	
;main.c: 559: {
;main.c: 560: if(PreTdsData>3)
	movlw	0
	subwf	(_PreTdsData+1),w
	movlw	04h
	skipnz
	subwf	(_PreTdsData),w
	skipc
	goto	u9431
	goto	u9430
u9431:
	goto	l10426
u9430:
	line	561
	
l10424:	
;main.c: 561: TDSTyp->TdsData=PreTdsData-3;
	movf	(_PreTdsData),w
	addlw	low(0FFFDh)
	movwf	(??_TDS_Handle+0)+0
	movf	(_PreTdsData+1),w
	skipnc
	addlw	1
	addlw	high(0FFFDh)
	movwf	1+(??_TDS_Handle+0)+0
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	indf
	goto	l1066
	line	562
	
l10426:	
;main.c: 562: else TDSTyp->TdsData=1;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movlw	01h
	movwf	indf
	incf	fsr0,f
	movlw	0
	movwf	indf
	goto	l1066
	line	564
	
l10428:	
;main.c: 564: else if(TdsCk60sFlag==3)
		movlw	3
	xorwf	((_TdsCk60sFlag)),w
	btfss	status,2
	goto	u9441
	goto	u9440
u9441:
	goto	l10436
u9440:
	line	566
	
l10430:	
;main.c: 565: {
;main.c: 566: if(PreTdsData>2)
	movlw	0
	subwf	(_PreTdsData+1),w
	movlw	03h
	skipnz
	subwf	(_PreTdsData),w
	skipc
	goto	u9451
	goto	u9450
u9451:
	goto	l10434
u9450:
	line	567
	
l10432:	
;main.c: 567: TDSTyp->TdsData=PreTdsData-2;
	movf	(_PreTdsData),w
	addlw	low(0FFFEh)
	movwf	(??_TDS_Handle+0)+0
	movf	(_PreTdsData+1),w
	skipnc
	addlw	1
	addlw	high(0FFFEh)
	movwf	1+(??_TDS_Handle+0)+0
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	indf
	goto	l1066
	line	568
	
l10434:	
;main.c: 568: else TDSTyp->TdsData=1;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movlw	01h
	movwf	indf
	incf	fsr0,f
	movlw	0
	movwf	indf
	goto	l1066
	line	571
	
l10436:	
;main.c: 571: else if(TdsCk60sFlag==0)
	movf	((_TdsCk60sFlag)),w
	btfss	status,2
	goto	u9461
	goto	u9460
u9461:
	goto	l1071
u9460:
	line	573
	
l10438:	
;main.c: 572: {
;main.c: 573: TDSTyp->TdsData=PreTdsData+3;
	movf	(_PreTdsData),w
	addlw	low(03h)
	movwf	(??_TDS_Handle+0)+0
	movf	(_PreTdsData+1),w
	skipnc
	addlw	1
	addlw	high(03h)
	movwf	1+(??_TDS_Handle+0)+0
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	indf
	goto	l1066
	line	575
	
l1071:	
;main.c: 574: }
;main.c: 575: }
	goto	l1066
	line	576
	
l1068:	
	line	578
;main.c: 576: else
;main.c: 577: {
;main.c: 578: _BITS.Bits.bit_6=1;
	bsf	(__BITS),6
	line	581
	
l1066:	
	line	582
;main.c: 579: }
;main.c: 580: }
;main.c: 581: }
;main.c: 582: if(_BITS.Bits.bit_6){
	btfss	(__BITS),6
	goto	u9471
	goto	u9470
u9471:
	goto	l1083
u9470:
	line	583
	
l10440:	
;main.c: 583: PreTdsData=TDSTyp->TdsData;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	indf,w
	movwf	(_PreTdsData)
	incf	fsr0,f
	movf	indf,w
	movwf	(_PreTdsData+1)
	line	602
	
l1083:	
	return
	opt stack 0
GLOBAL	__end_of_TDS_Handle
	__end_of_TDS_Handle:
	signat	_TDS_Handle,8313
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK0 ] unsigned int 
;;  dividend        2    2[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    5[BANK0 ] unsigned int 
;;  counter         1    4[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       4       0       0
;;      Locals:         0       3       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       7       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_TDS_Handle
;; This function uses a non-reentrant model
;;
psect	text33,local,class=CODE,delta=2,merge=1,group=2
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lwdiv.c"
	line	6
global __ptext33
__ptext33:	;psect for function ___lwdiv
psect	text33
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 6
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l10296:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l10298:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u9181
	goto	u9180
u9181:
	goto	l10318
u9180:
	line	16
	
l10300:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l10304
	line	18
	
l10302:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l10304:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u9191
	goto	u9190
u9191:
	goto	l10302
u9190:
	line	22
	
l10306:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l10308:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u9205
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u9205:
	skipc
	goto	u9201
	goto	u9200
u9201:
	goto	l10314
u9200:
	line	24
	
l10310:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l10312:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l10314:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l10316:	
	decfsz	(___lwdiv@counter),f
	goto	u9211
	goto	u9210
u9211:
	goto	l10306
u9210:
	line	30
	
l10318:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l4045:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    0[BANK0 ] unsigned long 
;;  multiplicand    4    4[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4    8[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    0[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       8       0       0
;;      Locals:         0       4       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_TDS_Handle
;; This function uses a non-reentrant model
;;
psect	text34,local,class=CODE,delta=2,merge=1,group=2
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul32.c"
	line	15
global __ptext34
__ptext34:	;psect for function ___lmul
psect	text34
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 6
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l10258:	
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l3713:	
	line	121
	btfss	(___lmul@multiplier),(0)&7
	goto	u9111
	goto	u9110
u9111:
	goto	l10262
u9110:
	line	122
	
l10260:	
	movf	(___lmul@multiplicand),w
	addwf	(___lmul@product),f
	movf	(___lmul@multiplicand+1),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u9121
	addwf	(___lmul@product+1),f
u9121:
	movf	(___lmul@multiplicand+2),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u9122
	addwf	(___lmul@product+2),f
u9122:
	movf	(___lmul@multiplicand+3),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u9123
	addwf	(___lmul@product+3),f
u9123:

	line	123
	
l10262:	
	clrc
	rlf	(___lmul@multiplicand),f
	rlf	(___lmul@multiplicand+1),f
	rlf	(___lmul@multiplicand+2),f
	rlf	(___lmul@multiplicand+3),f
	line	124
	
l10264:	
	clrc
	rrf	(___lmul@multiplier+3),f
	rrf	(___lmul@multiplier+2),f
	rrf	(___lmul@multiplier+1),f
	rrf	(___lmul@multiplier),f
	line	125
	movf	(___lmul@multiplier+3),w
	iorwf	(___lmul@multiplier+2),w
	iorwf	(___lmul@multiplier+1),w
	iorwf	(___lmul@multiplier),w
	skipz
	goto	u9131
	goto	u9130
u9131:
	goto	l3713
u9130:
	line	128
	
l10266:	
	movf	(___lmul@product+3),w
	movwf	(?___lmul+3)
	movf	(___lmul@product+2),w
	movwf	(?___lmul+2)
	movf	(___lmul@product+1),w
	movwf	(?___lmul+1)
	movf	(___lmul@product),w
	movwf	(?___lmul)

	line	129
	
l3716:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    0[BANK0 ] unsigned long 
;;  dividend        4    4[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4    8[BANK0 ] unsigned long 
;;  counter         1   12[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    0[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       8       0       0
;;      Locals:         0       5       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0      13       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_TDS_Handle
;; This function uses a non-reentrant model
;;
psect	text35,local,class=CODE,delta=2,merge=1,group=2
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lldiv.c"
	line	6
global __ptext35
__ptext35:	;psect for function ___lldiv
psect	text35
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 6
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l10270:	
	clrf	(___lldiv@quotient)
	clrf	(___lldiv@quotient+1)
	clrf	(___lldiv@quotient+2)
	clrf	(___lldiv@quotient+3)
	line	15
	
l10272:	
	movf	(___lldiv@divisor+3),w
	iorwf	(___lldiv@divisor+2),w
	iorwf	(___lldiv@divisor+1),w
	iorwf	(___lldiv@divisor),w
	skipnz
	goto	u9141
	goto	u9140
u9141:
	goto	l10292
u9140:
	line	16
	
l10274:	
	clrf	(___lldiv@counter)
	incf	(___lldiv@counter),f
	line	17
	goto	l10278
	line	18
	
l10276:	
	clrc
	rlf	(___lldiv@divisor),f
	rlf	(___lldiv@divisor+1),f
	rlf	(___lldiv@divisor+2),f
	rlf	(___lldiv@divisor+3),f
	line	19
	incf	(___lldiv@counter),f
	line	17
	
l10278:	
	btfss	(___lldiv@divisor+3),(31)&7
	goto	u9151
	goto	u9150
u9151:
	goto	l10276
u9150:
	line	22
	
l10280:	
	clrc
	rlf	(___lldiv@quotient),f
	rlf	(___lldiv@quotient+1),f
	rlf	(___lldiv@quotient+2),f
	rlf	(___lldiv@quotient+3),f
	line	23
	
l10282:	
	movf	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),w
	skipz
	goto	u9165
	movf	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),w
	skipz
	goto	u9165
	movf	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),w
	skipz
	goto	u9165
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),w
u9165:
	skipc
	goto	u9161
	goto	u9160
u9161:
	goto	l10288
u9160:
	line	24
	
l10284:	
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),f
	movf	(___lldiv@divisor+1),w
	skipc
	incfsz	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),f
	movf	(___lldiv@divisor+2),w
	skipc
	incfsz	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),f
	movf	(___lldiv@divisor+3),w
	skipc
	incfsz	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),f
	line	25
	
l10286:	
	bsf	(___lldiv@quotient)+(0/8),(0)&7
	line	27
	
l10288:	
	clrc
	rrf	(___lldiv@divisor+3),f
	rrf	(___lldiv@divisor+2),f
	rrf	(___lldiv@divisor+1),f
	rrf	(___lldiv@divisor),f
	line	28
	
l10290:	
	decfsz	(___lldiv@counter),f
	goto	u9171
	goto	u9170
u9171:
	goto	l10280
u9170:
	line	30
	
l10292:	
	movf	(___lldiv@quotient+3),w
	movwf	(?___lldiv+3)
	movf	(___lldiv@quotient+2),w
	movwf	(?___lldiv+2)
	movf	(___lldiv@quotient+1),w
	movwf	(?___lldiv+1)
	movf	(___lldiv@quotient),w
	movwf	(?___lldiv)

	line	31
	
l3992:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	_GetCurTdsHz

;; *************** function _GetCurTdsHz *****************
;; Defined at:
;;		line 364 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  AdPtr           1    wreg     PTR struct .
;;		 -> PureTDSTyp(17), 
;;  Tab             2    0[BANK0 ] PTR unsigned int 
;;		 -> PureHz_Tab(380), 
;;  index           2    2[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  AdPtr           1   14[BANK0 ] PTR struct .
;;		 -> PureTDSTyp(17), 
;;  tmp             2   12[BANK0 ] unsigned int 
;;  i               2   10[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2    0[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       4       0       0
;;      Locals:         0       5       0       0
;;      Temps:          0       6       0       0
;;      Totals:         0      15       0       0
;;Total ram usage:       15 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_TDS_Handle
;; This function uses a non-reentrant model
;;
psect	text36,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	364
global __ptext36
__ptext36:	;psect for function _GetCurTdsHz
psect	text36
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	364
	global	__size_of_GetCurTdsHz
	__size_of_GetCurTdsHz	equ	__end_of_GetCurTdsHz-_GetCurTdsHz
	
_GetCurTdsHz:	
;incstack = 0
	opt	stack 6
; Regs used in _GetCurTdsHz: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
;GetCurTdsHz@AdPtr stored from wreg
	movwf	(GetCurTdsHz@AdPtr)
	line	367
	
l9348:	
;main.c: 366: U16_T tmp, i;
;main.c: 367: tmp=0x00;
	clrf	(GetCurTdsHz@tmp)
	clrf	(GetCurTdsHz@tmp+1)
	line	369
	
l9350:	
;main.c: 369: if(AdPtr->TdsHz<Tab[0])
	movf	(GetCurTdsHz@Tab+1),w
	movwf	btemp+1
	movf	(GetCurTdsHz@Tab),w
	movwf	fsr0
	fcall	stringtab
	movwf	(??_GetCurTdsHz+0)+0
	fcall	stringtab
	movwf	(??_GetCurTdsHz+0)+0+1
	movf	(GetCurTdsHz@AdPtr),w
	addlw	0Bh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_GetCurTdsHz+2)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_GetCurTdsHz+2)+0+1
	movf	1+(??_GetCurTdsHz+0)+0,w
	subwf	1+(??_GetCurTdsHz+2)+0,w
	skipz
	goto	u7665
	movf	0+(??_GetCurTdsHz+0)+0,w
	subwf	0+(??_GetCurTdsHz+2)+0,w
u7665:
	skipnc
	goto	u7661
	goto	u7660
u7661:
	goto	l9354
u7660:
	goto	l1016
	line	372
	
l9354:	
;main.c: 372: else if(AdPtr->TdsHz>=Tab[index]){tmp=index;}
	movf	(GetCurTdsHz@index+1),w
	movwf	(??_GetCurTdsHz+0)+0+1
	movf	(GetCurTdsHz@index),w
	movwf	(??_GetCurTdsHz+0)+0
	clrc
	rlf	(??_GetCurTdsHz+0)+0,f
	rlf	(??_GetCurTdsHz+0)+1,f
	movf	0+(??_GetCurTdsHz+0)+0,w
	addwf	(GetCurTdsHz@Tab),w
	movwf	fsr0
	movf	1+(??_GetCurTdsHz+0)+0,w
	skipnc
	incf	1+(??_GetCurTdsHz+0)+0,w
	addwf	(GetCurTdsHz@Tab+1),w
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_GetCurTdsHz+2)+0
	fcall	stringtab
	movwf	(??_GetCurTdsHz+2)+0+1
	movf	(GetCurTdsHz@AdPtr),w
	addlw	0Bh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_GetCurTdsHz+4)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_GetCurTdsHz+4)+0+1
	movf	1+(??_GetCurTdsHz+2)+0,w
	subwf	1+(??_GetCurTdsHz+4)+0,w
	skipz
	goto	u7675
	movf	0+(??_GetCurTdsHz+2)+0,w
	subwf	0+(??_GetCurTdsHz+4)+0,w
u7675:
	skipc
	goto	u7671
	goto	u7670
u7671:
	goto	l9358
u7670:
	
l9356:	
	movf	(GetCurTdsHz@index+1),w
	movwf	(GetCurTdsHz@tmp+1)
	movf	(GetCurTdsHz@index),w
	movwf	(GetCurTdsHz@tmp)
	goto	l1016
	line	375
	
l9358:	
;main.c: 373: else
;main.c: 374: {
;main.c: 375: for(i = 10; i < index; )
	movlw	0Ah
	movwf	(GetCurTdsHz@i)
	clrf	(GetCurTdsHz@i+1)
	goto	l1019
	line	377
	
l9360:	
;main.c: 376: {
;main.c: 377: if(AdPtr->TdsHz >= Tab[i]){tmp = i;}
	movf	(GetCurTdsHz@i+1),w
	movwf	(??_GetCurTdsHz+0)+0+1
	movf	(GetCurTdsHz@i),w
	movwf	(??_GetCurTdsHz+0)+0
	clrc
	rlf	(??_GetCurTdsHz+0)+0,f
	rlf	(??_GetCurTdsHz+0)+1,f
	movf	0+(??_GetCurTdsHz+0)+0,w
	addwf	(GetCurTdsHz@Tab),w
	movwf	fsr0
	movf	1+(??_GetCurTdsHz+0)+0,w
	skipnc
	incf	1+(??_GetCurTdsHz+0)+0,w
	addwf	(GetCurTdsHz@Tab+1),w
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_GetCurTdsHz+2)+0
	fcall	stringtab
	movwf	(??_GetCurTdsHz+2)+0+1
	movf	(GetCurTdsHz@AdPtr),w
	addlw	0Bh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_GetCurTdsHz+4)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_GetCurTdsHz+4)+0+1
	movf	1+(??_GetCurTdsHz+2)+0,w
	subwf	1+(??_GetCurTdsHz+4)+0,w
	skipz
	goto	u7685
	movf	0+(??_GetCurTdsHz+2)+0,w
	subwf	0+(??_GetCurTdsHz+4)+0,w
u7685:
	skipc
	goto	u7681
	goto	u7680
u7681:
	goto	l1021
u7680:
	
l9362:	
	movf	(GetCurTdsHz@i+1),w
	movwf	(GetCurTdsHz@tmp+1)
	movf	(GetCurTdsHz@i),w
	movwf	(GetCurTdsHz@tmp)
	
l1021:	
	line	378
;main.c: 378: i += 10;
	movlw	0Ah
	addwf	(GetCurTdsHz@i),f
	skipnc
	incf	(GetCurTdsHz@i+1),f
	line	375
	
l1019:	
	movf	(GetCurTdsHz@index+1),w
	subwf	(GetCurTdsHz@i+1),w
	skipz
	goto	u7695
	movf	(GetCurTdsHz@index),w
	subwf	(GetCurTdsHz@i),w
u7695:
	skipc
	goto	u7691
	goto	u7690
u7691:
	goto	l9360
u7690:
	line	380
	
l9364:	
	movf	(GetCurTdsHz@AdPtr),w
	addlw	0Bh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_GetCurTdsHz+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_GetCurTdsHz+0)+0+1
	movf	(GetCurTdsHz@tmp+1),w
	movwf	(??_GetCurTdsHz+2)+0+1
	movf	(GetCurTdsHz@tmp),w
	movwf	(??_GetCurTdsHz+2)+0
	incf	(GetCurTdsHz@tmp),f
	skipnz
	incf	(GetCurTdsHz@tmp+1),f
	clrc
	rlf	(??_GetCurTdsHz+2)+0,f
	rlf	(??_GetCurTdsHz+2)+1,f
	movf	0+(??_GetCurTdsHz+2)+0,w
	addwf	(GetCurTdsHz@Tab),w
	movwf	fsr0
	movf	1+(??_GetCurTdsHz+2)+0,w
	skipnc
	incf	1+(??_GetCurTdsHz+2)+0,w
	addwf	(GetCurTdsHz@Tab+1),w
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_GetCurTdsHz+4)+0
	fcall	stringtab
	movwf	(??_GetCurTdsHz+4)+0+1
	movf	1+(??_GetCurTdsHz+0)+0,w
	subwf	1+(??_GetCurTdsHz+4)+0,w
	skipz
	goto	u7705
	movf	0+(??_GetCurTdsHz+0)+0,w
	subwf	0+(??_GetCurTdsHz+4)+0,w
u7705:
	skipc
	goto	u7701
	goto	u7700
u7701:
	goto	l9364
u7700:
	line	381
	
l9366:	
;main.c: 381: if(tmp){tmp--;}
	movf	((GetCurTdsHz@tmp)),w
iorwf	((GetCurTdsHz@tmp+1)),w
	btfsc	status,2
	goto	u7711
	goto	u7710
u7711:
	goto	l1016
u7710:
	
l9368:	
	movlw	01h
	subwf	(GetCurTdsHz@tmp),f
	movlw	0
	skipc
	decf	(GetCurTdsHz@tmp+1),f
	subwf	(GetCurTdsHz@tmp+1),f
	line	382
	
l1016:	
	line	383
;main.c: 382: }
;main.c: 383: return(tmp);
	movf	(GetCurTdsHz@tmp+1),w
	movwf	(?_GetCurTdsHz+1)
	movf	(GetCurTdsHz@tmp),w
	movwf	(?_GetCurTdsHz)
	line	385
	
l1027:	
	return
	opt stack 0
GLOBAL	__end_of_GetCurTdsHz
	__end_of_GetCurTdsHz:
	signat	_GetCurTdsHz,12410
	global	_Page_ProgramData

;; *************** function _Page_ProgramData *****************
;; Defined at:
;;		line 2679 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               2    3[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       2       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Memory_Write
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text37,local,class=CODE,delta=2,merge=1,group=0
	line	2679
global __ptext37
__ptext37:	;psect for function _Page_ProgramData
psect	text37
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	2679
	global	__size_of_Page_ProgramData
	__size_of_Page_ProgramData	equ	__end_of_Page_ProgramData-_Page_ProgramData
	
_Page_ProgramData:	
;incstack = 0
	opt	stack 6
; Regs used in _Page_ProgramData: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	2680
	
l10970:	
;main.c: 2680: unsigned int i=0;
	clrf	(Page_ProgramData@i)
	clrf	(Page_ProgramData@i+1)
	line	2681
;main.c: 2681: for(i=0;i<12;i++){
	clrf	(Page_ProgramData@i)
	clrf	(Page_ProgramData@i+1)
	line	2682
	
l10976:	
;main.c: 2682: Memory_Write(i,Read_Word_Buff[i]);
	movf	(Page_ProgramData@i+1),w
	movwf	(Memory_Write@Addr+1)
	movf	(Page_ProgramData@i),w
	movwf	(Memory_Write@Addr)
	movf	(Page_ProgramData@i),w
	addlw	low(_Read_Word_Buff|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(Memory_Write@Value)
	fcall	_Memory_Write
	line	2681
	
l10978:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(Page_ProgramData@i),f
	skipnz
	incf	(Page_ProgramData@i+1),f
	
l10980:	
	movlw	0
	subwf	(Page_ProgramData@i+1),w
	movlw	0Ch
	skipnz
	subwf	(Page_ProgramData@i),w
	skipc
	goto	u10361
	goto	u10360
u10361:
	goto	l10976
u10360:
	line	2684
	
l1526:	
	return
	opt stack 0
GLOBAL	__end_of_Page_ProgramData
	__end_of_Page_ProgramData:
	signat	_Page_ProgramData,89
	global	_Memory_Write

;; *************** function _Memory_Write *****************
;; Defined at:
;;		line 1763 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Addr            2    0[BANK0 ] unsigned int 
;;  Value           1    2[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  i               1    4[COMMON] volatile unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       3       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       3       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Page_ProgramData
;; This function uses a non-reentrant model
;;
psect	text38,local,class=CODE,delta=2,merge=1,group=0
	line	1763
global __ptext38
__ptext38:	;psect for function _Memory_Write
psect	text38
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	1763
	global	__size_of_Memory_Write
	__size_of_Memory_Write	equ	__end_of_Memory_Write-_Memory_Write
	
_Memory_Write:	
;incstack = 0
	opt	stack 6
; Regs used in _Memory_Write: [wreg+status,2]
	line	1766
	
l9576:	
;main.c: 1766: volatile unsigned char i = 0;
	clrf	(Memory_Write@i)	;volatile
	line	1769
	
l9578:	
;main.c: 1769: EEADR = Addr;
	movf	(Memory_Write@Addr),w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(391)^0180h	;volatile
	line	1770
	
l9580:	
;main.c: 1770: EEDAT= Value;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Memory_Write@Value),w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(390)^0180h	;volatile
	line	1771
;main.c: 1771: EECON1 = 0;
	clrf	(396)^0180h	;volsfr
	line	1772
	
l9582:	
;main.c: 1772: EEPGD = 0;
	bcf	(3175/8)^0180h,(3175)&7	;volsfr
	line	1773
	
l9584:	
;main.c: 1773: EECON1 | = 0x10;
	bsf	(396)^0180h+(4/8),(4)&7	;volsfr
	line	1774
# 1774 "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text38
	line	1777
	
l9586:	
;main.c: 1777: WREN = 1;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	bsf	(3170/8)^0180h,(3170)&7	;volsfr
	line	1778
	
l9588:	
;main.c: 1778: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	1779
	
l9590:	
;main.c: 1779: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	1780
	
l9592:	
;main.c: 1780: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	1781
;main.c: 1781: while(GIE)
	goto	l1349
	
l1350:	
	line	1783
;main.c: 1782: {
;main.c: 1783: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	1784
;main.c: 1784: if(0 == --i)
	decfsz	(Memory_Write@i),f	;volatile
	goto	u8091
	goto	u8090
u8091:
	goto	l1349
u8090:
	line	1787
	
l9594:	
;main.c: 1785: {
;main.c: 1787: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	1788
;main.c: 1788: return 0;
;	Return value of _Memory_Write is never used
	goto	l1352
	line	1790
	
l1349:	
	line	1781
	btfsc	(95/8),(95)&7	;volatile
	goto	u8101
	goto	u8100
u8101:
	goto	l1350
u8100:
	
l1353:	
	line	1791
# 1791 "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text38
	line	1793
	
l9596:	
;main.c: 1793: EECON2 = 0x55;
	movlw	low(055h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(397)^0180h	;volsfr
	line	1794
;main.c: 1794: EECON2 = 0xaa;
	movlw	low(0AAh)
	movwf	(397)^0180h	;volsfr
	line	1795
	
l9598:	
;main.c: 1795: WR = 1;
	bsf	(3169/8)^0180h,(3169)&7	;volsfr
	line	1796
# 1796 "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	1797
# 1797 "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	1798
# 1798 "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text38
	line	1799
	
l9600:	
;main.c: 1799: WREN = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	bcf	(3170/8)^0180h,(3170)&7	;volsfr
	line	1801
	
l9602:	
;main.c: 1801: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	1803
	
l9604:	
;main.c: 1803: if(WRERR) return 0;
	line	1805
	
l1352:	
	return
	opt stack 0
GLOBAL	__end_of_Memory_Write
	__end_of_Memory_Write:
	signat	_Memory_Write,8313
	global	_Led_Handle

;; *************** function _Led_Handle *****************
;; Defined at:
;;		line 970 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               2    4[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       2       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_LedControlSt
;;		___bmul
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text39,local,class=CODE,delta=2,merge=1,group=0
	line	970
global __ptext39
__ptext39:	;psect for function _Led_Handle
psect	text39
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	970
	global	__size_of_Led_Handle
	__size_of_Led_Handle	equ	__end_of_Led_Handle-_Led_Handle
	
_Led_Handle:	
;incstack = 0
	opt	stack 6
; Regs used in _Led_Handle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	971
	
l10652:	
;main.c: 971: unsigned int i=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(Led_Handle@i)
	clrf	(Led_Handle@i+1)
	line	973
;main.c: 973: for(i=0;i<6;i++){
	clrf	(Led_Handle@i)
	clrf	(Led_Handle@i+1)
	line	974
	
l10658:	
;main.c: 974: LedMod[i].LedTime++;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	bsf	status, 7	;select IRP bank2
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	975
;main.c: 975: switch(LedMod[i].LedState){
	goto	l10702
	line	977
	
l10660:	
;main.c: 977: LedControlSt(i,0);
	clrf	(LedControlSt@Sta)
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	978
;main.c: 978: break;
	goto	l10704
	line	980
	
l10662:	
;main.c: 980: LedControlSt(i,1);
	clrf	(LedControlSt@Sta)
	incf	(LedControlSt@Sta),f
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	981
;main.c: 981: break;
	goto	l10704
	line	983
	
l10664:	
;main.c: 983: if(LedMod[i].LedFlashNum){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movf	((??_Led_Handle+0)+0),w
iorwf	((??_Led_Handle+0)+1),w
	btfsc	status,2
	goto	u9871
	goto	u9870
u9871:
	goto	l1161
u9870:
	line	984
	
l10666:	
;main.c: 984: if(LedMod[i].LedTime<=25){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	01Ah
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9881
	goto	u9880
u9881:
	goto	l10670
u9880:
	line	985
	
l10668:	
;main.c: 985: LedControlSt(i,0);
	clrf	(LedControlSt@Sta)
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	986
;main.c: 986: }
	goto	l10704
	line	987
	
l10670:	
;main.c: 987: else if(LedMod[i].LedTime<=25*2)
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	033h
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9891
	goto	u9890
u9891:
	goto	l10674
u9890:
	line	989
	
l10672:	
;main.c: 988: {
;main.c: 989: LedControlSt(i,1);
	clrf	(LedControlSt@Sta)
	incf	(LedControlSt@Sta),f
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	990
;main.c: 990: }
	goto	l10704
	line	993
	
l10674:	
;main.c: 991: else
;main.c: 992: {
;main.c: 993: LedMod[i].LedFlashNum--;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	movlw	low(01h)
	bsf	status, 7	;select IRP bank2
	subwf	indf,f
	incfsz	fsr0,f
	movlw	high(01h)
	skipc
	decf	indf,f
	subwf	indf,f
	decf	fsr0,f
	line	994
;main.c: 994: LedMod[i].LedTime=0;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l10704
	line	997
	
l1161:	
	line	999
;main.c: 997: else
;main.c: 998: {
;main.c: 999: _BITS.Bits.bit_0=0;
	bcf	(__BITS),0
	goto	l10704
	line	1003
	
l10676:	
;main.c: 1003: if(LedMod[i].LedTime<=100){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	065h
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9901
	goto	u9900
u9901:
	goto	l10680
u9900:
	line	1004
	
l10678:	
;main.c: 1004: LedControlSt(i,1);
	clrf	(LedControlSt@Sta)
	incf	(LedControlSt@Sta),f
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	1005
;main.c: 1005: }
	goto	l10704
	line	1006
	
l10680:	
;main.c: 1006: else if(LedMod[i].LedTime<=100*2)
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	0C9h
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9911
	goto	u9910
u9911:
	goto	l10684
u9910:
	line	1008
	
l10682:	
;main.c: 1007: {
;main.c: 1008: LedControlSt(i,0);
	clrf	(LedControlSt@Sta)
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	1009
;main.c: 1009: }
	goto	l10704
	line	1012
	
l10684:	
;main.c: 1010: else
;main.c: 1011: {
;main.c: 1012: LedMod[i].LedTime=0;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l10704
	line	1017
	
l10686:	
;main.c: 1017: if(LedMod[i].LedFlashNum){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movf	((??_Led_Handle+0)+0),w
iorwf	((??_Led_Handle+0)+1),w
	btfsc	status,2
	goto	u9921
	goto	u9920
u9921:
	goto	l1173
u9920:
	line	1018
	
l10688:	
;main.c: 1018: if(LedMod[i].LedTime<=100){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	065h
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9931
	goto	u9930
u9931:
	goto	l10692
u9930:
	line	1019
	
l10690:	
;main.c: 1019: LedControlSt(i,0);
	clrf	(LedControlSt@Sta)
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	1020
;main.c: 1020: }
	goto	l10704
	line	1021
	
l10692:	
;main.c: 1021: else if(LedMod[i].LedTime<=100*2)
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	0C9h
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9941
	goto	u9940
u9941:
	goto	l10696
u9940:
	line	1023
	
l10694:	
;main.c: 1022: {
;main.c: 1023: LedControlSt(i,1);
	clrf	(LedControlSt@Sta)
	incf	(LedControlSt@Sta),f
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	1024
;main.c: 1024: }
	goto	l10704
	line	1027
	
l10696:	
;main.c: 1025: else
;main.c: 1026: {
;main.c: 1027: LedMod[i].LedFlashNum--;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	movlw	low(01h)
	bsf	status, 7	;select IRP bank2
	subwf	indf,f
	incfsz	fsr0,f
	movlw	high(01h)
	skipc
	decf	indf,f
	subwf	indf,f
	decf	fsr0,f
	line	1028
;main.c: 1028: LedMod[i].LedTime=0;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l10704
	line	1031
	
l1173:	
	line	1033
;main.c: 1031: else
;main.c: 1032: {
;main.c: 1033: _BITS.Bits.bit_0=0;
	bcf	(__BITS),0
	line	1034
	
l10698:	
;main.c: 1034: LedControlSt(i,0);
	clrf	(LedControlSt@Sta)
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	1035
;main.c: 1035: LedMod[i].LedState=0;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	goto	l10704
	line	975
	
l10702:	
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	; Switch size 1, requested type "space"
; Number of cases is 5, Range of values is 0 to 5
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           16     9 (average)
; direct_byte           26     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l10660
	xorlw	1^0	; case 1
	skipnz
	goto	l10662
	xorlw	2^1	; case 2
	skipnz
	goto	l10664
	xorlw	3^2	; case 3
	skipnz
	goto	l10676
	xorlw	5^3	; case 5
	skipnz
	goto	l10686
	goto	l10704
	opt asmopt_pop

	line	973
	
l10704:	
	incf	(Led_Handle@i),f
	skipnz
	incf	(Led_Handle@i+1),f
	
l10706:	
	movlw	0
	subwf	(Led_Handle@i+1),w
	movlw	06h
	skipnz
	subwf	(Led_Handle@i),w
	skipc
	goto	u9951
	goto	u9950
u9951:
	goto	l10658
u9950:
	line	1045
	
l1179:	
	return
	opt stack 0
GLOBAL	__end_of_Led_Handle
	__end_of_Led_Handle:
	signat	_Led_Handle,89
	global	_LedControlSt

;; *************** function _LedControlSt *****************
;; Defined at:
;;		line 888 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Num             1    wreg     unsigned char 
;;  Sta             1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  Num             1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Led_Handle
;; This function uses a non-reentrant model
;;
psect	text40,local,class=CODE,delta=2,merge=1,group=0
	line	888
global __ptext40
__ptext40:	;psect for function _LedControlSt
psect	text40
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	888
	global	__size_of_LedControlSt
	__size_of_LedControlSt	equ	__end_of_LedControlSt-_LedControlSt
	
_LedControlSt:	
;incstack = 0
	opt	stack 6
; Regs used in _LedControlSt: [wreg-fsr0h+status,2+status,0]
;LedControlSt@Num stored from wreg
	movwf	(LedControlSt@Num)
	line	890
	
l9416:	
;main.c: 890: switch(Num){
	goto	l9452
	line	892
	
l9418:	
;main.c: 892: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7751
	goto	u7750
u7751:
	goto	l1127
u7750:
	line	893
	
l9420:	
;main.c: 893: RB6=0;
	bcf	(54/8),(54)&7	;volatile
	line	894
;main.c: 894: }
	goto	l1151
	line	895
	
l1127:	
	line	897
;main.c: 895: else
;main.c: 896: {
;main.c: 897: RB6=1;
	bsf	(54/8),(54)&7	;volatile
	goto	l1151
	line	901
	
l9422:	
;main.c: 901: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7761
	goto	u7760
u7761:
	goto	l1131
u7760:
	line	902
	
l9424:	
;main.c: 902: RB3=0;
	bcf	(51/8),(51)&7	;volatile
	line	903
;main.c: 903: }
	goto	l1151
	line	904
	
l1131:	
	line	906
;main.c: 904: else
;main.c: 905: {
;main.c: 906: RB3=1;
	bsf	(51/8),(51)&7	;volatile
	goto	l1151
	line	910
	
l9426:	
;main.c: 910: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7771
	goto	u7770
u7771:
	goto	l1134
u7770:
	line	911
	
l9428:	
;main.c: 911: RA6=0;
	bcf	(46/8),(46)&7	;volatile
	line	912
;main.c: 912: }
	goto	l1151
	line	913
	
l1134:	
	line	915
;main.c: 913: else
;main.c: 914: {
;main.c: 915: RA6=1;
	bsf	(46/8),(46)&7	;volatile
	goto	l1151
	line	919
	
l9430:	
;main.c: 919: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7781
	goto	u7780
u7781:
	goto	l1137
u7780:
	line	920
	
l9432:	
;main.c: 920: RA7=0;
	bcf	(47/8),(47)&7	;volatile
	line	921
;main.c: 921: }
	goto	l1151
	line	922
	
l1137:	
	line	924
;main.c: 922: else
;main.c: 923: {
;main.c: 924: RA7=1;
	bsf	(47/8),(47)&7	;volatile
	goto	l1151
	line	928
	
l9434:	
;main.c: 928: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7791
	goto	u7790
u7791:
	goto	l1140
u7790:
	line	929
	
l9436:	
;main.c: 929: RB0=0;
	bcf	(48/8),(48)&7	;volatile
	line	930
;main.c: 930: }
	goto	l1151
	line	931
	
l1140:	
	line	933
;main.c: 931: else
;main.c: 932: {
;main.c: 933: RB0=1;
	bsf	(48/8),(48)&7	;volatile
	goto	l1151
	line	937
	
l9438:	
;main.c: 937: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7801
	goto	u7800
u7801:
	goto	l1143
u7800:
	line	938
	
l9440:	
;main.c: 938: RB2=0;
	bcf	(50/8),(50)&7	;volatile
	line	939
;main.c: 939: }
	goto	l1151
	line	940
	
l1143:	
	line	942
;main.c: 940: else
;main.c: 941: {
;main.c: 942: RB2=1;
	bsf	(50/8),(50)&7	;volatile
	goto	l1151
	line	946
	
l9442:	
;main.c: 946: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7811
	goto	u7810
u7811:
	goto	l1146
u7810:
	line	947
	
l9444:	
;main.c: 947: RB5=0;
	bcf	(53/8),(53)&7	;volatile
	line	948
;main.c: 948: }
	goto	l1151
	line	949
	
l1146:	
	line	951
;main.c: 949: else
;main.c: 950: {
;main.c: 951: RB5=1;
	bsf	(53/8),(53)&7	;volatile
	goto	l1151
	line	955
	
l9446:	
;main.c: 955: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7821
	goto	u7820
u7821:
	goto	l1149
u7820:
	line	956
	
l9448:	
;main.c: 956: RB4=0;
	bcf	(52/8),(52)&7	;volatile
	line	957
;main.c: 957: }
	goto	l1151
	line	958
	
l1149:	
	line	960
;main.c: 958: else
;main.c: 959: {
;main.c: 960: RB4=1;
	bsf	(52/8),(52)&7	;volatile
	goto	l1151
	line	890
	
l9452:	
	movf	(LedControlSt@Num),w
	; Switch size 1, requested type "space"
; Number of cases is 8, Range of values is 0 to 7
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           25    13 (average)
; direct_byte           32     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l9418
	xorlw	1^0	; case 1
	skipnz
	goto	l9422
	xorlw	2^1	; case 2
	skipnz
	goto	l9426
	xorlw	3^2	; case 3
	skipnz
	goto	l9430
	xorlw	4^3	; case 4
	skipnz
	goto	l9434
	xorlw	5^4	; case 5
	skipnz
	goto	l9438
	xorlw	6^5	; case 6
	skipnz
	goto	l9442
	xorlw	7^6	; case 7
	skipnz
	goto	l9446
	goto	l1151
	opt asmopt_pop

	line	966
	
l1151:	
	return
	opt stack 0
GLOBAL	__end_of_LedControlSt
	__end_of_LedControlSt:
	signat	_LedControlSt,8313
	global	_GetDelayFilterFlag

;; *************** function _GetDelayFilterFlag *****************
;; Defined at:
;;		line 412 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  PtrMin          1    wreg     PTR struct .
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;; Auto vars:     Size  Location     Type
;;  PtrMin          1    5[BANK0 ] PTR struct .
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0       3       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Dec
;;		_DecF
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text41,local,class=CODE,delta=2,merge=1,group=0
	line	412
global __ptext41
__ptext41:	;psect for function _GetDelayFilterFlag
psect	text41
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	412
	global	__size_of_GetDelayFilterFlag
	__size_of_GetDelayFilterFlag	equ	__end_of_GetDelayFilterFlag-_GetDelayFilterFlag
	
_GetDelayFilterFlag:	
;incstack = 0
	opt	stack 6
; Regs used in _GetDelayFilterFlag: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;GetDelayFilterFlag@PtrMin stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(GetDelayFilterFlag@PtrMin)
	line	415
	
l10322:	
;main.c: 415: if(Dec(&PtrMin->u8Second,59))
	movlw	low(03Bh)
	movwf	(Dec@max)
	movf	(GetDelayFilterFlag@PtrMin),w
	fcall	_Dec
	xorlw	0
	skipnz
	goto	u9221
	goto	u9220
u9221:
	goto	l10332
u9220:
	line	417
	
l10324:	
;main.c: 416: {
;main.c: 417: if(Dec(&PtrMin->u8Minute,59))
	movlw	low(03Bh)
	movwf	(Dec@max)
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	01h
	fcall	_Dec
	xorlw	0
	skipnz
	goto	u9231
	goto	u9230
u9231:
	goto	l10332
u9230:
	line	419
	
l10326:	
;main.c: 418: {
;main.c: 419: if(Dec(&PtrMin->u8Hour,23))
	movlw	low(017h)
	movwf	(Dec@max)
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	02h
	fcall	_Dec
	xorlw	0
	skipnz
	goto	u9241
	goto	u9240
u9241:
	goto	l10332
u9240:
	line	421
	
l10328:	
;main.c: 420: {
;main.c: 421: if(DecF(&PtrMin->u16Day,65535))
	movlw	0FFh
	movwf	(DecF@max)
	movlw	0FFh
	movwf	((DecF@max))+1
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	03h
	fcall	_DecF
	xorlw	0
	skipnz
	goto	u9251
	goto	u9250
u9251:
	goto	l1044
u9250:
	goto	l1047
	line	426
	
l1044:	
	line	428
	
l10332:	
;main.c: 424: }
;main.c: 425: }
;main.c: 426: }
;main.c: 427: }
;main.c: 428: if(FilterFastCheck==1){
		decf	((_FilterFastCheck)),w
	btfss	status,2
	goto	u9261
	goto	u9260
u9261:
	goto	l1047
u9260:
	line	429
	
l10334:	
;main.c: 429: if(PtrMin->u16Day>=1)
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	03h
	movwf	fsr0
	movf	indf,w
	movwf	(??_GetDelayFilterFlag+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_GetDelayFilterFlag+0)+0+1
	movf	((??_GetDelayFilterFlag+0)+0),w
iorwf	((??_GetDelayFilterFlag+0)+1),w
	btfsc	status,2
	goto	u9271
	goto	u9270
u9271:
	goto	l10338
u9270:
	line	430
	
l10336:	
;main.c: 430: PtrMin->u16Day-=1;
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	03h
	movwf	fsr0
	movlw	low(01h)
	subwf	indf,f
	incfsz	fsr0,f
	movlw	high(01h)
	skipc
	decf	indf,f
	subwf	indf,f
	decf	fsr0,f
	goto	l1047
	line	432
	
l10338:	
;main.c: 431: else
;main.c: 432: PtrMin->u16Day=0;
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	03h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	436
	
l1047:	
	return
	opt stack 0
GLOBAL	__end_of_GetDelayFilterFlag
	__end_of_GetDelayFilterFlag:
	signat	_GetDelayFilterFlag,4217
	global	_DecF

;; *************** function _DecF *****************
;; Defined at:
;;		line 396 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  var             1    wreg     PTR unsigned int 
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;;  max             2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  var             1    2[BANK0 ] PTR unsigned int 
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       2       0       0
;;      Totals:         2       3       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_GetDelayFilterFlag
;; This function uses a non-reentrant model
;;
psect	text42,local,class=CODE,delta=2,merge=1,group=0
	line	396
global __ptext42
__ptext42:	;psect for function _DecF
psect	text42
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	396
	global	__size_of_DecF
	__size_of_DecF	equ	__end_of_DecF-_DecF
	
_DecF:	
;incstack = 0
	opt	stack 6
; Regs used in _DecF: [wreg-fsr0h+status,2+status,0]
;DecF@var stored from wreg
	movwf	(DecF@var)
	line	398
	
l9386:	
;main.c: 398: if((*var)){(*var)--;}
	movf	(DecF@var),w
	movwf	fsr0
	movf	indf,w
	movwf	(??_DecF+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_DecF+0)+0+1
	movf	((??_DecF+0)+0),w
iorwf	((??_DecF+0)+1),w
	btfsc	status,2
	goto	u7731
	goto	u7730
u7731:
	goto	l9390
u7730:
	
l9388:	
	movf	(DecF@var),w
	movwf	fsr0
	movlw	low(01h)
	subwf	indf,f
	incfsz	fsr0,f
	movlw	high(01h)
	skipc
	decf	indf,f
	subwf	indf,f
	decf	fsr0,f
	goto	l9394
	line	399
	
l9390:	
;main.c: 399: else{return(1);}
	movlw	low(01h)
	goto	l1037
	line	401
	
l9394:	
;main.c: 401: return(0);
	movlw	low(0)
	line	402
	
l1037:	
	return
	opt stack 0
GLOBAL	__end_of_DecF
	__end_of_DecF:
	signat	_DecF,8313
	global	_Dec

;; *************** function _Dec *****************
;; Defined at:
;;		line 388 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  var             1    wreg     PTR unsigned char 
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;;  max             1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  var             1    5[COMMON] PTR unsigned char 
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : B00/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_GetDelayFilterFlag
;; This function uses a non-reentrant model
;;
psect	text43,local,class=CODE,delta=2,merge=1,group=0
	line	388
global __ptext43
__ptext43:	;psect for function _Dec
psect	text43
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	388
	global	__size_of_Dec
	__size_of_Dec	equ	__end_of_Dec-_Dec
	
_Dec:	
;incstack = 0
	opt	stack 6
; Regs used in _Dec: [wreg-fsr0h+status,2+status,0]
;Dec@var stored from wreg
	movwf	(Dec@var)
	line	390
	
l9372:	
;main.c: 390: if((*var)){(*var)--;}
	movf	(Dec@var),w
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	(indf),w
	btfsc	status,2
	goto	u7721
	goto	u7720
u7721:
	goto	l9376
u7720:
	
l9374:	
	movf	(Dec@var),w
	movwf	fsr0
	decf	indf,f
	goto	l9382
	line	391
	
l9376:	
;main.c: 391: else{(*var)=max;return(1);}
	movf	(Dec@var),w
	movwf	fsr0
	movf	(Dec@max),w
	movwf	indf
	
l9378:	
	movlw	low(01h)
	goto	l1032
	line	393
	
l9382:	
;main.c: 393: return(0);
	movlw	low(0)
	line	394
	
l1032:	
	return
	opt stack 0
GLOBAL	__end_of_Dec
	__end_of_Dec:
	signat	_Dec,8313
	global	_FilterLifeFunc

;; *************** function _FilterLifeFunc *****************
;; Defined at:
;;		line 1257 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_BuzzerSet
;;		_FilterTimeHandle
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text44,local,class=CODE,delta=2,merge=1,group=0
	line	1257
global __ptext44
__ptext44:	;psect for function _FilterLifeFunc
psect	text44
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	1257
	global	__size_of_FilterLifeFunc
	__size_of_FilterLifeFunc	equ	__end_of_FilterLifeFunc-_FilterLifeFunc
	
_FilterLifeFunc:	
;incstack = 0
	opt	stack 4
; Regs used in _FilterLifeFunc: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1261
	
l10620:	
;main.c: 1261: if((Mode!=0)&&(Mode!=3)&&(_BITS.Bits.bit_0==0)){
	movf	((_Mode)),w
	btfsc	status,2
	goto	u9781
	goto	u9780
u9781:
	goto	l1223
u9780:
	
l10622:	
		movlw	3
	xorwf	((_Mode)),w
	btfsc	status,2
	goto	u9791
	goto	u9790
u9791:
	goto	l1223
u9790:
	
l10624:	
	btfsc	(__BITS),0
	goto	u9801
	goto	u9800
u9801:
	goto	l1223
u9800:
	line	1262
	
l10626:	
;main.c: 1262: FilterTimeHandle(FilterRO_time,&FilterROState,1,&FilterROGetWater);
	movlw	(FilterTimeHandle@Filter_time)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_FilterRO_time)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterRO_time)^080h+1,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterRO_time)^080h+2,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterRO_time)^080h+3,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterRO_time)^080h+4,w
	movwf	indf
	movlw	(low(_FilterROState|((0x0)<<8)))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	movwf	(FilterTimeHandle@FilterState)
	clrf	(FilterTimeHandle@Type)
	incf	(FilterTimeHandle@Type),f
	movlw	(low(_FilterROGetWater|((0x0)<<8)))&0ffh
	movwf	(FilterTimeHandle@FilterGetWater)
	fcall	_FilterTimeHandle
	line	1265
;main.c: 1265: FilterTimeHandle(FilterPCF_time,&FilterPCFState,0,&FilterPCFGetWater);
	movlw	(FilterTimeHandle@Filter_time)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_FilterPCF_time)^080h,w
	bcf	status, 7	;select IRP bank0
	movwf	indf
	incf	fsr0,f
	movf	(_FilterPCF_time)^080h+1,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterPCF_time)^080h+2,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterPCF_time)^080h+3,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterPCF_time)^080h+4,w
	movwf	indf
	movlw	(low(_FilterPCFState|((0x0)<<8)))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	movwf	(FilterTimeHandle@FilterState)
	clrf	(FilterTimeHandle@Type)
	movlw	(low(_FilterPCFGetWater|((0x0)<<8)))&0ffh
	movwf	(FilterTimeHandle@FilterGetWater)
	fcall	_FilterTimeHandle
	line	1266
	
l10628:	
;main.c: 1266: if(FilterFastCheck==1)
	bcf	status, 5	;RP0=0, select bank0
		decf	((_FilterFastCheck)),w
	btfss	status,2
	goto	u9811
	goto	u9810
u9811:
	goto	l1223
u9810:
	line	1268
	
l10630:	
;main.c: 1267: {
;main.c: 1268: if((FilterPCFState==3)&&(FilterROState==3)){
		movlw	3
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u9821
	goto	u9820
u9821:
	goto	l1223
u9820:
	
l10632:	
		movlw	3
	xorwf	((_FilterROState)),w
	btfss	status,2
	goto	u9831
	goto	u9830
u9831:
	goto	l1223
u9830:
	line	1269
	
l10634:	
;main.c: 1269: FilterFastCheck=2;
	movlw	low(02h)
	movwf	(_FilterFastCheck)
	line	1270
	
l10636:	
;main.c: 1270: BuzzerSet(3, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(03h)
	fcall	_BuzzerSet
	line	1277
	
l1223:	
	return
	opt stack 0
GLOBAL	__end_of_FilterLifeFunc
	__end_of_FilterLifeFunc:
	signat	_FilterLifeFunc,89
	global	_FilterTimeHandle

;; *************** function _FilterTimeHandle *****************
;; Defined at:
;;		line 1147 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Filter_time     5    3[BANK0 ] struct .
;;  FilterState     1    8[BANK0 ] PTR unsigned char 
;;		 -> FilterPCFState(1), FilterROState(1), 
;;  Type            1    9[BANK0 ] unsigned char 
;;  FilterGetWat    1   10[BANK0 ] PTR unsigned int 
;;		 -> FilterPCFGetWater(2), FilterROGetWater(2), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       8       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       4       0       0
;;      Totals:         0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_LedSetSt
;; This function is called by:
;;		_FilterLifeFunc
;; This function uses a non-reentrant model
;;
psect	text45,local,class=CODE,delta=2,merge=1,group=0
	line	1147
global __ptext45
__ptext45:	;psect for function _FilterTimeHandle
psect	text45
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	1147
	global	__size_of_FilterTimeHandle
	__size_of_FilterTimeHandle	equ	__end_of_FilterTimeHandle-_FilterTimeHandle
	
_FilterTimeHandle:	
;incstack = 0
	opt	stack 4
; Regs used in _FilterTimeHandle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1150
	
l9454:	
;main.c: 1150: Date_Temp=14;
	movlw	0Eh
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Date_Temp)^080h
	clrf	(_Date_Temp+1)^080h
	line	1151
	
l9456:	
;main.c: 1151: if(_BITS.Bits.bit_1==1) return;
	btfss	(__BITS),1
	goto	u7831
	goto	u7830
u7831:
	goto	l9460
u7830:
	goto	l1187
	line	1152
	
l9460:	
;main.c: 1152: if(Type==0){
	bcf	status, 5	;RP0=0, select bank0
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7841
	goto	u7840
u7841:
	goto	l9464
u7840:
	line	1153
	
l9462:	
;main.c: 1153: ML_Temp=3650;
	movlw	042h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_ML_Temp)^080h
	movlw	0Eh
	movwf	((_ML_Temp)^080h)+1
	line	1154
;main.c: 1154: }
	goto	l9466
	line	1157
	
l9464:	
;main.c: 1155: else
;main.c: 1156: {
;main.c: 1157: ML_Temp=10950;
	movlw	0C6h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_ML_Temp)^080h
	movlw	02Ah
	movwf	((_ML_Temp)^080h)+1
	line	1160
	
l9466:	
;main.c: 1158: }
;main.c: 1160: if(Filter_time.u16Day<=0){
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(FilterTimeHandle@Filter_time)+03h),w
iorwf	(1+(FilterTimeHandle@Filter_time)+03h),w
	btfss	status,2
	goto	u7851
	goto	u7850
u7851:
	goto	l9476
u7850:
	line	1162
	
l9468:	
;main.c: 1162: *FilterState=3;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(03h)
	movwf	indf
	line	1163
	
l9470:	
;main.c: 1163: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7861
	goto	u7860
u7861:
	goto	l9474
u7860:
	line	1164
	
l9472:	
;main.c: 1164: LedSetSt(4,1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(04h)
	fcall	_LedSetSt
	line	1165
;main.c: 1165: LedSetSt(5, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1166
;main.c: 1166: }
	goto	l1193
	line	1169
	
l9474:	
;main.c: 1167: else
;main.c: 1168: {
;main.c: 1169: LedSetSt(2, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(02h)
	fcall	_LedSetSt
	line	1170
;main.c: 1170: LedSetSt(3, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	goto	l1193
	line	1173
	
l9476:	
;main.c: 1173: else if(Filter_time.u16Day<=Date_Temp)
	movlw	0
	subwf	1+(FilterTimeHandle@Filter_time)+03h,w
	movlw	0Fh
	skipnz
	subwf	0+(FilterTimeHandle@Filter_time)+03h,w
	skipnc
	goto	u7871
	goto	u7870
u7871:
	goto	l9490
u7870:
	line	1175
	
l9478:	
;main.c: 1174: {
;main.c: 1175: if(*FilterState!=2){
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
		movlw	2
	xorwf	(indf),w
	btfsc	status,2
	goto	u7881
	goto	u7880
u7881:
	goto	l9486
u7880:
	line	1176
	
l9480:	
;main.c: 1176: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7891
	goto	u7890
u7891:
	goto	l9484
u7890:
	line	1177
	
l9482:	
;main.c: 1177: LedSetSt(4, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1178
;main.c: 1178: LedSetSt(5, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1179
;main.c: 1179: }
	goto	l9486
	line	1182
	
l9484:	
;main.c: 1180: else
;main.c: 1181: {
;main.c: 1182: LedSetSt(2, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1183
;main.c: 1183: LedSetSt(3, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1186
	
l9486:	
;main.c: 1184: }
;main.c: 1185: }
;main.c: 1186: if(*FilterState<=2)
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(03h)
	bcf	status, 7	;select IRP bank0
	subwf	indf,w
	skipnc
	goto	u7901
	goto	u7900
u7901:
	goto	l1193
u7900:
	line	1187
	
l9488:	
;main.c: 1187: *FilterState=2;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(02h)
	movwf	indf
	goto	l1193
	line	1191
	
l9490:	
;main.c: 1189: else
;main.c: 1190: {
;main.c: 1191: if(*FilterState==1){
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
		decf	(indf),w
	btfss	status,2
	goto	u7911
	goto	u7910
u7911:
	goto	l9498
u7910:
	line	1192
	
l9492:	
;main.c: 1192: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7921
	goto	u7920
u7921:
	goto	l9496
u7920:
	line	1193
	
l9494:	
;main.c: 1193: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1194
;main.c: 1194: LedSetSt(5, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(05h)
	fcall	_LedSetSt
	line	1195
;main.c: 1195: }
	goto	l9498
	line	1198
	
l9496:	
;main.c: 1196: else
;main.c: 1197: {
;main.c: 1198: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1199
;main.c: 1199: LedSetSt(3, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(03h)
	fcall	_LedSetSt
	line	1202
	
l9498:	
;main.c: 1200: }
;main.c: 1201: }
;main.c: 1202: if(*FilterState<=1)
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(02h)
	bcf	status, 7	;select IRP bank0
	subwf	indf,w
	skipnc
	goto	u7931
	goto	u7930
u7931:
	goto	l1193
u7930:
	line	1203
	
l9500:	
;main.c: 1203: *FilterState=1;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	1204
	
l1193:	
	line	1207
;main.c: 1204: }
;main.c: 1207: if(*FilterGetWater>=ML_Temp){
	movf	(FilterTimeHandle@FilterGetWater),w
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	movwf	(??_FilterTimeHandle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_FilterTimeHandle+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(_ML_Temp+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_FilterTimeHandle+0)+0,w
	skipz
	goto	u7945
	bsf	status, 5	;RP0=1, select bank1
	movf	(_ML_Temp)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_FilterTimeHandle+0)+0,w
u7945:
	skipc
	goto	u7941
	goto	u7940
u7941:
	goto	l9510
u7940:
	line	1209
	
l9502:	
;main.c: 1209: *FilterState=3;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(03h)
	movwf	indf
	line	1210
	
l9504:	
;main.c: 1210: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7951
	goto	u7950
u7951:
	goto	l9508
u7950:
	line	1211
	
l9506:	
;main.c: 1211: LedSetSt(4, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(04h)
	fcall	_LedSetSt
	line	1212
;main.c: 1212: LedSetSt(5, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1213
;main.c: 1213: }
	goto	l1187
	line	1216
	
l9508:	
;main.c: 1214: else
;main.c: 1215: {
;main.c: 1216: LedSetSt(2, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(02h)
	fcall	_LedSetSt
	line	1217
;main.c: 1217: LedSetSt(3, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	goto	l1187
	line	1220
	
l9510:	
;main.c: 1220: else if(*FilterGetWater>=ML_Temp-140)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_ML_Temp)^080h,w
	addlw	low(0FF74h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_FilterTimeHandle+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_ML_Temp+1)^080h,w
	skipnc
	addlw	1
	addlw	high(0FF74h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_FilterTimeHandle+0)+0
	movf	(FilterTimeHandle@FilterGetWater),w
	movwf	fsr0
	movf	indf,w
	movwf	(??_FilterTimeHandle+2)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_FilterTimeHandle+2)+0+1
	movf	1+(??_FilterTimeHandle+0)+0,w
	subwf	1+(??_FilterTimeHandle+2)+0,w
	skipz
	goto	u7965
	movf	0+(??_FilterTimeHandle+0)+0,w
	subwf	0+(??_FilterTimeHandle+2)+0,w
u7965:
	skipc
	goto	u7961
	goto	u7960
u7961:
	goto	l9524
u7960:
	line	1223
	
l9512:	
;main.c: 1222: {
;main.c: 1223: if(*FilterState!=2){
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
		movlw	2
	xorwf	(indf),w
	btfsc	status,2
	goto	u7971
	goto	u7970
u7971:
	goto	l9520
u7970:
	line	1224
	
l9514:	
;main.c: 1224: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7981
	goto	u7980
u7981:
	goto	l9518
u7980:
	line	1225
	
l9516:	
;main.c: 1225: LedSetSt(4, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1226
;main.c: 1226: LedSetSt(5, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1227
;main.c: 1227: }
	goto	l9520
	line	1230
	
l9518:	
;main.c: 1228: else
;main.c: 1229: {
;main.c: 1230: LedSetSt(2, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1231
;main.c: 1231: LedSetSt(3, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1234
	
l9520:	
;main.c: 1232: }
;main.c: 1233: }
;main.c: 1234: if(*FilterState<=2)
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(03h)
	bcf	status, 7	;select IRP bank0
	subwf	indf,w
	skipnc
	goto	u7991
	goto	u7990
u7991:
	goto	l1187
u7990:
	line	1235
	
l9522:	
;main.c: 1235: *FilterState=2;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(02h)
	movwf	indf
	goto	l1187
	line	1239
	
l9524:	
;main.c: 1237: else
;main.c: 1238: {
;main.c: 1239: if(*FilterState==1){
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
		decf	(indf),w
	btfss	status,2
	goto	u8001
	goto	u8000
u8001:
	goto	l9532
u8000:
	line	1240
	
l9526:	
;main.c: 1240: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u8011
	goto	u8010
u8011:
	goto	l9530
u8010:
	line	1241
	
l9528:	
;main.c: 1241: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1242
;main.c: 1242: LedSetSt(5, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(05h)
	fcall	_LedSetSt
	line	1243
;main.c: 1243: }
	goto	l9532
	line	1246
	
l9530:	
;main.c: 1244: else
;main.c: 1245: {
;main.c: 1246: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1247
;main.c: 1247: LedSetSt(3, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(03h)
	fcall	_LedSetSt
	line	1250
	
l9532:	
;main.c: 1248: }
;main.c: 1249: }
;main.c: 1250: if(*FilterState<=1)
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(02h)
	bcf	status, 7	;select IRP bank0
	subwf	indf,w
	skipnc
	goto	u8021
	goto	u8020
u8021:
	goto	l1187
u8020:
	line	1251
	
l9534:	
;main.c: 1251: *FilterState=1;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	1254
	
l1187:	
	return
	opt stack 0
GLOBAL	__end_of_FilterTimeHandle
	__end_of_FilterTimeHandle:
	signat	_FilterTimeHandle,16505
	global	_FilterKeyInputRest

;; *************** function _FilterKeyInputRest *****************
;; Defined at:
;;		line 1619 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_BuzzerSet
;;		_LedSetSt
;;		_SetFilterDelayReset
;;		_ShiftMode_Handle
;;		_WrterEEP
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text46,local,class=CODE,delta=2,merge=1,group=0
	line	1619
global __ptext46
__ptext46:	;psect for function _FilterKeyInputRest
psect	text46
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	1619
	global	__size_of_FilterKeyInputRest
	__size_of_FilterKeyInputRest	equ	__end_of_FilterKeyInputRest-_FilterKeyInputRest
	
_FilterKeyInputRest:	
;incstack = 0
	opt	stack 4
; Regs used in _FilterKeyInputRest: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1621
	
l10708:	
;main.c: 1620: static U16_T FilterSelect_10ms;
;main.c: 1621: if((Mode==0)||(Mode==3)) return;
	movf	((_Mode)),w
	btfsc	status,2
	goto	u9961
	goto	u9960
u9961:
	goto	l1320
u9960:
	
l10710:	
		movlw	3
	xorwf	((_Mode)),w
	btfss	status,2
	goto	u9971
	goto	u9970
u9971:
	goto	l10712
u9970:
	goto	l1320
	
l1319:	
	goto	l1320
	line	1623
	
l10712:	
;main.c: 1622: if((KeyPacket_y[1].KeyState==LongPressDown)
;main.c: 1623: &&(KeyPacket_y[2].KeyState==NotPress))
		movlw	2
	xorwf	(0+(_KeyPacket_y)+03h),w
	btfss	status,2
	goto	u9981
	goto	u9980
u9981:
	goto	l10766
u9980:
	
l10714:	
	movf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u9991
	goto	u9990
u9991:
	goto	l10766
u9990:
	line	1625
	
l10716:	
;main.c: 1624: {
;main.c: 1625: KeyPacket_y[1].KeyState=SuperPressDown;
	movlw	low(03h)
	movwf	0+(_KeyPacket_y)+03h
	line	1626
;main.c: 1626: if(Time_Power_1s<=10){
	movlw	low(0Bh)
	subwf	(_Time_Power_1s),w
	skipnc
	goto	u10001
	goto	u10000
u10001:
	goto	l10722
u10000:
	line	1627
	
l10718:	
;main.c: 1627: ShiftMode_Handle(5);
	movlw	low(05h)
	fcall	_ShiftMode_Handle
	line	1628
	
l10720:	
;main.c: 1628: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1629
;main.c: 1629: }
	goto	l10764
	line	1632
	
l10722:	
;main.c: 1630: else
;main.c: 1631: {
;main.c: 1632: _BITS.Bits.bit_1^=1;
	movlw	1<<1
	xorwf	(__BITS),f
	line	1633
	
l10724:	
;main.c: 1633: if(_BITS.Bits.bit_1==0){
	btfsc	(__BITS),1
	goto	u10011
	goto	u10010
u10011:
	goto	l1324
u10010:
	line	1634
	
l10726:	
;main.c: 1634: FilterSelect_10ms=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(FilterKeyInputRest@FilterSelect_10ms)^080h
	clrf	(FilterKeyInputRest@FilterSelect_10ms+1)^080h
	line	1635
	
l10728:	
;main.c: 1635: if(_BITS.Bits.bit_3==0)
	btfsc	(__BITS),3
	goto	u10021
	goto	u10020
u10021:
	goto	l10744
u10020:
	line	1637
	
l10730:	
;main.c: 1636: {
;main.c: 1637: PrePCFu16Day=FilterPCF_time.u16Day;
	movf	1+(_FilterPCF_time)^080h+03h,w
	movwf	(_PrePCFu16Day+1)^080h
	movf	0+(_FilterPCF_time)^080h+03h,w
	movwf	(_PrePCFu16Day)^080h
	line	1638
	
l10732:	
;main.c: 1638: SetFilterDelayReset(&FilterPCF_time, 365, 0, 0, 0);
	movlw	06Dh
	bcf	status, 5	;RP0=0, select bank0
	movwf	(SetFilterDelayReset@Day)
	movlw	01h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterPCF_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	1639
	
l10734:	
;main.c: 1639: FilterPCFGetWater=0;
	clrf	(_FilterPCFGetWater)
	clrf	(_FilterPCFGetWater+1)
	line	1640
	
l10736:	
;main.c: 1640: FilterPCFState=1;
	clrf	(_FilterPCFState)
	incf	(_FilterPCFState),f
	line	1641
	
l10738:	
;main.c: 1641: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1642
	
l10740:	
;main.c: 1642: LedSetSt(5, 2);
	movlw	low(02h)
	movwf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1643
	
l10742:	
;main.c: 1643: _BITS1.Bits.bit_3=1;
	bsf	(__BITS1),3
	line	1644
;main.c: 1644: }
	goto	l10758
	line	1647
	
l10744:	
;main.c: 1645: else
;main.c: 1646: {
;main.c: 1647: PreROu16Day=FilterRO_time.u16Day;
	movf	1+(_FilterRO_time)^080h+03h,w
	movwf	(_PreROu16Day+1)^080h
	movf	0+(_FilterRO_time)^080h+03h,w
	movwf	(_PreROu16Day)^080h
	line	1648
	
l10746:	
;main.c: 1648: SetFilterDelayReset(&FilterRO_time, 1095, 0, 0, 0);
	movlw	047h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(SetFilterDelayReset@Day)
	movlw	04h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterRO_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	1649
	
l10748:	
;main.c: 1649: FilterROGetWater=0;
	clrf	(_FilterROGetWater)
	clrf	(_FilterROGetWater+1)
	line	1650
	
l10750:	
;main.c: 1650: FilterROState=1;
	clrf	(_FilterROState)
	incf	(_FilterROState),f
	line	1651
	
l10752:	
;main.c: 1651: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1652
	
l10754:	
;main.c: 1652: LedSetSt(3, 2);
	movlw	low(02h)
	movwf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1653
	
l10756:	
;main.c: 1653: _BITS1.Bits.bit_2=1;
	bsf	(__BITS1),2
	line	1655
	
l10758:	
;main.c: 1654: }
;main.c: 1655: _BITS1.Bits.bit_7=0;
	bcf	(__BITS1),7
	line	1656
	
l10760:	
;main.c: 1656: FilterRst_1s=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_FilterRst_1s)^080h
	clrf	(_FilterRst_1s+1)^080h
	line	1657
	
l10762:	
;main.c: 1657: WrterEEP();
	fcall	_WrterEEP
	line	1658
;main.c: 1658: }
	goto	l10764
	line	1659
	
l1324:	
	line	1661
;main.c: 1659: else
;main.c: 1660: {
;main.c: 1661: _BITS.Bits.bit_3=1;
	bsf	(__BITS),3
	line	1664
	
l10764:	
;main.c: 1662: }
;main.c: 1663: }
;main.c: 1664: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1666
	
l10766:	
;main.c: 1665: }
;main.c: 1666: if(_BITS.Bits.bit_1==1){
	btfss	(__BITS),1
	goto	u10031
	goto	u10030
u10031:
	goto	l10804
u10030:
	line	1667
	
l10768:	
;main.c: 1667: if(++FilterSelect_10ms>=1000){
	bsf	status, 5	;RP0=1, select bank1
	incf	(FilterKeyInputRest@FilterSelect_10ms)^080h,f
	skipnz
	incf	(FilterKeyInputRest@FilterSelect_10ms+1)^080h,f
	movlw	03h
	subwf	((FilterKeyInputRest@FilterSelect_10ms+1)^080h),w
	movlw	0E8h
	skipnz
	subwf	((FilterKeyInputRest@FilterSelect_10ms)^080h),w
	skipc
	goto	u10041
	goto	u10040
u10041:
	goto	l10778
u10040:
	line	1668
	
l10770:	
;main.c: 1668: FilterSelect_10ms=0;
	clrf	(FilterKeyInputRest@FilterSelect_10ms)^080h
	clrf	(FilterKeyInputRest@FilterSelect_10ms+1)^080h
	line	1669
	
l10772:	
;main.c: 1669: BuzzerSet(1, 50);
	movlw	032h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1670
	
l10774:	
;main.c: 1670: _BITS.Bits.bit_1=0;
	bcf	(__BITS),1
	goto	l1320
	line	1674
	
l10778:	
;main.c: 1673: }
;main.c: 1674: if(KeyPacket_y[1].KeyState==ShortRelease)
		movlw	6
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(0+(_KeyPacket_y)+03h),w
	btfss	status,2
	goto	u10051
	goto	u10050
u10051:
	goto	l10786
u10050:
	line	1677
	
l10780:	
;main.c: 1677: BuzzerSet(1, 50);
	movlw	032h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1678
	
l10782:	
;main.c: 1678: FilterSelect_10ms=0;
	clrf	(FilterKeyInputRest@FilterSelect_10ms)^080h
	clrf	(FilterKeyInputRest@FilterSelect_10ms+1)^080h
	line	1679
	
l10784:	
;main.c: 1679: _BITS.Bits.bit_3^=1;
	movlw	1<<3
	xorwf	(__BITS),f
	line	1682
	
l10786:	
;main.c: 1680: }
;main.c: 1682: if(_BITS.Bits.bit_3==0){
	btfsc	(__BITS),3
	goto	u10061
	goto	u10060
u10061:
	goto	l10796
u10060:
	line	1683
	
l10788:	
;main.c: 1683: LedSetSt(3,0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1684
;main.c: 1684: LedSetSt(2,0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1685
	
l10790:	
;main.c: 1685: if(FilterPCFState==1){
		decf	((_FilterPCFState)),w
	btfss	status,2
	goto	u10071
	goto	u10070
u10071:
	goto	l10794
u10070:
	line	1686
	
l10792:	
;main.c: 1686: LedSetSt(5, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1687
;main.c: 1687: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1688
;main.c: 1688: }
	goto	l10804
	line	1691
	
l10794:	
;main.c: 1689: else
;main.c: 1690: {
;main.c: 1691: LedSetSt(4, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1692
;main.c: 1692: LedSetSt(5, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	goto	l10804
	line	1697
	
l10796:	
;main.c: 1695: else
;main.c: 1696: {
;main.c: 1697: LedSetSt(5,0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1698
;main.c: 1698: LedSetSt(4,0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1699
	
l10798:	
;main.c: 1699: if(FilterROState==1){
		decf	((_FilterROState)),w
	btfss	status,2
	goto	u10081
	goto	u10080
u10081:
	goto	l10802
u10080:
	line	1700
	
l10800:	
;main.c: 1700: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1701
;main.c: 1701: LedSetSt(3, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1702
;main.c: 1702: }
	goto	l10804
	line	1705
	
l10802:	
;main.c: 1703: else
;main.c: 1704: {
;main.c: 1705: LedSetSt(3, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1706
;main.c: 1706: LedSetSt(2, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1712
	
l10804:	
;main.c: 1707: }
;main.c: 1708: }
;main.c: 1709: }
;main.c: 1711: if((KeyPacket_y[2].KeyState==LongPressDown)
;main.c: 1712: &&(KeyPacket_y[1].KeyState==LongPressDown))
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u10091
	goto	u10090
u10091:
	goto	l1320
u10090:
	
l10806:	
		movlw	2
	xorwf	(0+(_KeyPacket_y)+03h),w
	btfss	status,2
	goto	u10101
	goto	u10100
u10101:
	goto	l1320
u10100:
	line	1714
	
l10808:	
;main.c: 1713: {
;main.c: 1714: KeyPacket_y[2].KeyState=SuperPressDown;
	movlw	low(03h)
	movwf	0+(_KeyPacket_y)+06h
	line	1715
;main.c: 1715: KeyPacket_y[1].KeyState=SuperPressDown;
	movlw	low(03h)
	movwf	0+(_KeyPacket_y)+03h
	line	1717
;main.c: 1717: if(Time_Power_1s<=10){
	movlw	low(0Bh)
	subwf	(_Time_Power_1s),w
	skipnc
	goto	u10111
	goto	u10110
u10111:
	goto	l10830
u10110:
	line	1718
	
l10810:	
;main.c: 1718: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1720
	
l10812:	
;main.c: 1720: ShiftMode_Handle(0);
	movlw	low(0)
	fcall	_ShiftMode_Handle
	line	1721
	
l10814:	
;main.c: 1721: PowerStep=3;
	movlw	low(03h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_PowerStep)
	line	1722
	
l10816:	
;main.c: 1722: SetFilterDelayReset(&FilterPCF_time, 365, 0, 0, 0);
	movlw	06Dh
	movwf	(SetFilterDelayReset@Day)
	movlw	01h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterPCF_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	1723
	
l10818:	
;main.c: 1723: SetFilterDelayReset(&FilterRO_time, 1095, 0, 0, 0);
	movlw	047h
	movwf	(SetFilterDelayReset@Day)
	movlw	04h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterRO_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	1724
	
l10820:	
;main.c: 1724: FilterROGetWater=0;
	clrf	(_FilterROGetWater)
	clrf	(_FilterROGetWater+1)
	line	1725
	
l10822:	
;main.c: 1725: FilterPCFGetWater=0;
	clrf	(_FilterPCFGetWater)
	clrf	(_FilterPCFGetWater+1)
	line	1726
	
l10824:	
;main.c: 1726: _BITS1.Bits.bit_7=0;
	bcf	(__BITS1),7
	line	1727
	
l10826:	
;main.c: 1727: Read_Word_Buff[11]=1;
	bsf	status, 5	;RP0=1, select bank1
	clrf	0+(_Read_Word_Buff)^080h+0Bh
	incf	0+(_Read_Word_Buff)^080h+0Bh,f
	line	1728
	
l10828:	
;main.c: 1728: WrterEEP();
	fcall	_WrterEEP
	line	1729
;main.c: 1729: }
	goto	l1320
	line	1733
	
l10830:	
;main.c: 1730: else
;main.c: 1731: {
;main.c: 1733: if((FilterRst_1s<300)&&((_BITS1.Bits.bit_3)||(_BITS1.Bits.bit_2))){
	movlw	01h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_FilterRst_1s+1)^080h,w
	movlw	02Ch
	skipnz
	subwf	(_FilterRst_1s)^080h,w
	skipnc
	goto	u10121
	goto	u10120
u10121:
	goto	l1340
u10120:
	
l10832:	
	bcf	status, 5	;RP0=0, select bank0
	btfsc	(__BITS1),3
	goto	u10131
	goto	u10130
u10131:
	goto	l1342
u10130:
	
l10834:	
	btfss	(__BITS1),2
	goto	u10141
	goto	u10140
u10141:
	goto	l1340
u10140:
	
l1342:	
	line	1734
;main.c: 1734: if(_BITS.Bits.bit_1==0){
	btfsc	(__BITS),1
	goto	u10151
	goto	u10150
u10151:
	goto	l1319
u10150:
	line	1736
	
l10836:	
;main.c: 1736: BuzzerSet(3, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(03h)
	fcall	_BuzzerSet
	line	1739
	
l10838:	
;main.c: 1739: if(_BITS1.Bits.bit_3){
	bcf	status, 5	;RP0=0, select bank0
	btfss	(__BITS1),3
	goto	u10161
	goto	u10160
u10161:
	goto	l10848
u10160:
	line	1740
	
l10840:	
;main.c: 1740: _BITS1.Bits.bit_3=0;
	bcf	(__BITS1),3
	line	1741
	
l10842:	
;main.c: 1741: FilterPCF_time.u16Day=PrePCFu16Day;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_PrePCFu16Day+1)^080h,w
	movwf	1+(_FilterPCF_time)^080h+03h
	movf	(_PrePCFu16Day)^080h,w
	movwf	0+(_FilterPCF_time)^080h+03h
	line	1742
	
l10844:	
;main.c: 1742: LedSetSt(5, 5);
	movlw	low(05h)
	movwf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1743
	
l10846:	
;main.c: 1743: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1745
	
l10848:	
;main.c: 1744: }
;main.c: 1745: if(_BITS1.Bits.bit_2){
	btfss	(__BITS1),2
	goto	u10171
	goto	u10170
u10171:
	goto	l10828
u10170:
	line	1746
	
l10850:	
;main.c: 1746: _BITS1.Bits.bit_2=0;
	bcf	(__BITS1),2
	line	1747
	
l10852:	
;main.c: 1747: FilterRO_time.u16Day=PreROu16Day;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_PreROu16Day+1)^080h,w
	movwf	1+(_FilterRO_time)^080h+03h
	movf	(_PreROu16Day)^080h,w
	movwf	0+(_FilterRO_time)^080h+03h
	line	1748
	
l10854:	
;main.c: 1748: LedSetSt(3, 5);
	movlw	low(05h)
	movwf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1749
	
l10856:	
;main.c: 1749: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	goto	l10828
	line	1754
	
l1340:	
	line	1756
;main.c: 1754: else
;main.c: 1755: {
;main.c: 1756: _BITS1.Bits.bit_3=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(__BITS1),3
	line	1757
;main.c: 1757: _BITS1.Bits.bit_2=0;
	bcf	(__BITS1),2
	line	1761
	
l1320:	
	return
	opt stack 0
GLOBAL	__end_of_FilterKeyInputRest
	__end_of_FilterKeyInputRest:
	signat	_FilterKeyInputRest,89
	global	_ErrorHandle

;; *************** function _ErrorHandle *****************
;; Defined at:
;;		line 2161 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_AllLedFlash
;;		_BuzzerSet
;;		_GetStop
;;		_LedSetSt
;;		_ShiftMode_Handle
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text47,local,class=CODE,delta=2,merge=1,group=0
	line	2161
global __ptext47
__ptext47:	;psect for function _ErrorHandle
psect	text47
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	2161
	global	__size_of_ErrorHandle
	__size_of_ErrorHandle	equ	__end_of_ErrorHandle-_ErrorHandle
	
_ErrorHandle:	
;incstack = 0
	opt	stack 4
; Regs used in _ErrorHandle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	2166
	
l10940:	
;main.c: 2166: if(Timer_LongGetWater_1s>=1800){
	movlw	07h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_LongGetWater_1s+1)^080h,w
	movlw	08h
	skipnz
	subwf	(_Timer_LongGetWater_1s)^080h,w
	skipc
	goto	u10311
	goto	u10310
u10311:
	goto	l10960
u10310:
	line	2169
	
l10942:	
;main.c: 2169: ShiftMode_Handle(3);
	movlw	low(03h)
	fcall	_ShiftMode_Handle
	line	2172
	
l10944:	
;main.c: 2172: if(ErrorVar==0x00){
	bcf	status, 5	;RP0=0, select bank0
	movf	((_ErrorVar)),w
	btfss	status,2
	goto	u10321
	goto	u10320
u10321:
	goto	l10956
u10320:
	line	2173
	
l10946:	
;main.c: 2173: Timer_ErrorLong_1s=0;
	clrf	(_Timer_ErrorLong_1s)
	line	2174
	
l10948:	
;main.c: 2174: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	2175
	
l10950:	
;main.c: 2175: LedSetSt(4, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	2176
	
l10952:	
;main.c: 2176: LedSetSt(2, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	2177
	
l10954:	
;main.c: 2177: LedSetSt(0, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(0)
	fcall	_LedSetSt
	line	2179
	
l10956:	
;main.c: 2178: }
;main.c: 2179: ErrorVar=0x02;
	movlw	low(02h)
	movwf	(_ErrorVar)
	line	2180
	
l10958:	
;main.c: 2180: GetStop();
	fcall	_GetStop
	line	2183
	
l10960:	
;main.c: 2181: }
;main.c: 2183: if((Timer_ErrorLong_1s<=30)&&(Mode==3)){
	movlw	low(01Fh)
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_Timer_ErrorLong_1s),w
	skipnc
	goto	u10331
	goto	u10330
u10331:
	goto	l1433
u10330:
	
l10962:	
		movlw	3
	xorwf	((_Mode)),w
	btfss	status,2
	goto	u10341
	goto	u10340
u10341:
	goto	l1433
u10340:
	line	2184
	
l10964:	
;main.c: 2184: Timer_ErrorLong_1s++;
	incf	(_Timer_ErrorLong_1s),f
	line	2185
	
l10966:	
;main.c: 2185: if(Timer_ErrorLong_1s%2==0){
	btfsc	(_Timer_ErrorLong_1s),(0)&7
	goto	u10351
	goto	u10350
u10351:
	goto	l1433
u10350:
	line	2186
	
l10968:	
;main.c: 2186: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	2192
	
l1433:	
	return
	opt stack 0
GLOBAL	__end_of_ErrorHandle
	__end_of_ErrorHandle:
	signat	_ErrorHandle,89
	global	_ShiftMode_Handle

;; *************** function _ShiftMode_Handle *****************
;; Defined at:
;;		line 1292 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Mod             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  Mod             1    3[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       1       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_BuzzerSet
;;		_LedSetSt
;;		_SetStandbyState
;; This function is called by:
;;		_GetMode_Handle
;;		_FilterKeyInputRest
;;		_StandbyMode_Handle
;;		_Run_Mode
;;		_ErrorHandle
;; This function uses a non-reentrant model
;;
psect	text48,local,class=CODE,delta=2,merge=1,group=0
	line	1292
global __ptext48
__ptext48:	;psect for function _ShiftMode_Handle
psect	text48
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	1292
	global	__size_of_ShiftMode_Handle
	__size_of_ShiftMode_Handle	equ	__end_of_ShiftMode_Handle-_ShiftMode_Handle
	
_ShiftMode_Handle:	
;incstack = 0
	opt	stack 4
; Regs used in _ShiftMode_Handle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;ShiftMode_Handle@Mod stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ShiftMode_Handle@Mod)
	line	1294
	
l9538:	
;main.c: 1294: Mode=Mod;
	movf	(ShiftMode_Handle@Mod),w
	movwf	(_Mode)
	line	1295
	
l9540:	
;main.c: 1295: RA1=0;
	bcf	(41/8),(41)&7	;volatile
	line	1296
	
l9542:	
;main.c: 1296: RC2=0;
	bcf	(58/8),(58)&7	;volatile
	line	1297
;main.c: 1297: switch(Mod){
	goto	l9566
	line	1299
;main.c: 1299: case 2:
	
l1230:	
	line	1300
;main.c: 1300: RC3=0;
	bcf	(59/8),(59)&7	;volatile
	line	1301
;main.c: 1301: {RA2=0;_BITS2.Bits.bit_1=0;};
	bcf	(42/8),(42)&7	;volatile
	bcf	(__BITS2),1
	line	1304
;main.c: 1304: _BITS.Bits.bit_5=0x00;
	bcf	(__BITS),5
	line	1305
	
l9544:	
;main.c: 1305: LedSetSt(1, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1306
	
l9546:	
;main.c: 1306: if(StandByStatus==WashState){
		decf	((_StandByStatus)),w
	btfss	status,2
	goto	u8031
	goto	u8030
u8031:
	goto	l1241
u8030:
	line	1307
	
l9548:	
;main.c: 1307: LedSetSt(1, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1308
;main.c: 1308: SetStandbyState(WashState,&WashRunTime, WashRunTime-Timer_WashRun_1s);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_Timer_WashRun_1s)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_WashRunTime),w
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	goto	l1241
	line	1311
;main.c: 1311: case 4:
	
l1233:	
	line	1312
;main.c: 1312: _BITS.Bits.bit_5=0x01;
	bsf	(__BITS),5
	line	1315
;main.c: 1315: RC3=1;
	bsf	(59/8),(59)&7	;volatile
	line	1316
;main.c: 1316: {RA2=1;_BITS2.Bits.bit_1=1;};
	bsf	(42/8),(42)&7	;volatile
	bsf	(__BITS2),1
	line	1317
	
l9550:	
;main.c: 1317: LedSetSt(1, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(01h)
	fcall	_LedSetSt
	line	1318
	
l9552:	
;main.c: 1318: if((FilterROState==3)||(FilterPCFState==3)){
		movlw	3
	xorwf	((_FilterROState)),w
	btfsc	status,2
	goto	u8041
	goto	u8040
u8041:
	goto	l9556
u8040:
	
l9554:	
		movlw	3
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u8051
	goto	u8050
u8051:
	goto	l9558
u8050:
	line	1319
	
l9556:	
;main.c: 1319: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1320
;main.c: 1320: }
	goto	l1241
	line	1321
	
l9558:	
;main.c: 1321: else if((FilterROState==2)||(FilterPCFState==2)){
		movlw	2
	xorwf	((_FilterROState)),w
	btfsc	status,2
	goto	u8061
	goto	u8060
u8061:
	goto	l9562
u8060:
	
l9560:	
		movlw	2
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u8071
	goto	u8070
u8071:
	goto	l1241
u8070:
	line	1322
	
l9562:	
;main.c: 1322: BuzzerSet(1, 1200);
	movlw	0B0h
	movwf	(BuzzerSet@filter)
	movlw	04h
	movwf	((BuzzerSet@filter))+1
	movlw	low(01h)
	fcall	_BuzzerSet
	goto	l1241
	line	1297
	
l9566:	
	movf	(ShiftMode_Handle@Mod),w
	; Switch size 1, requested type "space"
; Number of cases is 2, Range of values is 2 to 4
; switch strategies available:
; Name         Instructions Cycles
; simple_byte            7     4 (average)
; direct_byte           20    11 (fixed)
; jumptable            263     9 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	2^0	; case 2
	skipnz
	goto	l1230
	xorlw	4^2	; case 4
	skipnz
	goto	l1233
	goto	l1241
	opt asmopt_pop

	line	1329
	
l1241:	
	return
	opt stack 0
GLOBAL	__end_of_ShiftMode_Handle
	__end_of_ShiftMode_Handle:
	signat	_ShiftMode_Handle,4217
	global	_SetStandbyState

;; *************** function _SetStandbyState *****************
;; Defined at:
;;		line 1393 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  STY             1    wreg     enum E897
;;  Time            1    4[COMMON] PTR unsigned char 
;;		 -> WashRunTime(1), 
;;  Da              1    5[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  STY             1    0[BANK0 ] enum E897
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : B00/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       1       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_Count_Func
;;		_ShiftMode_Handle
;;		_WashHandle
;;		_StatusFun_Handle
;;		_StandbyMode_Handle
;;		_Run_Mode
;; This function uses a non-reentrant model
;;
psect	text49,local,class=CODE,delta=2,merge=1,group=0
	line	1393
global __ptext49
__ptext49:	;psect for function _SetStandbyState
psect	text49
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	1393
	global	__size_of_SetStandbyState
	__size_of_SetStandbyState	equ	__end_of_SetStandbyState-_SetStandbyState
	
_SetStandbyState:	
;incstack = 0
	opt	stack 7
; Regs used in _SetStandbyState: [wreg-fsr0h+status,2+status,0]
;SetStandbyState@STY stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(SetStandbyState@STY)
	line	1394
	
l9132:	
;main.c: 1394: *Time=Da;
	movf	(SetStandbyState@Time),w
	movwf	fsr0
	movf	(SetStandbyState@Da),w
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	1395
	
l9134:	
;main.c: 1395: StandByStatus=STY;
	movf	(SetStandbyState@STY),w
	movwf	(_StandByStatus)
	line	1401
	
l9136:	
;main.c: 1401: if(STY==WashState){
		decf	((SetStandbyState@STY)),w
	btfss	status,2
	goto	u7471
	goto	u7470
u7471:
	goto	l9140
u7470:
	line	1403
	
l9138:	
;main.c: 1403: {RA2=1;_BITS2.Bits.bit_1=1;};
	bsf	(42/8),(42)&7	;volatile
	bsf	(__BITS2),1
	line	1404
;main.c: 1404: RC3=1;
	bsf	(59/8),(59)&7	;volatile
	line	1405
;main.c: 1405: RC2=1;
	bsf	(58/8),(58)&7	;volatile
	line	1407
;main.c: 1407: }
	goto	l9144
	line	1408
	
l9140:	
;main.c: 1408: else if(STY==BackState){
		movlw	3
	xorwf	((SetStandbyState@STY)),w
	btfss	status,2
	goto	u7481
	goto	u7480
u7481:
	goto	l1256
u7480:
	line	1410
	
l9142:	
;main.c: 1410: {RA2=1;_BITS2.Bits.bit_1=1;};
	bsf	(42/8),(42)&7	;volatile
	bsf	(__BITS2),1
	line	1411
;main.c: 1411: RC3=1;
	bsf	(59/8),(59)&7	;volatile
	line	1412
;main.c: 1412: RA1=1;
	bsf	(41/8),(41)&7	;volatile
	line	1414
;main.c: 1414: }
	goto	l9144
	line	1415
	
l1256:	
	line	1417
;main.c: 1415: else
;main.c: 1416: {
;main.c: 1417: RC2=0;
	bcf	(58/8),(58)&7	;volatile
	line	1418
;main.c: 1418: {RA2=0;_BITS2.Bits.bit_1=0;};
	bcf	(42/8),(42)&7	;volatile
	bcf	(__BITS2),1
	line	1419
;main.c: 1419: RC3=0;
	bcf	(59/8),(59)&7	;volatile
	line	1420
;main.c: 1420: RA1=0;
	bcf	(41/8),(41)&7	;volatile
	line	1425
	
l9144:	
;main.c: 1424: }
;main.c: 1425: Timer_WashRun_1s=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_Timer_WashRun_1s)^080h
	clrf	(_Timer_WashRun_1s+1)^080h
	line	1428
	
l1258:	
	return
	opt stack 0
GLOBAL	__end_of_SetStandbyState
	__end_of_SetStandbyState:
	signat	_SetStandbyState,12409
	global	_GetStop

;; *************** function _GetStop *****************
;; Defined at:
;;		line 1287 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ErrorHandle
;; This function uses a non-reentrant model
;;
psect	text50,local,class=CODE,delta=2,merge=1,group=0
	line	1287
global __ptext50
__ptext50:	;psect for function _GetStop
psect	text50
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	1287
	global	__size_of_GetStop
	__size_of_GetStop	equ	__end_of_GetStop-_GetStop
	
_GetStop:	
;incstack = 0
	opt	stack 6
; Regs used in _GetStop: []
	line	1288
	
l9536:	
;main.c: 1288: _BITS.Bits.bit_5=0x00;
	bcf	(__BITS),5
	line	1290
	
l1226:	
	return
	opt stack 0
GLOBAL	__end_of_GetStop
	__end_of_GetStop:
	signat	_GetStop,89
	global	_AllLedFlash

;; *************** function _AllLedFlash *****************
;; Defined at:
;;		line 837 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Type            1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  Type            1    3[BANK0 ] unsigned char 
;;  i               2    4[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       3       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       3       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_LedSetSt
;; This function is called by:
;;		_FactoryMode_Handle
;;		_Run_Mode
;;		_ErrorHandle
;; This function uses a non-reentrant model
;;
psect	text51,local,class=CODE,delta=2,merge=1,group=0
	line	837
global __ptext51
__ptext51:	;psect for function _AllLedFlash
psect	text51
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	837
	global	__size_of_AllLedFlash
	__size_of_AllLedFlash	equ	__end_of_AllLedFlash-_AllLedFlash
	
_AllLedFlash:	
;incstack = 0
	opt	stack 4
; Regs used in _AllLedFlash: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;AllLedFlash@Type stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(AllLedFlash@Type)
	line	839
	
l9404:	
;main.c: 838: unsigned int i;
;main.c: 839: for(i=0;i<6;i++){
	clrf	(AllLedFlash@i)
	clrf	(AllLedFlash@i+1)
	line	840
	
l9410:	
;main.c: 840: LedSetSt(i, Type);
	movf	(AllLedFlash@Type),w
	movwf	(LedSetSt@Sta)
	movf	(AllLedFlash@i),w
	fcall	_LedSetSt
	line	839
	
l9412:	
	incf	(AllLedFlash@i),f
	skipnz
	incf	(AllLedFlash@i+1),f
	
l9414:	
	movlw	0
	subwf	(AllLedFlash@i+1),w
	movlw	06h
	skipnz
	subwf	(AllLedFlash@i),w
	skipc
	goto	u7741
	goto	u7740
u7741:
	goto	l9410
u7740:
	line	842
	
l1115:	
	return
	opt stack 0
GLOBAL	__end_of_AllLedFlash
	__end_of_AllLedFlash:
	signat	_AllLedFlash,4217
	global	_LedSetSt

;; *************** function _LedSetSt *****************
;; Defined at:
;;		line 872 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Num             1    wreg     unsigned char 
;;  Sta             1    5[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  Num             1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       1       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___bmul
;; This function is called by:
;;		_AllLedFlash
;;		_FilterTimeHandle
;;		_ShiftMode_Handle
;;		_WashHandle
;;		_FactoryMode_Handle
;;		_FilterKeyInputRest
;;		_StandbyMode_Handle
;;		_Run_Mode
;;		_ErrorHandle
;; This function uses a non-reentrant model
;;
psect	text52,local,class=CODE,delta=2,merge=1,group=0
	line	872
global __ptext52
__ptext52:	;psect for function _LedSetSt
psect	text52
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	872
	global	__size_of_LedSetSt
	__size_of_LedSetSt	equ	__end_of_LedSetSt-_LedSetSt
	
_LedSetSt:	
;incstack = 0
	opt	stack 4
; Regs used in _LedSetSt: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;LedSetSt@Num stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(LedSetSt@Num)
	line	874
	
l9146:	
;main.c: 874: if(LedMod[Num].LedState!=Sta){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	xorwf	(LedSetSt@Sta),w
	skipnz
	goto	u7491
	goto	u7490
u7491:
	goto	l1122
u7490:
	line	875
	
l9148:	
;main.c: 875: LedMod[Num].LedState=Sta;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(LedSetSt@Sta),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	line	876
;main.c: 876: if(LedMod[Num].LedState==2){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
		movlw	2
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfss	status,2
	goto	u7501
	goto	u7500
u7501:
	goto	l9154
u7500:
	line	877
	
l9150:	
;main.c: 877: LedMod[Num].LedFlashNum=2;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	movlw	02h
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movlw	0
	movwf	indf
	line	878
	
l9152:	
;main.c: 878: _BITS.Bits.bit_0=1;
	bsf	(__BITS),0
	line	879
;main.c: 879: }
	goto	l1120
	line	880
	
l9154:	
;main.c: 880: else if(LedMod[Num].LedState==5){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
		movlw	5
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfss	status,2
	goto	u7511
	goto	u7510
u7511:
	goto	l1120
u7510:
	line	881
	
l9156:	
;main.c: 881: LedMod[Num].LedFlashNum=3;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	movlw	03h
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movlw	0
	movwf	indf
	goto	l9152
	line	884
	
l1120:	
;main.c: 883: }
;main.c: 884: LedMod[Num].LedTime=0;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	886
	
l1122:	
	return
	opt stack 0
GLOBAL	__end_of_LedSetSt
	__end_of_LedSetSt:
	signat	_LedSetSt,8313
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    1[BANK0 ] unsigned char 
;;  product         1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         0       2       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       2       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_LedSetSt
;;		_Led_Handle
;; This function uses a non-reentrant model
;;
psect	text53,local,class=CODE,delta=2,merge=1,group=2
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul8.c"
	line	4
global __ptext53
__ptext53:	;psect for function ___bmul
psect	text53
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 6
; Regs used in ___bmul: [wreg+status,2+status,0]
;___bmul@multiplier stored from wreg
	movwf	(___bmul@multiplier)
	line	6
	
l9116:	
	clrf	(___bmul@product)
	line	43
	
l9118:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u7451
	goto	u7450
u7451:
	goto	l9122
u7450:
	line	44
	
l9120:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l9122:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l9124:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u7461
	goto	u7460
u7461:
	goto	l9118
u7460:
	line	50
	
l9126:	
	movf	(___bmul@product),w
	line	51
	
l3722:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	_CheckKey

;; *************** function _CheckKey *****************
;; Defined at:
;;		line 2070 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               2    7[BANK0 ] unsigned int 
;;  St              1    6[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       3       0       0
;;      Temps:          0       1       0       0
;;      Totals:         0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_KeyScan
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text54,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	2070
global __ptext54
__ptext54:	;psect for function _CheckKey
psect	text54
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	2070
	global	__size_of_CheckKey
	__size_of_CheckKey	equ	__end_of_CheckKey-_CheckKey
	
_CheckKey:	
;incstack = 0
	opt	stack 5
; Regs used in _CheckKey: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	2072
	
l10582:	
	line	2078
	
l10584:	
;main.c: 2073: static U8_T temp;
;main.c: 2076: static unsigned int KeyOldFlag = 0;
;main.c: 2078: unsigned int i = (unsigned int)((g_KeyFlag[1]<<8) | g_KeyFlag[0]);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	0+(_g_KeyFlag)+01h,w	;volatile
	movwf	(CheckKey@i+1)
	movf	(_g_KeyFlag),w	;volatile
	movwf	(CheckKey@i)
	line	2080
	
l10586:	
;main.c: 2080: if(i)
	movf	((CheckKey@i)),w
iorwf	((CheckKey@i+1)),w
	btfsc	status,2
	goto	u9711
	goto	u9710
u9711:
	goto	l10598
u9710:
	line	2082
	
l10588:	
;main.c: 2081: {
;main.c: 2082: if(i != KeyOldFlag)
	bsf	status, 5	;RP0=1, select bank1
	movf	(CheckKey@KeyOldFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(CheckKey@i+1),w
	skipz
	goto	u9725
	bsf	status, 5	;RP0=1, select bank1
	movf	(CheckKey@KeyOldFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(CheckKey@i),w
u9725:

	skipnz
	goto	u9721
	goto	u9720
u9721:
	goto	l10602
u9720:
	line	2084
	
l10590:	
;main.c: 2083: {
;main.c: 2084: KeyOldFlag = i;
	movf	(CheckKey@i+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(CheckKey@KeyOldFlag+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(CheckKey@i),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(CheckKey@KeyOldFlag)^080h
	line	2086
	
l10592:	
;main.c: 2086: if(0x01 & i){temp |= 0x02;}
	bcf	status, 5	;RP0=0, select bank0
	btfss	(CheckKey@i),(0)&7
	goto	u9731
	goto	u9730
u9731:
	goto	l1419
u9730:
	
l10594:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(CheckKey@temp)^080h+(1/8),(1)&7
	
l1419:	
	line	2087
;main.c: 2087: if(0x02 & i){temp |= 0x04;}
	bcf	status, 5	;RP0=0, select bank0
	btfss	(CheckKey@i),(1)&7
	goto	u9741
	goto	u9740
u9741:
	goto	l10602
u9740:
	
l10596:	
	bsf	status, 5	;RP0=1, select bank1
	bsf	(CheckKey@temp)^080h+(2/8),(2)&7
	goto	l10602
	line	2092
	
l10598:	
;main.c: 2090: else
;main.c: 2091: {
;main.c: 2092: KeyOldFlag = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(CheckKey@KeyOldFlag)^080h
	clrf	(CheckKey@KeyOldFlag+1)^080h
	line	2094
	
l10600:	
;main.c: 2094: temp&=0x01;
	movlw	low(01h)
	andwf	(CheckKey@temp)^080h,f
	line	2138
	
l10602:	
;main.c: 2095: }
;main.c: 2138: if(RC1==0){
	bcf	status, 5	;RP0=0, select bank0
	btfsc	(57/8),(57)&7	;volatile
	goto	u9751
	goto	u9750
u9751:
	goto	l1422
u9750:
	line	2141
	
l10604:	
;main.c: 2141: temp |= 0x01;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(CheckKey@temp)^080h+(0/8),(0)&7
	line	2143
;main.c: 2143: }
	goto	l10606
	line	2144
	
l1422:	
	line	2148
;main.c: 2144: else
;main.c: 2145: {
;main.c: 2148: temp &= ~(0x01);
	bsf	status, 5	;RP0=1, select bank1
	bcf	(CheckKey@temp)^080h+(0/8),(0)&7
	line	2153
	
l10606:	
;main.c: 2150: }
;main.c: 2153: for(i=0;i<3;i++){
	bcf	status, 5	;RP0=0, select bank0
	clrf	(CheckKey@i)
	clrf	(CheckKey@i+1)
	line	2154
	
l10612:	
;main.c: 2154: St=(U8_T)(temp>>i);
	bsf	status, 5	;RP0=1, select bank1
	movf	(CheckKey@temp)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_CheckKey+0)+0
	incf	(CheckKey@i),w
	goto	u9764
u9765:
	clrc
	rrf	(??_CheckKey+0)+0,f
u9764:
	addlw	-1
	skipz
	goto	u9765
	movf	0+(??_CheckKey+0)+0,w
	movwf	(CheckKey@St)
	line	2155
;main.c: 2155: St&=0x01;
	movlw	low(01h)
	andwf	(CheckKey@St),f
	line	2156
	
l10614:	
;main.c: 2156: KeyScan(St,i);
	movf	(CheckKey@i),w
	movwf	(KeyScan@num)
	movf	(CheckKey@St),w
	fcall	_KeyScan
	line	2153
	
l10616:	
	incf	(CheckKey@i),f
	skipnz
	incf	(CheckKey@i+1),f
	
l10618:	
	movlw	0
	subwf	(CheckKey@i+1),w
	movlw	03h
	skipnz
	subwf	(CheckKey@i),w
	skipc
	goto	u9771
	goto	u9770
u9771:
	goto	l10612
u9770:
	line	2158
	
l1426:	
	return
	opt stack 0
GLOBAL	__end_of_CheckKey
	__end_of_CheckKey:
	signat	_CheckKey,89
	global	_KeyScan

;; *************** function _KeyScan *****************
;; Defined at:
;;		line 8 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\KeyFunc.c"
;; Parameters:    Size  Location     Type
;;  sw_port         1    wreg     unsigned char 
;;  num             1    1[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  sw_port         1    4[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       1       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_BuzzerSet
;; This function is called by:
;;		_CheckKey
;; This function uses a non-reentrant model
;;
psect	text55,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\KeyFunc.c"
	line	8
global __ptext55
__ptext55:	;psect for function _KeyScan
psect	text55
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\KeyFunc.c"
	line	8
	global	__size_of_KeyScan
	__size_of_KeyScan	equ	__end_of_KeyScan-_KeyScan
	
_KeyScan:	
;incstack = 0
	opt	stack 5
; Regs used in _KeyScan: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;KeyScan@sw_port stored from wreg
	movwf	(KeyScan@sw_port)
	line	10
	
l9610:	
;KeyFunc.c: 10: if(sw_port)
	movf	((KeyScan@sw_port)),w
	btfsc	status,2
	goto	u8111
	goto	u8110
u8111:
	goto	l9684
u8110:
	goto	l9646
	line	16
	
l9614:	
;KeyFunc.c: 16: if(KeyPacket_y[num].KeyTime<2200){KeyPacket_y[num].KeyTime++;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	098h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipnc
	goto	u8121
	goto	u8120
u8121:
	goto	l2422
u8120:
	
l9616:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	
l2422:	
	line	17
;KeyFunc.c: 17: if(KeyPacket_y[num].KeyTime>=3){KeyPacket_y[num].KeyState=ShortPressDown;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	0
	subwf	1+(??_KeyScan+0)+0,w
	movlw	03h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipc
	goto	u8131
	goto	u8130
u8131:
	goto	l2444
u8130:
	
l9618:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	goto	l2444
	line	22
	
l9620:	
;KeyFunc.c: 22: if(KeyPacket_y[num].KeyTime<2200){KeyPacket_y[num].KeyTime++;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	098h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipnc
	goto	u8141
	goto	u8140
u8141:
	goto	l2426
u8140:
	
l9622:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	
l2426:	
	line	23
;KeyFunc.c: 23: if(KeyPacket_y[num].KeyTime>=300) {KeyPacket_y[num].KeyState=LongPressDown;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	01h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	02Ch
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipc
	goto	u8151
	goto	u8150
u8151:
	goto	l2444
u8150:
	
l9624:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	movwf	indf
	goto	l2444
	line	28
	
l9626:	
;KeyFunc.c: 28: if(KeyPacket_y[num].KeyTime<2200){KeyPacket_y[num].KeyTime++;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	098h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipnc
	goto	u8161
	goto	u8160
u8161:
	goto	l2429
u8160:
	
l9628:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	
l2429:	
	line	29
;KeyFunc.c: 29: if(KeyPacket_y[num].KeyTime>=1000) {KeyPacket_y[num].KeyState=SuperPressDown;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	03h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	0E8h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipc
	goto	u8171
	goto	u8170
u8171:
	goto	l2444
u8170:
	
l9630:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(03h)
	movwf	indf
	goto	l2444
	line	32
	
l9632:	
;KeyFunc.c: 32: if(KeyPacket_y[num].KeyTime<2200){KeyPacket_y[num].KeyTime++;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	098h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipnc
	goto	u8181
	goto	u8180
u8181:
	goto	l2432
u8180:
	
l9634:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	
l2432:	
	line	33
;KeyFunc.c: 33: if(KeyPacket_y[num].KeyTime>=2100) {KeyPacket_y[num].KeyState=SuperLongPressDown;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	034h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipc
	goto	u8191
	goto	u8190
u8191:
	goto	l2444
u8190:
	
l9636:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(04h)
	movwf	indf
	goto	l2444
	line	36
	
l9638:	
;KeyFunc.c: 36: if(KeyPacket_y[num].KeyTime<2200){KeyPacket_y[num].KeyTime++;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	098h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipnc
	goto	u8201
	goto	u8200
u8201:
	goto	l2444
u8200:
	
l9640:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	goto	l2444
	line	44
	
l9642:	
;KeyFunc.c: 44: KeyPacket_y[num].KeyTime=0;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	45
;KeyFunc.c: 45: KeyPacket_y[num].KeyState=NotPress;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	46
;KeyFunc.c: 46: break;
	goto	l2444
	line	13
	
l9646:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	; Switch size 1, requested type "space"
; Number of cases is 5, Range of values is 0 to 4
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           16     9 (average)
; direct_byte           23     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l9614
	xorlw	1^0	; case 1
	skipnz
	goto	l9620
	xorlw	2^1	; case 2
	skipnz
	goto	l9626
	xorlw	3^2	; case 3
	skipnz
	goto	l9632
	xorlw	4^3	; case 4
	skipnz
	goto	l9638
	goto	l9642
	opt asmopt_pop

	line	55
	
l9648:	
;KeyFunc.c: 55: KeyPacket_y[num].KeyTime=0;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	56
;KeyFunc.c: 56: break;
	goto	l2444
	line	59
	
l9650:	
;KeyFunc.c: 59: KeyPacket_y[num].KeyState=ShortRelease;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(06h)
	movwf	indf
	line	60
	
l9652:	
;KeyFunc.c: 60: if(num!=1)
		decf	((KeyScan@num)),w
	btfsc	status,2
	goto	u8211
	goto	u8210
u8211:
	goto	l9664
u8210:
	line	62
	
l9654:	
;KeyFunc.c: 61: {
;KeyFunc.c: 62: if(_BITS.Bits.bit_1==1){
	btfss	(__BITS),1
	goto	u8221
	goto	u8220
u8221:
	goto	l9664
u8220:
	line	63
	
l9656:	
;KeyFunc.c: 63: _BITS.Bits.bit_1=0;
	bcf	(__BITS),1
	line	65
	
l9658:	
;KeyFunc.c: 65: BuzzerSet(1, 50);
	movlw	032h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	66
	
l9660:	
;KeyFunc.c: 66: KeyPacket_y[num].KeyState=NotPress;
	bcf	status, 5	;RP0=0, select bank0
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	clrf	indf
	goto	l2444
	line	70
	
l9664:	
;KeyFunc.c: 68: }
;KeyFunc.c: 69: }
;KeyFunc.c: 70: if((FilterFastCheck==1)&&(num!=0)){
		decf	((_FilterFastCheck)),w
	btfss	status,2
	goto	u8231
	goto	u8230
u8231:
	goto	l2444
u8230:
	
l9666:	
	movf	((KeyScan@num)),w
	btfsc	status,2
	goto	u8241
	goto	u8240
u8241:
	goto	l2444
u8240:
	line	71
	
l9668:	
;KeyFunc.c: 71: FilterFastCheck=2;
	movlw	low(02h)
	movwf	(_FilterFastCheck)
	line	72
	
l9670:	
;KeyFunc.c: 72: BuzzerSet(3, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(03h)
	fcall	_BuzzerSet
	goto	l9660
	line	78
	
l9676:	
;KeyFunc.c: 78: KeyPacket_y[num].KeyState=LongRelease;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	79
;KeyFunc.c: 79: break;
	goto	l2444
	line	81
	
l9678:	
;KeyFunc.c: 81: KeyPacket_y[num].KeyState=SuperRelease;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(08h)
	movwf	indf
	line	82
;KeyFunc.c: 82: break;
	goto	l2444
	line	52
	
l9684:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	; Switch size 1, requested type "space"
; Number of cases is 4, Range of values is 0 to 3
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           13     7 (average)
; direct_byte           20     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l9648
	xorlw	1^0	; case 1
	skipnz
	goto	l9650
	xorlw	2^1	; case 2
	skipnz
	goto	l9676
	xorlw	3^2	; case 3
	skipnz
	goto	l9678
	goto	l9642
	opt asmopt_pop

	line	90
	
l2444:	
	return
	opt stack 0
GLOBAL	__end_of_KeyScan
	__end_of_KeyScan:
	signat	_KeyScan,8313
	global	_BuzzerSet

;; *************** function _BuzzerSet *****************
;; Defined at:
;;		line 1585 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  cnt             1    wreg     unsigned char 
;;  filter          2    4[COMMON] unsigned short 
;; Auto vars:     Size  Location     Type
;;  cnt             1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       1       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_Count_Func
;;		_FilterLifeFunc
;;		_ShiftMode_Handle
;;		_FactoryMode_Handle
;;		_FilterKeyInputRest
;;		_StandbyMode_Handle
;;		_Run_Mode
;;		_ErrorHandle
;;		_KeyScan
;; This function uses a non-reentrant model
;;
psect	text56,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	1585
global __ptext56
__ptext56:	;psect for function _BuzzerSet
psect	text56
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	1585
	global	__size_of_BuzzerSet
	__size_of_BuzzerSet	equ	__end_of_BuzzerSet-_BuzzerSet
	
_BuzzerSet:	
;incstack = 0
	opt	stack 6
; Regs used in _BuzzerSet: [wreg]
;BuzzerSet@cnt stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(BuzzerSet@cnt)
	line	1587
	
l9130:	
;main.c: 1587: BeepAlmCnt = cnt;
	movf	(BuzzerSet@cnt),w
	movwf	(_BeepAlmCnt)
	line	1588
;main.c: 1588: BuzzerFilter = filter;
	movf	(BuzzerSet@filter+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_BuzzerFilter+1)^080h
	movf	(BuzzerSet@filter),w
	movwf	(_BuzzerFilter)^080h
	line	1589
;main.c: 1589: BeepOnTimeCnt=BuzzerFilter;
	movf	(_BuzzerFilter+1)^080h,w
	movwf	(_BeepOnTimeCnt+1)^080h
	movf	(_BuzzerFilter)^080h,w
	movwf	(_BeepOnTimeCnt)^080h
	line	1590
	
l1303:	
	return
	opt stack 0
GLOBAL	__end_of_BuzzerSet
	__end_of_BuzzerSet:
	signat	_BuzzerSet,8313
	global	_AD_Testing

;; *************** function _AD_Testing *****************
;; Defined at:
;;		line 2433 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  ad_fd           1    wreg     unsigned char 
;;  ad_ch           1    4[COMMON] unsigned char 
;;  ad_lr           1    5[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  ad_fd           1    2[BANK0 ] unsigned char 
;;  data            2    6[BANK0 ] volatile unsigned int 
;;  AD_Result       2    3[BANK0 ] volatile unsigned int 
;;  i               1    5[BANK0 ] volatile unsigned char 
;; Return value:  Size  Location     Type
;;                  2    4[COMMON] unsigned int 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       6       0       0
;;      Temps:          0       2       0       0
;;      Totals:         2       8       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text57,local,class=CODE,delta=2,merge=1,group=0
	line	2433
global __ptext57
__ptext57:	;psect for function _AD_Testing
psect	text57
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	2433
	global	__size_of_AD_Testing
	__size_of_AD_Testing	equ	__end_of_AD_Testing-_AD_Testing
	
_AD_Testing:	
;incstack = 0
	opt	stack 7
; Regs used in _AD_Testing: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
;AD_Testing@ad_fd stored from wreg
	movwf	(AD_Testing@ad_fd)
	line	2441
	
l10442:	
;main.c: 2436: static volatile unsigned char adtimes;
;main.c: 2437: static volatile unsigned int admin,admax, adsum;
;main.c: 2438: volatile unsigned int data;
;main.c: 2439: volatile unsigned int AD_Result;
;main.c: 2441: volatile unsigned char i = 0;
	clrf	(AD_Testing@i)	;volatile
	line	2443
	
l10444:	
;main.c: 2443: if(!ad_lr)
	movf	((AD_Testing@ad_lr)),w
	btfss	status,2
	goto	u9481
	goto	u9480
u9481:
	goto	l10448
u9480:
	line	2444
	
l10446:	
;main.c: 2444: ADCON1 = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(159)^080h	;volatile
	goto	l10450
	line	2446
	
l10448:	
;main.c: 2445: else
;main.c: 2446: ADCON1 = 0x80;
	movlw	low(080h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(159)^080h	;volatile
	line	2448
	
l10450:	
;main.c: 2448: if(ad_ch & 0x10)
	btfss	(AD_Testing@ad_ch),(4)&7
	goto	u9491
	goto	u9490
u9491:
	goto	l10454
u9490:
	line	2449
	
l10452:	
;main.c: 2449: ADCON1 |= 0x40;
	bsf	(159)^080h+(6/8),(6)&7	;volatile
	line	2451
	
l10454:	
;main.c: 2451: ADCON0 = 0;
	clrf	(158)^080h	;volatile
	line	2452
	
l10456:	
;main.c: 2452: ad_ch &= 0x0f;
	movlw	low(0Fh)
	andwf	(AD_Testing@ad_ch),f
	line	2453
	
l10458:	
;main.c: 2453: ADCON0 |= (unsigned char)(ad_fd << 6);
	bcf	status, 5	;RP0=0, select bank0
	movf	(AD_Testing@ad_fd),w
	movwf	(??_AD_Testing+0)+0
	rrf	(??_AD_Testing+0)+0,f
	rrf	(??_AD_Testing+0)+0,f
	rrf	(??_AD_Testing+0)+0,w
	andlw	0c0h
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(158)^080h,f	;volatile
	line	2454
	
l10460:	
;main.c: 2454: ADCON0 |= (unsigned char)(ad_ch << 2);
	movf	(AD_Testing@ad_ch),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_AD_Testing+0)+0
	movlw	(02h)-1
u9505:
	clrc
	rlf	(??_AD_Testing+0)+0,f
	addlw	-1
	skipz
	goto	u9505
	clrc
	rlf	(??_AD_Testing+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(158)^080h,f	;volatile
	line	2455
	
l10462:	
;main.c: 2455: ADCON0 |= 0x01;
	bsf	(158)^080h+(0/8),(0)&7	;volatile
	line	2457
# 2457 "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	2458
# 2458 "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
nop ;# 
psect	text57
	line	2459
	
l10464:	
;main.c: 2459: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1265/8)^080h,(1265)&7	;volatile
	line	2461
;main.c: 2461: while(GODONE)
	goto	l1487
	
l1488:	
	line	2463
# 2463 "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	2464
# 2464 "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
nop ;# 
psect	text57
	line	2465
;main.c: 2465: if((--i) == 0)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(AD_Testing@i),f	;volatile
	goto	u9511
	goto	u9510
u9511:
	goto	l1487
u9510:
	goto	l1490
	line	2467
	
l1487:	
	line	2461
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1265/8)^080h,(1265)&7	;volatile
	goto	u9521
	goto	u9520
u9521:
	goto	l1488
u9520:
	line	2469
	
l10468:	
;main.c: 2467: }
;main.c: 2469: if(!ad_lr)
	movf	((AD_Testing@ad_lr)),w
	btfss	status,2
	goto	u9531
	goto	u9530
u9531:
	goto	l10474
u9530:
	line	2471
	
l10470:	
;main.c: 2470: {
;main.c: 2471: data = (unsigned int)(ADRESH<<4);
	movf	(157)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(AD_Testing@data)	;volatile
	clrf	(AD_Testing@data+1)	;volatile
	swapf	(AD_Testing@data),f	;volatile
	swapf	(AD_Testing@data+1),f	;volatile
	movlw	0f0h
	andwf	(AD_Testing@data+1),f	;volatile
	movf	(AD_Testing@data),w	;volatile
	andlw	0fh
	iorwf	(AD_Testing@data+1),f	;volatile
	movlw	0f0h
	andwf	(AD_Testing@data),f	;volatile
	line	2472
	
l10472:	
;main.c: 2472: data |= (unsigned int)(ADRESL>>4);
	bsf	status, 5	;RP0=1, select bank1
	swapf	(156)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(AD_Testing@data),f	;volatile
	line	2473
;main.c: 2473: }
	goto	l10476
	line	2476
	
l10474:	
;main.c: 2474: else
;main.c: 2475: {
;main.c: 2476: data = (unsigned int)(ADRESH<<8);
	movf	(157)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(AD_Testing@data+1)	;volatile
	clrf	(AD_Testing@data)	;volatile
	line	2477
;main.c: 2477: data |= (unsigned int)ADRESL;
	bsf	status, 5	;RP0=1, select bank1
	movf	(156)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(AD_Testing@data),f	;volatile
	line	2480
	
l10476:	
;main.c: 2478: }
;main.c: 2480: if(adtimes == 0)
	movf	((AD_Testing@adtimes)),w	;volatile
	btfss	status,2
	goto	u9541
	goto	u9540
u9541:
	goto	l10480
u9540:
	line	2482
	
l10478:	
;main.c: 2481: {
;main.c: 2482: admax = data;
	movf	(AD_Testing@data+1),w	;volatile
	movwf	(AD_Testing@admax+1)	;volatile
	movf	(AD_Testing@data),w	;volatile
	movwf	(AD_Testing@admax)	;volatile
	line	2483
;main.c: 2483: admin = data;
	movf	(AD_Testing@data+1),w	;volatile
	movwf	(AD_Testing@admin+1)	;volatile
	movf	(AD_Testing@data),w	;volatile
	movwf	(AD_Testing@admin)	;volatile
	line	2484
;main.c: 2484: }
	goto	l1495
	line	2485
	
l10480:	
;main.c: 2485: else if(data > admax)
	movf	(AD_Testing@data+1),w	;volatile
	subwf	(AD_Testing@admax+1),w	;volatile
	skipz
	goto	u9555
	movf	(AD_Testing@data),w	;volatile
	subwf	(AD_Testing@admax),w	;volatile
u9555:
	skipnc
	goto	u9551
	goto	u9550
u9551:
	goto	l10484
u9550:
	line	2487
	
l10482:	
;main.c: 2486: {
;main.c: 2487: admax = data;
	movf	(AD_Testing@data+1),w	;volatile
	movwf	(AD_Testing@admax+1)	;volatile
	movf	(AD_Testing@data),w	;volatile
	movwf	(AD_Testing@admax)	;volatile
	line	2488
;main.c: 2488: }
	goto	l1495
	line	2489
	
l10484:	
;main.c: 2489: else if(data < admin)
	movf	(AD_Testing@admin+1),w	;volatile
	subwf	(AD_Testing@data+1),w	;volatile
	skipz
	goto	u9565
	movf	(AD_Testing@admin),w	;volatile
	subwf	(AD_Testing@data),w	;volatile
u9565:
	skipnc
	goto	u9561
	goto	u9560
u9561:
	goto	l1495
u9560:
	line	2491
	
l10486:	
;main.c: 2490: {
;main.c: 2491: admin = data;
	movf	(AD_Testing@data+1),w	;volatile
	movwf	(AD_Testing@admin+1)	;volatile
	movf	(AD_Testing@data),w	;volatile
	movwf	(AD_Testing@admin)	;volatile
	line	2494
	
l1495:	
;main.c: 2492: }
;main.c: 2494: adsum += data;
	movf	(AD_Testing@data),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	addwf	(AD_Testing@adsum)^080h,f	;volatile
	skipnc
	incf	(AD_Testing@adsum+1)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(AD_Testing@data+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	addwf	(AD_Testing@adsum+1)^080h,f	;volatile
	line	2495
	
l10488:	
;main.c: 2495: if(++adtimes >= 10)
	movlw	low(0Ah)
	bcf	status, 5	;RP0=0, select bank0
	incf	(AD_Testing@adtimes),f	;volatile
	subwf	((AD_Testing@adtimes)),w	;volatile
	skipc
	goto	u9571
	goto	u9570
u9571:
	goto	l1490
u9570:
	line	2497
	
l10490:	
;main.c: 2496: {
;main.c: 2497: adsum -= admax;
	movf	(AD_Testing@admax),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	subwf	(AD_Testing@adsum)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(AD_Testing@admax+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	skipc
	decf	(AD_Testing@adsum+1)^080h,f	;volatile
	subwf	(AD_Testing@adsum+1)^080h,f	;volatile
	line	2498
;main.c: 2498: adsum -= admin;
	bcf	status, 5	;RP0=0, select bank0
	movf	(AD_Testing@admin),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	subwf	(AD_Testing@adsum)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(AD_Testing@admin+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	skipc
	decf	(AD_Testing@adsum+1)^080h,f	;volatile
	subwf	(AD_Testing@adsum+1)^080h,f	;volatile
	line	2500
	
l10492:	
;main.c: 2500: AD_Result = adsum >> 3;
	movf	(AD_Testing@adsum+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_AD_Testing+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(AD_Testing@adsum)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_AD_Testing+0)+0
	clrc
	rrf	(??_AD_Testing+0)+1,f
	rrf	(??_AD_Testing+0)+0,f
	clrc
	rrf	(??_AD_Testing+0)+1,f
	rrf	(??_AD_Testing+0)+0,f
	clrc
	rrf	(??_AD_Testing+0)+1,f
	rrf	(??_AD_Testing+0)+0,f
	movf	0+(??_AD_Testing+0)+0,w
	movwf	(AD_Testing@AD_Result)	;volatile
	movf	1+(??_AD_Testing+0)+0,w
	movwf	(AD_Testing@AD_Result+1)	;volatile
	line	2502
	
l10494:	
;main.c: 2502: adsum = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(AD_Testing@adsum)^080h	;volatile
	clrf	(AD_Testing@adsum+1)^080h	;volatile
	line	2503
	
l10496:	
;main.c: 2503: admin = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(AD_Testing@admin)	;volatile
	clrf	(AD_Testing@admin+1)	;volatile
	line	2504
	
l10498:	
;main.c: 2504: admax = 0;
	clrf	(AD_Testing@admax)	;volatile
	clrf	(AD_Testing@admax+1)	;volatile
	line	2505
	
l10500:	
;main.c: 2505: adtimes = 0;
	clrf	(AD_Testing@adtimes)	;volatile
	line	2506
	
l10502:	
;main.c: 2506: for(i=0;i<50;i++){
	clrf	(AD_Testing@i)	;volatile
	
l10504:	
	movlw	low(032h)
	subwf	(AD_Testing@i),w	;volatile
	skipc
	goto	u9581
	goto	u9580
u9581:
	goto	l10508
u9580:
	goto	l1490
	line	2507
	
l10508:	
;main.c: 2507: if(NTC_Tab[i]<=AD_Result){
	clrc
	rlf	(AD_Testing@i),w	;volatile
	addlw	low(((_NTC_Tab)|8000h))
	movwf	fsr0
	movlw	high(((_NTC_Tab)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_AD_Testing+0)+0
	fcall	stringtab
	movwf	(??_AD_Testing+0)+0+1
	movf	1+(??_AD_Testing+0)+0,w
	subwf	(AD_Testing@AD_Result+1),w	;volatile
	skipz
	goto	u9595
	movf	0+(??_AD_Testing+0)+0,w
	subwf	(AD_Testing@AD_Result),w	;volatile
u9595:
	skipc
	goto	u9591
	goto	u9590
u9591:
	goto	l10512
u9590:
	line	2508
	
l10510:	
;main.c: 2508: Temp_Ntc=i;
	movf	(AD_Testing@i),w	;volatile
	movwf	(_Temp_Ntc)
	line	2509
;main.c: 2509: break;
	goto	l1490
	line	2506
	
l10512:	
	incf	(AD_Testing@i),f	;volatile
	
l10514:	
	movlw	low(032h)
	subwf	(AD_Testing@i),w	;volatile
	skipc
	goto	u9601
	goto	u9600
u9601:
	goto	l10508
u9600:
	line	2516
	
l1490:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Testing
	__end_of_AD_Testing:
	signat	_AD_Testing,12410
	global	_Initialize

;; *************** function _Initialize *****************
;; Defined at:
;;		line 2588 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Init_ram
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text58,local,class=CODE,delta=2,merge=1,group=0
	line	2588
global __ptext58
__ptext58:	;psect for function _Initialize
psect	text58
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	2588
	global	__size_of_Initialize
	__size_of_Initialize	equ	__end_of_Initialize-_Initialize
	
_Initialize:	
;incstack = 0
	opt	stack 7
; Regs used in _Initialize: [wreg+status,2+status,0+pclath+cstack]
	line	2590
	
l8954:	
# 2590 "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	2591
# 2591 "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text58
	line	2594
	
l8956:	
;main.c: 2594: OSCCON = 0X70;
	movlw	low(070h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(143)^080h	;volatile
	line	2598
;main.c: 2598: PORTA=0B11111111;
	movlw	low(0FFh)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	line	2599
;main.c: 2599: PORTB=0B11111111;
	movlw	low(0FFh)
	movwf	(6)	;volatile
	line	2600
;main.c: 2600: PORTC=0x01;
	movlw	low(01h)
	movwf	(7)	;volatile
	line	2602
;main.c: 2602: TRISA = 0B00111000;
	movlw	low(038h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	line	2603
;main.c: 2603: TRISB = 0B00000010;
	movlw	low(02h)
	movwf	(134)^080h	;volatile
	line	2604
;main.c: 2604: TRISC = 0B00100011;
	movlw	low(023h)
	movwf	(135)^080h	;volatile
	line	2605
;main.c: 2605: TRISD = 0B00000100;
	movlw	low(04h)
	movwf	(136)^080h	;volatile
	line	2607
;main.c: 2607: WPUA = 0B00000001;
	movlw	low(01h)
	movwf	(153)^080h	;volatile
	line	2608
;main.c: 2608: WPUB = 0B00000010;
	movlw	low(02h)
	movwf	(149)^080h	;volatile
	line	2609
;main.c: 2609: WPUC = 0B00000001;
	movlw	low(01h)
	movwf	(154)^080h	;volatile
	line	2611
;main.c: 2611: OPTION_REG = 0x02;
	movlw	low(02h)
	movwf	(129)^080h	;volatile
	line	2612
;main.c: 2612: TMR0 = 255-125;
	movlw	low(082h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(1)	;volatile
	line	2614
;main.c: 2614: TMR1L = (65535-32000)%256;
	movlw	low(0FFh)
	movwf	(14)	;volatile
	line	2615
;main.c: 2615: TMR1H = (65535-32000)/256;
	movlw	low(082h)
	movwf	(15)	;volatile
	line	2616
	
l8958:	
;main.c: 2616: TMR1IF = 0;
	bcf	(96/8),(96)&7	;volatile
	line	2617
	
l8960:	
;main.c: 2617: TMR1IE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1120/8)^080h,(1120)&7	;volatile
	line	2618
;main.c: 2618: T1CON = 0x01;
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(16)	;volatile
	line	2619
;main.c: 2619: ANSEL1 = 0B10000000;
	movlw	low(080h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(137)^080h	;volatile
	line	2621
	
l8962:	
;main.c: 2621: Init_ram();
	fcall	_Init_ram
	line	2622
	
l8964:	
;main.c: 2622: INTEDG = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1038/8)^080h,(1038)&7	;volatile
	line	2623
	
l8966:	
;main.c: 2623: INTCON = 0xe0;
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	2626
	
l1508:	
	return
	opt stack 0
GLOBAL	__end_of_Initialize
	__end_of_Initialize:
	signat	_Initialize,89
	global	_Init_ram

;; *************** function _Init_ram *****************
;; Defined at:
;;		line 2574 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Initialize
;; This function uses a non-reentrant model
;;
psect	text59,local,class=CODE,delta=2,merge=1,group=0
	line	2574
global __ptext59
__ptext59:	;psect for function _Init_ram
psect	text59
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	2574
	global	__size_of_Init_ram
	__size_of_Init_ram	equ	__end_of_Init_ram-_Init_ram
	
_Init_ram:	
;incstack = 0
	opt	stack 7
; Regs used in _Init_ram: [wreg+status,2]
	line	2576
	
l8850:	
# 2576 "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text59
	line	2577
	
l8852:	
;main.c: 2577: PIE2 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(141)^080h	;volatile
	line	2578
	
l8854:	
;main.c: 2578: PIE1 = 0B00000010;
	movlw	low(02h)
	movwf	(140)^080h	;volatile
	line	2579
	
l8856:	
;main.c: 2579: PR2 = 125;
	movlw	low(07Dh)
	movwf	(146)^080h	;volatile
	line	2580
	
l8858:	
;main.c: 2580: T2CON = 5;
	movlw	low(05h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(18)	;volatile
	line	2583
	
l1505:	
	return
	opt stack 0
GLOBAL	__end_of_Init_ram
	__end_of_Init_ram:
	signat	_Init_ram,89
	global	_EEPROM_Page

;; *************** function _EEPROM_Page *****************
;; Defined at:
;;		line 2378 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_ReadDataArry
;;		_SetFilterDelayReset
;;		_WrterEEP
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text60,local,class=CODE,delta=2,merge=1,group=0
	line	2378
global __ptext60
__ptext60:	;psect for function _EEPROM_Page
psect	text60
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	2378
	global	__size_of_EEPROM_Page
	__size_of_EEPROM_Page	equ	__end_of_EEPROM_Page-_EEPROM_Page
	
_EEPROM_Page:	
;incstack = 0
	opt	stack 6
; Regs used in _EEPROM_Page: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	2380
	
l11428:	
;main.c: 2380: ReadDataArry();
	fcall	_ReadDataArry
	line	2382
	
l11430:	
;main.c: 2382: if(Read_Word_Buff[0]==0xA5){
		movlw	165
	bsf	status, 5	;RP0=1, select bank1
	xorwf	((_Read_Word_Buff)^080h),w
	btfss	status,2
	goto	u11041
	goto	u11040
u11041:
	goto	l1470
u11040:
	line	2383
	
l11432:	
;main.c: 2383: FilterPCF_time.u8Hour=Read_Word_Buff[1];
	movf	0+(_Read_Word_Buff)^080h+01h,w
	movwf	0+(_FilterPCF_time)^080h+02h
	line	2384
;main.c: 2384: FilterPCF_time.u16Day=(U16_T)Read_Word_Buff[2]<<8;
	movf	0+(_Read_Word_Buff)^080h+02h,w
	movwf	1+(_FilterPCF_time)^080h+03h
	clrf	0+(_FilterPCF_time)^080h+03h
	line	2385
;main.c: 2385: FilterPCF_time.u16Day|=Read_Word_Buff[3];
	movf	0+(_Read_Word_Buff)^080h+03h,w
	iorwf	0+(_FilterPCF_time)^080h+03h,f
	line	2387
;main.c: 2387: FilterRO_time.u8Hour=Read_Word_Buff[4];
	movf	0+(_Read_Word_Buff)^080h+04h,w
	movwf	0+(_FilterRO_time)^080h+02h
	line	2388
;main.c: 2388: FilterRO_time.u16Day=(U16_T)Read_Word_Buff[5]<<8;
	movf	0+(_Read_Word_Buff)^080h+05h,w
	movwf	1+(_FilterRO_time)^080h+03h
	clrf	0+(_FilterRO_time)^080h+03h
	line	2389
;main.c: 2389: FilterRO_time.u16Day|=Read_Word_Buff[6];
	movf	0+(_Read_Word_Buff)^080h+06h,w
	iorwf	0+(_FilterRO_time)^080h+03h,f
	line	2391
;main.c: 2391: FilterPCFGetWater=Read_Word_Buff[7];
	movf	0+(_Read_Word_Buff)^080h+07h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_FilterPCFGetWater)
	clrf	(_FilterPCFGetWater+1)
	line	2392
;main.c: 2392: FilterPCFGetWater=FilterPCFGetWater<<8;
	movf	(_FilterPCFGetWater),w
	movwf	(_FilterPCFGetWater+1)
	clrf	(_FilterPCFGetWater)
	line	2393
;main.c: 2393: FilterPCFGetWater|=Read_Word_Buff[8];
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_Read_Word_Buff)^080h+08h,w
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(_FilterPCFGetWater),f
	line	2395
;main.c: 2395: FilterROGetWater=Read_Word_Buff[9];
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_Read_Word_Buff)^080h+09h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_FilterROGetWater)
	clrf	(_FilterROGetWater+1)
	line	2396
;main.c: 2396: FilterROGetWater=FilterROGetWater<<8;
	movf	(_FilterROGetWater),w
	movwf	(_FilterROGetWater+1)
	clrf	(_FilterROGetWater)
	line	2397
;main.c: 2397: FilterROGetWater|=Read_Word_Buff[10];
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_Read_Word_Buff)^080h+0Ah,w
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(_FilterROGetWater),f
	line	2402
;main.c: 2402: }
	goto	l11448
	line	2403
	
l1470:	
	line	2405
;main.c: 2403: else
;main.c: 2404: {
;main.c: 2405: _BITS1.Bits.bit_1=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(__BITS1),1
	line	2406
	
l11434:	
;main.c: 2406: Read_Word_Buff[0]=0xA5;
	movlw	low(0A5h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Read_Word_Buff)^080h
	line	2408
	
l11436:	
;main.c: 2408: Read_Word_Buff[11]=1;
	clrf	0+(_Read_Word_Buff)^080h+0Bh
	incf	0+(_Read_Word_Buff)^080h+0Bh,f
	line	2409
	
l11438:	
;main.c: 2409: SetFilterDelayReset(&FilterPCF_time, 365, 0, 0, 0);
	movlw	06Dh
	bcf	status, 5	;RP0=0, select bank0
	movwf	(SetFilterDelayReset@Day)
	movlw	01h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterPCF_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	2410
	
l11440:	
;main.c: 2410: SetFilterDelayReset(&FilterRO_time, 1095, 0, 0, 0);
	movlw	047h
	movwf	(SetFilterDelayReset@Day)
	movlw	04h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterRO_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	2411
	
l11442:	
;main.c: 2411: FilterROGetWater=0;
	clrf	(_FilterROGetWater)
	clrf	(_FilterROGetWater+1)
	line	2412
	
l11444:	
;main.c: 2412: FilterPCFGetWater=0;
	clrf	(_FilterPCFGetWater)
	clrf	(_FilterPCFGetWater+1)
	line	2413
	
l11446:	
;main.c: 2413: WrterEEP();
	fcall	_WrterEEP
	line	2415
	
l11448:	
;main.c: 2414: }
;main.c: 2415: _BITS1.Bits.bit_0=1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(__BITS1),0
	line	2416
	
l11450:	
;main.c: 2416: PreROu16Day=FilterRO_time.u16Day;
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_FilterRO_time)^080h+03h,w
	movwf	(_PreROu16Day+1)^080h
	movf	0+(_FilterRO_time)^080h+03h,w
	movwf	(_PreROu16Day)^080h
	line	2417
	
l11452:	
;main.c: 2417: PrePCFu16Day=FilterPCF_time.u16Day;
	movf	1+(_FilterPCF_time)^080h+03h,w
	movwf	(_PrePCFu16Day+1)^080h
	movf	0+(_FilterPCF_time)^080h+03h,w
	movwf	(_PrePCFu16Day)^080h
	line	2418
	
l11454:	
;main.c: 2418: _BITS1.Bits.bit_7=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(__BITS1),7
	line	2426
	
l11456:	
;main.c: 2425: if((FilterROGetWater>=(21*2))
;main.c: 2426: &&(FilterPCFGetWater>=(21*2))){
	movlw	0
	subwf	(_FilterROGetWater+1),w
	movlw	02Ah
	skipnz
	subwf	(_FilterROGetWater),w
	skipc
	goto	u11051
	goto	u11050
u11051:
	goto	l1473
u11050:
	
l11458:	
	movlw	0
	subwf	(_FilterPCFGetWater+1),w
	movlw	02Ah
	skipnz
	subwf	(_FilterPCFGetWater),w
	skipc
	goto	u11061
	goto	u11060
u11061:
	goto	l1473
u11060:
	line	2429
	
l11460:	
;main.c: 2429: _BITS1.Bits.bit_7=1;
	bsf	(__BITS1),7
	line	2431
	
l1473:	
	return
	opt stack 0
GLOBAL	__end_of_EEPROM_Page
	__end_of_EEPROM_Page:
	signat	_EEPROM_Page,89
	global	_WrterEEP

;; *************** function _WrterEEP *****************
;; Defined at:
;;		line 2352 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_GetMode_Handle
;;		_FilterKeyInputRest
;;		_StandbyMode_Handle
;;		_EEPROM_Page
;; This function uses a non-reentrant model
;;
psect	text61,local,class=CODE,delta=2,merge=1,group=0
	line	2352
global __ptext61
__ptext61:	;psect for function _WrterEEP
psect	text61
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	2352
	global	__size_of_WrterEEP
	__size_of_WrterEEP	equ	__end_of_WrterEEP-_WrterEEP
	
_WrterEEP:	
;incstack = 0
	opt	stack 6
; Regs used in _WrterEEP: [wreg+status,2+status,0]
	line	2353
	
l9568:	
;main.c: 2353: if(FilterFastCheck) return;
	bcf	status, 5	;RP0=0, select bank0
	movf	((_FilterFastCheck)),w
	btfsc	status,2
	goto	u8081
	goto	u8080
u8081:
	goto	l9572
u8080:
	goto	l1462
	line	2355
	
l9572:	
;main.c: 2355: Read_Word_Buff[1]=FilterPCF_time.u8Hour;
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_FilterPCF_time)^080h+02h,w
	movwf	0+(_Read_Word_Buff)^080h+01h
	line	2356
;main.c: 2356: Read_Word_Buff[2]=FilterPCF_time.u16Day>>8;
	movf	1+(_FilterPCF_time)^080h+03h,w
	movwf	0+(_Read_Word_Buff)^080h+02h
	line	2357
;main.c: 2357: Read_Word_Buff[3]=FilterPCF_time.u16Day&0X00FF;
	movf	0+(_FilterPCF_time)^080h+03h,w
	movwf	0+(_Read_Word_Buff)^080h+03h
	line	2359
;main.c: 2359: Read_Word_Buff[4]=FilterRO_time.u8Hour;
	movf	0+(_FilterRO_time)^080h+02h,w
	movwf	0+(_Read_Word_Buff)^080h+04h
	line	2360
;main.c: 2360: Read_Word_Buff[5]=FilterRO_time.u16Day>>8;
	movf	1+(_FilterRO_time)^080h+03h,w
	movwf	0+(_Read_Word_Buff)^080h+05h
	line	2361
;main.c: 2361: Read_Word_Buff[6]=FilterRO_time.u16Day&0X00FF;
	movf	0+(_FilterRO_time)^080h+03h,w
	movwf	0+(_Read_Word_Buff)^080h+06h
	line	2363
;main.c: 2363: Read_Word_Buff[7]=FilterPCFGetWater>>8;
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(_FilterPCFGetWater)+01h,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_Read_Word_Buff)^080h+07h
	line	2364
;main.c: 2364: Read_Word_Buff[8]=FilterPCFGetWater&0X00FF;
	bcf	status, 5	;RP0=0, select bank0
	movf	(_FilterPCFGetWater),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_Read_Word_Buff)^080h+08h
	line	2366
;main.c: 2366: Read_Word_Buff[9]=FilterROGetWater>>8;
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(_FilterROGetWater)+01h,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_Read_Word_Buff)^080h+09h
	line	2367
;main.c: 2367: Read_Word_Buff[10]=FilterROGetWater&0X00FF;
	bcf	status, 5	;RP0=0, select bank0
	movf	(_FilterROGetWater),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_Read_Word_Buff)^080h+0Ah
	line	2369
	
l9574:	
;main.c: 2369: _BITS.Bits.bit_4=1;
	bsf	(__BITS),4
	line	2370
	
l1462:	
	return
	opt stack 0
GLOBAL	__end_of_WrterEEP
	__end_of_WrterEEP:
	signat	_WrterEEP,89
	global	_SetFilterDelayReset

;; *************** function _SetFilterDelayReset *****************
;; Defined at:
;;		line 404 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  TimPtr          1    wreg     PTR struct .
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;;  Day             2    0[BANK0 ] unsigned int 
;;  hour            1    2[BANK0 ] unsigned char 
;;  min             1    3[BANK0 ] unsigned char 
;;  sec             2    4[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  TimPtr          1    4[COMMON] PTR struct .
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       6       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       6       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_FilterKeyInputRest
;;		_EEPROM_Page
;; This function uses a non-reentrant model
;;
psect	text62,local,class=CODE,delta=2,merge=1,group=0
	line	404
global __ptext62
__ptext62:	;psect for function _SetFilterDelayReset
psect	text62
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	404
	global	__size_of_SetFilterDelayReset
	__size_of_SetFilterDelayReset	equ	__end_of_SetFilterDelayReset-_SetFilterDelayReset
	
_SetFilterDelayReset:	
;incstack = 0
	opt	stack 6
; Regs used in _SetFilterDelayReset: [wreg-fsr0h+status,2+status,0]
;SetFilterDelayReset@TimPtr stored from wreg
	movwf	(SetFilterDelayReset@TimPtr)
	line	406
	
l9398:	
;main.c: 406: TimPtr->u16Day=Day;
	movf	(SetFilterDelayReset@TimPtr),w
	addlw	03h
	movwf	fsr0
	movf	(SetFilterDelayReset@Day),w
	bcf	status, 7	;select IRP bank0
	movwf	indf
	incf	fsr0,f
	movf	(SetFilterDelayReset@Day+1),w
	movwf	indf
	line	407
;main.c: 407: TimPtr->u8Hour=hour;
	movf	(SetFilterDelayReset@TimPtr),w
	addlw	02h
	movwf	fsr0
	movf	(SetFilterDelayReset@hour),w
	movwf	indf
	line	408
	
l9400:	
;main.c: 408: TimPtr->u8Minute=min;
	incf	(SetFilterDelayReset@TimPtr),w
	movwf	fsr0
	movf	(SetFilterDelayReset@min),w
	movwf	indf
	line	409
	
l9402:	
;main.c: 409: TimPtr->u8Second=sec;
	movf	(SetFilterDelayReset@TimPtr),w
	movwf	fsr0
	movf	(SetFilterDelayReset@sec),w
	movwf	indf
	line	410
	
l1040:	
	return
	opt stack 0
GLOBAL	__end_of_SetFilterDelayReset
	__end_of_SetFilterDelayReset:
	signat	_SetFilterDelayReset,20601
	global	_ReadDataArry

;; *************** function _ReadDataArry *****************
;; Defined at:
;;		line 2371 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               2    0[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       2       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Memory_Read
;; This function is called by:
;;		_EEPROM_Page
;; This function uses a non-reentrant model
;;
psect	text63,local,class=CODE,delta=2,merge=1,group=0
	line	2371
global __ptext63
__ptext63:	;psect for function _ReadDataArry
psect	text63
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	2371
	global	__size_of_ReadDataArry
	__size_of_ReadDataArry	equ	__end_of_ReadDataArry-_ReadDataArry
	
_ReadDataArry:	
;incstack = 0
	opt	stack 6
; Regs used in _ReadDataArry: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	2373
	
l11356:	
;main.c: 2373: unsigned int i=0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ReadDataArry@i)
	clrf	(ReadDataArry@i+1)
	line	2374
;main.c: 2374: for(i=0;i<12;i++){
	clrf	(ReadDataArry@i)
	clrf	(ReadDataArry@i+1)
	line	2375
	
l11362:	
;main.c: 2375: Read_Word_Buff[i]=Memory_Read(i);
	movf	(ReadDataArry@i),w
	addlw	low(_Read_Word_Buff|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(ReadDataArry@i+1),w
	movwf	(Memory_Read@Addr+1)
	movf	(ReadDataArry@i),w
	movwf	(Memory_Read@Addr)
	fcall	_Memory_Read
	movf	(0+(?_Memory_Read)),w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	line	2374
	
l11364:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(ReadDataArry@i),f
	skipnz
	incf	(ReadDataArry@i+1),f
	
l11366:	
	movlw	0
	subwf	(ReadDataArry@i+1),w
	movlw	0Ch
	skipnz
	subwf	(ReadDataArry@i),w
	skipc
	goto	u10991
	goto	u10990
u10991:
	goto	l11362
u10990:
	line	2377
	
l1467:	
	return
	opt stack 0
GLOBAL	__end_of_ReadDataArry
	__end_of_ReadDataArry:
	signat	_ReadDataArry,89
	global	_Memory_Read

;; *************** function _Memory_Read *****************
;; Defined at:
;;		line 1816 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Addr            2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  2    4[COMMON] unsigned int 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/300
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ReadDataArry
;; This function uses a non-reentrant model
;;
psect	text64,local,class=CODE,delta=2,merge=1,group=0
	line	1816
global __ptext64
__ptext64:	;psect for function _Memory_Read
psect	text64
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	1816
	global	__size_of_Memory_Read
	__size_of_Memory_Read	equ	__end_of_Memory_Read-_Memory_Read
	
_Memory_Read:	
;incstack = 0
	opt	stack 6
; Regs used in _Memory_Read: [wreg]
	line	1819
	
l11132:	
;main.c: 1819: EEADR = Addr;
	movf	(Memory_Read@Addr),w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(391)^0180h	;volatile
	line	1820
	
l11134:	
;main.c: 1820: EEPGD = 0;
	bcf	(3175/8)^0180h,(3175)&7	;volsfr
	line	1827
	
l11136:	
;main.c: 1827: RD=1;
	bsf	(3168/8)^0180h,(3168)&7	;volsfr
	line	1828
# 1828 "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	1829
# 1829 "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
nop ;# 
psect	text64
	line	1832
;main.c: 1832: return (EEDAT);
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(390)^0180h,w	;volatile
	movwf	(?_Memory_Read)
	clrf	(?_Memory_Read+1)
	line	1836
	
l1358:	
	return
	opt stack 0
GLOBAL	__end_of_Memory_Read
	__end_of_Memory_Read:
	signat	_Memory_Read,4218
	global	_Timer1_Isr

;; *************** function _Timer1_Isr *****************
;; Defined at:
;;		line 2629 in file "E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          4       0       0       0
;;      Totals:         4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		___CMS_TouchKeyValue
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text65,local,class=CODE,delta=2,merge=1,group=0
	line	2629
global __ptext65
__ptext65:	;psect for function _Timer1_Isr
psect	text65
	file	"E:\Project\Sbaak\Sbaak_738B\Sbaake\main.c"
	line	2629
	global	__size_of_Timer1_Isr
	__size_of_Timer1_Isr	equ	__end_of_Timer1_Isr-_Timer1_Isr
	
_Timer1_Isr:	
;incstack = 0
	opt	stack 2
; Regs used in _Timer1_Isr: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	movwf	(??_Timer1_Isr+0)
	movf	fsr0,w
	movwf	(??_Timer1_Isr+1)
	movf	pclath,w
	movwf	(??_Timer1_Isr+2)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	btemp+1,w
	movwf	(??_Timer1_Isr+3)
	ljmp	_Timer1_Isr
psect	text65
	line	2632
	
i1l9056:	
;main.c: 2631: static U8_T T1_1ms=0;
;main.c: 2632: if(T0IF)
	btfss	(90/8),(90)&7	;volatile
	goto	u739_21
	goto	u739_20
u739_21:
	goto	i1l9062
u739_20:
	line	2635
	
i1l9058:	
;main.c: 2633: {
;main.c: 2635: TMR0 += 255-125;
	movlw	low(082h)
	addwf	(1),f	;volatile
	line	2638
	
i1l9060:	
;main.c: 2638: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	2649
	
i1l9062:	
;main.c: 2647: }
;main.c: 2649: if(TMR1IF)
	btfss	(96/8),(96)&7	;volatile
	goto	u740_21
	goto	u740_20
u740_21:
	goto	i1l9072
u740_20:
	line	2652
	
i1l9064:	
;main.c: 2650: {
;main.c: 2652: TMR1L += (65535-32000)%256;
	movlw	low(0FFh)
	addwf	(14),f	;volatile
	line	2653
;main.c: 2653: TMR1H += (65535-32000)/256;
	movlw	low(082h)
	addwf	(15),f	;volatile
	line	2657
;main.c: 2657: if(++T1_1ms>=10){
	movlw	low(0Ah)
	bsf	status, 5	;RP0=1, select bank1
	incf	(Timer1_Isr@T1_1ms)^080h,f
	subwf	((Timer1_Isr@T1_1ms)^080h),w
	skipc
	goto	u741_21
	goto	u741_20
u741_21:
	goto	i1l9070
u741_20:
	line	2658
	
i1l9066:	
;main.c: 2658: T1_1ms=0;
	clrf	(Timer1_Isr@T1_1ms)^080h
	line	2659
	
i1l9068:	
;main.c: 2659: _BITS2.Bits.bit_0=1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(__BITS2),0
	line	2662
	
i1l9070:	
;main.c: 2660: }
;main.c: 2662: TMR1IF = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(96/8),(96)&7	;volatile
	line	2664
	
i1l9072:	
;main.c: 2663: }
;main.c: 2664: if(TMR2IF)
	btfss	(97/8),(97)&7	;volatile
	goto	u742_21
	goto	u742_20
u742_21:
	goto	i1l9078
u742_20:
	line	2666
	
i1l9074:	
;main.c: 2665: {
;main.c: 2666: TMR2IF = 0;
	bcf	(97/8),(97)&7	;volatile
	line	2668
	
i1l9076:	
;main.c: 2668: __CMS_TouchKeyValue();
	fcall	___CMS_TouchKeyValue
	line	2670
	
i1l9078:	
;main.c: 2669: }
;main.c: 2670: if(INTF)
	btfss	(89/8),(89)&7	;volatile
	goto	u743_21
	goto	u743_20
u743_21:
	goto	i1l1521
u743_20:
	line	2672
	
i1l9080:	
;main.c: 2671: {
;main.c: 2672: INTF = 0;
	bcf	(89/8),(89)&7	;volatile
	line	2673
	
i1l9082:	
;main.c: 2673: if(PureTDSTyp.HzCount<0xfff0)
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	1+(_PureTDSTyp)^0100h+0Dh,w
	movlw	0F0h
	skipnz
	subwf	0+(_PureTDSTyp)^0100h+0Dh,w
	skipnc
	goto	u744_21
	goto	u744_20
u744_21:
	goto	i1l1521
u744_20:
	line	2674
	
i1l9084:	
;main.c: 2674: PureTDSTyp.HzCount++;
	incf	0+(_PureTDSTyp)^0100h+0Dh,f
	skipnz
	incf	1+(_PureTDSTyp)^0100h+0Dh,f
	line	2677
	
i1l1521:	
	movf	(??_Timer1_Isr+3),w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	movf	(??_Timer1_Isr+2),w
	movwf	pclath
	movf	(??_Timer1_Isr+1),w
	movwf	fsr0
	swapf	(??_Timer1_Isr+0)^0FFFFFF80h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Timer1_Isr
	__end_of_Timer1_Isr:
	signat	_Timer1_Isr,89
	global	___CMS_TouchKeyValue

;; *************** function ___CMS_TouchKeyValue *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Timer1_Isr
;; This function uses a non-reentrant model
;;
psect	text66,local,class=CODE,delta=2,merge=1,group=1
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
global __ptext66
__ptext66:	;psect for function ___CMS_TouchKeyValue
psect	text66
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_TouchKeyValue
	__size_of___CMS_TouchKeyValue	equ	__end_of___CMS_TouchKeyValue-___CMS_TouchKeyValue
	
___CMS_TouchKeyValue:	
;incstack = 0
	opt	stack 2
; Regs used in ___CMS_TouchKeyValue: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
	
i1l8968:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text66
	btfss	(_926/8),(_926)&7	;volatile
	goto	u734_21
	goto	u734_20
u734_21:
	goto	i1l3689
u734_20:
	
i1l8970:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(13),(6)&7	;volatile
	goto	u735_21
	goto	u735_20
u735_21:
	goto	i1l3689
u735_20:
	
i1l8972:	
	bcf	(13)+(6/8),(6)&7	;volatile
	
i1l8974:	
	movf	((_918)),w	;volatile
	btfss	status,2
	goto	u736_21
	goto	u736_20
u736_21:
	goto	i1l3689
u736_20:
	
i1l8976:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(415)^0180h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_922)	;volatile
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
i1l8978:	
	clrc
	rlf	(_919),w	;volatile
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(411)^0180h,w	;volatile
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(412)^0180h,w	;volatile
	movwf	indf
	
i1l8980:	
	clrc
	rlf	(_919),w	;volatile
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(409)^0180h,w	;volatile
	movwf	indf
	incf	fsr0,f
	movf	(410)^0180h,w	;volatile
	movwf	indf
	movlw	low(08h)
	movwf	(415)^0180h	;volatile
	
i1l8982:	
	clrc
	rlf	(_919),w	;volatile
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(413)^0180h,w	;volatile
	movwf	indf
	incf	fsr0,f
	movf	(414)^0180h,w	;volatile
	movwf	indf
	
i1l8984:	
	movlw	low(02h)
	incf	(_919),f	;volatile
	subwf	((_919)),w	;volatile
	skipc
	goto	u737_21
	goto	u737_20
u737_21:
	goto	i1l8990
u737_20:
	
i1l8986:	
	clrf	(_919)	;volatile
	
i1l8988:	
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_918)	;volatile
	goto	i1l9024
	
i1l8990:	
	movlw	low(0C2h)
	andwf	(400)^0180h,f	;volatile
	movlw	low(0E0h)
	andwf	(401)^0180h,f	;volatile
	
i1l8992:	
	movf	(_919),w
	addlw	low(((_gc_Table_KeyChannel)|8000h))
	movwf	fsr0
	movlw	high(((_gc_Table_KeyChannel)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	andlw	01Fh
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(401)^0180h,f	;volatile
	
i1l8994:	
	movlw	low(010h)
	movwf	(415)^0180h	;volatile
	
i1l8996:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u738_21
	goto	u738_20
u738_21:
	goto	i1l9008
u738_20:
	
i1l8998:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(_923)	;volatile
	
i1l9000:	
	movlw	low(0Fh)
	andwf	(_923),f	;volatile
	
i1l9002:	
	movlw	low(0F1h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(405)^0180h,f	;volatile
	
i1l9004:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_923),w
	addlw	low(((_sc_CurStep_Table)|8000h))
	movwf	fsr0
	movlw	high(((_sc_CurStep_Table)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(405)^0180h,f	;volatile
	
i1l9006:	
	movf	(_919),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(406)^0180h	;volatile
	goto	i1l9018
	
i1l9008:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	swapf	indf,w
	andlw	(0ffh shr 4) & 0ffh
	movwf	(_923)	;volatile
	
i1l9010:	
	movlw	low(0Fh)
	andwf	(_923),f	;volatile
	
i1l9012:	
	movlw	low(0F1h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(405)^0180h,f	;volatile
	
i1l9014:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_923),w
	addlw	low(((_sc_CurStep_Table)|8000h))
	movwf	fsr0
	movlw	high(((_sc_CurStep_Table)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(405)^0180h,f	;volatile
	
i1l9016:	
	movf	(_919),w
	addlw	low(432|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(406)^0180h	;volatile
	
i1l9018:	
	movf	(406)^0180h,w	;volatile
	movwf	(407)^0180h	;volatile
	
i1l9022:	
	bsf	(400)^0180h+(0/8),(0)&7	;volatile
	
i1l9024:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_922),w	;volatile
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
i1l3689:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text66
	
i1l3698:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_TouchKeyValue
	__end_of___CMS_TouchKeyValue:
	signat	___CMS_TouchKeyValue,89
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end

#ifndef _FUNC_H
#define _FUNC_H

#include <cms.h>					//о?????????????????????????????????



//typedef unsigned char   	uchar;
//typedef unsigned int   	uint;
typedef unsigned char   	U8_T;
typedef unsigned int   	U16_T;
typedef unsigned long   	U32_T;
typedef unsigned char   	uint8_t;
typedef unsigned int   	uint16_t;
typedef float           F32_T;
typedef double          F64_T;

#ifdef Main_F

#define exter 

#else
 
#define exter extern

#endif 
#define  HEADDATAI             0xAA   
#define  HEADDATAII            0x55   
#define  RECVMAXBUF            14
  
#define Rx_Max   15 

//#define TestHz
#define AQPFilterT  1825	 
#define In3FilterT  365   
#define G_400     0
#define G_600     1 
#define G_800     2  
#define G800     G_800    


//#define  Debug    
  


#if G800==G_400

#define Unit_L 11

#elif G800==G_600 

#define Unit_L 16

#else

#define Unit_L 21	

#endif

//#define DISABLE  0
//#define ENABLE  1 



//#define DebugTouch
/**************************Buzzer*******************************************************/
#define ToneC6 	1 
#define ToneCS6 2 
#define ToneD6 	3 
#define ToneDS6 4 
#define ToneE6 	5 
#define ToneF6 	6 
#define ToneFS6 7 
#define ToneG6 	8 
#define ToneGS6 9 
#define ToneA6 	10 
#define ToneAS6 11 
#define ToneB6 	12 

#define ToneC7 13 
#define ToneCS7 14 
#define ToneD7 15 
#define ToneDS7 16 
#define ToneE7 17 
#define ToneF7 18 
#define ToneFS7 19
#define ToneG7 20 
#define ToneGS7 21
#define ToneA7 22 
#define ToneAS7 23
#define ToneAB7 24

#define END  0

#define Sound1 0
#define Sound2 1
#define Sound3 2
#define Sound4 3

#define SoundPow   0
#define  SoundShortSingle     1
#define  SoundLongSingle     2
#define  SoundSupLongSingle     3

#define PowerNum  9
#define SingleNum  3
#define ReadNum     12

/*********************************************************************************/
#define Bu_6s     1200

#define Bu_1s     200
#define bu_500ms	100
#define bu_250ms	50
#define GetStyMod          0x00
#define GetWaterMod        0x01
#define GetErrorMod               0x02

#define  Error_Normal   0x00
#define  Error_Get   0x02
#define  Error_Uart   0x03

#define HiHail      0
#define KeyTK1     1
#define keyTk2      2

#define Read_HallSwitch_IO   RC1

//#define Buz_On  RC4=0                
//#define Buz_Off  RC4=1  
       
#define InputValveOpen  RC3=1                
#define InputValveClose  RC3=0  


#define WasteValveOpen  RC2=1               
#define WasteValveClose  RC2=0


#define BackValveOpen  RA1=1               
#define BackValveClose  RA1=0

#define TDS_KG_On  RA0=0
#define TDS_KG_Off  RA0=1

#define MotoOpen  {RA2=1;MotoFalg=1;}           
#define MotoClose {RA2=0;MotoFalg=0;}

#define LedWifiRed_O    RB5
#define LedWifiBlue_O    RB4

#define Led3inRed_O     RB0
#define Led3inBlue_O     RB2

#define LedAQPRed_O     RA6
#define LedAQPBlue_O     RA7

#define LedWashRed_O     RB6
#define LedWashBlue_O     RB3

#define B_ON     RC4^=1
#define B_OFF     RC4=1


#define  Max_Rx_Num 5
#define   CkNum     4

#define  RX_FH1_Num  0x0
#define  RX_FH2_Num  0x1

#define  RX_FH1  0xA5
#define  RX_FH2  0xA6

#define Off_L   0
#define On_L  1
#define Flash_L 2

#define On  0
#define Off 1

#define  Max_Led_Num 6
#define  FastFlashTime  25
#define  FlashTime 		100


#define Normal   0
#define Specillay   0x81

#define AutBoil    200
#define AutBoilOver    201

/*
#define KeyChildLock   0
#define KeyTemp   1
#define KeyValueMl   0
#define KeyGet   2
*/

#define HiVSwitch   0
#define KeyWash   2
#define KeyFilter   1
//#define KeyRO   3
//#define HiVSwitch  4


#define Wifi_LedBlue     7
#define Wifi_LedRed     6

#define in3_LedBlue   5
#define in3_LedRed   4

#define AQP_LedBlue     3
#define AQP_LedRed     2

#define Wash_LedBlue    1
#define Wash_LedRed    0




#define  PowerMode    0
#define  SleepMode      1
#define  StandbyMode 2
#define  ErrorMode    3
#define  GetMode      4
#define  FactoryMod   5






#define ErrorAlarm   3
#define ShortSing  30
//#define SoundLongSingle   100
#define Eooer_E    0x0a
// unit 10ms
#define K_MAX_VALUE 2200     
#define K_SUPER_LONG_VALUE 2100    
#define K_SUPER_VALUE 1000   
#define K_LONG_VALUE 300    
#define K_SHORT_VALUE 3    
#define K_NOPRESS_VALUE 0

#define FilterLedOff  	       0
#define FilterNormal  	       1
#define FilterPreWarning  2
#define FilterExpire   		3
#define BreathPeriod        6000
#define BreathLedMin        6001
#define BreathLedMax	0

#define Drop	0
#define Rise	1

typedef union
{
	uint8_t Byte;
	struct 
	{
		uint8_t bit_0 :1;
		uint8_t bit_1 :1;
		uint8_t bit_2 :1;
		uint8_t bit_3 :1;
		uint8_t bit_4 :1;
		uint8_t bit_5 :1;
		uint8_t bit_6 :1;
		uint8_t bit_7 :1; 	
	 }Bits;
} BITS;
BITS _BITS;
#define  LedFlashFinish_Flag  _BITS.Bits.bit_0        //Led flash finish goto
#define  FilterRstState  _BITS.Bits.bit_1
#define  PowerWashFlag  _BITS.Bits.bit_2      
#define  FilterSelectType  _BITS.Bits.bit_3

#define  WriteEEP_Flag  _BITS.Bits.bit_4      
#define  GetWaterState  _BITS.Bits.bit_5
#define  TdsMake_Flag  _BITS.Bits.bit_6     
#define  BuzzerEnableFlag  _BITS.Bits.bit_7

BITS _BITS1;
#define  Powerfirst  _BITS1.Bits.bit_0        //
#define  EEP_Me  _BITS1.Bits.bit_1        //
#define  FilterAqpRstFlag  _BITS1.Bits.bit_2        //
#define  Filter3inRstFlag  _BITS1.Bits.bit_3        //
#define  BackRunFlag  _BITS1.Bits.bit_4        //
//#define  TdsCk60sFlag  _BITS1.Bits.bit_5       //
#define  BackRun12HFlag  _BITS1.Bits.bit_6 
#define  FirstMakeWater  _BITS1.Bits.bit_7 

BITS _BITS2;
#define  Time_flag_10ms  _BITS2.Bits.bit_0 
#define  MotoFalg  _BITS2.Bits.bit_1 
#define  Wash72HFlag  _BITS2.Bits.bit_2 


/*
typedef enum FunctionalStatus{
	DISABLE = 0,
	ENABLE = 1
} ; 
*/

//exter U8_T EEP_Me;
typedef struct  
{	
//	LedStat LedState;	
	U8_T LedState;	
	U16_T   LedTime; 
	U16_T   LedFlashNum; 
		
}LedType;

#define TdsTab_Max   5
typedef struct 
{	
//	LedStat LedState;	
	/*
	U32_T TdsHz_Tab[TdsTab_Max];	
	U8_T   TdsTime; 
	U16_T  TdsHz; 
	U32_T  HzCount;
 	U32_T TdsData;
 	U16_T TdsHzMax;
 	U16_T TdsHzMin;
 	U8_T FactoryTestHz;
 	U32_T PreTdsData;
 	*/
 	U16_T TdsHz_Tab[TdsTab_Max];	
	U8_T   TdsTime; 
	U16_T  TdsHz; 
	U16_T  HzCount;
 	U16_T TdsData;
 //	U16_T TdsHzMax;
 //	U8_T TdsHzMin;
 //	U8_T PreTdsData;	
}TDSType_t;
//exter TDSType_t RawTDSTyp;
exter  TDSType_t PureTDSTyp;


/*
typedef struct
{
	U8_T Rx_FH1;
	U8_T Rx_FH2;
	U8_T Rx_TotalLength;
	U8_T Rx_Data;
	U8_T Rx_Check;
}RxTyp;

typedef union
{
	RxTyp RxType;
	U8_T Rx_Tab[Max_Rx_Num];
}R_Type;
*/
//exter R_Type Rx_Type;

#define FILTER_X_HOUR 23
#define FILTER_X_MIN 59 // -> 1 Hour
#define FILTER_X_SEC 59	// ->1 min


typedef struct 
{
     U8_T  u8Second;         
     U8_T  u8Minute;      
     U8_T  u8Hour;       
     U16_T  u16Day;            
} Filter_time_t; 

exter Filter_time_t FilterPCF_time;
exter Filter_time_t FilterRO_time;

#define PFCLife 0
#define ROLife   1

#define DrainT 180
#define BackT 30
#define WashT 30

#define StateLedOff 0
#define StateLedOn  1

#define WashLedOff  0
#define WashOn  2
#define WashBreathe  1
#define WashFlash 5
#define WashErrorLong 3

#define RstSty   0
#define RstSelect  1
#define RstIndi   2

#define Ba_Colse   0
#define Ba_Open 1
#define Ba_run   2
#define Ba_Stop   3

//exter U8_T DiaplayWashState;


typedef enum 
{
	NornalStopState=0,	
	WashState=1,	
	DrainState=2,
	BackState=3,
	RainPressure=4,
}StyStat;

#define Raw_Flag   0
#define Pure_Flag   1
//exter U32_T NTC_;
//exter U32_T Muni_c;
exter U16_T Time_made_1s;
exter  U8_T Timer_ErrorLong_1s;
exter  U8_T FilterFastCheck;

exter U8_T Timer_TdsMake_1s;

//exter U8_T TdsMake_Flag;


//exter U8_T SingNums;

//exter U8_T LedFlashFinish_Flag;    //Led flash finish goto



//exter U8_T Write_Word_Buff[10];
exter U8_T Read_Word_Buff[ReadNum];



//exter  unsigned long adsum;
//exter unsigned int admin;
//exter unsigned int admax;
//exter unsigned int Voltage_ntc;
//exter U8_T Temp_Ntc;





//exter U8_T UartErrorCount;
//exter U16_T UartErrorCountTime;


exter StyStat StandByStatus;

exter U8_T WashRunTime;













exter U16_T GetWater_ML;

exter U16_T FilterPCFGetWater;
exter U16_T FilterROGetWater;


//exter U8_T EEP_Me;


exter LedType LedMod[Max_Led_Num];





exter U8_T FilterPCFState;
exter U8_T FilterROState;  


 

//exter U8_T Timer_HISoff_100ms;

exter U8_T Timer_Power_100ms;
exter U16_T Timer_LongGetWater_1s;

//exter U8_T Timer_NotWater_10ms;

exter U8_T Time_1s;
exter U8_T Time_GetWater_1s;
//exter U8_T Time_GetWater_1Min;


exter U8_T Time_100ms;
//exter U16_T Time_Tx_10ms;
//exter U8_T Time_Rx_10ms;
//exter U8_T Time_ErrorEU_100ms;
//exter U16_T Time_NotWater_100ms;


//exter U16_T Key_Map_bk;
//exter U8_T ScanCount;


//exter U8_T Func_Flag_10ms;


//exter U8_T HallSwitch_Flag;
exter U8_T PowerStep;
exter U8_T Mode;

//exter	 U8_T DisplayTdsType;


//exter	 U16_T PureTds;
//exter	 U16_T RawTds;

//exter	 U16_T RxDataPtr;
//exter	 U16_T TxDataPtr;
//exter	 U8_T RxDataFlag;
//exter	 U8_T TxDataFlag;

void Deal_ADC();
void ADC_Sample(unsigned char ADCset1,unsigned char ADCset2);
void DelayXms(unsigned char x);
void PWM_System(void);
void Sleep_System();
void Sleep_Mode();
void Time0_System(void);
void IO_System();

void ShiftMode_Handle(U8_T Mod);
void Led_Handle();
void LedSetSt(U8_T Num,U8_T Sta);
void LedControlSt(U8_T Num,U8_T Sta);
void LedIndicationFunc();
void  LedGreOff ();
void  LedGreOn();
void  LedRedOff();
void  LedRedOn();
void GetStart(void);
void GetStop(void);
U8_T GetDelayFilterFlag(Filter_time_t * PtrMin);
void SetFilterDelayReset(Filter_time_t *TimPtr,U16_T Day,U8_T hour,U8_T min,U16_T sec);
void FilterLifeFunc(void);
void FilterTimeHandle(Filter_time_t Filter_time,U8_T *FilterState,U8_T Type,U16_T *FilterGetWater);
void SetStandbyState(StyStat STY,U8_T *Time,U8_T Da);
void SoundSet();
void BuzzerStart(U8_T Nums,U8_T type);
void SoundControl(void);
void RainPressHandle(void);
void BackHandle(void);
void StatusFun_Handle();
void ErrorHandle();
void FilterKeyInputRest(void);	
void BuzzerSet(uint8_t cnt,uint16_t filter);
 void KeyScan(uint8_t sw_port,uint8_t num);
 void TaskAlarmHandle(void);
void Page_ProgramData();
void  Tx_Display(void);
void Run_Mode(void);
unsigned int  AD_Testing(unsigned char ad_fd,unsigned char ad_ch,unsigned char ad_lr);
#endif

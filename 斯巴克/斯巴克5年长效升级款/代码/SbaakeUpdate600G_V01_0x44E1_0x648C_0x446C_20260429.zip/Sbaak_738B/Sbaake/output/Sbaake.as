opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	79F738B
opt include "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\include\79f738b.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
	FNCALL	_main,_EEPROM_Page
	FNCALL	_main,_Initialize
	FNCALL	_main,_Run_Mode
	FNCALL	_main,_Set_PWM
	FNCALL	_main,_Set_Usart_Async
	FNCALL	_main,_Time_Count_Func
	FNCALL	_Run_Mode,_AllLedFlash
	FNCALL	_Run_Mode,_BuzzerSet
	FNCALL	_Run_Mode,_FactoryMode_Handle
	FNCALL	_Run_Mode,_GetMode_Handle
	FNCALL	_Run_Mode,_LedSetSt
	FNCALL	_Run_Mode,_SetStandbyState
	FNCALL	_Run_Mode,_ShiftMode_Handle
	FNCALL	_Run_Mode,_StandbyMode_Handle
	FNCALL	_StandbyMode_Handle,_BuzzerSet
	FNCALL	_StandbyMode_Handle,_LedSetSt
	FNCALL	_StandbyMode_Handle,_SetStandbyState
	FNCALL	_StandbyMode_Handle,_ShiftMode_Handle
	FNCALL	_StandbyMode_Handle,_StatusFun_Handle
	FNCALL	_StandbyMode_Handle,_WrterEEP
	FNCALL	_StatusFun_Handle,_SetStandbyState
	FNCALL	_StatusFun_Handle,_WashHandle
	FNCALL	_WashHandle,_LedSetSt
	FNCALL	_WashHandle,_SetStandbyState
	FNCALL	_GetMode_Handle,_ShiftMode_Handle
	FNCALL	_GetMode_Handle,_WrterEEP
	FNCALL	_FactoryMode_Handle,_AllLedFlash
	FNCALL	_FactoryMode_Handle,_BuzzerSet
	FNCALL	_FactoryMode_Handle,_LedSetSt
	FNCALL	_FactoryMode_Handle,_Time_Count_Func
	FNCALL	_Time_Count_Func,_AD_Testing
	FNCALL	_Time_Count_Func,_BuzzerSet
	FNCALL	_Time_Count_Func,_CheckKey
	FNCALL	_Time_Count_Func,_ErrorHandle
	FNCALL	_Time_Count_Func,_FilterKeyInputRest
	FNCALL	_Time_Count_Func,_FilterLifeFunc
	FNCALL	_Time_Count_Func,_GetDelayFilterFlag
	FNCALL	_Time_Count_Func,_Led_Handle
	FNCALL	_Time_Count_Func,_Page_ProgramData
	FNCALL	_Time_Count_Func,_SetStandbyState
	FNCALL	_Time_Count_Func,_TDS_Handle
	FNCALL	_Time_Count_Func,_TaskAlarmHandle
	FNCALL	_Time_Count_Func,_Tx_Display
	FNCALL	_Time_Count_Func,___CMS_CheckTouchKey
	FNCALL	___CMS_CheckTouchKey,___CMS_CheckKeyOldValue
	FNCALL	___CMS_CheckTouchKey,___CMS_CheckOnceResult
	FNCALL	___CMS_CheckTouchKey,___CMS_CheckValidTime
	FNCALL	___CMS_CheckTouchKey,___CMS_CurAdjust
	FNCALL	___CMS_CheckTouchKey,___CMS_KeyDatIIR
	FNCALL	___CMS_CheckTouchKey,___CMS_KeyModeSet
	FNCALL	___CMS_CheckTouchKey,___CMS_KeyStart
	FNCALL	___CMS_CheckTouchKey,___CMS_KeyStopClear
	FNCALL	___CMS_CheckTouchKey,___CMS_Key_UNNOL_Check
	FNCALL	___CMS_CheckTouchKey,___CMS_NewRAMClr
	FNCALL	___CMS_CheckTouchKey,___CMS_Noise_check
	FNCALL	___CMS_CheckTouchKey,___GET_32M_FREDAT
	FNCALL	___CMS_KeyStopClear,___CMS_KeyClearOne
	FNCALL	___CMS_CurAdjust,___CMS_CurAdjMode
	FNCALL	___CMS_CurAdjust,___CMS_CurJudge
	FNCALL	___CMS_CurAdjust,___CMS_KeyModeSet
	FNCALL	___CMS_CurAdjust,___CMS_KeyStart
	FNCALL	___CMS_CheckOnceResult,___CMS_KeyHaveDown
	FNCALL	___CMS_CheckOnceResult,___CMS_KeyIsIn
	FNCALL	___CMS_CheckOnceResult,___CMS_KeyOpen
	FNCALL	___CMS_CheckKeyOldValue,___CMS_KeyIsIn
	FNCALL	___CMS_CheckKeyOldValue,_abs
	FNCALL	_TDS_Handle,_GetCurTdsHz
	FNCALL	_TDS_Handle,___lldiv
	FNCALL	_TDS_Handle,___lmul
	FNCALL	_TDS_Handle,___lwdiv
	FNCALL	_Page_ProgramData,_Memory_Write
	FNCALL	_Led_Handle,_LedControlSt
	FNCALL	_Led_Handle,___bmul
	FNCALL	_GetDelayFilterFlag,_Dec
	FNCALL	_GetDelayFilterFlag,_DecF
	FNCALL	_FilterLifeFunc,_BuzzerSet
	FNCALL	_FilterLifeFunc,_FilterTimeHandle
	FNCALL	_FilterTimeHandle,_LedSetSt
	FNCALL	_FilterKeyInputRest,_BuzzerSet
	FNCALL	_FilterKeyInputRest,_LedSetSt
	FNCALL	_FilterKeyInputRest,_SetFilterDelayReset
	FNCALL	_FilterKeyInputRest,_ShiftMode_Handle
	FNCALL	_FilterKeyInputRest,_WrterEEP
	FNCALL	_ErrorHandle,_AllLedFlash
	FNCALL	_ErrorHandle,_BuzzerSet
	FNCALL	_ErrorHandle,_GetStop
	FNCALL	_ErrorHandle,_LedSetSt
	FNCALL	_ErrorHandle,_ShiftMode_Handle
	FNCALL	_ShiftMode_Handle,_BuzzerSet
	FNCALL	_ShiftMode_Handle,_LedSetSt
	FNCALL	_ShiftMode_Handle,_SetStandbyState
	FNCALL	_AllLedFlash,_LedSetSt
	FNCALL	_LedSetSt,___bmul
	FNCALL	_CheckKey,_KeyScan
	FNCALL	_KeyScan,_BuzzerSet
	FNCALL	_Initialize,_Init_ram
	FNCALL	_EEPROM_Page,_ReadDataArry
	FNCALL	_EEPROM_Page,_SetFilterDelayReset
	FNCALL	_EEPROM_Page,_WrterEEP
	FNCALL	_ReadDataArry,_Memory_Read
	FNROOT	_main
	FNCALL	_Timer1_Isr,___CMS_TouchKeyValue
	FNCALL	intlevel1,_Timer1_Isr
	global	intlevel1
	FNROOT	intlevel1
	global	_NTC_Tab
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	136
_NTC_Tab:
	retlw	0BCh
	retlw	0Bh

	retlw	098h
	retlw	0Bh

	retlw	075h
	retlw	0Bh

	retlw	051h
	retlw	0Bh

	retlw	02Ch
	retlw	0Bh

	retlw	07h
	retlw	0Bh

	retlw	0E2h
	retlw	0Ah

	retlw	0BCh
	retlw	0Ah

	retlw	097h
	retlw	0Ah

	retlw	070h
	retlw	0Ah

	retlw	04Ah
	retlw	0Ah

	retlw	023h
	retlw	0Ah

	retlw	0FCh
	retlw	09h

	retlw	0D5h
	retlw	09h

	retlw	0AEh
	retlw	09h

	retlw	087h
	retlw	09h

	retlw	060h
	retlw	09h

	retlw	038h
	retlw	09h

	retlw	011h
	retlw	09h

	retlw	0EAh
	retlw	08h

	retlw	0C3h
	retlw	08h

	retlw	09Bh
	retlw	08h

	retlw	074h
	retlw	08h

	retlw	04Dh
	retlw	08h

	retlw	027h
	retlw	08h

	retlw	0
	retlw	08h

	retlw	0DAh
	retlw	07h

	retlw	0B4h
	retlw	07h

	retlw	08Eh
	retlw	07h

	retlw	068h
	retlw	07h

	retlw	043h
	retlw	07h

	retlw	01Eh
	retlw	07h

	retlw	0F9h
	retlw	06h

	retlw	0D5h
	retlw	06h

	retlw	0B1h
	retlw	06h

	retlw	08Eh
	retlw	06h

	retlw	06Bh
	retlw	06h

	retlw	049h
	retlw	06h

	retlw	026h
	retlw	06h

	retlw	05h
	retlw	06h

	retlw	0E4h
	retlw	05h

	retlw	0C3h
	retlw	05h

	retlw	0A3h
	retlw	05h

	retlw	083h
	retlw	05h

	retlw	064h
	retlw	05h

	retlw	045h
	retlw	05h

	retlw	027h
	retlw	05h

	retlw	09h
	retlw	05h

	retlw	0ECh
	retlw	04h

	retlw	low(0)
	retlw	high(0)

	global __end_of_NTC_Tab
__end_of_NTC_Tab:
	global	_sc_FreScanTable1
psect	stringtext
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
_sc_FreScanTable1:
	retlw	low(0)
	retlw	01h
	retlw	low(0)
	retlw	01h
	retlw	low(0)
	retlw	01h
	retlw	low(0)
	retlw	01h
	global __end_of_sc_FreScanTable1
__end_of_sc_FreScanTable1:
	global	_sc_FreScanTable
psect	stringtext
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
_sc_FreScanTable:
	retlw	low(0)
	retlw	01h
	retlw	01h
	retlw	01h
	retlw	01h
	retlw	01h
	retlw	01h
	retlw	01h
	global __end_of_sc_FreScanTable
__end_of_sc_FreScanTable:
	global	_sc_Table_KeyFalg
psect	stringtext
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
_sc_Table_KeyFalg:
	retlw	01h
	retlw	02h
	retlw	04h
	retlw	08h
	retlw	010h
	retlw	020h
	retlw	040h
	retlw	080h
	global __end_of_sc_Table_KeyFalg
__end_of_sc_Table_KeyFalg:
	global	_sc_CurStep_Table
psect	stringtext
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
_sc_CurStep_Table:
	retlw	low(0)
	retlw	02h
	retlw	04h
	retlw	06h
	retlw	08h
	retlw	0Ah
	global __end_of_sc_CurStep_Table
__end_of_sc_CurStep_Table:
	global	_gc_Table_KeyDown
psect	stringtext
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	36
_gc_Table_KeyDown:
	retlw	03Ch
	retlw	0

	retlw	03Ch
	retlw	0

	global __end_of_gc_Table_KeyDown
__end_of_gc_Table_KeyDown:
	global	_gc_Table_KeyChannel
psect	stringtext
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	28
_gc_Table_KeyChannel:
	retlw	04h
	retlw	05h
	global __end_of_gc_Table_KeyChannel
__end_of_gc_Table_KeyChannel:
	global	_PureHz_Tab
psect	stringtext
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	60
_PureHz_Tab:
	retlw	01Ch
	retlw	0

	retlw	026h
	retlw	0

	retlw	030h
	retlw	0

	retlw	03Ah
	retlw	0

	retlw	044h
	retlw	0

	retlw	04Eh
	retlw	0

	retlw	058h
	retlw	0

	retlw	062h
	retlw	0

	retlw	06Ch
	retlw	0

	retlw	076h
	retlw	0

	retlw	083h
	retlw	0

	retlw	090h
	retlw	0

	retlw	09Ch
	retlw	0

	retlw	0A9h
	retlw	0

	retlw	0B6h
	retlw	0

	retlw	0C3h
	retlw	0

	retlw	0D0h
	retlw	0

	retlw	0DDh
	retlw	0

	retlw	0EAh
	retlw	0

	retlw	0F7h
	retlw	0

	retlw	0FFh
	retlw	0

	retlw	07h
	retlw	01h

	retlw	0Fh
	retlw	01h

	retlw	019h
	retlw	01h

	retlw	023h
	retlw	01h

	retlw	02Dh
	retlw	01h

	retlw	037h
	retlw	01h

	retlw	041h
	retlw	01h

	retlw	04Bh
	retlw	01h

	retlw	055h
	retlw	01h

	retlw	05Eh
	retlw	01h

	retlw	06Bh
	retlw	01h

	retlw	077h
	retlw	01h

	retlw	081h
	retlw	01h

	retlw	08Bh
	retlw	01h

	retlw	095h
	retlw	01h

	retlw	09Fh
	retlw	01h

	retlw	0A9h
	retlw	01h

	retlw	0B3h
	retlw	01h

	retlw	0BDh
	retlw	01h

	retlw	0C9h
	retlw	01h

	retlw	0D6h
	retlw	01h

	retlw	0E2h
	retlw	01h

	retlw	0EDh
	retlw	01h

	retlw	0F7h
	retlw	01h

	retlw	01h
	retlw	02h

	retlw	0Bh
	retlw	02h

	retlw	015h
	retlw	02h

	retlw	01Fh
	retlw	02h

	retlw	029h
	retlw	02h

	retlw	033h
	retlw	02h

	retlw	03Ah
	retlw	02h

	retlw	044h
	retlw	02h

	retlw	04Eh
	retlw	02h

	retlw	058h
	retlw	02h

	retlw	062h
	retlw	02h

	retlw	06Ch
	retlw	02h

	retlw	077h
	retlw	02h

	retlw	082h
	retlw	02h

	retlw	08Dh
	retlw	02h

	retlw	09Bh
	retlw	02h

	retlw	0A9h
	retlw	02h

	retlw	0B7h
	retlw	02h

	retlw	0C6h
	retlw	02h

	retlw	0D3h
	retlw	02h

	retlw	0E1h
	retlw	02h

	retlw	0EBh
	retlw	02h

	retlw	0F5h
	retlw	02h

	retlw	0FFh
	retlw	02h

	retlw	09h
	retlw	03h

	retlw	013h
	retlw	03h

	retlw	01Dh
	retlw	03h

	retlw	027h
	retlw	03h

	retlw	031h
	retlw	03h

	retlw	03Bh
	retlw	03h

	retlw	043h
	retlw	03h

	retlw	04Bh
	retlw	03h

	retlw	053h
	retlw	03h

	retlw	057h
	retlw	03h

	retlw	05Ch
	retlw	03h

	retlw	05Fh
	retlw	03h

	retlw	064h
	retlw	03h

	retlw	06Ch
	retlw	03h

	retlw	074h
	retlw	03h

	retlw	07Ch
	retlw	03h

	retlw	084h
	retlw	03h

	retlw	08Ch
	retlw	03h

	retlw	094h
	retlw	03h

	retlw	09Ch
	retlw	03h

	retlw	0A4h
	retlw	03h

	retlw	0ACh
	retlw	03h

	retlw	0B4h
	retlw	03h

	retlw	0BCh
	retlw	03h

	retlw	0C4h
	retlw	03h

	retlw	0CCh
	retlw	03h

	retlw	0D4h
	retlw	03h

	retlw	0DCh
	retlw	03h

	retlw	0E4h
	retlw	03h

	retlw	0ECh
	retlw	03h

	retlw	0F4h
	retlw	03h

	retlw	0FCh
	retlw	03h

	retlw	0Bh
	retlw	04h

	retlw	01Ah
	retlw	04h

	retlw	022h
	retlw	04h

	retlw	029h
	retlw	04h

	retlw	031h
	retlw	04h

	retlw	038h
	retlw	04h

	retlw	040h
	retlw	04h

	retlw	048h
	retlw	04h

	retlw	04Fh
	retlw	04h

	retlw	057h
	retlw	04h

	retlw	05Eh
	retlw	04h

	retlw	066h
	retlw	04h

	retlw	06Eh
	retlw	04h

	retlw	075h
	retlw	04h

	retlw	07Dh
	retlw	04h

	retlw	084h
	retlw	04h

	retlw	08Ch
	retlw	04h

	retlw	094h
	retlw	04h

	retlw	09Bh
	retlw	04h

	retlw	0A3h
	retlw	04h

	retlw	0AAh
	retlw	04h

	retlw	0B2h
	retlw	04h

	retlw	0BAh
	retlw	04h

	retlw	0C1h
	retlw	04h

	retlw	0C9h
	retlw	04h

	retlw	0D0h
	retlw	04h

	retlw	0D8h
	retlw	04h

	retlw	0E0h
	retlw	04h

	retlw	0E7h
	retlw	04h

	retlw	0EFh
	retlw	04h

	retlw	0F6h
	retlw	04h

	retlw	0FEh
	retlw	04h

	retlw	06h
	retlw	05h

	retlw	0Dh
	retlw	05h

	retlw	015h
	retlw	05h

	retlw	01Ch
	retlw	05h

	retlw	024h
	retlw	05h

	retlw	02Ch
	retlw	05h

	retlw	033h
	retlw	05h

	retlw	03Bh
	retlw	05h

	retlw	042h
	retlw	05h

	retlw	04Ah
	retlw	05h

	retlw	052h
	retlw	05h

	retlw	059h
	retlw	05h

	retlw	061h
	retlw	05h

	retlw	068h
	retlw	05h

	retlw	06Ch
	retlw	05h

	retlw	070h
	retlw	05h

	retlw	074h
	retlw	05h

	retlw	078h
	retlw	05h

	retlw	07Ch
	retlw	05h

	retlw	080h
	retlw	05h

	retlw	084h
	retlw	05h

	retlw	088h
	retlw	05h

	retlw	08Ch
	retlw	05h

	retlw	090h
	retlw	05h

	retlw	094h
	retlw	05h

	retlw	098h
	retlw	05h

	retlw	09Ch
	retlw	05h

	retlw	0A0h
	retlw	05h

	retlw	0A4h
	retlw	05h

	retlw	0A8h
	retlw	05h

	retlw	0ACh
	retlw	05h

	retlw	0B0h
	retlw	05h

	retlw	0B4h
	retlw	05h

	retlw	0B8h
	retlw	05h

	retlw	0BCh
	retlw	05h

	retlw	0C0h
	retlw	05h

	retlw	0C4h
	retlw	05h

	retlw	0C8h
	retlw	05h

	retlw	0CCh
	retlw	05h

	retlw	0D0h
	retlw	05h

	retlw	0D4h
	retlw	05h

	retlw	0D8h
	retlw	05h

	retlw	0DCh
	retlw	05h

	retlw	0E0h
	retlw	05h

	retlw	0E4h
	retlw	05h

	retlw	0E8h
	retlw	05h

	retlw	0ECh
	retlw	05h

	retlw	0F0h
	retlw	05h

	retlw	0F4h
	retlw	05h

	retlw	0F8h
	retlw	05h

	retlw	0FCh
	retlw	05h

	retlw	0
	retlw	06h

	retlw	04h
	retlw	06h

	retlw	08h
	retlw	06h

	retlw	0Ch
	retlw	06h

	retlw	010h
	retlw	06h

	retlw	014h
	retlw	06h

	global __end_of_PureHz_Tab
__end_of_PureHz_Tab:
psect	stringtext
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	124
_gc_KeyLDOSel:
	retlw	03h
	global __end_of_gc_KeyLDOSel
__end_of_gc_KeyLDOSel:
psect	stringtext
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	122
_gc_LMDValue:
	retlw	01h
	global __end_of_gc_LMDValue
__end_of_gc_LMDValue:
psect	stringtext
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	116
_gc_CmBase:
	retlw	06h
	global __end_of_gc_CmBase
__end_of_gc_CmBase:
psect	stringtext
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
_gc_VolValue:
	retlw	032h
	global __end_of_gc_VolValue
__end_of_gc_VolValue:
	global	_NTC_Tab
	global	_sc_FreScanTable1
	global	_sc_FreScanTable
	global	_sc_Table_KeyFalg
	global	_sc_CurStep_Table
	global	_gc_Table_KeyDown
	global	_gc_Table_KeyChannel
	global	_PureHz_Tab
	global	_919
	global	_Mode
	global	__BITS
	global	_927
	global	_926
	global	_925
	global	_924
	global	_gf_kerr
	global	_KeyPacket_y
	global	AD_Testing@admax
	global	AD_Testing@admin
	global	_PreTdsData
	global	_g_KeyFlag
	global	___CMS_Noise_check@F966
	global	___CMS_Noise_check@F965
	global	___CMS_Noise_check@F964
	global	_923
	global	_922
	global	_921
	global	_920
	global	_918
	global	_917
	global	_916
	global	Timer1_Isr@T1_1ms
	global	AD_Testing@adtimes
	global	CheckKey@temp
	global	StandbyMode_Handle@Ti_1h
	global	_BeepAlmCnt
	global	_ErrorVar
	global	_Time_Power_1s
	global	_Temp_Ntc
	global	_FilterBuzzer_1s
	global	_TdsCk60sFlag
	global	_PowerStep
	global	_Time_100ms
	global	_Time_GetWater_1s
	global	_Time_1s
	global	_Timer_Power_100ms
	global	_StandByStatus
	global	_Timer_TdsMake_1s
	global	_FilterFastCheck
	global	_Timer_ErrorLong_1s
	global	__BITS2
	global	__BITS1
	global	_FilterROGetWater
	global	_FilterPCFGetWater
	global	_FilterROState
	global	_FilterPCFState
	global	_WashRunTime
	global	_Read_Word_Buff
	global	TDS_Handle@Muni_c
	global	TDS_Handle@NTC_
	global	___CMS_CheckValidTime@F1029
	global	___CMS_Noise_check@F969
	global	___CMS_Noise_check@F968
	global	AD_Testing@adsum
	global	CheckKey@KeyOldFlag
	global	FilterKeyInputRest@PreFilterROGetWater
	global	FilterKeyInputRest@PreFilterPCFGetWater
	global	FilterKeyInputRest@FilterSelect_10ms
	global	_BeepOnTimeCnt
	global	_BuzzerFilter
	global	_ML_Temp
	global	_Date_Temp
	global	_Timer_Standby_1H
	global	_Timer_BackT_1H
	global	_Timer_Standby_1s
	global	_Timer_WashRun_1s
	global	_FilterRst_1s
	global	_PreROu16Day
	global	_PrePCFu16Day
	global	_Timer_LongGetWater_1s
	global	_GetWater_ML
	global	_Time_made_1s
	global	___CMS_CheckTouchKey@F1073
	global	___CMS_CurAdjust@F1044
	global	___CMS_Key_UNNOL_Check@F1016
	global	___CMS_Noise_check@F967
	global	_FilterRO_time
	global	_FilterPCF_time
	global	_LedMod
	global	_Tx_Type
	global	_PureTDSTyp
	global	_887
_887	set	13
	global	_T2CON
_T2CON	set	18
	global	_T1CON
_T1CON	set	16
	global	_TMR1H
_TMR1H	set	15
	global	_TMR1L
_TMR1L	set	14
	global	_INTCON
_INTCON	set	11
	global	_PORTC
_PORTC	set	7
	global	_PORTB
_PORTB	set	6
	global	_PORTA
_PORTA	set	5
	global	_TMR0
_TMR0	set	1
	global	_TMR1IF
_TMR1IF	set	96
	global	_TMR2IF
_TMR2IF	set	97
	global	_INTF
_INTF	set	89
	global	_T0IF
_T0IF	set	90
	global	_GIE
_GIE	set	95
	global	_RC1
_RC1	set	57
	global	_RC2
_RC2	set	58
	global	_RC3
_RC3	set	59
	global	_RB0
_RB0	set	48
	global	_RB2
_RB2	set	50
	global	_RB3
_RB3	set	51
	global	_RB4
_RB4	set	52
	global	_RB5
_RB5	set	53
	global	_RB6
_RB6	set	54
	global	_RA0
_RA0	set	40
	global	_RA1
_RA1	set	41
	global	_RA2
_RA2	set	42
	global	_RA6
_RA6	set	46
	global	_RA7
_RA7	set	47
	global	_ADCON1
_ADCON1	set	159
	global	_ADCON0
_ADCON0	set	158
	global	_ADRESH
_ADRESH	set	157
	global	_ADRESL
_ADRESL	set	156
	global	_WPUC
_WPUC	set	154
	global	_WPUA
_WPUA	set	153
	global	_SPBRG1
_SPBRG1	set	152
	global	_WPUB
_WPUB	set	149
	global	_PR2
_PR2	set	146
	global	_OSCCON
_OSCCON	set	143
	global	_PIE2
_PIE2	set	141
	global	_PIE1
_PIE1	set	140
	global	_ANSEL1
_ANSEL1	set	137
	global	_TRISD
_TRISD	set	136
	global	_TRISC
_TRISC	set	135
	global	_TRISB
_TRISB	set	134
	global	_TRISA
_TRISA	set	133
	global	_OPTION_REG
_OPTION_REG	set	129
	global	_GODONE
_GODONE	set	1265
	global	_RC1IE
_RC1IE	set	1129
	global	_TX1IE
_TX1IE	set	1130
	global	_TMR1IE
_TMR1IE	set	1120
	global	_INTEDG
_INTEDG	set	1038
	global	_TXREG1
_TXREG1	set	285
	global	_PWMTH
_PWMTH	set	284
	global	_PWMTL
_PWMTL	set	283
	global	_PWMD01H
_PWMD01H	set	273
	global	_PWMD1L
_PWMD1L	set	269
	global	_PWMCON1
_PWMCON1	set	263
	global	_PWMCON0
_PWMCON0	set	262
	global	_TRMT1
_TRMT1	set	2297
	global	_SCKP1
_SCKP1	set	2299
	global	_SYNC1
_SYNC1	set	2300
	global	_TXEN1
_TXEN1	set	2301
	global	_TX9EN1
_TX9EN1	set	2302
	global	_PWM1EN
_PWM1EN	set	2097
	global	_CREN1
_CREN1	set	2092
	global	_RX9EN1
_RX9EN1	set	2094
	global	_SPEN1
_SPEN1	set	2095
	global	_914
_914	set	416
	global	_905
_905	set	416
	global	_903
_903	set	448
	global	_902
_902	set	416
	global	_900
_900	set	448
	global	_899
_899	set	416
	global	_897
_897	set	448
	global	_896
_896	set	416
	global	_913
_913	set	480
	global	_912
_912	set	464
	global	_911
_911	set	448
	global	_910
_910	set	432
	global	_909
_909	set	416
	global	_904
_904	set	480
	global	_901
_901	set	480
	global	_898
_898	set	480
	global	_886
_886	set	415
	global	_885
_885	set	412
	global	_884
_884	set	411
	global	_883
_883	set	414
	global	_882
_882	set	413
	global	_881
_881	set	410
	global	_880
_880	set	409
	global	_879
_879	set	408
	global	_878
_878	set	407
	global	_877
_877	set	406
	global	_876
_876	set	405
	global	_875
_875	set	404
	global	_874
_874	set	403
	global	_873
_873	set	402
	global	_872
_872	set	401
	global	_871
_871	set	400
	global	_EECON2
_EECON2	set	397
	global	_EECON1
_EECON1	set	396
	global	_EEADR
_EEADR	set	391
	global	_EEDAT
_EEDAT	set	390
	global	_RD
_RD	set	3168
	global	_WR
_WR	set	3169
	global	_WREN
_WREN	set	3170
	global	_WRERR
_WRERR	set	3171
	global	_EEPGD
_EEPGD	set	3175
; #config settings
	file	"Sbaake.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_927:
       ds      1

_926:
       ds      1

_925:
       ds      1

_924:
       ds      1

_gf_kerr:
       ds      1

psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_919:
       ds      1

_Mode:
       ds      1

__BITS:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_KeyPacket_y:
       ds      9

AD_Testing@admax:
       ds      2

AD_Testing@admin:
       ds      2

_PreTdsData:
       ds      2

_g_KeyFlag:
       ds      2

___CMS_Noise_check@F966:
       ds      1

___CMS_Noise_check@F965:
       ds      1

___CMS_Noise_check@F964:
       ds      1

_923:
       ds      1

_922:
       ds      1

_921:
       ds      1

_920:
       ds      1

_918:
       ds      1

_917:
       ds      1

_916:
       ds      1

Timer1_Isr@T1_1ms:
       ds      1

AD_Testing@adtimes:
       ds      1

CheckKey@temp:
       ds      1

StandbyMode_Handle@Ti_1h:
       ds      1

_BeepAlmCnt:
       ds      1

_ErrorVar:
       ds      1

_Time_Power_1s:
       ds      1

_Temp_Ntc:
       ds      1

_FilterBuzzer_1s:
       ds      1

_TdsCk60sFlag:
       ds      1

_PowerStep:
       ds      1

_Time_100ms:
       ds      1

_Time_GetWater_1s:
       ds      1

_Time_1s:
       ds      1

_Timer_Power_100ms:
       ds      1

_StandByStatus:
       ds      1

_Timer_TdsMake_1s:
       ds      1

_FilterFastCheck:
       ds      1

_Timer_ErrorLong_1s:
       ds      1

__BITS2:
       ds      1

__BITS1:
       ds      1

_FilterROGetWater:
       ds      2

_FilterPCFGetWater:
       ds      2

_FilterROState:
       ds      1

_FilterPCFState:
       ds      1

_WashRunTime:
       ds      1

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_Read_Word_Buff:
       ds      12

TDS_Handle@Muni_c:
       ds      4

TDS_Handle@NTC_:
       ds      4

___CMS_CheckValidTime@F1029:
       ds      2

___CMS_Noise_check@F969:
       ds      2

___CMS_Noise_check@F968:
       ds      2

AD_Testing@adsum:
       ds      2

CheckKey@KeyOldFlag:
       ds      2

FilterKeyInputRest@PreFilterROGetWater:
       ds      2

FilterKeyInputRest@PreFilterPCFGetWater:
       ds      2

FilterKeyInputRest@FilterSelect_10ms:
       ds      2

_BeepOnTimeCnt:
       ds      2

_BuzzerFilter:
       ds      2

_ML_Temp:
       ds      2

_Date_Temp:
       ds      2

_Timer_Standby_1H:
       ds      2

_Timer_BackT_1H:
       ds      2

_Timer_Standby_1s:
       ds      2

_Timer_WashRun_1s:
       ds      2

_FilterRst_1s:
       ds      2

_PreROu16Day:
       ds      2

_PrePCFu16Day:
       ds      2

_Timer_LongGetWater_1s:
       ds      2

_GetWater_ML:
       ds      2

_Time_made_1s:
       ds      2

___CMS_CheckTouchKey@F1073:
       ds      1

___CMS_CurAdjust@F1044:
       ds      1

___CMS_Key_UNNOL_Check@F1016:
       ds      1

___CMS_Noise_check@F967:
       ds      1

_FilterRO_time:
       ds      5

_FilterPCF_time:
       ds      5

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_LedMod:
       ds      30

_Tx_Type:
       ds      17

_PureTDSTyp:
       ds      17

	file	"Sbaake.as"
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
	clrf	((__pbssCOMMON)+1)&07Fh
	clrf	((__pbssCOMMON)+2)&07Fh
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+037h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+04Eh)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+040h)
	fcall	clear_ram0
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
	global	FactoryMode_Handle@Step
FactoryMode_Handle@Step:	; 1 bytes @ 0x0
	ds	1
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?___CMS_CheckTouchKey:	; 1 bytes @ 0x0
?_CheckKey:	; 1 bytes @ 0x0
?_FilterLifeFunc:	; 1 bytes @ 0x0
?_TaskAlarmHandle:	; 1 bytes @ 0x0
?_Led_Handle:	; 1 bytes @ 0x0
?_FilterKeyInputRest:	; 1 bytes @ 0x0
?_Tx_Display:	; 1 bytes @ 0x0
?_ErrorHandle:	; 1 bytes @ 0x0
?_Page_ProgramData:	; 1 bytes @ 0x0
?_WrterEEP:	; 1 bytes @ 0x0
?___CMS_TouchKeyValue:	; 1 bytes @ 0x0
??___CMS_TouchKeyValue:	; 1 bytes @ 0x0
?_GetDelayFilterFlag:	; 1 bytes @ 0x0
?_Time_Count_Func:	; 1 bytes @ 0x0
?_AllLedFlash:	; 1 bytes @ 0x0
?_GetStop:	; 1 bytes @ 0x0
?_ShiftMode_Handle:	; 1 bytes @ 0x0
?_GetMode_Handle:	; 1 bytes @ 0x0
?_WashHandle:	; 1 bytes @ 0x0
?_StatusFun_Handle:	; 1 bytes @ 0x0
?_FactoryMode_Handle:	; 1 bytes @ 0x0
?_StandbyMode_Handle:	; 1 bytes @ 0x0
?_Run_Mode:	; 1 bytes @ 0x0
?_ReadDataArry:	; 1 bytes @ 0x0
?_EEPROM_Page:	; 1 bytes @ 0x0
?_Init_ram:	; 1 bytes @ 0x0
?_Initialize:	; 1 bytes @ 0x0
?_Timer1_Isr:	; 1 bytes @ 0x0
??_Timer1_Isr:	; 1 bytes @ 0x0
?_Set_Usart_Async:	; 1 bytes @ 0x0
?_Set_PWM:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?___CMS_KeyIsIn:	; 1 bytes @ 0x0
?___CMS_KeyClearOne:	; 1 bytes @ 0x0
?___CMS_KeyStopClear:	; 1 bytes @ 0x0
?___CMS_Noise_check:	; 1 bytes @ 0x0
?___CMS_CheckOnceResult:	; 1 bytes @ 0x0
?___CMS_CheckKeyOldValue:	; 1 bytes @ 0x0
?___CMS_Key_UNNOL_Check:	; 1 bytes @ 0x0
?___CMS_KeyDatIIR:	; 1 bytes @ 0x0
?___CMS_CheckValidTime:	; 1 bytes @ 0x0
?___CMS_CurAdjMode:	; 1 bytes @ 0x0
?___CMS_KeyModeSet:	; 1 bytes @ 0x0
?___CMS_KeyStart:	; 1 bytes @ 0x0
?___CMS_CurJudge:	; 1 bytes @ 0x0
?___CMS_CurAdjust:	; 1 bytes @ 0x0
?___CMS_NewRAMClr:	; 1 bytes @ 0x0
?___GET_32M_FREDAT:	; 1 bytes @ 0x0
	ds	4
??_TaskAlarmHandle:	; 1 bytes @ 0x4
??_Tx_Display:	; 1 bytes @ 0x4
?_BuzzerSet:	; 1 bytes @ 0x4
?_SetStandbyState:	; 1 bytes @ 0x4
??_WrterEEP:	; 1 bytes @ 0x4
?_Dec:	; 1 bytes @ 0x4
?_DecF:	; 1 bytes @ 0x4
??_SetFilterDelayReset:	; 1 bytes @ 0x4
?_TDS_Handle:	; 1 bytes @ 0x4
?_LedControlSt:	; 1 bytes @ 0x4
??_GetStop:	; 1 bytes @ 0x4
??_Memory_Write:	; 1 bytes @ 0x4
??_Init_ram:	; 1 bytes @ 0x4
??_Initialize:	; 1 bytes @ 0x4
??_Set_Usart_Async:	; 1 bytes @ 0x4
??_Set_PWM:	; 1 bytes @ 0x4
??___CMS_KeyIsIn:	; 1 bytes @ 0x4
?___CMS_KeyOpen:	; 1 bytes @ 0x4
?___CMS_KeyHaveDown:	; 1 bytes @ 0x4
??___CMS_KeyClearOne:	; 1 bytes @ 0x4
??___CMS_Key_UNNOL_Check:	; 1 bytes @ 0x4
??___CMS_KeyDatIIR:	; 1 bytes @ 0x4
??___CMS_CheckValidTime:	; 1 bytes @ 0x4
??___CMS_CurAdjMode:	; 1 bytes @ 0x4
??___CMS_KeyModeSet:	; 1 bytes @ 0x4
??___CMS_KeyStart:	; 1 bytes @ 0x4
??___CMS_CurJudge:	; 1 bytes @ 0x4
??___CMS_NewRAMClr:	; 1 bytes @ 0x4
??___GET_32M_FREDAT:	; 1 bytes @ 0x4
??___lmul:	; 1 bytes @ 0x4
?___bmul:	; 1 bytes @ 0x4
??___lldiv:	; 1 bytes @ 0x4
??___lwdiv:	; 1 bytes @ 0x4
?_AD_Testing:	; 2 bytes @ 0x4
	global	?_abs
?_abs:	; 2 bytes @ 0x4
	global	?_Memory_Read
?_Memory_Read:	; 2 bytes @ 0x4
	global	Dec@max
Dec@max:	; 1 bytes @ 0x4
	global	SetFilterDelayReset@TimPtr
SetFilterDelayReset@TimPtr:	; 1 bytes @ 0x4
	global	TDS_Handle@Type
TDS_Handle@Type:	; 1 bytes @ 0x4
	global	LedControlSt@Sta
LedControlSt@Sta:	; 1 bytes @ 0x4
	global	SetStandbyState@Time
SetStandbyState@Time:	; 1 bytes @ 0x4
	global	Memory_Write@i
Memory_Write@i:	; 1 bytes @ 0x4
	global	AD_Testing@ad_ch
AD_Testing@ad_ch:	; 1 bytes @ 0x4
	global	___CMS_KeyIsIn@947
___CMS_KeyIsIn@947:	; 1 bytes @ 0x4
	global	___CMS_KeyOpen@952
___CMS_KeyOpen@952:	; 1 bytes @ 0x4
	global	___CMS_KeyHaveDown@956
___CMS_KeyHaveDown@956:	; 1 bytes @ 0x4
	global	___CMS_CurAdjMode@1032
___CMS_CurAdjMode@1032:	; 1 bytes @ 0x4
	global	___CMS_KeyModeSet@1035
___CMS_KeyModeSet@1035:	; 1 bytes @ 0x4
	global	___CMS_KeyStart@1038
___CMS_KeyStart@1038:	; 1 bytes @ 0x4
	global	___CMS_NewRAMClr@1051
___CMS_NewRAMClr@1051:	; 1 bytes @ 0x4
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x4
	global	DecF@max
DecF@max:	; 2 bytes @ 0x4
	global	BuzzerSet@filter
BuzzerSet@filter:	; 2 bytes @ 0x4
	global	Memory_Read@Addr
Memory_Read@Addr:	; 2 bytes @ 0x4
	global	abs@a
abs@a:	; 2 bytes @ 0x4
	ds	1
??_Page_ProgramData:	; 1 bytes @ 0x5
?_LedSetSt:	; 1 bytes @ 0x5
??_Dec:	; 1 bytes @ 0x5
??_LedControlSt:	; 1 bytes @ 0x5
??___CMS_KeyOpen:	; 1 bytes @ 0x5
??___CMS_KeyHaveDown:	; 1 bytes @ 0x5
??___bmul:	; 1 bytes @ 0x5
	global	Dec@var
Dec@var:	; 1 bytes @ 0x5
	global	LedSetSt@Sta
LedSetSt@Sta:	; 1 bytes @ 0x5
	global	LedControlSt@Num
LedControlSt@Num:	; 1 bytes @ 0x5
	global	SetStandbyState@Da
SetStandbyState@Da:	; 1 bytes @ 0x5
	global	AD_Testing@ad_lr
AD_Testing@ad_lr:	; 1 bytes @ 0x5
	global	___CMS_KeyIsIn@946
___CMS_KeyIsIn@946:	; 1 bytes @ 0x5
	global	___CMS_KeyOpen@951
___CMS_KeyOpen@951:	; 1 bytes @ 0x5
	global	___CMS_KeyHaveDown@955
___CMS_KeyHaveDown@955:	; 1 bytes @ 0x5
	ds	1
??___CMS_CheckTouchKey:	; 1 bytes @ 0x6
??_FilterLifeFunc:	; 1 bytes @ 0x6
??_FilterKeyInputRest:	; 1 bytes @ 0x6
??_ErrorHandle:	; 1 bytes @ 0x6
??_BuzzerSet:	; 1 bytes @ 0x6
??_SetStandbyState:	; 1 bytes @ 0x6
??_LedSetSt:	; 1 bytes @ 0x6
??_AllLedFlash:	; 1 bytes @ 0x6
??_ShiftMode_Handle:	; 1 bytes @ 0x6
??_GetMode_Handle:	; 1 bytes @ 0x6
??_StatusFun_Handle:	; 1 bytes @ 0x6
??_FactoryMode_Handle:	; 1 bytes @ 0x6
??_Memory_Read:	; 1 bytes @ 0x6
??_StandbyMode_Handle:	; 1 bytes @ 0x6
??_Run_Mode:	; 1 bytes @ 0x6
??_ReadDataArry:	; 1 bytes @ 0x6
??_EEPROM_Page:	; 1 bytes @ 0x6
??_main:	; 1 bytes @ 0x6
??___CMS_KeyStopClear:	; 1 bytes @ 0x6
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
??_AD_Testing:	; 1 bytes @ 0x0
??_abs:	; 1 bytes @ 0x0
??_DecF:	; 1 bytes @ 0x0
?_SetFilterDelayReset:	; 1 bytes @ 0x0
?_Memory_Write:	; 1 bytes @ 0x0
??___CMS_Noise_check:	; 1 bytes @ 0x0
??___CMS_CheckOnceResult:	; 1 bytes @ 0x0
??___CMS_CurAdjust:	; 1 bytes @ 0x0
	global	?_GetCurTdsHz
?_GetCurTdsHz:	; 2 bytes @ 0x0
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x0
	global	?___lmul
?___lmul:	; 4 bytes @ 0x0
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x0
	global	SetStandbyState@STY
SetStandbyState@STY:	; 1 bytes @ 0x0
	global	BuzzerSet@cnt
BuzzerSet@cnt:	; 1 bytes @ 0x0
	global	Tx_Display@Sum_Tot
Tx_Display@Sum_Tot:	; 1 bytes @ 0x0
	global	___CMS_KeyClearOne@958
___CMS_KeyClearOne@958:	; 1 bytes @ 0x0
	global	___CMS_Key_UNNOL_Check@1018
___CMS_Key_UNNOL_Check@1018:	; 1 bytes @ 0x0
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x0
	global	GetCurTdsHz@Tab
GetCurTdsHz@Tab:	; 2 bytes @ 0x0
	global	SetFilterDelayReset@Day
SetFilterDelayReset@Day:	; 2 bytes @ 0x0
	global	Memory_Write@Addr
Memory_Write@Addr:	; 2 bytes @ 0x0
	global	ReadDataArry@i
ReadDataArry@i:	; 2 bytes @ 0x0
	global	___CMS_KeyDatIIR@1023
___CMS_KeyDatIIR@1023:	; 2 bytes @ 0x0
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x0
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x0
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x0
	ds	1
?_KeyScan:	; 1 bytes @ 0x1
	global	Tx_Display@Temp1
Tx_Display@Temp1:	; 1 bytes @ 0x1
	global	KeyScan@num
KeyScan@num:	; 1 bytes @ 0x1
	global	___CMS_KeyStopClear@961
___CMS_KeyStopClear@961:	; 1 bytes @ 0x1
	global	___CMS_Key_UNNOL_Check@1017
___CMS_Key_UNNOL_Check@1017:	; 1 bytes @ 0x1
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x1
	ds	1
??_Led_Handle:	; 1 bytes @ 0x2
??_KeyScan:	; 1 bytes @ 0x2
??___CMS_CheckKeyOldValue:	; 1 bytes @ 0x2
	global	DecF@var
DecF@var:	; 1 bytes @ 0x2
	global	SetFilterDelayReset@hour
SetFilterDelayReset@hour:	; 1 bytes @ 0x2
	global	LedSetSt@Num
LedSetSt@Num:	; 1 bytes @ 0x2
	global	Memory_Write@Value
Memory_Write@Value:	; 1 bytes @ 0x2
	global	AD_Testing@ad_fd
AD_Testing@ad_fd:	; 1 bytes @ 0x2
	global	___CMS_CurAdjust@1046
___CMS_CurAdjust@1046:	; 1 bytes @ 0x2
	global	GetCurTdsHz@index
GetCurTdsHz@index:	; 2 bytes @ 0x2
	global	Tx_Display@i
Tx_Display@i:	; 2 bytes @ 0x2
	global	___CMS_KeyDatIIR@1024
___CMS_KeyDatIIR@1024:	; 2 bytes @ 0x2
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x2
	ds	1
??_GetDelayFilterFlag:	; 1 bytes @ 0x3
?_FilterTimeHandle:	; 1 bytes @ 0x3
??_WashHandle:	; 1 bytes @ 0x3
	global	SetFilterDelayReset@min
SetFilterDelayReset@min:	; 1 bytes @ 0x3
	global	AllLedFlash@Type
AllLedFlash@Type:	; 1 bytes @ 0x3
	global	ShiftMode_Handle@Mod
ShiftMode_Handle@Mod:	; 1 bytes @ 0x3
	global	___CMS_CurAdjust@1045
___CMS_CurAdjust@1045:	; 1 bytes @ 0x3
	global	AD_Testing@AD_Result
AD_Testing@AD_Result:	; 2 bytes @ 0x3
	global	Page_ProgramData@i
Page_ProgramData@i:	; 2 bytes @ 0x3
	global	___CMS_Noise_check@974
___CMS_Noise_check@974:	; 2 bytes @ 0x3
	global	FilterTimeHandle@Filter_time
FilterTimeHandle@Filter_time:	; 5 bytes @ 0x3
	ds	1
??_GetCurTdsHz:	; 1 bytes @ 0x4
	global	KeyScan@sw_port
KeyScan@sw_port:	; 1 bytes @ 0x4
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x4
	global	SetFilterDelayReset@sec
SetFilterDelayReset@sec:	; 2 bytes @ 0x4
	global	AllLedFlash@i
AllLedFlash@i:	; 2 bytes @ 0x4
	global	Led_Handle@i
Led_Handle@i:	; 2 bytes @ 0x4
	global	___CMS_CheckKeyOldValue@1006
___CMS_CheckKeyOldValue@1006:	; 2 bytes @ 0x4
	global	___CMS_KeyDatIIR@1022
___CMS_KeyDatIIR@1022:	; 2 bytes @ 0x4
	global	___CMS_CurAdjust@1047
___CMS_CurAdjust@1047:	; 2 bytes @ 0x4
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x4
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x4
	ds	1
??_CheckKey:	; 1 bytes @ 0x5
	global	GetDelayFilterFlag@PtrMin
GetDelayFilterFlag@PtrMin:	; 1 bytes @ 0x5
	global	AD_Testing@i
AD_Testing@i:	; 1 bytes @ 0x5
	global	___CMS_Noise_check@971
___CMS_Noise_check@971:	; 1 bytes @ 0x5
	global	___CMS_CheckOnceResult@989
___CMS_CheckOnceResult@989:	; 2 bytes @ 0x5
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x5
	ds	1
	global	CheckKey@St
CheckKey@St:	; 1 bytes @ 0x6
	global	___CMS_Noise_check@972
___CMS_Noise_check@972:	; 1 bytes @ 0x6
	global	___CMS_CheckKeyOldValue@1004
___CMS_CheckKeyOldValue@1004:	; 1 bytes @ 0x6
	global	AD_Testing@data
AD_Testing@data:	; 2 bytes @ 0x6
	global	___CMS_KeyDatIIR@1025
___CMS_KeyDatIIR@1025:	; 2 bytes @ 0x6
	ds	1
	global	___CMS_CheckOnceResult@980
___CMS_CheckOnceResult@980:	; 1 bytes @ 0x7
	global	CheckKey@i
CheckKey@i:	; 2 bytes @ 0x7
	global	___CMS_Noise_check@975
___CMS_Noise_check@975:	; 2 bytes @ 0x7
	global	___CMS_CheckKeyOldValue@1007
___CMS_CheckKeyOldValue@1007:	; 2 bytes @ 0x7
	ds	1
	global	FilterTimeHandle@FilterState
FilterTimeHandle@FilterState:	; 1 bytes @ 0x8
	global	___CMS_CheckOnceResult@981
___CMS_CheckOnceResult@981:	; 1 bytes @ 0x8
	global	___CMS_KeyDatIIR@1026
___CMS_KeyDatIIR@1026:	; 2 bytes @ 0x8
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x8
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x8
	ds	1
	global	FilterTimeHandle@Type
FilterTimeHandle@Type:	; 1 bytes @ 0x9
	global	___CMS_CheckOnceResult@985
___CMS_CheckOnceResult@985:	; 1 bytes @ 0x9
	global	___CMS_Noise_check@973
___CMS_Noise_check@973:	; 2 bytes @ 0x9
	global	___CMS_CheckKeyOldValue@1008
___CMS_CheckKeyOldValue@1008:	; 2 bytes @ 0x9
	ds	1
	global	FilterTimeHandle@FilterGetWater
FilterTimeHandle@FilterGetWater:	; 1 bytes @ 0xA
	global	___CMS_CheckOnceResult@986
___CMS_CheckOnceResult@986:	; 1 bytes @ 0xA
	global	___CMS_KeyDatIIR@1021
___CMS_KeyDatIIR@1021:	; 1 bytes @ 0xA
	global	GetCurTdsHz@i
GetCurTdsHz@i:	; 2 bytes @ 0xA
	ds	1
??_FilterTimeHandle:	; 1 bytes @ 0xB
	global	___CMS_Noise_check@970
___CMS_Noise_check@970:	; 1 bytes @ 0xB
	global	___CMS_CheckOnceResult@982
___CMS_CheckOnceResult@982:	; 1 bytes @ 0xB
	global	___CMS_CheckKeyOldValue@1009
___CMS_CheckKeyOldValue@1009:	; 2 bytes @ 0xB
	ds	1
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0xC
	global	GetCurTdsHz@tmp
GetCurTdsHz@tmp:	; 2 bytes @ 0xC
	global	___CMS_CheckOnceResult@990
___CMS_CheckOnceResult@990:	; 2 bytes @ 0xC
	ds	1
	global	___CMS_CheckKeyOldValue@1005
___CMS_CheckKeyOldValue@1005:	; 1 bytes @ 0xD
	ds	1
	global	GetCurTdsHz@AdPtr
GetCurTdsHz@AdPtr:	; 1 bytes @ 0xE
	global	___CMS_CheckKeyOldValue@1003
___CMS_CheckKeyOldValue@1003:	; 1 bytes @ 0xE
	global	___CMS_CheckOnceResult@991
___CMS_CheckOnceResult@991:	; 2 bytes @ 0xE
	ds	1
??_TDS_Handle:	; 1 bytes @ 0xF
	ds	1
	global	___CMS_CheckOnceResult@983
___CMS_CheckOnceResult@983:	; 1 bytes @ 0x10
	ds	1
	global	___CMS_CheckOnceResult@984
___CMS_CheckOnceResult@984:	; 1 bytes @ 0x11
	ds	1
	global	___CMS_CheckOnceResult@988
___CMS_CheckOnceResult@988:	; 1 bytes @ 0x12
	ds	1
	global	___CMS_CheckOnceResult@987
___CMS_CheckOnceResult@987:	; 1 bytes @ 0x13
	global	TDS_Handle@i
TDS_Handle@i:	; 2 bytes @ 0x13
	ds	1
	global	___CMS_CheckOnceResult@979
___CMS_CheckOnceResult@979:	; 1 bytes @ 0x14
	ds	1
	global	TDS_Handle@TDSTyp
TDS_Handle@TDSTyp:	; 1 bytes @ 0x15
	ds	1
??_Time_Count_Func:	; 1 bytes @ 0x16
	ds	3
;!
;!Data Sizes:
;!    Strings     0
;!    Constant    520
;!    Data        0
;!    BSS         200
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14      6      10
;!    BANK0            80     25      80
;!    BANK1            80      1      79
;!    BANK2            80      0      64

;!
;!Pointer List with Targets:
;!
;!    SetStandbyState@Time	PTR unsigned char  size(1) Largest target is 1
;!		 -> WashRunTime(BANK0[1]), 
;!
;!    FilterTimeHandle@FilterGetWater	PTR unsigned int  size(1) Largest target is 2
;!		 -> FilterPCFGetWater(BANK0[2]), FilterROGetWater(BANK0[2]), 
;!
;!    FilterTimeHandle@FilterState	PTR unsigned char  size(1) Largest target is 1
;!		 -> FilterPCFState(BANK0[1]), FilterROState(BANK0[1]), 
;!
;!    TDS_Handle@TDSTyp	PTR struct . size(1) Largest target is 17
;!		 -> PureTDSTyp(BANK2[17]), 
;!
;!    GetDelayFilterFlag@PtrMin	PTR struct . size(1) Largest target is 5
;!		 -> FilterRO_time(BANK1[5]), FilterPCF_time(BANK1[5]), 
;!
;!    SetFilterDelayReset@TimPtr	PTR struct . size(1) Largest target is 5
;!		 -> FilterRO_time(BANK1[5]), FilterPCF_time(BANK1[5]), 
;!
;!    DecF@var	PTR unsigned int  size(1) Largest target is 5
;!		 -> FilterRO_time(BANK1[5]), FilterPCF_time(BANK1[5]), 
;!
;!    Dec@var	PTR unsigned char  size(1) Largest target is 5
;!		 -> FilterRO_time(BANK1[5]), FilterPCF_time(BANK1[5]), 
;!
;!    GetCurTdsHz@Tab	PTR unsigned int  size(2) Largest target is 380
;!		 -> PureHz_Tab(CODE[380]), 
;!
;!    GetCurTdsHz@AdPtr	PTR struct . size(1) Largest target is 17
;!		 -> PureTDSTyp(BANK2[17]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    _Run_Mode->_BuzzerSet
;!    _Run_Mode->_LedSetSt
;!    _Run_Mode->_SetStandbyState
;!    _StandbyMode_Handle->_BuzzerSet
;!    _StandbyMode_Handle->_LedSetSt
;!    _StandbyMode_Handle->_SetStandbyState
;!    _StatusFun_Handle->_SetStandbyState
;!    _WashHandle->_LedSetSt
;!    _WashHandle->_SetStandbyState
;!    _FactoryMode_Handle->_BuzzerSet
;!    _FactoryMode_Handle->_LedSetSt
;!    _Time_Count_Func->_AD_Testing
;!    _Time_Count_Func->_BuzzerSet
;!    _Time_Count_Func->_SetStandbyState
;!    _Time_Count_Func->_TaskAlarmHandle
;!    ___CMS_CheckTouchKey->___CMS_Key_UNNOL_Check
;!    ___CMS_KeyStopClear->___CMS_KeyClearOne
;!    ___CMS_CurAdjust->___CMS_CurJudge
;!    ___CMS_CheckOnceResult->___CMS_KeyHaveDown
;!    ___CMS_CheckOnceResult->___CMS_KeyIsIn
;!    ___CMS_CheckOnceResult->___CMS_KeyOpen
;!    ___CMS_CheckKeyOldValue->___CMS_KeyIsIn
;!    ___CMS_CheckKeyOldValue->_abs
;!    _Page_ProgramData->_Memory_Write
;!    _Led_Handle->_LedControlSt
;!    _GetDelayFilterFlag->_Dec
;!    _GetDelayFilterFlag->_DecF
;!    _FilterLifeFunc->_BuzzerSet
;!    _FilterTimeHandle->_LedSetSt
;!    _FilterKeyInputRest->_BuzzerSet
;!    _FilterKeyInputRest->_LedSetSt
;!    _ErrorHandle->_BuzzerSet
;!    _ErrorHandle->_LedSetSt
;!    _ShiftMode_Handle->_BuzzerSet
;!    _ShiftMode_Handle->_LedSetSt
;!    _ShiftMode_Handle->_SetStandbyState
;!    _AllLedFlash->_LedSetSt
;!    _LedSetSt->___bmul
;!    _KeyScan->_BuzzerSet
;!    _ReadDataArry->_Memory_Read
;!
;!Critical Paths under _Timer1_Isr in COMMON
;!
;!    None.
;!
;!Critical Paths under _main in BANK0
;!
;!    _main->_Time_Count_Func
;!    _StatusFun_Handle->_WashHandle
;!    _WashHandle->_LedSetSt
;!    _GetMode_Handle->_ShiftMode_Handle
;!    _FactoryMode_Handle->_Time_Count_Func
;!    _Time_Count_Func->_TDS_Handle
;!    ___CMS_CheckTouchKey->___CMS_CheckOnceResult
;!    ___CMS_KeyStopClear->___CMS_KeyClearOne
;!    ___CMS_CheckKeyOldValue->_abs
;!    _TDS_Handle->_GetCurTdsHz
;!    _Page_ProgramData->_Memory_Write
;!    _Led_Handle->___bmul
;!    _GetDelayFilterFlag->_DecF
;!    _FilterLifeFunc->_FilterTimeHandle
;!    _FilterTimeHandle->_LedSetSt
;!    _FilterKeyInputRest->_SetFilterDelayReset
;!    _ErrorHandle->_AllLedFlash
;!    _ShiftMode_Handle->_LedSetSt
;!    _AllLedFlash->_LedSetSt
;!    _LedSetSt->___bmul
;!    _CheckKey->_KeyScan
;!    _KeyScan->_BuzzerSet
;!    _EEPROM_Page->_SetFilterDelayReset
;!
;!Critical Paths under _Timer1_Isr in BANK0
;!
;!    None.
;!
;!Critical Paths under _main in BANK1
;!
;!    _Run_Mode->_FactoryMode_Handle
;!
;!Critical Paths under _Timer1_Isr in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Timer1_Isr in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 0, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 0     0      0  257695
;!                        _EEPROM_Page
;!                         _Initialize
;!                           _Run_Mode
;!                            _Set_PWM
;!                    _Set_Usart_Async
;!                    _Time_Count_Func
;! ---------------------------------------------------------------------------------
;! (1) _Set_Usart_Async                                      0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Set_PWM                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Run_Mode                                             0     0      0  172737
;!                        _AllLedFlash
;!                          _BuzzerSet
;!                 _FactoryMode_Handle
;!                     _GetMode_Handle
;!                           _LedSetSt
;!                    _SetStandbyState
;!                   _ShiftMode_Handle
;!                 _StandbyMode_Handle
;! ---------------------------------------------------------------------------------
;! (2) _StandbyMode_Handle                                   0     0      0   33341
;!                          _BuzzerSet
;!                           _LedSetSt
;!                    _SetStandbyState
;!                   _ShiftMode_Handle
;!                   _StatusFun_Handle
;!                           _WrterEEP
;! ---------------------------------------------------------------------------------
;! (3) _StatusFun_Handle                                     0     0      0   11309
;!                    _SetStandbyState
;!                         _WashHandle
;! ---------------------------------------------------------------------------------
;! (4) _WashHandle                                           2     2      0    9306
;!                                              3 BANK0      2     2      0
;!                           _LedSetSt
;!                    _SetStandbyState
;! ---------------------------------------------------------------------------------
;! (2) _GetMode_Handle                                       0     0      0   11047
;!                   _ShiftMode_Handle
;!                           _WrterEEP
;! ---------------------------------------------------------------------------------
;! (2) _FactoryMode_Handle                                   1     1      0   98884
;!                                              0 BANK1      1     1      0
;!                        _AllLedFlash
;!                          _BuzzerSet
;!                           _LedSetSt
;!                    _Time_Count_Func
;! ---------------------------------------------------------------------------------
;! (1) _Time_Count_Func                                      3     3      0   82423
;!                                             22 BANK0      3     3      0
;!                         _AD_Testing
;!                          _BuzzerSet
;!                           _CheckKey
;!                        _ErrorHandle
;!                 _FilterKeyInputRest
;!                     _FilterLifeFunc
;!                 _GetDelayFilterFlag
;!                         _Led_Handle
;!                   _Page_ProgramData
;!                    _SetStandbyState
;!                         _TDS_Handle
;!                    _TaskAlarmHandle
;!                         _Tx_Display
;!                ___CMS_CheckTouchKey
;! ---------------------------------------------------------------------------------
;! (2) ___CMS_CheckTouchKey                                  1     1      0    7129
;!             ___CMS_CheckKeyOldValue
;!              ___CMS_CheckOnceResult
;!               ___CMS_CheckValidTime
;!                    ___CMS_CurAdjust
;!                    ___CMS_KeyDatIIR
;!                   ___CMS_KeyModeSet
;!                     ___CMS_KeyStart
;!                 ___CMS_KeyStopClear
;!              ___CMS_Key_UNNOL_Check
;!                    ___CMS_NewRAMClr
;!                  ___CMS_Noise_check
;!                   ___GET_32M_FREDAT
;! ---------------------------------------------------------------------------------
;! (3) ___GET_32M_FREDAT                                     0     0      0       0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_Noise_check                                   12    12      0     380
;!                                              0 BANK0     12    12      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_NewRAMClr                                      1     1      0     223
;!                                              4 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_Key_UNNOL_Check                                4     4      0     359
;!                                              4 COMMON     2     2      0
;!                                              0 BANK0      2     2      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_KeyStopClear                                   1     1      0     347
;!                                              1 BANK0      1     1      0
;!                  ___CMS_KeyClearOne
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_KeyClearOne                                    3     3      0     248
;!                                              4 COMMON     2     2      0
;!                                              0 BANK0      1     1      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_KeyDatIIR                                     11    11      0     656
;!                                              0 BANK0     11    11      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_CurAdjust                                      6     6      0     528
;!                                              0 BANK0      6     6      0
;!                   ___CMS_CurAdjMode
;!                     ___CMS_CurJudge
;!                   ___CMS_KeyModeSet
;!                     ___CMS_KeyStart
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_KeyStart                                       1     1      0      74
;!                                              4 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_KeyModeSet                                     1     1      0      34
;!                                              4 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_CurJudge                                       2     2      0       0
;!                                              4 COMMON     2     2      0
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_CurAdjMode                                     1     1      0     145
;!                                              4 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_CheckValidTime                                 0     0      0       0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_CheckOnceResult                               21    21      0    2549
;!                                              0 BANK0     21    21      0
;!                  ___CMS_KeyHaveDown
;!                      ___CMS_KeyIsIn
;!                      ___CMS_KeyOpen
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_KeyOpen                                        2     1      1     173
;!                                              4 COMMON     2     1      1
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_KeyHaveDown                                    2     1      1     401
;!                                              4 COMMON     2     1      1
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_CheckKeyOldValue                              13    13      0    1979
;!                                              2 BANK0     13    13      0
;!                      ___CMS_KeyIsIn
;!                                _abs
;! ---------------------------------------------------------------------------------
;! (4) _abs                                                  4     2      2     537
;!                                              4 COMMON     2     0      2
;!                                              0 BANK0      2     2      0
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_KeyIsIn                                        2     2      0     102
;!                                              4 COMMON     2     2      0
;! ---------------------------------------------------------------------------------
;! (2) _Tx_Display                                           4     4      0     278
;!                                              0 BANK0      4     4      0
;! ---------------------------------------------------------------------------------
;! (2) _TaskAlarmHandle                                      2     2      0       0
;!                                              4 COMMON     2     2      0
;! ---------------------------------------------------------------------------------
;! (2) _TDS_Handle                                           8     7      1    3263
;!                                              4 COMMON     1     0      1
;!                                             15 BANK0      7     7      0
;!                        _GetCurTdsHz
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (3) ___lwdiv                                              7     3      4     580
;!                                              0 BANK0      7     3      4
;! ---------------------------------------------------------------------------------
;! (3) ___lmul                                              12     4      8     290
;!                                              0 BANK0     12     4      8
;! ---------------------------------------------------------------------------------
;! (3) ___lldiv                                             13     5      8     395
;!                                              0 BANK0     13     5      8
;! ---------------------------------------------------------------------------------
;! (3) _GetCurTdsHz                                         15    11      4     732
;!                                              0 BANK0     15    11      4
;! ---------------------------------------------------------------------------------
;! (2) _Page_ProgramData                                     2     2      0     383
;!                                              3 BANK0      2     2      0
;!                       _Memory_Write
;! ---------------------------------------------------------------------------------
;! (3) _Memory_Write                                         4     1      3     250
;!                                              4 COMMON     1     1      0
;!                                              0 BANK0      3     0      3
;! ---------------------------------------------------------------------------------
;! (2) _Led_Handle                                           4     4      0    2759
;!                                              2 BANK0      4     4      0
;!                       _LedControlSt
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (3) _LedControlSt                                         2     1      1     972
;!                                              4 COMMON     2     1      1
;! ---------------------------------------------------------------------------------
;! (2) _GetDelayFilterFlag                                   3     3      0     909
;!                                              3 BANK0      3     3      0
;!                                _Dec
;!                               _DecF
;! ---------------------------------------------------------------------------------
;! (3) _DecF                                                 5     3      2     172
;!                                              4 COMMON     2     0      2
;!                                              0 BANK0      3     3      0
;! ---------------------------------------------------------------------------------
;! (3) _Dec                                                  2     1      1     454
;!                                              4 COMMON     2     1      1
;! ---------------------------------------------------------------------------------
;! (2) _FilterLifeFunc                                       0     0      0   10379
;!                          _BuzzerSet
;!                   _FilterTimeHandle
;! ---------------------------------------------------------------------------------
;! (3) _FilterTimeHandle                                    12     4      8    8700
;!                                              3 BANK0     12     4      8
;!                           _LedSetSt
;! ---------------------------------------------------------------------------------
;! (2) _FilterKeyInputRest                                   0     0      0   22323
;!                          _BuzzerSet
;!                           _LedSetSt
;!                _SetFilterDelayReset
;!                   _ShiftMode_Handle
;!                           _WrterEEP
;! ---------------------------------------------------------------------------------
;! (2) _ErrorHandle                                          0     0      0   27462
;!                        _AllLedFlash
;!                          _BuzzerSet
;!                            _GetStop
;!                           _LedSetSt
;!                   _ShiftMode_Handle
;! ---------------------------------------------------------------------------------
;! (3) _ShiftMode_Handle                                     1     1      0   11047
;!                                              3 BANK0      1     1      0
;!                          _BuzzerSet
;!                           _LedSetSt
;!                    _SetStandbyState
;! ---------------------------------------------------------------------------------
;! (2) _SetStandbyState                                      3     1      2    2003
;!                                              4 COMMON     2     0      2
;!                                              0 BANK0      1     1      0
;! ---------------------------------------------------------------------------------
;! (3) _GetStop                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (3) _AllLedFlash                                          3     3      0    7433
;!                                              3 BANK0      3     3      0
;!                           _LedSetSt
;! ---------------------------------------------------------------------------------
;! (4) _LedSetSt                                             2     1      1    7303
;!                                              5 COMMON     1     0      1
;!                                              2 BANK0      1     1      0
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (3) ___bmul                                               3     2      1     941
;!                                              4 COMMON     1     0      1
;!                                              0 BANK0      2     2      0
;! ---------------------------------------------------------------------------------
;! (2) _CheckKey                                             4     4      0    3107
;!                                              5 BANK0      4     4      0
;!                            _KeyScan
;! ---------------------------------------------------------------------------------
;! (3) _KeyScan                                              4     3      1    2779
;!                                              1 BANK0      4     3      1
;!                          _BuzzerSet
;! ---------------------------------------------------------------------------------
;! (3) _BuzzerSet                                            3     1      2    1679
;!                                              4 COMMON     2     0      2
;!                                              0 BANK0      1     1      0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Testing                                          10     8      2     749
;!                                              4 COMMON     2     0      2
;!                                              0 BANK0      8     8      0
;! ---------------------------------------------------------------------------------
;! (1) _Initialize                                           0     0      0       0
;!                           _Init_ram
;! ---------------------------------------------------------------------------------
;! (2) _Init_ram                                             0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _EEPROM_Page                                          0     0      0    2535
;!                       _ReadDataArry
;!                _SetFilterDelayReset
;!                           _WrterEEP
;! ---------------------------------------------------------------------------------
;! (3) _WrterEEP                                             0     0      0       0
;! ---------------------------------------------------------------------------------
;! (3) _SetFilterDelayReset                                  7     1      6    2294
;!                                              4 COMMON     1     1      0
;!                                              0 BANK0      6     0      6
;! ---------------------------------------------------------------------------------
;! (2) _ReadDataArry                                         2     2      0     241
;!                                              0 BANK0      2     2      0
;!                        _Memory_Read
;! ---------------------------------------------------------------------------------
;! (3) _Memory_Read                                          2     0      2     108
;!                                              4 COMMON     2     0      2
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 4
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (8) _Timer1_Isr                                           4     4      0       0
;!                                              0 COMMON     4     4      0
;!                ___CMS_TouchKeyValue
;! ---------------------------------------------------------------------------------
;! (10) ___CMS_TouchKeyValue                                 0     0      0       0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 10
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _EEPROM_Page
;!     _ReadDataArry
;!       _Memory_Read
;!     _SetFilterDelayReset
;!     _WrterEEP
;!   _Initialize
;!     _Init_ram
;!   _Run_Mode
;!     _AllLedFlash
;!       _LedSetSt
;!         ___bmul
;!     _BuzzerSet
;!     _FactoryMode_Handle
;!       _AllLedFlash
;!         _LedSetSt
;!           ___bmul
;!       _BuzzerSet
;!       _LedSetSt
;!         ___bmul
;!       _Time_Count_Func
;!         _AD_Testing
;!         _BuzzerSet
;!         _CheckKey
;!           _KeyScan
;!             _BuzzerSet
;!         _ErrorHandle
;!           _AllLedFlash
;!             _LedSetSt
;!               ___bmul
;!           _BuzzerSet
;!           _GetStop
;!           _LedSetSt
;!             ___bmul
;!           _ShiftMode_Handle
;!             _BuzzerSet
;!             _LedSetSt
;!               ___bmul
;!             _SetStandbyState
;!         _FilterKeyInputRest
;!           _BuzzerSet
;!           _LedSetSt
;!             ___bmul
;!           _SetFilterDelayReset
;!           _ShiftMode_Handle
;!             _BuzzerSet
;!             _LedSetSt
;!               ___bmul
;!             _SetStandbyState
;!           _WrterEEP
;!         _FilterLifeFunc
;!           _BuzzerSet
;!           _FilterTimeHandle
;!             _LedSetSt
;!               ___bmul
;!         _GetDelayFilterFlag
;!           _Dec
;!           _DecF
;!         _Led_Handle
;!           _LedControlSt
;!           ___bmul
;!         _Page_ProgramData
;!           _Memory_Write
;!         _SetStandbyState
;!         _TDS_Handle
;!           _GetCurTdsHz
;!           ___lldiv
;!           ___lmul
;!           ___lwdiv
;!         _TaskAlarmHandle
;!         _Tx_Display
;!         ___CMS_CheckTouchKey
;!           ___CMS_CheckKeyOldValue
;!             ___CMS_KeyIsIn
;!             _abs
;!           ___CMS_CheckOnceResult
;!             ___CMS_KeyHaveDown
;!             ___CMS_KeyIsIn
;!             ___CMS_KeyOpen
;!           ___CMS_CheckValidTime
;!           ___CMS_CurAdjust
;!             ___CMS_CurAdjMode
;!             ___CMS_CurJudge
;!             ___CMS_KeyModeSet
;!             ___CMS_KeyStart
;!           ___CMS_KeyDatIIR
;!           ___CMS_KeyModeSet
;!           ___CMS_KeyStart
;!           ___CMS_KeyStopClear
;!             ___CMS_KeyClearOne
;!           ___CMS_Key_UNNOL_Check
;!           ___CMS_NewRAMClr
;!           ___CMS_Noise_check
;!           ___GET_32M_FREDAT
;!     _GetMode_Handle
;!       _ShiftMode_Handle
;!         _BuzzerSet
;!         _LedSetSt
;!           ___bmul
;!         _SetStandbyState
;!       _WrterEEP
;!     _LedSetSt
;!       ___bmul
;!     _SetStandbyState
;!     _ShiftMode_Handle
;!       _BuzzerSet
;!       _LedSetSt
;!         ___bmul
;!       _SetStandbyState
;!     _StandbyMode_Handle
;!       _BuzzerSet
;!       _LedSetSt
;!         ___bmul
;!       _SetStandbyState
;!       _ShiftMode_Handle
;!         _BuzzerSet
;!         _LedSetSt
;!           ___bmul
;!         _SetStandbyState
;!       _StatusFun_Handle
;!         _SetStandbyState
;!         _WashHandle
;!           _LedSetSt
;!             ___bmul
;!           _SetStandbyState
;!       _WrterEEP
;!   _Set_PWM
;!   _Set_Usart_Async
;!   _Time_Count_Func
;!     _AD_Testing
;!     _BuzzerSet
;!     _CheckKey
;!       _KeyScan
;!         _BuzzerSet
;!     _ErrorHandle
;!       _AllLedFlash
;!         _LedSetSt
;!           ___bmul
;!       _BuzzerSet
;!       _GetStop
;!       _LedSetSt
;!         ___bmul
;!       _ShiftMode_Handle
;!         _BuzzerSet
;!         _LedSetSt
;!           ___bmul
;!         _SetStandbyState
;!     _FilterKeyInputRest
;!       _BuzzerSet
;!       _LedSetSt
;!         ___bmul
;!       _SetFilterDelayReset
;!       _ShiftMode_Handle
;!         _BuzzerSet
;!         _LedSetSt
;!           ___bmul
;!         _SetStandbyState
;!       _WrterEEP
;!     _FilterLifeFunc
;!       _BuzzerSet
;!       _FilterTimeHandle
;!         _LedSetSt
;!           ___bmul
;!     _GetDelayFilterFlag
;!       _Dec
;!       _DecF
;!     _Led_Handle
;!       _LedControlSt
;!       ___bmul
;!     _Page_ProgramData
;!       _Memory_Write
;!     _SetStandbyState
;!     _TDS_Handle
;!       _GetCurTdsHz
;!       ___lldiv
;!       ___lmul
;!       ___lwdiv
;!     _TaskAlarmHandle
;!     _Tx_Display
;!     ___CMS_CheckTouchKey
;!       ___CMS_CheckKeyOldValue
;!         ___CMS_KeyIsIn
;!         _abs
;!       ___CMS_CheckOnceResult
;!         ___CMS_KeyHaveDown
;!         ___CMS_KeyIsIn
;!         ___CMS_KeyOpen
;!       ___CMS_CheckValidTime
;!       ___CMS_CurAdjust
;!         ___CMS_CurAdjMode
;!         ___CMS_CurJudge
;!         ___CMS_KeyModeSet
;!         ___CMS_KeyStart
;!       ___CMS_KeyDatIIR
;!       ___CMS_KeyModeSet
;!       ___CMS_KeyStart
;!       ___CMS_KeyStopClear
;!         ___CMS_KeyClearOne
;!       ___CMS_Key_UNNOL_Check
;!       ___CMS_NewRAMClr
;!       ___CMS_Noise_check
;!       ___GET_32M_FREDAT
;!
;! _Timer1_Isr (ROOT)
;!   ___CMS_TouchKeyValue
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BITCOMMON            E      0       1       0        7.1%
;!NULL                 0      0       0       0        0.0%
;!CODE                 0      0       0       0        0.0%
;!COMMON               E      6       A       1       71.4%
;!BITSFR0              0      0       0       1        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!SFR1                 0      0       0       2        0.0%
;!STACK                0      0       0       2        0.0%
;!BITBANK0            50      0       0       3        0.0%
;!BANK0               50     19      50       4      100.0%
;!BITSFR3              0      0       0       4        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITBANK1            50      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BANK1               50      1      4F       6       98.8%
;!BANK2               50      0      40       7       80.0%
;!ABS                  0      0      E9       8        0.0%
;!DATA                 0      0      E9       9        0.0%
;!BITBANK2            50      0       0      10        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 2747 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels required when called:   10
;; This function calls:
;;		_EEPROM_Page
;;		_Initialize
;;		_Run_Mode
;;		_Set_PWM
;;		_Set_Usart_Async
;;		_Time_Count_Func
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	2747
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	2747
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	2750
	
l11488:	
# 2750 "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	2751
# 2751 "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	maintext
	line	2752
	
l11490:	
;main.c: 2752: Initialize();
	fcall	_Initialize
	line	2753
	
l11492:	
;main.c: 2753: EEPROM_Page();
	fcall	_EEPROM_Page
	line	2755
	
l11494:	
;main.c: 2755: Set_PWM();
	fcall	_Set_PWM
	line	2756
	
l11496:	
;main.c: 2756: Set_Usart_Async();
	fcall	_Set_Usart_Async
	line	2758
	
l11498:	
;main.c: 2758: Tx_Type.TxType.Tx_FH1=0xa5;
	movlw	low(0A5h)
	movwf	(_Tx_Type)^0100h
	line	2759
	
l11500:	
;main.c: 2759: Tx_Type.TxType.Tx_FH2=0xa6;
	movlw	low(0A6h)
	movwf	0+(_Tx_Type)^0100h+01h
	line	2760
	
l11502:	
;main.c: 2760: Tx_Type.TxType.Tx_TotalLength=0x11U;
	movlw	low(011h)
	movwf	0+(_Tx_Type)^0100h+02h
	line	2763
	
l11504:	
;main.c: 2763: PreTdsData=PureTDSTyp.TdsData=0x03;
	movlw	low(0Fh)
	addlw	low(_PureTDSTyp|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	03h
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movlw	0
	movwf	indf
	movlw	03h
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_PreTdsData)
	movlw	0
	movwf	((_PreTdsData))+1
	line	2770
	
l11506:	
;main.c: 2770: RC2=0;
	bcf	(58/8),(58)&7	;volatile
	line	2771
	
l11508:	
;main.c: 2771: {RA2=0;_BITS2.Bits.bit_1=0;};
	bcf	(42/8),(42)&7	;volatile
	
l11510:	
	bcf	(__BITS2),1
	line	2772
	
l11512:	
;main.c: 2772: RC3=0;
	bcf	(59/8),(59)&7	;volatile
	line	2780
;main.c: 2780: while(1)
	
l1545:	
	line	2784
# 2784 "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	maintext
	line	2786
	
l11514:	
;main.c: 2786: Time_Count_Func();
	fcall	_Time_Count_Func
	line	2789
	
l11516:	
;main.c: 2789: Run_Mode();
	fcall	_Run_Mode
	goto	l1545
	global	start
	ljmp	start
	opt stack 0
	line	2797
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_Set_Usart_Async

;; *************** function _Set_Usart_Async *****************
;; Defined at:
;;		line 2690 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/200
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	2690
global __ptext1
__ptext1:	;psect for function _Set_Usart_Async
psect	text1
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	2690
	global	__size_of_Set_Usart_Async
	__size_of_Set_Usart_Async	equ	__end_of_Set_Usart_Async-_Set_Usart_Async
	
_Set_Usart_Async:	
;incstack = 0
	opt	stack 8
; Regs used in _Set_Usart_Async: [wreg]
	line	2706
	
l9046:	
;main.c: 2706: SPBRG1 = 103;
	movlw	low(067h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(152)^080h	;volatile
	line	2707
	
l9048:	
;main.c: 2707: SYNC1 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2300/8)^0100h,(2300)&7	;volatile
	line	2708
	
l9050:	
;main.c: 2708: SCKP1 = 0;
	bcf	(2299/8)^0100h,(2299)&7	;volatile
	line	2710
	
l9052:	
;main.c: 2710: SPEN1 = 1;
	bsf	(2095/8)^0100h,(2095)&7	;volatile
	line	2711
	
l9054:	
;main.c: 2711: RC1IE = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1129/8)^080h,(1129)&7	;volatile
	line	2712
	
l9056:	
;main.c: 2712: TX1IE = 0;
	bcf	(1130/8)^080h,(1130)&7	;volatile
	line	2713
	
l9058:	
;main.c: 2713: RX9EN1 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2094/8)^0100h,(2094)&7	;volatile
	line	2714
	
l9060:	
;main.c: 2714: TX9EN1 = 0;
	bcf	(2302/8)^0100h,(2302)&7	;volatile
	line	2715
	
l9062:	
;main.c: 2715: CREN1 = 0;
	bcf	(2092/8)^0100h,(2092)&7	;volatile
	line	2716
	
l9064:	
;main.c: 2716: TXEN1 = 1;
	bsf	(2301/8)^0100h,(2301)&7	;volatile
	line	2717
	
l1537:	
	return
	opt stack 0
GLOBAL	__end_of_Set_Usart_Async
	__end_of_Set_Usart_Async:
	signat	_Set_Usart_Async,89
	global	_Set_PWM

;; *************** function _Set_PWM *****************
;; Defined at:
;;		line 2718 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	line	2718
global __ptext2
__ptext2:	;psect for function _Set_PWM
psect	text2
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	2718
	global	__size_of_Set_PWM
	__size_of_Set_PWM	equ	__end_of_Set_PWM-_Set_PWM
	
_Set_PWM:	
;incstack = 0
	opt	stack 8
; Regs used in _Set_PWM: [wreg+status,2]
	line	2720
	
l9066:	
;main.c: 2720: PWMTL = 0xfa;
	movlw	low(0FAh)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(283)^0100h	;volatile
	line	2722
;main.c: 2722: PWMTH = 0B00000100;
	movlw	low(04h)
	movwf	(284)^0100h	;volatile
	line	2727
	
l9068:	
;main.c: 2727: PWMD01H = 0x00;
	clrf	(273)^0100h	;volatile
	line	2731
	
l9070:	
;main.c: 2731: PWMD1L = 0x7d;
	movlw	low(07Dh)
	movwf	(269)^0100h	;volatile
	line	2743
	
l9072:	
;main.c: 2743: PWMCON1 = 0B01000000;
	movlw	low(040h)
	movwf	(263)^0100h	;volatile
	line	2744
	
l9074:	
;main.c: 2744: PWMCON0 = 0B10100000;
	movlw	low(0A0h)
	movwf	(262)^0100h	;volatile
	line	2746
	
l1540:	
	return
	opt stack 0
GLOBAL	__end_of_Set_PWM
	__end_of_Set_PWM:
	signat	_Set_PWM,89
	global	_Run_Mode

;; *************** function _Run_Mode *****************
;; Defined at:
;;		line 1981 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    9
;; This function calls:
;;		_AllLedFlash
;;		_BuzzerSet
;;		_FactoryMode_Handle
;;		_GetMode_Handle
;;		_LedSetSt
;;		_SetStandbyState
;;		_ShiftMode_Handle
;;		_StandbyMode_Handle
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	line	1981
global __ptext3
__ptext3:	;psect for function _Run_Mode
psect	text3
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	1981
	global	__size_of_Run_Mode
	__size_of_Run_Mode	equ	__end_of_Run_Mode-_Run_Mode
	
_Run_Mode:	
;incstack = 0
	opt	stack 2
; Regs used in _Run_Mode: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1983
	
l11394:	
;main.c: 1983: switch(Mode){
	goto	l11452
	line	1987
	
l11396:	
;main.c: 1987: AllLedFlash(1);
	movlw	low(01h)
	fcall	_AllLedFlash
	line	1988
	
l11398:	
;main.c: 1988: _BITS.Bits.bit_5=0x01;
	bsf	(__BITS),5
	line	1989
	
l11400:	
;main.c: 1989: Timer_Power_100ms=0;
	clrf	(_Timer_Power_100ms)
	line	1990
	
l11402:	
;main.c: 1990: PowerStep=1;
	clrf	(_PowerStep)
	incf	(_PowerStep),f
	line	1991
	
l11404:	
;main.c: 1991: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	line	1992
	
l11406:	
;main.c: 1992: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1994
;main.c: 1994: break;
	goto	l1418
	line	1996
	
l11408:	
;main.c: 1996: if(Timer_Power_100ms>=30){
	movlw	low(01Eh)
	subwf	(_Timer_Power_100ms),w
	skipc
	goto	u11001
	goto	u11000
u11001:
	goto	l1418
u11000:
	line	1997
	
l11410:	
;main.c: 1997: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1998
	
l11412:	
;main.c: 1998: PowerStep=2;
	movlw	low(02h)
	movwf	(_PowerStep)
	goto	l1418
	line	2004
	
l11414:	
;main.c: 2004: if(Timer_Power_100ms>=31){
	movlw	low(01Fh)
	subwf	(_Timer_Power_100ms),w
	skipc
	goto	u11011
	goto	u11010
u11011:
	goto	l1418
u11010:
	line	2005
	
l11416:	
;main.c: 2005: ShiftMode_Handle(2);
	movlw	low(02h)
	fcall	_ShiftMode_Handle
	line	2007
;main.c: 2007: SetStandbyState(WashState,&WashRunTime, 18);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(012h)
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	goto	l1418
	line	2011
	
l11418:	
;main.c: 2011: Timer_Power_100ms=0;
	clrf	(_Timer_Power_100ms)
	line	2012
	
l11420:	
;main.c: 2012: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	2016
	
l11422:	
;main.c: 2016: LedSetSt(1, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(01h)
	fcall	_LedSetSt
	line	2017
	
l11424:	
;main.c: 2017: LedSetSt(5, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(05h)
	fcall	_LedSetSt
	line	2018
	
l11426:	
;main.c: 2018: LedSetSt(3, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(03h)
	fcall	_LedSetSt
	line	2025
	
l11428:	
;main.c: 2025: PowerStep=4;
	movlw	low(04h)
	movwf	(_PowerStep)
	line	2026
;main.c: 2026: break;
	goto	l1418
	line	2028
	
l11430:	
;main.c: 2028: if(Timer_Power_100ms>=10){
	movlw	low(0Ah)
	subwf	(_Timer_Power_100ms),w
	skipc
	goto	u11021
	goto	u11020
u11021:
	goto	l1418
u11020:
	line	2029
	
l11432:	
;main.c: 2029: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	2030
;main.c: 2030: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	line	2031
;main.c: 2031: LedSetSt(4, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(04h)
	fcall	_LedSetSt
	line	2032
;main.c: 2032: LedSetSt(2, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(02h)
	fcall	_LedSetSt
	line	2043
	
l11434:	
;main.c: 2043: PowerStep=5;
	movlw	low(05h)
	movwf	(_PowerStep)
	goto	l1418
	line	2049
	
l11436:	
;main.c: 2049: if(Timer_Power_100ms>=20){
	movlw	low(014h)
	subwf	(_Timer_Power_100ms),w
	skipc
	goto	u11031
	goto	u11030
u11031:
	goto	l1418
u11030:
	line	2050
	
l11438:	
;main.c: 2050: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	2051
;main.c: 2051: ShiftMode_Handle(2);
	movlw	low(02h)
	fcall	_ShiftMode_Handle
	goto	l1418
	line	1985
	
l11442:	
	movf	(_PowerStep),w
	; Switch size 1, requested type "space"
; Number of cases is 6, Range of values is 0 to 5
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           19    10 (average)
; direct_byte           26     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l11396
	xorlw	1^0	; case 1
	skipnz
	goto	l11408
	xorlw	2^1	; case 2
	skipnz
	goto	l11414
	xorlw	3^2	; case 3
	skipnz
	goto	l11418
	xorlw	4^3	; case 4
	skipnz
	goto	l11430
	xorlw	5^4	; case 5
	skipnz
	goto	l11436
	goto	l1418
	opt asmopt_pop

	line	2059
	
l11444:	
;main.c: 2059: StandbyMode_Handle();
	fcall	_StandbyMode_Handle
	line	2060
;main.c: 2060: break;
	goto	l1418
	line	2062
	
l11446:	
;main.c: 2062: GetMode_Handle();
	fcall	_GetMode_Handle
	line	2063
;main.c: 2063: break;
	goto	l1418
	line	2065
	
l11448:	
;main.c: 2065: FactoryMode_Handle();
	fcall	_FactoryMode_Handle
	line	2066
;main.c: 2066: break;
	goto	l1418
	line	2067
;main.c: 2067: case 3:
	
l1417:	
	line	2068
;main.c: 2068: {RA2=0;_BITS2.Bits.bit_1=0;};
	bcf	(42/8),(42)&7	;volatile
	bcf	(__BITS2),1
	line	2069
;main.c: 2069: RC3=0;
	bcf	(59/8),(59)&7	;volatile
	line	2070
;main.c: 2070: RC2=0;
	bcf	(58/8),(58)&7	;volatile
	line	2071
;main.c: 2071: break;
	goto	l1418
	line	1983
	
l11452:	
	movf	(_Mode),w
	; Switch size 1, requested type "space"
; Number of cases is 5, Range of values is 0 to 5
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           16     9 (average)
; direct_byte           26     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l11442
	xorlw	2^0	; case 2
	skipnz
	goto	l11444
	xorlw	3^2	; case 3
	skipnz
	goto	l1417
	xorlw	4^3	; case 4
	skipnz
	goto	l11446
	xorlw	5^4	; case 5
	skipnz
	goto	l11448
	goto	l1418
	opt asmopt_pop

	line	2073
	
l1418:	
	return
	opt stack 0
GLOBAL	__end_of_Run_Mode
	__end_of_Run_Mode:
	signat	_Run_Mode,89
	global	_StandbyMode_Handle

;; *************** function _StandbyMode_Handle *****************
;; Defined at:
;;		line 1849 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    7
;; This function calls:
;;		_BuzzerSet
;;		_LedSetSt
;;		_SetStandbyState
;;		_ShiftMode_Handle
;;		_StatusFun_Handle
;;		_WrterEEP
;; This function is called by:
;;		_Run_Mode
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	line	1849
global __ptext4
__ptext4:	;psect for function _StandbyMode_Handle
psect	text4
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	1849
	global	__size_of_StandbyMode_Handle
	__size_of_StandbyMode_Handle	equ	__end_of_StandbyMode_Handle-_StandbyMode_Handle
	
_StandbyMode_Handle:	
;incstack = 0
	opt	stack 3
; Regs used in _StandbyMode_Handle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1854
	
l11280:	
;main.c: 1853: static U8_T Ti_1h=0;
;main.c: 1854: if(Read_Word_Buff[11]==2)
		movlw	2
	bsf	status, 5	;RP0=1, select bank1
	xorwf	(0+(_Read_Word_Buff)^080h+0Bh),w
	btfss	status,2
	goto	u10781
	goto	u10780
u10781:
	goto	l11300
u10780:
	line	1857
	
l11282:	
;main.c: 1855: {
;main.c: 1857: if(Timer_Standby_1s>=300)
	movlw	01h
	subwf	(_Timer_Standby_1s+1)^080h,w
	movlw	02Ch
	skipnz
	subwf	(_Timer_Standby_1s)^080h,w
	skipc
	goto	u10791
	goto	u10790
u10791:
	goto	l11290
u10790:
	line	1860
	
l11284:	
;main.c: 1858: {
;main.c: 1860: if(_BITS1.Bits.bit_4==0){
	bcf	status, 5	;RP0=0, select bank0
	btfsc	(__BITS1),4
	goto	u10801
	goto	u10800
u10801:
	goto	l11290
u10800:
	line	1861
	
l11286:	
;main.c: 1861: _BITS1.Bits.bit_4=1;
	bsf	(__BITS1),4
	line	1862
	
l11288:	
;main.c: 1862: SetStandbyState(BackState,&WashRunTime, 30);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(01Eh)
	movwf	(SetStandbyState@Da)
	movlw	low(03h)
	fcall	_SetStandbyState
	line	1866
	
l11290:	
;main.c: 1863: }
;main.c: 1864: }
;main.c: 1866: if(Timer_BackT_1H>=12)
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_BackT_1H+1)^080h,w
	movlw	0Ch
	skipnz
	subwf	(_Timer_BackT_1H)^080h,w
	skipc
	goto	u10811
	goto	u10810
u10811:
	goto	l11300
u10810:
	line	1870
	
l11292:	
;main.c: 1868: {
;main.c: 1870: if(_BITS1.Bits.bit_6==0)
	bcf	status, 5	;RP0=0, select bank0
	btfsc	(__BITS1),6
	goto	u10821
	goto	u10820
u10821:
	goto	l11300
u10820:
	line	1872
	
l11294:	
;main.c: 1871: {
;main.c: 1872: _BITS1.Bits.bit_6=1;
	bsf	(__BITS1),6
	line	1873
	
l11296:	
;main.c: 1873: SetStandbyState(BackState,&WashRunTime, 30);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(01Eh)
	movwf	(SetStandbyState@Da)
	movlw	low(03h)
	fcall	_SetStandbyState
	line	1874
	
l11298:	
;main.c: 1874: Read_Word_Buff[11]=3;
	movlw	low(03h)
	movwf	0+(_Read_Word_Buff)^080h+0Bh
	line	1879
	
l11300:	
;main.c: 1875: }
;main.c: 1876: }
;main.c: 1877: }
;main.c: 1879: if(Timer_Standby_1s>=3600)
	movlw	0Eh
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_Standby_1s+1)^080h,w
	movlw	010h
	skipnz
	subwf	(_Timer_Standby_1s)^080h,w
	skipc
	goto	u10831
	goto	u10830
u10831:
	goto	l11314
u10830:
	line	1882
	
l11302:	
;main.c: 1881: {
;main.c: 1882: Timer_Standby_1s=0;
	clrf	(_Timer_Standby_1s)^080h
	clrf	(_Timer_Standby_1s+1)^080h
	line	1883
	
l11304:	
;main.c: 1883: if(Timer_Standby_1H<0xf0)
	movlw	0
	subwf	(_Timer_Standby_1H+1)^080h,w
	movlw	0F0h
	skipnz
	subwf	(_Timer_Standby_1H)^080h,w
	skipnc
	goto	u10841
	goto	u10840
u10841:
	goto	l1377
u10840:
	line	1884
	
l11306:	
;main.c: 1884: Timer_Standby_1H++;
	incf	(_Timer_Standby_1H)^080h,f
	skipnz
	incf	(_Timer_Standby_1H+1)^080h,f
	
l1377:	
	line	1885
;main.c: 1885: Timer_BackT_1H++;
	incf	(_Timer_BackT_1H)^080h,f
	skipnz
	incf	(_Timer_BackT_1H+1)^080h,f
	line	1886
	
l11308:	
;main.c: 1886: if(++Ti_1h>=10){
	movlw	low(0Ah)
	bcf	status, 5	;RP0=0, select bank0
	incf	(StandbyMode_Handle@Ti_1h),f
	subwf	((StandbyMode_Handle@Ti_1h)),w
	skipc
	goto	u10851
	goto	u10850
u10851:
	goto	l11314
u10850:
	line	1887
	
l11310:	
;main.c: 1887: Ti_1h=0;
	clrf	(StandbyMode_Handle@Ti_1h)
	line	1888
	
l11312:	
;main.c: 1888: WrterEEP();
	fcall	_WrterEEP
	line	1892
	
l11314:	
;main.c: 1889: }
;main.c: 1890: }
;main.c: 1892: if(Timer_Standby_1H>=72)
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_Standby_1H+1)^080h,w
	movlw	048h
	skipnz
	subwf	(_Timer_Standby_1H)^080h,w
	skipc
	goto	u10861
	goto	u10860
u10861:
	goto	l11324
u10860:
	line	1896
	
l11316:	
;main.c: 1894: {
;main.c: 1896: Timer_Standby_1H=0;
	clrf	(_Timer_Standby_1H)^080h
	clrf	(_Timer_Standby_1H+1)^080h
	line	1897
	
l11318:	
;main.c: 1897: if(_BITS2.Bits.bit_2==0){
	bcf	status, 5	;RP0=0, select bank0
	btfsc	(__BITS2),2
	goto	u10871
	goto	u10870
u10871:
	goto	l11324
u10870:
	line	1899
	
l11320:	
;main.c: 1899: if(StandByStatus==NornalStopState){
	movf	((_StandByStatus)),w
	btfss	status,2
	goto	u10881
	goto	u10880
u10881:
	goto	l11324
u10880:
	line	1900
	
l11322:	
;main.c: 1900: SetStandbyState(WashState,&WashRunTime, 30);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(01Eh)
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	line	1910
	
l11324:	
;main.c: 1901: }
;main.c: 1902: }
;main.c: 1903: }
;main.c: 1909: if((KeyPacket_y[2].KeyState==LongPressDown)
;main.c: 1910: &&(KeyPacket_y[1].KeyState==NotPress))
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u10891
	goto	u10890
u10891:
	goto	l11360
u10890:
	
l11326:	
	movf	(0+(_KeyPacket_y)+03h),w
	btfss	status,2
	goto	u10901
	goto	u10900
u10901:
	goto	l11360
u10900:
	line	1912
	
l11328:	
;main.c: 1911: {
;main.c: 1912: KeyPacket_y[2].KeyState=SuperPressDown;
	movlw	low(03h)
	movwf	0+(_KeyPacket_y)+06h
	line	1913
;main.c: 1913: if(Time_Power_1s<=10){
	movlw	low(0Bh)
	subwf	(_Time_Power_1s),w
	skipnc
	goto	u10911
	goto	u10910
u10911:
	goto	l11334
u10910:
	line	1914
	
l11330:	
;main.c: 1914: BuzzerSet(3, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(03h)
	fcall	_BuzzerSet
	line	1915
	
l11332:	
;main.c: 1915: FilterFastCheck=1;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_FilterFastCheck)
	incf	(_FilterFastCheck),f
	line	1916
;main.c: 1916: }
	goto	l11360
	line	1919
	
l11334:	
;main.c: 1917: else
;main.c: 1918: {
;main.c: 1919: if(Read_Word_Buff[11]==0){
	bsf	status, 5	;RP0=1, select bank1
	movf	(0+(_Read_Word_Buff)^080h+0Bh),w
	btfss	status,2
	goto	u10921
	goto	u10920
u10921:
	goto	l11338
u10920:
	line	1920
	
l11336:	
;main.c: 1920: Read_Word_Buff[11]=3;
	movlw	low(03h)
	movwf	0+(_Read_Word_Buff)^080h+0Bh
	line	1921
;main.c: 1921: }
	goto	l11340
	line	1924
	
l11338:	
;main.c: 1922: else
;main.c: 1923: {
;main.c: 1924: Read_Word_Buff[11]=0;
	clrf	0+(_Read_Word_Buff)^080h+0Bh
	line	1928
	
l11340:	
;main.c: 1925: }
;main.c: 1928: WrterEEP();
	fcall	_WrterEEP
	line	1929
	
l11342:	
;main.c: 1929: if(Read_Word_Buff[11])
	bsf	status, 5	;RP0=1, select bank1
	movf	(0+(_Read_Word_Buff)^080h+0Bh),w
	btfsc	status,2
	goto	u10931
	goto	u10930
u10931:
	goto	l11356
u10930:
	line	1931
	
l11344:	
;main.c: 1930: {
;main.c: 1931: Read_Word_Buff[11]=3;
	movlw	low(03h)
	movwf	0+(_Read_Word_Buff)^080h+0Bh
	line	1932
	
l11346:	
;main.c: 1932: Timer_Standby_1s=0;
	clrf	(_Timer_Standby_1s)^080h
	clrf	(_Timer_Standby_1s+1)^080h
	line	1933
	
l11348:	
;main.c: 1933: Timer_BackT_1H=0;
	clrf	(_Timer_BackT_1H)^080h
	clrf	(_Timer_BackT_1H+1)^080h
	line	1934
	
l11350:	
;main.c: 1934: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1935
	
l11352:	
;main.c: 1935: LedSetSt(1, 5);
	movlw	low(05h)
	movwf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1936
	
l11354:	
;main.c: 1936: LedMod[1].LedFlashNum=1;
	bsf	status, 6	;RP1=1, select bank2
	clrf	0+(_LedMod)^0100h+08h
	incf	0+(_LedMod)^0100h+08h,f
	clrf	1+(_LedMod)^0100h+08h
	line	1937
;main.c: 1937: }
	goto	l11360
	line	1940
	
l11356:	
;main.c: 1938: else
;main.c: 1939: {
;main.c: 1940: LedSetSt(1, 5);
	movlw	low(05h)
	movwf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1941
	
l11358:	
;main.c: 1941: BuzzerSet(3, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(03h)
	fcall	_BuzzerSet
	line	1947
	
l11360:	
;main.c: 1942: }
;main.c: 1944: }
;main.c: 1945: }
;main.c: 1947: if(KeyPacket_y[2].KeyState==ShortRelease)
		movlw	6
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	xorwf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u10941
	goto	u10940
u10941:
	goto	l11374
u10940:
	line	1949
	
l11362:	
;main.c: 1948: {
;main.c: 1949: KeyPacket_y[2].KeyState=NotPress;
	clrf	0+(_KeyPacket_y)+06h
	line	1950
	
l11364:	
;main.c: 1950: if(_BITS1.Bits.bit_0==0){
	btfsc	(__BITS1),0
	goto	u10951
	goto	u10950
u10951:
	goto	l11374
u10950:
	line	1951
	
l11366:	
;main.c: 1951: BuzzerSet(1, 50);
	movlw	032h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1952
	
l11368:	
;main.c: 1952: if(StandByStatus==WashState)
	bcf	status, 5	;RP0=0, select bank0
		decf	((_StandByStatus)),w
	btfss	status,2
	goto	u10961
	goto	u10960
u10961:
	goto	l11372
u10960:
	line	1954
	
l11370:	
;main.c: 1953: {
;main.c: 1954: LedSetSt(1, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1955
;main.c: 1955: SetStandbyState(NornalStopState,&WashRunTime, 0);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	clrf	(SetStandbyState@Da)
	movlw	low(0)
	fcall	_SetStandbyState
	line	1956
;main.c: 1956: }
	goto	l11374
	line	1959
	
l11372:	
;main.c: 1957: else
;main.c: 1958: {
;main.c: 1959: SetStandbyState(WashState,&WashRunTime, 180);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(0B4h)
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	line	1968
	
l11374:	
;main.c: 1960: }
;main.c: 1961: }
;main.c: 1963: }
;main.c: 1968: if(KeyPacket_y[0].KeyState==NotPress){
	bcf	status, 5	;RP0=0, select bank0
	movf	((_KeyPacket_y)),w
	btfss	status,2
	goto	u10971
	goto	u10970
u10971:
	goto	l11378
u10970:
	line	1969
	
l11376:	
;main.c: 1969: StatusFun_Handle();
	fcall	_StatusFun_Handle
	line	1970
;main.c: 1970: }
	goto	l1396
	line	1973
	
l11378:	
;main.c: 1971: else
;main.c: 1972: {
;main.c: 1973: if(StandByStatus==BackState)
		movlw	3
	xorwf	((_StandByStatus)),w
	btfss	status,2
	goto	u10981
	goto	u10980
u10981:
	goto	l1395
u10980:
	line	1975
	
l11380:	
;main.c: 1974: {
;main.c: 1975: SetStandbyState(NornalStopState,&WashRunTime, 0);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	clrf	(SetStandbyState@Da)
	movlw	low(0)
	fcall	_SetStandbyState
	line	1976
	
l1395:	
	line	1977
;main.c: 1976: }
;main.c: 1977: ShiftMode_Handle(4);
	movlw	low(04h)
	fcall	_ShiftMode_Handle
	line	1980
	
l1396:	
	return
	opt stack 0
GLOBAL	__end_of_StandbyMode_Handle
	__end_of_StandbyMode_Handle:
	signat	_StandbyMode_Handle,89
	global	_StatusFun_Handle

;; *************** function _StatusFun_Handle *****************
;; Defined at:
;;		line 1456 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_SetStandbyState
;;		_WashHandle
;; This function is called by:
;;		_StandbyMode_Handle
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	line	1456
global __ptext5
__ptext5:	;psect for function _StatusFun_Handle
psect	text5
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	1456
	global	__size_of_StatusFun_Handle
	__size_of_StatusFun_Handle	equ	__end_of_StatusFun_Handle-_StatusFun_Handle
	
_StatusFun_Handle:	
;incstack = 0
	opt	stack 3
; Regs used in _StatusFun_Handle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1458
	
l11148:	
;main.c: 1458: switch(StandByStatus){
	goto	l11156
	line	1462
	
l11150:	
;main.c: 1461: case BackState:
;main.c: 1462: WashHandle();
	fcall	_WashHandle
	line	1463
;main.c: 1463: break;
	goto	l1275
	line	1465
	
l11152:	
;main.c: 1465: SetStandbyState(NornalStopState,&WashRunTime, 0);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	clrf	(SetStandbyState@Da)
	movlw	low(0)
	fcall	_SetStandbyState
	line	1466
;main.c: 1466: break;
	goto	l1275
	line	1458
	
l11156:	
	movf	(_StandByStatus),w
	; Switch size 1, requested type "space"
; Number of cases is 3, Range of values is 0 to 3
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           10     6 (average)
; direct_byte           20     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l11152
	xorlw	1^0	; case 1
	skipnz
	goto	l11150
	xorlw	3^1	; case 3
	skipnz
	goto	l11150
	goto	l1275
	opt asmopt_pop

	line	1468
	
l1275:	
	return
	opt stack 0
GLOBAL	__end_of_StatusFun_Handle
	__end_of_StatusFun_Handle:
	signat	_StatusFun_Handle,89
	global	_WashHandle

;; *************** function _WashHandle *****************
;; Defined at:
;;		line 1436 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_LedSetSt
;;		_SetStandbyState
;; This function is called by:
;;		_StatusFun_Handle
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	line	1436
global __ptext6
__ptext6:	;psect for function _WashHandle
psect	text6
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	1436
	global	__size_of_WashHandle
	__size_of_WashHandle	equ	__end_of_WashHandle-_WashHandle
	
_WashHandle:	
;incstack = 0
	opt	stack 3
; Regs used in _WashHandle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1437
	
l11008:	
;main.c: 1437: if((LedMod[1].LedState==0)&&(StandByStatus==WashState)){
	bsf	status, 6	;RP1=1, select bank2
	movf	(0+(_LedMod)^0100h+05h),w
	btfss	status,2
	goto	u10371
	goto	u10370
u10371:
	goto	l11014
u10370:
	
l11010:	
	bcf	status, 6	;RP1=0, select bank0
		decf	((_StandByStatus)),w
	btfss	status,2
	goto	u10381
	goto	u10380
u10381:
	goto	l11014
u10380:
	line	1438
	
l11012:	
;main.c: 1438: LedSetSt(1, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1440
	
l11014:	
;main.c: 1439: }
;main.c: 1440: if(Timer_WashRun_1s>=WashRunTime){
	bcf	status, 6	;RP1=0, select bank0
	movf	(_WashRunTime),w
	movwf	(??_WashHandle+0)+0
	clrf	(??_WashHandle+0)+0+1
	movf	1+(??_WashHandle+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_WashRun_1s+1)^080h,w
	skipz
	goto	u10395
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_WashHandle+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_WashRun_1s)^080h,w
u10395:
	skipc
	goto	u10391
	goto	u10390
u10391:
	goto	l1267
u10390:
	line	1446
	
l11016:	
;main.c: 1446: Time_made_1s=0;
	clrf	(_Time_made_1s)^080h
	clrf	(_Time_made_1s+1)^080h
	line	1449
	
l11018:	
;main.c: 1449: _BITS1.Bits.bit_0=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(__BITS1),0
	line	1450
	
l11020:	
;main.c: 1450: LedSetSt(1, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1451
	
l11022:	
;main.c: 1451: SetStandbyState(NornalStopState,&WashRunTime, 0);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	clrf	(SetStandbyState@Da)
	movlw	low(0)
	fcall	_SetStandbyState
	line	1453
	
l1267:	
	return
	opt stack 0
GLOBAL	__end_of_WashHandle
	__end_of_WashHandle:
	signat	_WashHandle,89
	global	_GetMode_Handle

;; *************** function _GetMode_Handle *****************
;; Defined at:
;;		line 1340 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_ShiftMode_Handle
;;		_WrterEEP
;; This function is called by:
;;		_Run_Mode
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	line	1340
global __ptext7
__ptext7:	;psect for function _GetMode_Handle
psect	text7
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	1340
	global	__size_of_GetMode_Handle
	__size_of_GetMode_Handle	equ	__end_of_GetMode_Handle-_GetMode_Handle
	
_GetMode_Handle:	
;incstack = 0
	opt	stack 4
; Regs used in _GetMode_Handle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1344
	
l11166:	
;main.c: 1344: if(KeyPacket_y[0].KeyState==NotPress)
	movf	((_KeyPacket_y)),w
	btfss	status,2
	goto	u10611
	goto	u10610
u10611:
	goto	l11172
u10610:
	line	1346
	
l11168:	
;main.c: 1345: {
;main.c: 1346: ShiftMode_Handle(2);
	movlw	low(02h)
	fcall	_ShiftMode_Handle
	line	1347
	
l11170:	
;main.c: 1347: Timer_Standby_1H=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_Timer_Standby_1H)^080h
	clrf	(_Timer_Standby_1H+1)^080h
	line	1351
	
l11172:	
;main.c: 1348: }
;main.c: 1351: if(Time_GetWater_1s>=60){
	movlw	low(03Ch)
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_Time_GetWater_1s),w
	skipc
	goto	u10621
	goto	u10620
u10621:
	goto	l11190
u10620:
	line	1352
	
l11174:	
;main.c: 1352: Time_GetWater_1s=0;
	clrf	(_Time_GetWater_1s)
	line	1353
	
l11176:	
;main.c: 1353: GetWater_ML+=21;
	movlw	015h
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_GetWater_ML)^080h,f
	skipnc
	incf	(_GetWater_ML+1)^080h,f
	line	1370
	
l11178:	
;main.c: 1370: if(GetWater_ML>=(21*10)){
	movlw	0
	subwf	(_GetWater_ML+1)^080h,w
	movlw	0D2h
	skipnz
	subwf	(_GetWater_ML)^080h,w
	skipc
	goto	u10631
	goto	u10630
u10631:
	goto	l11190
u10630:
	line	1371
	
l11180:	
;main.c: 1371: GetWater_ML=0;
	clrf	(_GetWater_ML)^080h
	clrf	(_GetWater_ML+1)^080h
	line	1372
	
l11182:	
;main.c: 1372: if(FilterROGetWater<0xfff0)
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_FilterROGetWater+1),w
	movlw	0F0h
	skipnz
	subwf	(_FilterROGetWater),w
	skipnc
	goto	u10641
	goto	u10640
u10641:
	goto	l1251
u10640:
	line	1373
	
l11184:	
;main.c: 1373: FilterROGetWater+=21;
	movlw	015h
	addwf	(_FilterROGetWater),f
	skipnc
	incf	(_FilterROGetWater+1),f
	
l1251:	
	line	1374
;main.c: 1374: if(FilterPCFGetWater<0xfff0)
	movlw	0FFh
	subwf	(_FilterPCFGetWater+1),w
	movlw	0F0h
	skipnz
	subwf	(_FilterPCFGetWater),w
	skipnc
	goto	u10651
	goto	u10650
u10651:
	goto	l11188
u10650:
	line	1375
	
l11186:	
;main.c: 1375: FilterPCFGetWater+=21;
	movlw	015h
	addwf	(_FilterPCFGetWater),f
	skipnc
	incf	(_FilterPCFGetWater+1),f
	line	1376
	
l11188:	
;main.c: 1376: WrterEEP();
	fcall	_WrterEEP
	line	1386
	
l11190:	
;main.c: 1377: }
;main.c: 1379: }
;main.c: 1385: if((FilterROGetWater>=(21*2))
;main.c: 1386: &&(FilterPCFGetWater>=(21*2))){
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_FilterROGetWater+1),w
	movlw	02Ah
	skipnz
	subwf	(_FilterROGetWater),w
	skipc
	goto	u10661
	goto	u10660
u10661:
	goto	l11196
u10660:
	
l11192:	
	movlw	0
	subwf	(_FilterPCFGetWater+1),w
	movlw	02Ah
	skipnz
	subwf	(_FilterPCFGetWater),w
	skipc
	goto	u10671
	goto	u10670
u10671:
	goto	l11196
u10670:
	line	1388
	
l11194:	
;main.c: 1388: _BITS1.Bits.bit_7=1;
	bsf	(__BITS1),7
	line	1390
	
l11196:	
;main.c: 1389: }
;main.c: 1390: if(Read_Word_Buff[11]!=0)
	bsf	status, 5	;RP0=1, select bank1
	movf	(0+(_Read_Word_Buff)^080h+0Bh),w
	btfsc	status,2
	goto	u10681
	goto	u10680
u10681:
	goto	l1255
u10680:
	line	1391
	
l11198:	
;main.c: 1391: Read_Word_Buff[11]=2;
	movlw	low(02h)
	movwf	0+(_Read_Word_Buff)^080h+0Bh
	line	1393
	
l1255:	
	return
	opt stack 0
GLOBAL	__end_of_GetMode_Handle
	__end_of_GetMode_Handle:
	signat	_GetMode_Handle,89
	global	_FactoryMode_Handle

;; *************** function _FactoryMode_Handle *****************
;; Defined at:
;;		line 1470 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  Step            1    0[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       1       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       1       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    8
;; This function calls:
;;		_AllLedFlash
;;		_BuzzerSet
;;		_LedSetSt
;;		_Time_Count_Func
;; This function is called by:
;;		_Run_Mode
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	1470
global __ptext8
__ptext8:	;psect for function _FactoryMode_Handle
psect	text8
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	1470
	global	__size_of_FactoryMode_Handle
	__size_of_FactoryMode_Handle	equ	__end_of_FactoryMode_Handle-_FactoryMode_Handle
	
_FactoryMode_Handle:	
;incstack = 0
	opt	stack 2
; Regs used in _FactoryMode_Handle: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1471
	
l11200:	
;main.c: 1471: U8_T Step=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(FactoryMode_Handle@Step)^080h
	line	1472
;main.c: 1472: Timer_Power_100ms=0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_Timer_Power_100ms)
	line	1473
	
l11202:	
;main.c: 1473: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1474
;main.c: 1474: while(1){
	
l1278:	
	line	1475
# 1475 "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text8
	line	1476
	
l11204:	
;main.c: 1476: _BITS.Bits.bit_5=0x01;
	bsf	(__BITS),5
	line	1477
;main.c: 1477: switch(Step){
	goto	l11276
	line	1492
	
l11206:	
;main.c: 1492: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	line	1493
;main.c: 1493: LedSetSt(1, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(01h)
	fcall	_LedSetSt
	line	1496
	
l11208:	
;main.c: 1496: if(Timer_Power_100ms>=10)
	movlw	low(0Ah)
	subwf	(_Timer_Power_100ms),w
	skipc
	goto	u10691
	goto	u10690
u10691:
	goto	l11278
u10690:
	line	1499
	
l11210:	
;main.c: 1497: {
;main.c: 1499: Step=1;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(FactoryMode_Handle@Step)^080h
	incf	(FactoryMode_Handle@Step)^080h,f
	goto	l11278
	line	1502
;main.c: 1502: case 1:
	
l1283:	
	line	1503
;main.c: 1503: RC2=1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(58/8),(58)&7	;volatile
	line	1504
;main.c: 1504: {RA2=1;_BITS2.Bits.bit_1=1;};
	bsf	(42/8),(42)&7	;volatile
	bsf	(__BITS2),1
	line	1505
;main.c: 1505: RC3=1;
	bsf	(59/8),(59)&7	;volatile
	line	1506
;main.c: 1506: RA1=1;
	bsf	(41/8),(41)&7	;volatile
	line	1507
	
l11212:	
;main.c: 1507: if(KeyPacket_y[1].KeyState==ShortRelease)
		movlw	6
	xorwf	(0+(_KeyPacket_y)+03h),w
	btfss	status,2
	goto	u10701
	goto	u10700
u10701:
	goto	l11278
u10700:
	line	1509
	
l11214:	
;main.c: 1508: {
;main.c: 1509: KeyPacket_y[1].KeyState=NotPress;
	clrf	0+(_KeyPacket_y)+03h
	line	1510
	
l11216:	
;main.c: 1510: RC2=0;
	bcf	(58/8),(58)&7	;volatile
	line	1511
	
l11218:	
;main.c: 1511: {RA2=0;_BITS2.Bits.bit_1=0;};
	bcf	(42/8),(42)&7	;volatile
	
l11220:	
	bcf	(__BITS2),1
	line	1512
	
l11222:	
;main.c: 1512: RC3=0;
	bcf	(59/8),(59)&7	;volatile
	line	1513
	
l11224:	
;main.c: 1513: RA1=0;
	bcf	(41/8),(41)&7	;volatile
	line	1514
	
l11226:	
;main.c: 1514: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1515
	
l11228:	
;main.c: 1515: Step=2;
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(FactoryMode_Handle@Step)^080h
	line	1516
	
l11230:	
;main.c: 1516: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	goto	l11278
	line	1520
	
l11232:	
;main.c: 1520: if(KeyPacket_y[0].KeyState==NotPress)
	bcf	status, 5	;RP0=0, select bank0
	movf	((_KeyPacket_y)),w
	btfss	status,2
	goto	u10711
	goto	u10710
u10711:
	goto	l11236
u10710:
	line	1522
	
l11234:	
;main.c: 1521: {
;main.c: 1522: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1523
;main.c: 1523: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1524
;main.c: 1524: LedSetSt(0, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(0)
	fcall	_LedSetSt
	line	1525
;main.c: 1525: }
	goto	l11238
	line	1528
	
l11236:	
;main.c: 1526: else
;main.c: 1527: {
;main.c: 1528: LedSetSt(4, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(04h)
	fcall	_LedSetSt
	line	1529
;main.c: 1529: LedSetSt(2, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(02h)
	fcall	_LedSetSt
	line	1530
;main.c: 1530: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	line	1532
	
l11238:	
;main.c: 1531: }
;main.c: 1532: if(KeyPacket_y[2].KeyState==ShortRelease)
		movlw	6
	xorwf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u10721
	goto	u10720
u10721:
	goto	l11278
u10720:
	line	1534
	
l11240:	
;main.c: 1533: {
;main.c: 1534: KeyPacket_y[2].KeyState=NotPress;
	clrf	0+(_KeyPacket_y)+06h
	line	1535
	
l11242:	
;main.c: 1535: Step=3;
	movlw	low(03h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(FactoryMode_Handle@Step)^080h
	line	1536
	
l11244:	
;main.c: 1536: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1537
	
l11246:	
;main.c: 1537: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	goto	l11278
	line	1542
	
l11248:	
;main.c: 1542: if(PureTDSTyp.TdsData>10&&PureTDSTyp.TdsData<50){
	movlw	0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	1+(_PureTDSTyp)^0100h+0Fh,w
	movlw	0Bh
	skipnz
	subwf	0+(_PureTDSTyp)^0100h+0Fh,w
	skipc
	goto	u10731
	goto	u10730
u10731:
	goto	l11254
u10730:
	
l11250:	
	movlw	0
	subwf	1+(_PureTDSTyp)^0100h+0Fh,w
	movlw	032h
	skipnz
	subwf	0+(_PureTDSTyp)^0100h+0Fh,w
	skipnc
	goto	u10741
	goto	u10740
u10741:
	goto	l11254
u10740:
	line	1543
	
l11252:	
;main.c: 1543: LedSetSt(5, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(05h)
	fcall	_LedSetSt
	line	1544
;main.c: 1544: LedSetSt(3, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(03h)
	fcall	_LedSetSt
	line	1545
;main.c: 1545: LedSetSt(1, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(01h)
	fcall	_LedSetSt
	line	1546
;main.c: 1546: }
	goto	l11256
	line	1549
	
l11254:	
;main.c: 1547: else
;main.c: 1548: {
;main.c: 1549: LedSetSt(4, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(04h)
	fcall	_LedSetSt
	line	1550
;main.c: 1550: LedSetSt(2, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(02h)
	fcall	_LedSetSt
	line	1551
;main.c: 1551: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	line	1553
	
l11256:	
;main.c: 1552: }
;main.c: 1553: if(KeyPacket_y[2].KeyState==ShortPressDown)
		decf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u10751
	goto	u10750
u10751:
	goto	l11278
u10750:
	line	1555
	
l11258:	
;main.c: 1554: {
;main.c: 1555: KeyPacket_y[2].KeyState=NotPress;
	clrf	0+(_KeyPacket_y)+06h
	line	1556
	
l11260:	
;main.c: 1556: Step=4;
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(FactoryMode_Handle@Step)^080h
	line	1557
	
l11262:	
;main.c: 1557: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1558
	
l11264:	
;main.c: 1558: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	goto	l11278
	line	1562
	
l11266:	
;main.c: 1562: if(Temp_Ntc>15&&PureTDSTyp.TdsData<45){
	movlw	low(010h)
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_Temp_Ntc),w
	skipc
	goto	u10761
	goto	u10760
u10761:
	goto	l11272
u10760:
	
l11268:	
	movlw	0
	bsf	status, 6	;RP1=1, select bank2
	subwf	1+(_PureTDSTyp)^0100h+0Fh,w
	movlw	02Dh
	skipnz
	subwf	0+(_PureTDSTyp)^0100h+0Fh,w
	skipnc
	goto	u10771
	goto	u10770
u10771:
	goto	l11272
u10770:
	line	1564
	
l11270:	
;main.c: 1564: LedSetSt(1, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(01h)
	fcall	_LedSetSt
	line	1565
;main.c: 1565: }
	goto	l11278
	line	1568
	
l11272:	
;main.c: 1566: else
;main.c: 1567: {
;main.c: 1568: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	goto	l11278
	line	1477
	
l11276:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(FactoryMode_Handle@Step)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 5, Range of values is 0 to 4
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           16     9 (average)
; direct_byte           23     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l11206
	xorlw	1^0	; case 1
	skipnz
	goto	l1283
	xorlw	2^1	; case 2
	skipnz
	goto	l11232
	xorlw	3^2	; case 3
	skipnz
	goto	l11248
	xorlw	4^3	; case 4
	skipnz
	goto	l11266
	goto	l11278
	opt asmopt_pop

	line	1572
	
l11278:	
;main.c: 1572: Time_Count_Func();
	fcall	_Time_Count_Func
	goto	l1278
	return
	opt stack 0
	line	1576
GLOBAL	__end_of_FactoryMode_Handle
	__end_of_FactoryMode_Handle:
	signat	_FactoryMode_Handle,89
	global	_Time_Count_Func

;; *************** function _Time_Count_Func *****************
;; Defined at:
;;		line 607 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       3       0       0
;;      Totals:         0       3       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    7
;; This function calls:
;;		_AD_Testing
;;		_BuzzerSet
;;		_CheckKey
;;		_ErrorHandle
;;		_FilterKeyInputRest
;;		_FilterLifeFunc
;;		_GetDelayFilterFlag
;;		_Led_Handle
;;		_Page_ProgramData
;;		_SetStandbyState
;;		_TDS_Handle
;;		_TaskAlarmHandle
;;		_Tx_Display
;;		___CMS_CheckTouchKey
;; This function is called by:
;;		_FactoryMode_Handle
;;		_main
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	607
global __ptext9
__ptext9:	;psect for function _Time_Count_Func
psect	text9
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	607
	global	__size_of_Time_Count_Func
	__size_of_Time_Count_Func	equ	__end_of_Time_Count_Func-_Time_Count_Func
	
_Time_Count_Func:	
;incstack = 0
	opt	stack 4
; Regs used in _Time_Count_Func: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	609
	
l11024:	
;main.c: 609: if(_BITS2.Bits.bit_0){
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(__BITS2),0
	goto	u10401
	goto	u10400
u10401:
	goto	l1114
u10400:
	line	610
	
l11026:	
;main.c: 610: _BITS2.Bits.bit_0=0;
	bcf	(__BITS2),0
	line	612
	
l11028:	
;main.c: 612: AD_Testing(1,15,0);
	movlw	low(0Fh)
	movwf	(AD_Testing@ad_ch)
	clrf	(AD_Testing@ad_lr)
	movlw	low(01h)
	fcall	_AD_Testing
	line	613
;main.c: 613: __CMS_CheckTouchKey();
	fcall	___CMS_CheckTouchKey
	line	614
	
l11030:	
;main.c: 614: CheckKey();
	fcall	_CheckKey
	line	616
	
l11032:	
;main.c: 616: if(Mode!=5)
		movlw	5
	xorwf	((_Mode)),w
	btfsc	status,2
	goto	u10411
	goto	u10410
u10411:
	goto	l11036
u10410:
	line	617
	
l11034:	
;main.c: 617: FilterLifeFunc();
	fcall	_FilterLifeFunc
	line	618
	
l11036:	
;main.c: 618: TaskAlarmHandle();
	fcall	_TaskAlarmHandle
	line	619
	
l11038:	
;main.c: 619: Led_Handle();
	fcall	_Led_Handle
	line	623
	
l11040:	
;main.c: 623: FilterKeyInputRest();
	fcall	_FilterKeyInputRest
	line	624
	
l11042:	
;main.c: 624: Time_100ms++;
	bcf	status, 5	;RP0=0, select bank0
	incf	(_Time_100ms),f
	line	625
	
l11044:	
;main.c: 625: if(Time_100ms>=10){
	movlw	low(0Ah)
	subwf	(_Time_100ms),w
	skipc
	goto	u10421
	goto	u10420
u10421:
	goto	l1114
u10420:
	line	626
	
l11046:	
;main.c: 626: Time_100ms=0;
	clrf	(_Time_100ms)
	line	627
	
l11048:	
;main.c: 627: Timer_Power_100ms++;
	incf	(_Timer_Power_100ms),f
	line	629
	
l11050:	
;main.c: 629: Time_1s++;
	incf	(_Time_1s),f
	line	630
	
l11052:	
;main.c: 630: if(Time_1s>=10){
	movlw	low(0Ah)
	subwf	(_Time_1s),w
	skipc
	goto	u10431
	goto	u10430
u10431:
	goto	l1114
u10430:
	line	631
	
l11054:	
;main.c: 631: Time_1s=0;
	clrf	(_Time_1s)
	line	632
	
l11056:	
;main.c: 632: if(Mode!=0){
	movf	((_Mode)),w
	btfsc	status,2
	goto	u10441
	goto	u10440
u10441:
	goto	l11060
u10440:
	line	633
	
l11058:	
;main.c: 633: Tx_Display();
	fcall	_Tx_Display
	line	635
	
l11060:	
;main.c: 634: }
;main.c: 635: if(Mode!=0)
	movf	((_Mode)),w
	btfsc	status,2
	goto	u10451
	goto	u10450
u10451:
	goto	l11064
u10450:
	line	636
	
l11062:	
;main.c: 636: ErrorHandle();
	fcall	_ErrorHandle
	line	638
	
l11064:	
;main.c: 638: if(Time_Power_1s<0xf0)
	movlw	low(0F0h)
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_Time_Power_1s),w
	skipnc
	goto	u10461
	goto	u10460
u10461:
	goto	l11068
u10460:
	line	639
	
l11066:	
;main.c: 639: Time_Power_1s++;
	incf	(_Time_Power_1s),f
	line	640
	
l11068:	
;main.c: 640: if(_BITS.Bits.bit_4==1){
	btfss	(__BITS),4
	goto	u10471
	goto	u10470
u10471:
	goto	l11074
u10470:
	line	641
	
l11070:	
;main.c: 641: _BITS.Bits.bit_4=0;
	bcf	(__BITS),4
	line	642
	
l11072:	
;main.c: 642: Page_ProgramData();
	fcall	_Page_ProgramData
	line	644
	
l11074:	
;main.c: 643: }
;main.c: 644: if(FilterRst_1s<0xfff0)
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_FilterRst_1s+1)^080h,w
	movlw	0F0h
	skipnz
	subwf	(_FilterRst_1s)^080h,w
	skipnc
	goto	u10481
	goto	u10480
u10481:
	goto	l11078
u10480:
	line	645
	
l11076:	
;main.c: 645: FilterRst_1s++;
	incf	(_FilterRst_1s)^080h,f
	skipnz
	incf	(_FilterRst_1s+1)^080h,f
	line	648
	
l11078:	
;main.c: 648: if(_BITS2.Bits.bit_1==1){
	bcf	status, 5	;RP0=0, select bank0
	btfss	(__BITS2),1
	goto	u10491
	goto	u10490
u10491:
	goto	l11082
u10490:
	line	649
	
l11080:	
;main.c: 649: Timer_LongGetWater_1s++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_Timer_LongGetWater_1s)^080h,f
	skipnz
	incf	(_Timer_LongGetWater_1s+1)^080h,f
	line	650
;main.c: 650: }
	goto	l11084
	line	653
	
l11082:	
;main.c: 651: else
;main.c: 652: {
;main.c: 653: Timer_LongGetWater_1s=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_Timer_LongGetWater_1s)^080h
	clrf	(_Timer_LongGetWater_1s+1)^080h
	line	656
	
l11084:	
;main.c: 654: }
;main.c: 656: if(_BITS.Bits.bit_5==0x01){
	btfss	(__BITS),5
	goto	u10501
	goto	u10500
u10501:
	goto	l11118
u10500:
	line	657
	
l11086:	
;main.c: 657: _BITS1.Bits.bit_4=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(__BITS1),4
	line	658
;main.c: 658: _BITS1.Bits.bit_6=0;
	bcf	(__BITS1),6
	line	659
;main.c: 659: _BITS2.Bits.bit_2=0;
	bcf	(__BITS2),2
	line	660
	
l11088:	
;main.c: 660: Time_GetWater_1s++;
	incf	(_Time_GetWater_1s),f
	line	661
	
l11090:	
;main.c: 661: Timer_Standby_1s=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_Timer_Standby_1s)^080h
	clrf	(_Timer_Standby_1s+1)^080h
	line	662
	
l11092:	
;main.c: 662: Timer_BackT_1H=0;
	clrf	(_Timer_BackT_1H)^080h
	clrf	(_Timer_BackT_1H+1)^080h
	line	664
	
l11094:	
;main.c: 664: if(FilterFastCheck==1){
	bcf	status, 5	;RP0=0, select bank0
		decf	((_FilterFastCheck)),w
	btfss	status,2
	goto	u10511
	goto	u10510
u10511:
	goto	l11098
u10510:
	line	665
	
l11096:	
;main.c: 665: FilterROGetWater+=21;
	movlw	015h
	addwf	(_FilterROGetWater),f
	skipnc
	incf	(_FilterROGetWater+1),f
	line	666
;main.c: 666: FilterPCFGetWater+=21;
	movlw	015h
	addwf	(_FilterPCFGetWater),f
	skipnc
	incf	(_FilterPCFGetWater+1),f
	line	669
	
l11098:	
;main.c: 667: }
;main.c: 669: Time_made_1s++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_Time_made_1s)^080h,f
	skipnz
	incf	(_Time_made_1s+1)^080h,f
	line	670
	
l11100:	
;main.c: 670: RA0=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(40/8),(40)&7	;volatile
	line	677
;main.c: 677: if(++Timer_TdsMake_1s>=60){
	movlw	low(03Ch)
	incf	(_Timer_TdsMake_1s),f
	subwf	((_Timer_TdsMake_1s)),w
	skipc
	goto	u10521
	goto	u10520
u10521:
	goto	l11104
u10520:
	line	678
	
l11102:	
;main.c: 678: _BITS.Bits.bit_6=1;
	bsf	(__BITS),6
	line	681
	
l11104:	
;main.c: 679: }
;main.c: 681: TDS_Handle(&PureTDSTyp,1);
	clrf	(TDS_Handle@Type)
	incf	(TDS_Handle@Type),f
	movlw	(low(_PureTDSTyp|((0x1)<<8)))&0ffh
	fcall	_TDS_Handle
	line	686
	
l11106:	
;main.c: 686: if((FilterROState==3)||(FilterPCFState==3)){
		movlw	3
	xorwf	((_FilterROState)),w
	btfsc	status,2
	goto	u10531
	goto	u10530
u10531:
	goto	l11110
u10530:
	
l11108:	
		movlw	3
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u10541
	goto	u10540
u10541:
	goto	l1108
u10540:
	line	687
	
l11110:	
;main.c: 687: FilterBuzzer_1s++;
	incf	(_FilterBuzzer_1s),f
	line	688
	
l11112:	
;main.c: 688: if(FilterBuzzer_1s>=2)
	movlw	low(02h)
	subwf	(_FilterBuzzer_1s),w
	skipc
	goto	u10551
	goto	u10550
u10551:
	goto	l1108
u10550:
	line	690
	
l11114:	
;main.c: 689: {
;main.c: 690: FilterBuzzer_1s=0;
	clrf	(_FilterBuzzer_1s)
	line	691
	
l11116:	
;main.c: 691: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	goto	l1108
	line	697
	
l11118:	
;main.c: 695: else
;main.c: 696: {
;main.c: 697: FilterBuzzer_1s=0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_FilterBuzzer_1s)
	line	699
	
l11120:	
;main.c: 699: if((Time_made_1s>=300)&&(Mode!=3)){
	movlw	01h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Time_made_1s+1)^080h,w
	movlw	02Ch
	skipnz
	subwf	(_Time_made_1s)^080h,w
	skipc
	goto	u10561
	goto	u10560
u10561:
	goto	l11136
u10560:
	
l11122:	
		movlw	3
	xorwf	((_Mode)),w
	btfsc	status,2
	goto	u10571
	goto	u10570
u10571:
	goto	l11136
u10570:
	line	700
	
l11124:	
;main.c: 700: Time_made_1s=0;
	clrf	(_Time_made_1s)^080h
	clrf	(_Time_made_1s+1)^080h
	line	701
	
l11126:	
;main.c: 701: if(StandByStatus!=WashState)
	bcf	status, 5	;RP0=0, select bank0
		decf	((_StandByStatus)),w
	btfsc	status,2
	goto	u10581
	goto	u10580
u10581:
	goto	l11130
u10580:
	line	703
	
l11128:	
;main.c: 702: {
;main.c: 703: SetStandbyState(WashState,&WashRunTime, 6);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(06h)
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	line	704
;main.c: 704: }
	goto	l11136
	line	707
	
l11130:	
;main.c: 705: else
;main.c: 706: {
;main.c: 707: if(StandByStatus!=BackState){
		movlw	3
	xorwf	((_StandByStatus)),w
	btfsc	status,2
	goto	u10591
	goto	u10590
u10591:
	goto	l11136
u10590:
	line	708
	
l11132:	
;main.c: 708: if(WashRunTime-Timer_WashRun_1s<6){
	movf	(_WashRunTime),w
	movwf	(??_Time_Count_Func+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_Timer_WashRun_1s)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(??_Time_Count_Func+0)+0,w
	movwf	(??_Time_Count_Func+1)+0
	bsf	status, 5	;RP0=1, select bank1
	comf	(_Timer_WashRun_1s+1)^080h,w
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_Time_Count_Func+1)+0)+1
	movlw	0
	subwf	1+(??_Time_Count_Func+1)+0,w
	movlw	06h
	skipnz
	subwf	0+(??_Time_Count_Func+1)+0,w
	skipnc
	goto	u10601
	goto	u10600
u10601:
	goto	l1111
u10600:
	line	709
	
l11134:	
;main.c: 709: SetStandbyState(WashState,&WashRunTime, 6);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(06h)
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	goto	l11136
	line	712
	
l1111:	
	line	715
	
l11136:	
;main.c: 710: }
;main.c: 711: }
;main.c: 712: }
;main.c: 713: }
;main.c: 715: RA0=1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(40/8),(40)&7	;volatile
	line	716
	
l11138:	
;main.c: 716: _BITS.Bits.bit_6=0;
	bcf	(__BITS),6
	line	717
	
l11140:	
;main.c: 717: TdsCk60sFlag=0;
	clrf	(_TdsCk60sFlag)
	line	718
	
l11142:	
;main.c: 718: Timer_TdsMake_1s=0;
	clrf	(_Timer_TdsMake_1s)
	line	719
	
l11144:	
;main.c: 719: Timer_WashRun_1s++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_Timer_WashRun_1s)^080h,f
	skipnz
	incf	(_Timer_WashRun_1s+1)^080h,f
	line	721
	
l11146:	
;main.c: 721: Timer_Standby_1s++;
	incf	(_Timer_Standby_1s)^080h,f
	skipnz
	incf	(_Timer_Standby_1s+1)^080h,f
	line	723
	
l1108:	
	line	729
;main.c: 723: }
;main.c: 729: GetDelayFilterFlag(&FilterPCF_time);
	movlw	(low(_FilterPCF_time|((0x0)<<8)))&0ffh
	fcall	_GetDelayFilterFlag
	line	730
;main.c: 730: GetDelayFilterFlag(&FilterRO_time);
	movlw	(low(_FilterRO_time|((0x0)<<8)))&0ffh
	fcall	_GetDelayFilterFlag
	line	737
	
l1114:	
	return
	opt stack 0
GLOBAL	__end_of_Time_Count_Func
	__end_of_Time_Count_Func:
	signat	_Time_Count_Func,89
	global	___CMS_CheckTouchKey

;; *************** function ___CMS_CheckTouchKey *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1074            1    0        unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		___CMS_CheckKeyOldValue
;;		___CMS_CheckOnceResult
;;		___CMS_CheckValidTime
;;		___CMS_CurAdjust
;;		___CMS_KeyDatIIR
;;		___CMS_KeyModeSet
;;		___CMS_KeyStart
;;		___CMS_KeyStopClear
;;		___CMS_Key_UNNOL_Check
;;		___CMS_NewRAMClr
;;		___CMS_Noise_check
;;		___GET_32M_FREDAT
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=1
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
global __ptext10
__ptext10:	;psect for function ___CMS_CheckTouchKey
psect	text10
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CheckTouchKey
	__size_of___CMS_CheckTouchKey	equ	__end_of___CMS_CheckTouchKey-___CMS_CheckTouchKey
	
___CMS_CheckTouchKey:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CheckTouchKey: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	
l10538:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text10
	btfsc	(_924/8),(_924)&7	;volatile
	goto	u9611
	goto	u9610
u9611:
	goto	l10546
u9610:
	
l10540:	
	bsf	(_924/8),(_924)&7	;volatile
	
l10542:	
	fcall	___CMS_NewRAMClr
	
l10544:	
	fcall	___GET_32M_FREDAT
	
l10546:	
	btfsc	(_926/8),(_926)&7	;volatile
	goto	u9621
	goto	u9620
u9621:
	goto	l10550
u9620:
	
l10548:	
	fcall	___CMS_CurAdjust
	goto	l10602
	
l10550:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_918)),w	;volatile
	btfsc	status,2
	goto	u9631
	goto	u9630
u9631:
	goto	l10594
u9630:
	
l10552:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_CheckTouchKey@F1073)^080h
	
l10554:	
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	xorwf	((_918)),w	;volatile
	btfsc	status,2
	goto	u9641
	goto	u9640
u9641:
	goto	l10560
u9640:
	
l10556:	
	fcall	___CMS_KeyDatIIR
	
l10558:	
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_918)	;volatile
	goto	l10602
	
l10560:	
	fcall	___CMS_Noise_check
	
l10562:	
	fcall	___CMS_CheckKeyOldValue
	
l10564:	
	fcall	___CMS_CheckOnceResult
	
l10566:	
	movlw	low(08h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_920),f	;volatile
	subwf	((_920)),w	;volatile
	skipc
	goto	u9651
	goto	u9650
u9651:
	goto	l10570
u9650:
	
l10568:	
	clrf	(_920)	;volatile
	
l10570:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u9661
	goto	u9660
u9661:
	goto	l10574
u9660:
	
l10572:	
	movf	(_920),w
	addlw	low(((_sc_FreScanTable)|8000h))
	movwf	fsr0
	movlw	high(((_sc_FreScanTable)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(_921)	;volatile
	goto	l10576
	
l10574:	
	movf	(_920),w
	addlw	low(((_sc_FreScanTable1)|8000h))
	movwf	fsr0
	movlw	high(((_sc_FreScanTable1)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(_921)	;volatile
	
l10576:	
	btfsc	(_gf_kerr/8),(_gf_kerr)&7	;volatile
	goto	u9671
	goto	u9670
u9671:
	goto	l10580
u9670:
	
l10578:	
	movlw	low(03h)
	subwf	(_917),w	;volatile
	skipc
	goto	u9681
	goto	u9680
u9681:
	goto	l10584
u9680:
	
l10580:	
	fcall	___CMS_KeyStopClear
	
l10582:	
	bcf	(_gf_kerr/8),(_gf_kerr)&7	;volatile
	
l10584:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_917)	;volatile
	
l10586:	
	fcall	___CMS_Key_UNNOL_Check
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_918)	;volatile
	
l10588:	
	btfss	(_926/8),(_926)&7	;volatile
	goto	u9691
	goto	u9690
u9691:
	goto	l3692
u9690:
	
l10590:	
	fcall	___CMS_KeyModeSet
	
l10592:	
	fcall	___CMS_KeyStart
	goto	l10602
	
l10594:	
	movlw	low(0FAh)
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_CheckTouchKey@F1073)^080h,f
	subwf	((___CMS_CheckTouchKey@F1073)^080h),w
	skipc
	goto	u9701
	goto	u9700
u9701:
	goto	l10602
u9700:
	
l10596:	
	clrf	(___CMS_CheckTouchKey@F1073)^080h
	clrf	(_919)	;volatile
	goto	l10590
	
l3692:	
	
l10602:	
	fcall	___CMS_CheckValidTime
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text10
	
l3694:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CheckTouchKey
	__end_of___CMS_CheckTouchKey:
	signat	___CMS_CheckTouchKey,89
	global	___GET_32M_FREDAT

;; *************** function ___GET_32M_FREDAT *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=1
global __ptext11
__ptext11:	;psect for function ___GET_32M_FREDAT
psect	text11
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___GET_32M_FREDAT
	__size_of___GET_32M_FREDAT	equ	__end_of___GET_32M_FREDAT-___GET_32M_FREDAT
	
___GET_32M_FREDAT:	
;incstack = 0
	opt	stack 6
; Regs used in ___GET_32M_FREDAT: [wreg+status,2+status,0]
	
l10266:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text11
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	bsf	(404)^0180h+(0/8),(0)&7	;volatile
	
l10268:	
	movf	(404)^0180h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_916)	;volatile
	
l10270:	
	movlw	low(070h)
	andwf	(_916),f	;volatile
	
l10272:	
	movlw	low(061h)
	subwf	(_916),w	;volatile
	skipc
	goto	u9091
	goto	u9090
u9091:
	goto	l10276
u9090:
	
l10274:	
	movlw	low(060h)
	movwf	(_916)	;volatile
	goto	l3649
	
l10276:	
	movlw	low(010h)
	subwf	(_916),w	;volatile
	skipnc
	goto	u9101
	goto	u9100
u9101:
	goto	l3649
u9100:
	
l10278:	
	movlw	low(010h)
	movwf	(_916)	;volatile
	
l3649:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text11
	
l3651:	
	return
	opt stack 0
GLOBAL	__end_of___GET_32M_FREDAT
	__end_of___GET_32M_FREDAT:
	signat	___GET_32M_FREDAT,89
	global	___CMS_Noise_check

;; *************** function ___CMS_Noise_check *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  973             2    9[BANK0 ] unsigned short 
;;  975             2    7[BANK0 ] unsigned short 
;;  974             2    3[BANK0 ] unsigned short 
;;  970             1   11[BANK0 ] unsigned char 
;;  972             1    6[BANK0 ] unsigned char 
;;  971             1    5[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       9       0       0
;;      Temps:          0       3       0       0
;;      Totals:         0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=1
global __ptext12
__ptext12:	;psect for function ___CMS_Noise_check
psect	text12
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_Noise_check
	__size_of___CMS_Noise_check	equ	__end_of___CMS_Noise_check-___CMS_Noise_check
	
___CMS_Noise_check:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_Noise_check: [wreg-fsr0h+status,2+status,0]
	
l9722:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text12
	
l9724:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_Noise_check@970)
	clrf	(___CMS_Noise_check@971)
	clrf	(___CMS_Noise_check@972)
	clrf	(___CMS_Noise_check@973)
	clrf	(___CMS_Noise_check@973+1)
	
l9726:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9728:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_Noise_check@970),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_Noise_check@974)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_Noise_check@974+1)
	
l9730:	
	movf	((_921)),w	;volatile
	btfsc	status,2
	goto	u8261
	goto	u8260
u8261:
	goto	l9736
u8260:
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
	
l9732:	
	clrc
	rlf	(___CMS_Noise_check@970),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_Noise_check@975)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_Noise_check@975+1)
	
l9734:	
	movlw	04Bh
	addwf	(___CMS_Noise_check@975),f
	skipnc
	incf	(___CMS_Noise_check@975+1),f
	line	1
	goto	l9740
	line	114
	
l9736:	
	clrc
	rlf	(___CMS_Noise_check@970),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_Noise_check@975)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_Noise_check@975+1)
	
l9738:	
	movlw	064h
	addwf	(___CMS_Noise_check@975),f
	skipnc
	incf	(___CMS_Noise_check@975+1),f
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9740:	
	movf	(___CMS_Noise_check@974+1),w
	subwf	(___CMS_Noise_check@975+1),w
	skipz
	goto	u8275
	movf	(___CMS_Noise_check@974),w
	subwf	(___CMS_Noise_check@975),w
u8275:
	skipnc
	goto	u8271
	goto	u8270
u8271:
	goto	l9746
u8270:
	
l9742:	
	incf	(___CMS_Noise_check@970),w
	movwf	(??___CMS_Noise_check+0)+0
	movlw	01h
	movwf	(??___CMS_Noise_check+1)+0
	movlw	0
	movwf	(??___CMS_Noise_check+1)+0+1
	goto	u8284
u8285:
	clrc
	rlf	(??___CMS_Noise_check+1)+0,f
	rlf	(??___CMS_Noise_check+1)+1,f
u8284:
	decfsz	(??___CMS_Noise_check+0)+0,f
	goto	u8285
	
	movf	0+(??___CMS_Noise_check+1)+0,w
	iorwf	(___CMS_Noise_check@973),f
	movf	1+(??___CMS_Noise_check+1)+0,w
	iorwf	(___CMS_Noise_check@973+1),f
	
l9744:	
	incf	(___CMS_Noise_check@971),f
	
l9746:	
	movlw	low(02h)
	incf	(___CMS_Noise_check@970),f
	subwf	((___CMS_Noise_check@970)),w
	skipc
	goto	u8291
	goto	u8290
u8291:
	goto	l9726
u8290:
	
l9748:	
	movlw	low(02h)
	subwf	(___CMS_Noise_check@971),w
	skipc
	goto	u8301
	goto	u8300
u8301:
	goto	l9760
u8300:
	
l9750:	
	clrf	(___CMS_Noise_check@972)
	incf	(___CMS_Noise_check@972),f
	
l9752:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_Noise_check@F967)^080h
	
l9754:	
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank0
	incf	(___CMS_Noise_check@F966),f
	subwf	((___CMS_Noise_check@F966)),w
	skipc
	goto	u8311
	goto	u8310
u8311:
	goto	l9764
u8310:
	
l9756:	
	clrf	(___CMS_Noise_check@F966)
	
l9758:	
	bsf	(_925/8),(_925)&7	;volatile
	goto	l9764
	
l9760:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Noise_check@F967)^080h,f
	subwf	((___CMS_Noise_check@F967)^080h),w
	skipc
	goto	u8321
	goto	u8320
u8321:
	goto	l9764
u8320:
	
l9762:	
	clrf	(___CMS_Noise_check@F967)^080h
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___CMS_Noise_check@F966)
	
l9764:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___CMS_Noise_check@973),w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(___CMS_Noise_check@F969)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??___CMS_Noise_check+0)+0
	movf	(___CMS_Noise_check@973+1),w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(___CMS_Noise_check@F969+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??___CMS_Noise_check+0)+0
	movf	((??___CMS_Noise_check+0)+0),w
iorwf	((??___CMS_Noise_check+0)+1),w
	btfsc	status,2
	goto	u8331
	goto	u8330
u8331:
	goto	l9776
u8330:
	
l9766:	
	clrf	(___CMS_Noise_check@972)
	incf	(___CMS_Noise_check@972),f
	
l9768:	
	clrf	(___CMS_Noise_check@F965)
	
l9770:	
	movlw	low(02h)
	incf	(___CMS_Noise_check@F964),f
	subwf	((___CMS_Noise_check@F964)),w
	skipc
	goto	u8341
	goto	u8340
u8341:
	goto	l9780
u8340:
	
l9772:	
	clrf	(___CMS_Noise_check@F964)
	
l9774:	
	bsf	(_925/8),(_925)&7	;volatile
	goto	l9780
	
l9776:	
	movlw	low(02h)
	incf	(___CMS_Noise_check@F965),f
	subwf	((___CMS_Noise_check@F965)),w
	skipc
	goto	u8351
	goto	u8350
u8351:
	goto	l9780
u8350:
	
l9778:	
	clrf	(___CMS_Noise_check@F965)
	clrf	(___CMS_Noise_check@F964)
	
l9780:	
	movf	(___CMS_Noise_check@973+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___CMS_Noise_check@F969+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___CMS_Noise_check@973),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___CMS_Noise_check@F969)^080h
	
l9782:	
	btfss	(_925/8),(_925)&7	;volatile
	goto	u8361
	goto	u8360
u8361:
	goto	l9802
u8360:
	
l9784:	
	bcf	status, 5	;RP0=0, select bank0
	movf	((___CMS_Noise_check@972)),w
	btfss	status,2
	goto	u8371
	goto	u8370
u8371:
	goto	l9802
u8370:
	
l9786:	
	movf	((_g_KeyFlag)),w	;volatile
	btfss	status,2
	goto	u8381
	goto	u8380
u8381:
	goto	l9796
u8380:
	
l9788:	
	movf	(0+(_g_KeyFlag)+01h),w	;volatile
	btfss	status,2
	goto	u8391
	goto	u8390
u8391:
	goto	l9796
u8390:
	
l9790:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Noise_check@F968)^080h,f
	skipnz
	incf	(___CMS_Noise_check@F968+1)^080h,f
	movlw	0
	subwf	((___CMS_Noise_check@F968+1)^080h),w
	movlw	064h
	skipnz
	subwf	((___CMS_Noise_check@F968)^080h),w
	skipc
	goto	u8401
	goto	u8400
u8401:
	goto	l3481
u8400:
	
l9792:	
	clrf	(___CMS_Noise_check@F968)^080h
	clrf	(___CMS_Noise_check@F968+1)^080h
	
l9794:	
	bcf	(_925/8),(_925)&7	;volatile
	goto	l3481
	
l9796:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Noise_check@F968)^080h,f
	skipnz
	incf	(___CMS_Noise_check@F968+1)^080h,f
	movlw	01h
	subwf	((___CMS_Noise_check@F968+1)^080h),w
	movlw	02Ch
	skipnz
	subwf	((___CMS_Noise_check@F968)^080h),w
	skipc
	goto	u8411
	goto	u8410
u8411:
	goto	l3481
u8410:
	goto	l9792
	
l9802:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_Noise_check@F968)^080h
	clrf	(___CMS_Noise_check@F968+1)^080h
	
l3481:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text12
	
l3482:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_Noise_check
	__end_of___CMS_Noise_check:
	signat	___CMS_Noise_check,89
	global	___CMS_NewRAMClr

;; *************** function ___CMS_NewRAMClr *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1051            1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=1
global __ptext13
__ptext13:	;psect for function ___CMS_NewRAMClr
psect	text13
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_NewRAMClr
	__size_of___CMS_NewRAMClr	equ	__end_of___CMS_NewRAMClr-___CMS_NewRAMClr
	
___CMS_NewRAMClr:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_NewRAMClr: [wreg-fsr0h+status,2+status,0]
	
l10240:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text13
	
l10242:	
	clrf	(___CMS_NewRAMClr@1051)
	
l10248:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10250:	
	movf	(___CMS_NewRAMClr@1051),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l10252:	
	movlw	low(02h)
	movwf	(415)^0180h	;volatile
	movf	(___CMS_NewRAMClr@1051),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l10254:	
	movlw	low(04h)
	movwf	(415)^0180h	;volatile
	
l10256:	
	movf	(___CMS_NewRAMClr@1051),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	movlw	low(08h)
	movwf	(415)^0180h	;volatile
	
l10258:	
	movf	(___CMS_NewRAMClr@1051),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l10260:	
	movlw	low(010h)
	movwf	(415)^0180h	;volatile
	movf	(___CMS_NewRAMClr@1051),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l10262:	
	incf	(___CMS_NewRAMClr@1051),f
	
l10264:	
	movlw	low(050h)
	subwf	(___CMS_NewRAMClr@1051),w
	skipc
	goto	u9081
	goto	u9080
u9081:
	goto	l10248
u9080:
	
l3644:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text13
	
l3645:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_NewRAMClr
	__end_of___CMS_NewRAMClr:
	signat	___CMS_NewRAMClr,89
	global	___CMS_Key_UNNOL_Check

;; *************** function ___CMS_Key_UNNOL_Check *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1017            1    1[BANK0 ] unsigned char 
;;  1018            1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       2       0       0
;;      Temps:          2       0       0       0
;;      Totals:         2       2       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=1
global __ptext14
__ptext14:	;psect for function ___CMS_Key_UNNOL_Check
psect	text14
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_Key_UNNOL_Check
	__size_of___CMS_Key_UNNOL_Check	equ	__end_of___CMS_Key_UNNOL_Check-___CMS_Key_UNNOL_Check
	
___CMS_Key_UNNOL_Check:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_Key_UNNOL_Check: [wreg-fsr0h+status,2+status,0]
	
l10050:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text14
	
l10052:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_Key_UNNOL_Check@1017)
	clrf	(___CMS_Key_UNNOL_Check@1018)
	
l10054:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u8781
	goto	u8780
u8781:
	goto	l3553
u8780:
	
l10056:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10058:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	movlw	0Ch
	subwf	1+(??___CMS_Key_UNNOL_Check+0)+0,w
	movlw	01h
	skipnz
	subwf	0+(??___CMS_Key_UNNOL_Check+0)+0,w
	skipnc
	goto	u8791
	goto	u8790
u8791:
	goto	l10062
u8790:
	
l10060:	
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	movlw	04h
	subwf	1+(??___CMS_Key_UNNOL_Check+0)+0,w
	movlw	0
	skipnz
	subwf	0+(??___CMS_Key_UNNOL_Check+0)+0,w
	skipnc
	goto	u8801
	goto	u8800
u8801:
	goto	l10066
u8800:
	
l10062:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Key_UNNOL_Check@F1016)^080h,f
	
l10064:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___CMS_Key_UNNOL_Check@1018)
	incf	(___CMS_Key_UNNOL_Check@1018),f
	
l10066:	
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	movlw	0Ch
	subwf	1+(??___CMS_Key_UNNOL_Check+0)+0,w
	movlw	01h
	skipnz
	subwf	0+(??___CMS_Key_UNNOL_Check+0)+0,w
	skipnc
	goto	u8811
	goto	u8810
u8811:
	goto	l10070
u8810:
	
l10068:	
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	movlw	04h
	subwf	1+(??___CMS_Key_UNNOL_Check+0)+0,w
	movlw	0
	skipnz
	subwf	0+(??___CMS_Key_UNNOL_Check+0)+0,w
	skipnc
	goto	u8821
	goto	u8820
u8821:
	goto	l10074
u8820:
	
l10070:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Key_UNNOL_Check@F1016)^080h,f
	
l10072:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___CMS_Key_UNNOL_Check@1018)
	incf	(___CMS_Key_UNNOL_Check@1018),f
	
l10074:	
	movlw	low(02h)
	incf	(___CMS_Key_UNNOL_Check@1017),f
	subwf	((___CMS_Key_UNNOL_Check@1017)),w
	skipc
	goto	u8831
	goto	u8830
u8831:
	goto	l10056
u8830:
	
l10076:	
	movf	((___CMS_Key_UNNOL_Check@1018)),w
	btfss	status,2
	goto	u8841
	goto	u8840
u8841:
	goto	l10080
u8840:
	
l10078:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_Key_UNNOL_Check@F1016)^080h
	goto	l3553
	
l10080:	
	movlw	low(0C8h)
	bsf	status, 5	;RP0=1, select bank1
	subwf	(___CMS_Key_UNNOL_Check@F1016)^080h,w
	skipc
	goto	u8851
	goto	u8850
u8851:
	goto	l3553
u8850:
	
l10082:	
	clrf	(___CMS_Key_UNNOL_Check@F1016)^080h
	
l10084:	
	bcf	(_926/8),(_926)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_920)	;volatile
	clrf	(_921)	;volatile
	
l10086:	
	bcf	(_927/8),(_927)&7	;volatile
	clrf	(___CMS_Key_UNNOL_Check@1017)
	
l10092:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10094:	
	movlw	0
	movwf	(??___CMS_Key_UNNOL_Check+0)+0
	movlw	0Ch
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_Key_UNNOL_Check+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_Key_UNNOL_Check+0)+1,w
	movwf	indf
	
l10096:	
	movlw	0
	movwf	(??___CMS_Key_UNNOL_Check+0)+0
	movlw	0Ch
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_Key_UNNOL_Check+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_Key_UNNOL_Check+0)+1,w
	movwf	indf
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10098:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l10100:	
	incf	(___CMS_Key_UNNOL_Check@1017),f
	
l10102:	
	movlw	low(02h)
	subwf	(___CMS_Key_UNNOL_Check@1017),w
	skipc
	goto	u8861
	goto	u8860
u8861:
	goto	l10092
u8860:
	
l10104:	
	clrf	(_g_KeyFlag)	;volatile
	clrf	0+(_g_KeyFlag)+01h	;volatile
	
l3553:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text14
	
l3567:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_Key_UNNOL_Check
	__end_of___CMS_Key_UNNOL_Check:
	signat	___CMS_Key_UNNOL_Check,89
	global	___CMS_KeyStopClear

;; *************** function ___CMS_KeyStopClear *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  961             1    1[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       1       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___CMS_KeyClearOne
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=1
global __ptext15
__ptext15:	;psect for function ___CMS_KeyStopClear
psect	text15
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyStopClear
	__size_of___CMS_KeyStopClear	equ	__end_of___CMS_KeyStopClear-___CMS_KeyStopClear
	
___CMS_KeyStopClear:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_KeyStopClear: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	
l9708:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text15
	
l9710:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_g_KeyFlag)	;volatile
	clrf	0+(_g_KeyFlag)+01h	;volatile
	clrf	(___CMS_KeyStopClear@961)
	
l9716:	
	movf	(___CMS_KeyStopClear@961),w
	fcall	___CMS_KeyClearOne
	
l9718:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(___CMS_KeyStopClear@961),f
	
l9720:	
	movlw	low(02h)
	subwf	(___CMS_KeyStopClear@961),w
	skipc
	goto	u8251
	goto	u8250
u8251:
	goto	l9716
u8250:
	
l3447:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text15
	
l3448:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyStopClear
	__end_of___CMS_KeyStopClear:
	signat	___CMS_KeyStopClear,89
	global	___CMS_KeyClearOne

;; *************** function ___CMS_KeyClearOne *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;  958             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  958             1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          2       0       0       0
;;      Totals:         2       1       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_KeyStopClear
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=1
global __ptext16
__ptext16:	;psect for function ___CMS_KeyClearOne
psect	text16
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyClearOne
	__size_of___CMS_KeyClearOne	equ	__end_of___CMS_KeyClearOne-___CMS_KeyClearOne
	
___CMS_KeyClearOne:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_KeyClearOne: [wreg-fsr0h+status,2+status,0]
;___CMS_KeyClearOne@958 stored from wreg
	movwf	(___CMS_KeyClearOne@958)
	
l9216:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text16
	
l9218:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9220:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_KeyClearOne@958),w
	addlw	low(464|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l9222:	
	movf	(___CMS_KeyClearOne@958),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9224:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyClearOne@958),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	
l9226:	
	clrc
	rlf	(___CMS_KeyClearOne@958),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9228:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_KeyClearOne@958),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l9230:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_KeyClearOne@958),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l9232:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u7551
	goto	u7550
u7551:
	goto	l3442
u7550:
	
l9234:	
	movlw	0
	movwf	(??___CMS_KeyClearOne+0)+0
	movlw	0Ch
	movwf	(??___CMS_KeyClearOne+0)+0+1
	clrc
	rlf	(___CMS_KeyClearOne@958),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_KeyClearOne+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_KeyClearOne+0)+1,w
	movwf	indf
	movlw	0
	movwf	(??___CMS_KeyClearOne+0)+0
	movlw	0Ch
	movwf	(??___CMS_KeyClearOne+0)+0+1
	clrc
	rlf	(___CMS_KeyClearOne@958),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_KeyClearOne+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_KeyClearOne+0)+1,w
	movwf	indf
	
l3442:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text16
	
l3443:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyClearOne
	__end_of___CMS_KeyClearOne:
	signat	___CMS_KeyClearOne,4217
	global	___CMS_KeyDatIIR

;; *************** function ___CMS_KeyDatIIR *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1026            2    8[BANK0 ] unsigned short 
;;  1025            2    6[BANK0 ] unsigned short 
;;  1022            2    4[BANK0 ] unsigned short 
;;  1024            2    2[BANK0 ] unsigned short 
;;  1023            2    0[BANK0 ] unsigned short 
;;  1021            1   10[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0      11       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0      11       0       0
;;Total ram usage:       11 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=1
global __ptext17
__ptext17:	;psect for function ___CMS_KeyDatIIR
psect	text17
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyDatIIR
	__size_of___CMS_KeyDatIIR	equ	__end_of___CMS_KeyDatIIR-___CMS_KeyDatIIR
	
___CMS_KeyDatIIR:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_KeyDatIIR: [wreg-fsr0h+status,2+status,0]
	
l10106:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text17
	
l10108:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_KeyDatIIR@1021)
	
l10110:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10112:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1023)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1023+1)
	
l10114:	
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1024)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1024+1)
	
l10116:	
	movlw	low(08h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10118:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1022)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1022+1)
	
l10120:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10122:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u8871
	goto	u8870
u8871:
	goto	l10126
u8870:
	
l10124:	
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1025)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1025+1)
	goto	l10128
	
l10126:	
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1025)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1025+1)
	
l10128:	
	movf	((___CMS_KeyDatIIR@1022)),w
iorwf	((___CMS_KeyDatIIR@1022+1)),w
	btfsc	status,2
	goto	u8881
	goto	u8880
u8881:
	goto	l10152
u8880:
	
l10130:	
	movf	((___CMS_KeyDatIIR@1025)),w
iorwf	((___CMS_KeyDatIIR@1025+1)),w
	btfsc	status,2
	goto	u8891
	goto	u8890
u8891:
	goto	l10152
u8890:
	
l10132:	
	movf	(___CMS_KeyDatIIR@1025),w
	addwf	(___CMS_KeyDatIIR@1022),w
	movwf	(___CMS_KeyDatIIR@1026)
	movf	(___CMS_KeyDatIIR@1025+1),w
	skipnc
	incf	(___CMS_KeyDatIIR@1025+1),w
	addwf	(___CMS_KeyDatIIR@1022+1),w
	movwf	1+(___CMS_KeyDatIIR@1026)
	
l10134:	
	clrc
	rrf	(___CMS_KeyDatIIR@1026+1),f
	rrf	(___CMS_KeyDatIIR@1026),f
	movlw	low(08h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10136:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_KeyDatIIR@1026),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_KeyDatIIR@1026+1),w
	movwf	indf
	
l10138:	
	movf	(___CMS_KeyDatIIR@1025),w
	addwf	(___CMS_KeyDatIIR@1024),w
	movwf	(___CMS_KeyDatIIR@1026)
	movf	(___CMS_KeyDatIIR@1025+1),w
	skipnc
	incf	(___CMS_KeyDatIIR@1025+1),w
	addwf	(___CMS_KeyDatIIR@1024+1),w
	movwf	1+(___CMS_KeyDatIIR@1026)
	
l10140:	
	clrc
	rrf	(___CMS_KeyDatIIR@1026+1),f
	rrf	(___CMS_KeyDatIIR@1026),f
	
l10142:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10144:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_KeyDatIIR@1026),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_KeyDatIIR@1026+1),w
	movwf	indf
	
l10146:	
	movf	(___CMS_KeyDatIIR@1025),w
	addwf	(___CMS_KeyDatIIR@1023),w
	movwf	(___CMS_KeyDatIIR@1026)
	movf	(___CMS_KeyDatIIR@1025+1),w
	skipnc
	incf	(___CMS_KeyDatIIR@1025+1),w
	addwf	(___CMS_KeyDatIIR@1023+1),w
	movwf	1+(___CMS_KeyDatIIR@1026)
	clrc
	rrf	(___CMS_KeyDatIIR@1026+1),f
	rrf	(___CMS_KeyDatIIR@1026),f
	
l10148:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10150:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_KeyDatIIR@1026),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_KeyDatIIR@1026+1),w
	movwf	indf
	
l10152:	
	movlw	low(02h)
	incf	(___CMS_KeyDatIIR@1021),f
	subwf	((___CMS_KeyDatIIR@1021)),w
	skipc
	goto	u8901
	goto	u8900
u8901:
	goto	l10110
u8900:
	
l3570:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text17
	
l3576:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyDatIIR
	__end_of___CMS_KeyDatIIR:
	signat	___CMS_KeyDatIIR,89
	global	___CMS_CurAdjust

;; *************** function ___CMS_CurAdjust *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1047            2    4[BANK0 ] unsigned short 
;;  1045            1    3[BANK0 ] unsigned char 
;;  1046            1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       4       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0       6       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___CMS_CurAdjMode
;;		___CMS_CurJudge
;;		___CMS_KeyModeSet
;;		___CMS_KeyStart
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=1
global __ptext18
__ptext18:	;psect for function ___CMS_CurAdjust
psect	text18
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CurAdjust
	__size_of___CMS_CurAdjust	equ	__end_of___CMS_CurAdjust-___CMS_CurAdjust
	
___CMS_CurAdjust:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CurAdjust: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	
l10166:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text18
	
l10168:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_CurAdjust@1046)
	clrf	(___CMS_CurAdjust@1047)
	clrf	(___CMS_CurAdjust@1047+1)
	
l10170:	
	btfsc	(_927/8),(_927)&7	;volatile
	goto	u8931
	goto	u8930
u8931:
	goto	l10178
u8930:
	
l10172:	
	bsf	(_927/8),(_927)&7	;volatile
	
l10174:	
	fcall	___CMS_KeyModeSet
	
l10176:	
	fcall	___CMS_CurAdjMode
	goto	l3621
	
l10178:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10180:	
	btfsc	(402)^0180h,(7)&7	;volatile
	goto	u8941
	goto	u8940
u8941:
	goto	l10224
u8940:
	
l10182:	
	bcf	status, 6	;RP1=0, select bank1
	clrf	(___CMS_CurAdjust@F1044)^080h
	
l10184:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(414)^0180h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___CMS_CurAdjust@1047+1)
	clrf	(___CMS_CurAdjust@1047)
	
l10186:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(413)^0180h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	iorwf	(___CMS_CurAdjust@1047),f
	
l10188:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	btfss	(402)^0180h,(3)&7	;volatile
	goto	u8951
	goto	u8950
u8951:
	goto	l10198
u8950:
	
l10190:	
	movlw	08h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	subwf	(___CMS_CurAdjust@1047+1),w
	movlw	081h
	skipnz
	subwf	(___CMS_CurAdjust@1047),w
	skipnc
	goto	u8961
	goto	u8960
u8961:
	goto	l10216
u8960:
	
l10192:	
	movlw	07h
	subwf	(___CMS_CurAdjust@1047+1),w
	movlw	080h
	skipnz
	subwf	(___CMS_CurAdjust@1047),w
	skipc
	goto	u8971
	goto	u8970
u8971:
	goto	l10216
u8970:
	
l10194:	
	fcall	___CMS_CurJudge
	goto	l10216
	
l10198:	
	
l3627:	
	movlw	0Ch
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	subwf	(___CMS_CurAdjust@1047+1),w
	movlw	0
	skipnz
	subwf	(___CMS_CurAdjust@1047),w
	skipnc
	goto	u8981
	goto	u8980
u8981:
	goto	l10206
u8980:
	
l10200:	
	movlw	04h
	subwf	(___CMS_CurAdjust@1047+1),w
	movlw	01h
	skipnz
	subwf	(___CMS_CurAdjust@1047),w
	skipc
	goto	u8991
	goto	u8990
u8991:
	goto	l10206
u8990:
	
l10202:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
		incf	((406)^0180h),w	;volatile
	btfsc	status,2
	goto	u9001
	goto	u9000
u9001:
	goto	l10206
u9000:
	goto	l10194
	
l10206:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u9011
	goto	u9010
u9011:
	goto	l10212
u9010:
	
l10208:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	movlw	low(0Fh)
	andwf	(indf),w
	movwf	(??___CMS_CurAdjust+0)+0
	movlw	low(06h)
	subwf	0+(??___CMS_CurAdjust+0)+0,w
	skipc
	goto	u9021
	goto	u9020
u9021:
	goto	l10216
u9020:
	
l10210:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	movwf	indf
	goto	l10216
	
l10212:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(010h)
	bsf	status, 7	;select IRP bank3
	addwf	indf,f
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_CurAdjust+0)+0
	movlw	04h
u9035:
	clrc
	rrf	(??___CMS_CurAdjust+0)+0,f
	addlw	-1
	skipz
	goto	u9035
	movlw	low(0Fh)
	andwf	0+(??___CMS_CurAdjust+0)+0,w
	movwf	(??___CMS_CurAdjust+1)+0
	movlw	low(06h)
	subwf	0+(??___CMS_CurAdjust+1)+0,w
	skipc
	goto	u9041
	goto	u9040
u9041:
	goto	l10216
u9040:
	
l10214:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(0Fh)
	andwf	indf,f
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(050h)
	iorwf	indf,f
	
l10216:	
	fcall	___CMS_KeyModeSet
	
l10218:	
	btfsc	(_926/8),(_926)&7	;volatile
	goto	u9051
	goto	u9050
u9051:
	goto	l10222
u9050:
	goto	l10176
	
l10222:	
	fcall	___CMS_KeyStart
	goto	l3621
	
l10224:	
	movlw	low(0C8h)
	bcf	status, 6	;RP1=0, select bank1
	incf	(___CMS_CurAdjust@F1044)^080h,f
	subwf	((___CMS_CurAdjust@F1044)^080h),w
	skipc
	goto	u9061
	goto	u9060
u9061:
	goto	l3621
u9060:
	
l10226:	
	clrf	(___CMS_CurAdjust@F1044)^080h
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_921)	;volatile
	
l10228:	
	bcf	(_927/8),(_927)&7	;volatile
	clrf	(___CMS_CurAdjust@1045)
	
l10234:	
	movf	(___CMS_CurAdjust@1045),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l10236:	
	incf	(___CMS_CurAdjust@1045),f
	
l10238:	
	movlw	low(02h)
	subwf	(___CMS_CurAdjust@1045),w
	skipc
	goto	u9071
	goto	u9070
u9071:
	goto	l10234
u9070:
	
l3621:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text18
	
l3640:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CurAdjust
	__end_of___CMS_CurAdjust:
	signat	___CMS_CurAdjust,89
	global	___CMS_KeyStart

;; *************** function ___CMS_KeyStart *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1038            1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CurAdjust
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=1
global __ptext19
__ptext19:	;psect for function ___CMS_KeyStart
psect	text19
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyStart
	__size_of___CMS_KeyStart	equ	__end_of___CMS_KeyStart-___CMS_KeyStart
	
___CMS_KeyStart:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_KeyStart: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
	
l9306:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text19
	
l9308:	
	movlw	low(0C2h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(400)^0180h,f	;volatile
	movlw	low(0E0h)
	andwf	(401)^0180h,f	;volatile
	
l9310:	
	movf	(_919),w
	addlw	low(((_gc_Table_KeyChannel)|8000h))
	movwf	fsr0
	movlw	high(((_gc_Table_KeyChannel)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	andlw	01Fh
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(401)^0180h,f	;volatile
	
l9312:	
	movlw	low(010h)
	movwf	(415)^0180h	;volatile
	
l9314:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u7621
	goto	u7620
u7621:
	goto	l9326
u7620:
	
l9316:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_KeyStart@1038)
	
l9318:	
	movlw	low(0Fh)
	andwf	(___CMS_KeyStart@1038),f
	
l9320:	
	movlw	low(0F1h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(405)^0180h,f	;volatile
	
l9322:	
	movf	(___CMS_KeyStart@1038),w
	addlw	low(((_sc_CurStep_Table)|8000h))
	movwf	fsr0
	movlw	high(((_sc_CurStep_Table)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(405)^0180h,f	;volatile
	
l9324:	
	movf	(_919),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(406)^0180h	;volatile
	goto	l9336
	
l9326:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	swapf	indf,w
	andlw	(0ffh shr 4) & 0ffh
	movwf	(___CMS_KeyStart@1038)
	
l9328:	
	movlw	low(0Fh)
	andwf	(___CMS_KeyStart@1038),f
	
l9330:	
	movlw	low(0F1h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(405)^0180h,f	;volatile
	
l9332:	
	movf	(___CMS_KeyStart@1038),w
	addlw	low(((_sc_CurStep_Table)|8000h))
	movwf	fsr0
	movlw	high(((_sc_CurStep_Table)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(405)^0180h,f	;volatile
	
l9334:	
	movf	(_919),w
	addlw	low(432|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(406)^0180h	;volatile
	
l9336:	
	movf	(406)^0180h,w	;volatile
	movwf	(407)^0180h	;volatile
	
l9340:	
	bsf	(400)^0180h+(0/8),(0)&7	;volatile
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text19
	
l3607:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyStart
	__end_of___CMS_KeyStart:
	signat	___CMS_KeyStart,89
	global	___CMS_KeyModeSet

;; *************** function ___CMS_KeyModeSet *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1035            1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CurAdjust
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=1
global __ptext20
__ptext20:	;psect for function ___CMS_KeyModeSet
psect	text20
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyModeSet
	__size_of___CMS_KeyModeSet	equ	__end_of___CMS_KeyModeSet-___CMS_KeyModeSet
	
___CMS_KeyModeSet:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_KeyModeSet: [wreg+status,2+status,0]
	
l9280:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text20
	
l9282:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(400)^0180h	;volatile
	movlw	low(0E0h)
	movwf	(403)^0180h	;volatile
	
l9284:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_916),w	;volatile
	addlw	01h
	iorlw	0Ch
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(404)^0180h	;volatile
	
l9286:	
	movlw	low(030h)
	movwf	(405)^0180h	;volatile
	
l9288:	
	movlw	low(099h)
	movwf	(408)^0180h	;volatile
	
l9290:	
	movlw	low(040h)
	movwf	(401)^0180h	;volatile
	
l9292:	
	bsf	(401)^0180h+(5/8),(5)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfsc	status,2
	goto	u7601
	goto	u7600
u7601:
	goto	l9298
u7600:
	
l9294:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	incf	(403)^0180h,f
	incf	(403)^0180h,f	;volatile
	
l9296:	
	movlw	low(010h)
	addwf	(404)^0180h,f	;volatile
	goto	l3596
	
l9298:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	incf	(403)^0180h,f
	incf	(403)^0180h,f	;volatile
	
l9300:	
	movlw	010h
	subwf	(404)^0180h,f	;volatile
	
l9302:	
	bsf	(405)^0180h+(7/8),(7)&7	;volatile
	
l3596:	
	movlw	low(014h)
	movwf	(___CMS_KeyModeSet@1035)
	
l9304:	
	decf	(___CMS_KeyModeSet@1035),f
		incf	(((___CMS_KeyModeSet@1035))),w
	btfss	status,2
	goto	u7611
	goto	u7610
u7611:
	goto	l9304
u7610:
	
l3599:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text20
	
l3600:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyModeSet
	__end_of___CMS_KeyModeSet:
	signat	___CMS_KeyModeSet,89
	global	___CMS_CurJudge

;; *************** function ___CMS_CurJudge *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          2       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CurAdjust
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=1
global __ptext21
__ptext21:	;psect for function ___CMS_CurJudge
psect	text21
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CurJudge
	__size_of___CMS_CurJudge	equ	__end_of___CMS_CurJudge-___CMS_CurJudge
	
___CMS_CurJudge:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CurJudge: [wreg-fsr0h+status,2+status,0]
	
l9342:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text21
	
l9344:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9346:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u7631
	goto	u7630
u7631:
	goto	l9350
u7630:
	
l9348:	
	movf	(_919),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(406)^0180h,w	;volatile
	bsf	status, 7	;select IRP bank3
	movwf	indf
	goto	l9352
	
l9350:	
	movf	(_919),w
	addlw	low(432|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(406)^0180h,w	;volatile
	bsf	status, 7	;select IRP bank3
	movwf	indf
	
l9352:	
	movlw	low(04h)
	movwf	(415)^0180h	;volatile
	
l9354:	
	movlw	0
	movwf	(??___CMS_CurJudge+0)+0
	movlw	0Ch
	movwf	(??___CMS_CurJudge+0)+0+1
	clrc
	rlf	(_919),w	;volatile
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_CurJudge+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_CurJudge+0)+1,w
	movwf	indf
	
l9356:	
	movlw	0
	movwf	(??___CMS_CurJudge+0)+0
	movlw	0Ch
	movwf	(??___CMS_CurJudge+0)+0+1
	clrc
	rlf	(_919),w	;volatile
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_CurJudge+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_CurJudge+0)+1,w
	movwf	indf
	
l9358:	
	movlw	low(02h)
	incf	(_919),f	;volatile
	subwf	((_919)),w	;volatile
	skipc
	goto	u7641
	goto	u7640
u7641:
	goto	l3612
u7640:
	
l9360:	
	clrf	(_919)	;volatile
	
l9362:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u7651
	goto	u7650
u7651:
	goto	l3613
u7650:
	
l9364:	
	movlw	low(01h)
	movwf	(_921)	;volatile
	goto	l3612
	
l3613:	
	bcf	(13)+(6/8),(6)&7	;volatile
	bsf	(_926/8),(_926)&7	;volatile
	
l9366:	
	clrf	(_920)	;volatile
	clrf	(_921)	;volatile
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(402)^0180h	;volatile
	
l3612:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text21
	
l3615:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CurJudge
	__end_of___CMS_CurJudge:
	signat	___CMS_CurJudge,89
	global	___CMS_CurAdjMode

;; *************** function ___CMS_CurAdjMode *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1032            1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CurAdjust
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=1
global __ptext22
__ptext22:	;psect for function ___CMS_CurAdjMode
psect	text22
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CurAdjMode
	__size_of___CMS_CurAdjMode	equ	__end_of___CMS_CurAdjMode-___CMS_CurAdjMode
	
___CMS_CurAdjMode:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CurAdjMode: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
	
l9242:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text22
	
l9244:	
	
l9246:	
	movf	(_919),w
	addlw	low(((_gc_Table_KeyChannel)|8000h))
	movwf	fsr0
	movlw	high(((_gc_Table_KeyChannel)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	andlw	01Fh
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(401)^0180h,f	;volatile
	
l9248:	
	movlw	low(010h)
	movwf	(415)^0180h	;volatile
	
l9250:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u7571
	goto	u7570
u7571:
	goto	l9264
u7570:
	
l9252:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_CurAdjMode@1032)
	
l9254:	
	movlw	low(0Fh)
	andwf	(___CMS_CurAdjMode@1032),f
	
l9256:	
	movlw	low(06h)
	subwf	(___CMS_CurAdjMode@1032),w
	skipc
	goto	u7581
	goto	u7580
u7581:
	goto	l9260
u7580:
	
l9258:	
	movlw	low(05h)
	movwf	(___CMS_CurAdjMode@1032)
	
l9260:	
	movlw	low(0F1h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(405)^0180h,f	;volatile
	
l9262:	
	movf	(___CMS_CurAdjMode@1032),w
	addlw	low(((_sc_CurStep_Table)|8000h))
	movwf	fsr0
	movlw	high(((_sc_CurStep_Table)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(405)^0180h,f	;volatile
	goto	l9276
	
l9264:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	swapf	indf,w
	andlw	(0ffh shr 4) & 0ffh
	movwf	(___CMS_CurAdjMode@1032)
	
l9266:	
	movlw	low(0Fh)
	andwf	(___CMS_CurAdjMode@1032),f
	
l9268:	
	movlw	low(06h)
	subwf	(___CMS_CurAdjMode@1032),w
	skipc
	goto	u7591
	goto	u7590
u7591:
	goto	l9260
u7590:
	goto	l9258
	
l9276:	
	movlw	low(010h)
	movwf	(402)^0180h	;volatile
	
l9278:	
	bsf	(402)^0180h+(7/8),(7)&7	;volatile
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text22
	
l3592:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CurAdjMode
	__end_of___CMS_CurAdjMode:
	signat	___CMS_CurAdjMode,89
	global	___CMS_CheckValidTime

;; *************** function ___CMS_CheckValidTime *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=1
global __ptext23
__ptext23:	;psect for function ___CMS_CheckValidTime
psect	text23
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CheckValidTime
	__size_of___CMS_CheckValidTime	equ	__end_of___CMS_CheckValidTime-___CMS_CheckValidTime
	
___CMS_CheckValidTime:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_CheckValidTime: [wreg+status,2+status,0]
	
l10154:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text23
	
l10156:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	0+(_g_KeyFlag)+01h,w	;volatile
	iorwf	(_g_KeyFlag),w	;volatile
	btfsc	status,2
	goto	u8911
	goto	u8910
u8911:
	goto	l10162
u8910:
	
l10158:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_CheckValidTime@F1029)^080h,f
	skipnz
	incf	(___CMS_CheckValidTime@F1029+1)^080h,f
	movlw	013h
	subwf	((___CMS_CheckValidTime@F1029+1)^080h),w
	movlw	088h
	skipnz
	subwf	((___CMS_CheckValidTime@F1029)^080h),w
	skipc
	goto	u8921
	goto	u8920
u8921:
	goto	l3581
u8920:
	
l10160:	
	bsf	(_gf_kerr/8),(_gf_kerr)&7	;volatile
	
l10162:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_CheckValidTime@F1029)^080h
	clrf	(___CMS_CheckValidTime@F1029+1)^080h
	
l3581:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text23
	
l3585:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CheckValidTime
	__end_of___CMS_CheckValidTime:
	signat	___CMS_CheckValidTime,89
	global	___CMS_CheckOnceResult

;; *************** function ___CMS_CheckOnceResult *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  991             2   14[BANK0 ] unsigned short 
;;  990             2   12[BANK0 ] unsigned short 
;;  989             2    5[BANK0 ] unsigned short 
;;  979             1   20[BANK0 ] unsigned char 
;;  987             1   19[BANK0 ] unsigned char 
;;  988             1   18[BANK0 ] unsigned char 
;;  984             1   17[BANK0 ] unsigned char 
;;  983             1   16[BANK0 ] unsigned char 
;;  982             1   11[BANK0 ] unsigned char 
;;  986             1   10[BANK0 ] unsigned char 
;;  985             1    9[BANK0 ] unsigned char 
;;  981             1    8[BANK0 ] unsigned char 
;;  980             1    7[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0      16       0       0
;;      Temps:          0       5       0       0
;;      Totals:         0      21       0       0
;;Total ram usage:       21 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___CMS_KeyHaveDown
;;		___CMS_KeyIsIn
;;		___CMS_KeyOpen
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=1
global __ptext24
__ptext24:	;psect for function ___CMS_CheckOnceResult
psect	text24
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CheckOnceResult
	__size_of___CMS_CheckOnceResult	equ	__end_of___CMS_CheckOnceResult-___CMS_CheckOnceResult
	
___CMS_CheckOnceResult:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CheckOnceResult: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	
l9804:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text24
	
l9806:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_CheckOnceResult@979)
	
l9808:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u8421
	goto	u8420
u8421:
	goto	l9812
u8420:
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	112
	
l9810:	
	movlw	low(03h)
	movwf	(___CMS_CheckOnceResult@987)
	line	1
	goto	l3487
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9812:	
	movlw	low(04h)
	movwf	(___CMS_CheckOnceResult@987)
	
l3487:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9814:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u8431
	goto	u8430
u8431:
	goto	l9818
u8430:
	
l9816:	
	clrc
	rlf	(___CMS_CheckOnceResult@979),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@991)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@991+1)
	goto	l9820
	
l9818:	
	clrc
	rlf	(___CMS_CheckOnceResult@979),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@991)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@991+1)
	
l9820:	
	clrc
	rlf	(___CMS_CheckOnceResult@979),w
	addlw	low(((_gc_Table_KeyDown)|8000h))
	movwf	fsr0
	movlw	high(((_gc_Table_KeyDown)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(___CMS_CheckOnceResult@989)
	fcall	stringtab
	movwf	(___CMS_CheckOnceResult@989+1)
	
l9822:	
	movf	((___CMS_CheckOnceResult@991)),w
iorwf	((___CMS_CheckOnceResult@991+1)),w
	btfsc	status,2
	goto	u8441
	goto	u8440
u8441:
	goto	l9932
u8440:
	
l9824:	
	movlw	0Ch
	subwf	(___CMS_CheckOnceResult@991+1),w
	movlw	0
	skipnz
	subwf	(___CMS_CheckOnceResult@991),w
	skipnc
	goto	u8451
	goto	u8450
u8451:
	goto	l9932
u8450:
	
l9826:	
	movf	(___CMS_CheckOnceResult@979),w
	andlw	07h
	addlw	low(((_sc_Table_KeyFalg)|8000h))
	movwf	fsr0
	movlw	high(((_sc_Table_KeyFalg)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(___CMS_CheckOnceResult@988)
	
l9828:	
	movf	(___CMS_CheckOnceResult@989),w
	addwf	(___CMS_CheckOnceResult@991),w
	movwf	(___CMS_CheckOnceResult@990)
	movf	(___CMS_CheckOnceResult@989+1),w
	skipnc
	incf	(___CMS_CheckOnceResult@989+1),w
	addwf	(___CMS_CheckOnceResult@991+1),w
	movwf	1+(___CMS_CheckOnceResult@990)
	
l9830:	
	clrf	(___CMS_CheckOnceResult@980)
	
l9832:	
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyIsIn
	xorlw	0
	skipnz
	goto	u8461
	goto	u8460
u8461:
	goto	l9838
u8460:
	
l9834:	
	clrf	(___CMS_CheckOnceResult@980)
	incf	(___CMS_CheckOnceResult@980),f
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	115
	
l9836:	
	movf	(___CMS_CheckOnceResult@990),w
	addlw	low(0FFE7h)
	movwf	(___CMS_CheckOnceResult@990)
	movf	(___CMS_CheckOnceResult@990+1),w
	skipnc
	addlw	1
	addlw	high(0FFE7h)
	movwf	1+(___CMS_CheckOnceResult@990)
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9838:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9840:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrc
	rlf	indf,f
	
l9842:	
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(464|((0x1)<<8))&0ffh
	movwf	fsr0
	clrc
	rlf	indf,f
	
l9844:	
	movlw	low(08h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9846:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckOnceResult@979),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_CheckOnceResult+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_CheckOnceResult+0)+0+1
	movf	(___CMS_CheckOnceResult@990+1),w
	subwf	1+(??___CMS_CheckOnceResult+0)+0,w
	skipz
	goto	u8475
	movf	(___CMS_CheckOnceResult@990),w
	subwf	0+(??___CMS_CheckOnceResult+0)+0,w
u8475:
	skipc
	goto	u8471
	goto	u8470
u8471:
	goto	l9854
u8470:
	
l9848:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9850:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	indf+(0/8),(0)&7
	
l9852:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(464|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	indf+(0/8),(0)&7
	goto	l9862
	
l9854:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9856:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckOnceResult@979),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_CheckOnceResult+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_CheckOnceResult+0)+0+1
	movf	(___CMS_CheckOnceResult@990+1),w
	subwf	1+(??___CMS_CheckOnceResult+0)+0,w
	skipz
	goto	u8485
	movf	(___CMS_CheckOnceResult@990),w
	subwf	0+(??___CMS_CheckOnceResult+0)+0,w
u8485:
	skipc
	goto	u8481
	goto	u8480
u8481:
	goto	l9862
u8480:
	
l9858:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	goto	l9852
	
l9862:	
	clrf	(___CMS_CheckOnceResult@983)
	
l9864:	
	clrf	(___CMS_CheckOnceResult@984)
	
l9866:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(464|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@985)
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@986)
	
l9868:	
	clrf	(___CMS_CheckOnceResult@981)
	goto	l9880
	
l3496:	
	btfss	(___CMS_CheckOnceResult@985),(0)&7
	goto	u8491
	goto	u8490
u8491:
	goto	l9872
u8490:
	
l9870:	
	incf	(___CMS_CheckOnceResult@983),f
	
l9872:	
	clrc
	rrf	(___CMS_CheckOnceResult@985),f
	
l9874:	
	btfss	(___CMS_CheckOnceResult@986),(0)&7
	goto	u8501
	goto	u8500
u8501:
	goto	l9878
u8500:
	
l9876:	
	incf	(___CMS_CheckOnceResult@984),f
	
l9878:	
	clrc
	rrf	(___CMS_CheckOnceResult@986),f
	incf	(___CMS_CheckOnceResult@981),f
	
l9880:	
	clrc
	rlf	(___CMS_CheckOnceResult@987),w
	subwf	(___CMS_CheckOnceResult@981),w
	skipc
	goto	u8511
	goto	u8510
u8511:
	goto	l3496
u8510:
	
l9882:	
	clrf	(___CMS_CheckOnceResult@982)
	
l9884:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9886:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckOnceResult@987),w
	subwf	(___CMS_CheckOnceResult@984),w
	skipc
	goto	u8521
	goto	u8520
u8521:
	goto	l3500
u8520:
	
l9888:	
	movf	(___CMS_CheckOnceResult@988),w
	movwf	(___CMS_KeyHaveDown@956)
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyHaveDown
	
l9890:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_CheckOnceResult@982)
	incf	(___CMS_CheckOnceResult@982),f
	
l9892:	
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l9910
	
l3500:	
	btfss	(_925/8),(_925)&7	;volatile
	goto	u8531
	goto	u8530
u8531:
	goto	l9910
u8530:
	
l9894:	
	clrc
	rlf	(___CMS_CheckOnceResult@987),w
	subwf	(___CMS_CheckOnceResult@983),w
	skipc
	goto	u8541
	goto	u8540
u8541:
	goto	l9902
u8540:
	
l9896:	
	movf	(___CMS_CheckOnceResult@988),w
	movwf	(___CMS_KeyHaveDown@956)
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyHaveDown
	goto	l9890
	
l9902:	
	movf	(___CMS_CheckOnceResult@987),w
	movwf	(??___CMS_CheckOnceResult+0)+0
	clrc
	rlf	(??___CMS_CheckOnceResult+0)+0,f
	movlw	low(01h)
	addwf	0+(??___CMS_CheckOnceResult+0)+0,w
	movwf	(??___CMS_CheckOnceResult+1)+0
	movf	(___CMS_CheckOnceResult@984),w
	addwf	(___CMS_CheckOnceResult@983),w
	movwf	(??___CMS_CheckOnceResult+2)+0
	clrf	(??___CMS_CheckOnceResult+2)+0+1
	rlf	1+(??___CMS_CheckOnceResult+2)+0,f
	
	movf	1+(??___CMS_CheckOnceResult+2)+0,w
	xorlw	80h
	movwf	(??___CMS_CheckOnceResult+4)+0
	movlw	80h
	subwf	(??___CMS_CheckOnceResult+4)+0,w
	skipz
	goto	u8555
	movf	0+(??___CMS_CheckOnceResult+1)+0,w
	subwf	0+(??___CMS_CheckOnceResult+2)+0,w
u8555:

	skipc
	goto	u8551
	goto	u8550
u8551:
	goto	l3502
u8550:
	
l9904:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@988),w
	movwf	(___CMS_KeyHaveDown@956)
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyHaveDown
	goto	l9890
	
l3502:	
	
l9910:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((___CMS_CheckOnceResult@982)),w
	btfss	status,2
	goto	u8561
	goto	u8560
u8561:
	goto	l9932
u8560:
	
l9912:	
	movf	((___CMS_CheckOnceResult@980)),w
	btfsc	status,2
	goto	u8571
	goto	u8570
u8571:
	goto	l9932
u8570:
	
l9914:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9916:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u8581
	goto	u8580
u8581:
	goto	l9922
u8580:
	
l9918:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckOnceResult@987),w
	addlw	0FFh
	subwf	(___CMS_CheckOnceResult@984),w
	skipnc
	goto	u8591
	goto	u8590
u8591:
	goto	l3510
u8590:
	
l9920:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	goto	l3510
	
l9922:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@987),w
	movwf	(??___CMS_CheckOnceResult+0)+0
	clrc
	rlf	(??___CMS_CheckOnceResult+0)+0,f
	movlw	low(0FFh)
	addwf	0+(??___CMS_CheckOnceResult+0)+0,w
	movwf	(??___CMS_CheckOnceResult+1)+0
	movf	(___CMS_CheckOnceResult@984),w
	addwf	(___CMS_CheckOnceResult@983),w
	movwf	(??___CMS_CheckOnceResult+2)+0
	clrf	(??___CMS_CheckOnceResult+2)+0+1
	rlf	1+(??___CMS_CheckOnceResult+2)+0,f
	
	movf	1+(??___CMS_CheckOnceResult+2)+0,w
	xorlw	80h
	movwf	(??___CMS_CheckOnceResult+4)+0
	movlw	80h
	subwf	(??___CMS_CheckOnceResult+4)+0,w
	skipz
	goto	u8605
	movf	0+(??___CMS_CheckOnceResult+1)+0,w
	subwf	0+(??___CMS_CheckOnceResult+2)+0,w
u8605:

	skipnc
	goto	u8601
	goto	u8600
u8601:
	goto	l3510
u8600:
	goto	l9920
	
l3510:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrc
	rlf	(___CMS_CheckOnceResult@987),w
	addlw	0FFh
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u8611
	goto	u8610
u8611:
	goto	l9930
u8610:
	
l9926:	
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l9928:	
	movf	(___CMS_CheckOnceResult@988),w
	movwf	(___CMS_KeyOpen@952)
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyOpen
	goto	l9932
	
l9930:	
	movf	(___CMS_CheckOnceResult@988),w
	movwf	(___CMS_KeyHaveDown@956)
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyHaveDown
	
l9932:	
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(___CMS_CheckOnceResult@979),f
	subwf	((___CMS_CheckOnceResult@979)),w
	skipc
	goto	u8621
	goto	u8620
u8621:
	goto	l3487
u8620:
	
l3514:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text24
	
l3515:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CheckOnceResult
	__end_of___CMS_CheckOnceResult:
	signat	___CMS_CheckOnceResult,89
	global	___CMS_KeyOpen

;; *************** function ___CMS_KeyOpen *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;  951             1    wreg     unsigned char 
;;  952             1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  951             1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckOnceResult
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=1
global __ptext25
__ptext25:	;psect for function ___CMS_KeyOpen
psect	text25
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyOpen
	__size_of___CMS_KeyOpen	equ	__end_of___CMS_KeyOpen-___CMS_KeyOpen
	
___CMS_KeyOpen:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_KeyOpen: [wreg+status,2+status,0]
;___CMS_KeyOpen@951 stored from wreg
	movwf	(___CMS_KeyOpen@951)
	
l9196:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text25
	
l9198:	
	movlw	low(0FFh)
	xorwf	(___CMS_KeyOpen@952),f
	
l9200:	
	btfss	(___CMS_KeyOpen@951),(3)&7
	goto	u7531
	goto	u7530
u7531:
	goto	l9204
u7530:
	
l9202:	
	movf	(___CMS_KeyOpen@952),w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	andwf	0+(_g_KeyFlag)+01h,f	;volatile
	goto	l3433
	
l9204:	
	movf	(___CMS_KeyOpen@952),w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	andwf	(_g_KeyFlag),f	;volatile
	
l3433:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text25
	
l3434:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyOpen
	__end_of___CMS_KeyOpen:
	signat	___CMS_KeyOpen,8313
	global	___CMS_KeyHaveDown

;; *************** function ___CMS_KeyHaveDown *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;  955             1    wreg     unsigned char 
;;  956             1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  955             1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckOnceResult
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=1
global __ptext26
__ptext26:	;psect for function ___CMS_KeyHaveDown
psect	text26
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyHaveDown
	__size_of___CMS_KeyHaveDown	equ	__end_of___CMS_KeyHaveDown-___CMS_KeyHaveDown
	
___CMS_KeyHaveDown:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_KeyHaveDown: [wreg+status,2+status,0]
;___CMS_KeyHaveDown@955 stored from wreg
	movwf	(___CMS_KeyHaveDown@955)
	
l9206:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text26
	
l9208:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_917),f	;volatile
	
l9210:	
	btfss	(___CMS_KeyHaveDown@955),(3)&7
	goto	u7541
	goto	u7540
u7541:
	goto	l9214
u7540:
	
l9212:	
	movf	(___CMS_KeyHaveDown@956),w
	iorwf	0+(_g_KeyFlag)+01h,f	;volatile
	goto	l3438
	
l9214:	
	movf	(___CMS_KeyHaveDown@956),w
	iorwf	(_g_KeyFlag),f	;volatile
	
l3438:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text26
	
l3439:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyHaveDown
	__end_of___CMS_KeyHaveDown:
	signat	___CMS_KeyHaveDown,8313
	global	___CMS_CheckKeyOldValue

;; *************** function ___CMS_CheckKeyOldValue *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1009            2   11[BANK0 ] unsigned short 
;;  1008            2    9[BANK0 ] unsigned short 
;;  1007            2    7[BANK0 ] unsigned short 
;;  1006            2    4[BANK0 ] unsigned short 
;;  1003            1   14[BANK0 ] unsigned char 
;;  1005            1   13[BANK0 ] unsigned char 
;;  1004            1    6[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0      11       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0      13       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___CMS_KeyIsIn
;;		_abs
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=1
global __ptext27
__ptext27:	;psect for function ___CMS_CheckKeyOldValue
psect	text27
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CheckKeyOldValue
	__size_of___CMS_CheckKeyOldValue	equ	__end_of___CMS_CheckKeyOldValue-___CMS_CheckKeyOldValue
	
___CMS_CheckKeyOldValue:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CheckKeyOldValue: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	
l9934:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text27
	
l9936:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_CheckKeyOldValue@1003)
	
l9938:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u8631
	goto	u8630
u8631:
	goto	l9944
u8630:
	
l9940:	
	movlw	low(08h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9942:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1009)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1009+1)
	goto	l9948
	
l9944:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9946:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1009)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1009+1)
	
l9948:	
	movf	((_921)),w	;volatile
	btfsc	status,2
	goto	u8641
	goto	u8640
u8641:
	goto	l9996
u8640:
	
l9950:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9952:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1007)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1007+1)
	
l9954:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1008)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1008+1)
	
l9956:	
	movf	(___CMS_CheckKeyOldValue@1007+1),w
	movwf	(abs@a+1)
	movf	(___CMS_CheckKeyOldValue@1007),w
	movwf	(abs@a)
	movf	(___CMS_CheckKeyOldValue@1009),w
	subwf	(abs@a),f
	movf	(___CMS_CheckKeyOldValue@1009+1),w
	skipc
	decf	(abs@a+1),f
	subwf	(abs@a+1),f
	fcall	_abs
	movf	(1+(?_abs)),w
	movwf	(___CMS_CheckKeyOldValue@1006+1)
	movf	(0+(?_abs)),w
	movwf	(___CMS_CheckKeyOldValue@1006)
	
l9958:	
	movlw	0Ch
	subwf	(___CMS_CheckKeyOldValue@1008+1),w
	movlw	0
	skipnz
	subwf	(___CMS_CheckKeyOldValue@1008),w
	skipnc
	goto	u8651
	goto	u8650
u8651:
	goto	l9962
u8650:
	
l9960:	
	movf	((___CMS_CheckKeyOldValue@1008)),w
iorwf	((___CMS_CheckKeyOldValue@1008+1)),w
	btfss	status,2
	goto	u8661
	goto	u8660
u8661:
	goto	l9968
u8660:
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
	
l9962:	
	movlw	low(04Bh)
	movwf	(___CMS_CheckKeyOldValue@1004)
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9964:	
	
l9966:	
	movlw	low(06h)
	movwf	(___CMS_CheckKeyOldValue@1005)
	goto	l3526
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
	
l9968:	
	movlw	low(032h)
	movwf	(___CMS_CheckKeyOldValue@1004)
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9970:	
	btfss	(_925/8),(_925)&7	;volatile
	goto	u8671
	goto	u8670
u8671:
	goto	l9966
u8670:
	
l9972:	
	movlw	low(0Ch)
	movwf	(___CMS_CheckKeyOldValue@1005)
	
l3526:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9976:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_CheckKeyOldValue@1009),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_CheckKeyOldValue@1009+1),w
	movwf	indf
	
l9978:	
	movf	(___CMS_CheckKeyOldValue@1003),w
	fcall	___CMS_KeyIsIn
	xorlw	0
	skipz
	goto	u8681
	goto	u8680
u8681:
	goto	l9992
u8680:
	
l9980:	
	movf	(___CMS_CheckKeyOldValue@1004),w
	movwf	(??___CMS_CheckKeyOldValue+0)+0
	clrf	(??___CMS_CheckKeyOldValue+0)+0+1
	movf	(___CMS_CheckKeyOldValue@1006+1),w
	subwf	1+(??___CMS_CheckKeyOldValue+0)+0,w
	skipz
	goto	u8695
	movf	(___CMS_CheckKeyOldValue@1006),w
	subwf	0+(??___CMS_CheckKeyOldValue+0)+0,w
u8695:
	skipc
	goto	u8691
	goto	u8690
u8691:
	goto	l9992
u8690:
	
l9982:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9984:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	movf	(___CMS_CheckKeyOldValue@1005),w
	subwf	(indf),w
	skipc
	goto	u8701
	goto	u8700
u8701:
	goto	l10048
u8700:
	
l9986:	
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l9988:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9990:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_CheckKeyOldValue@1007),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_CheckKeyOldValue@1007+1),w
	movwf	indf
	goto	l10048
	
l9992:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9994:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l10048
	
l9996:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9998:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1007)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1007+1)
	
l10000:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1008)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1008+1)
	
l10002:	
	movf	(___CMS_CheckKeyOldValue@1007+1),w
	movwf	(abs@a+1)
	movf	(___CMS_CheckKeyOldValue@1007),w
	movwf	(abs@a)
	movf	(___CMS_CheckKeyOldValue@1009),w
	subwf	(abs@a),f
	movf	(___CMS_CheckKeyOldValue@1009+1),w
	skipc
	decf	(abs@a+1),f
	subwf	(abs@a+1),f
	fcall	_abs
	movf	(1+(?_abs)),w
	movwf	(___CMS_CheckKeyOldValue@1006+1)
	movf	(0+(?_abs)),w
	movwf	(___CMS_CheckKeyOldValue@1006)
	
l10004:	
	movlw	0Ch
	subwf	(___CMS_CheckKeyOldValue@1008+1),w
	movlw	0
	skipnz
	subwf	(___CMS_CheckKeyOldValue@1008),w
	skipnc
	goto	u8711
	goto	u8710
u8711:
	goto	l10008
u8710:
	
l10006:	
	movf	((___CMS_CheckKeyOldValue@1008)),w
iorwf	((___CMS_CheckKeyOldValue@1008+1)),w
	btfss	status,2
	goto	u8721
	goto	u8720
u8721:
	goto	l10018
u8720:
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
	
l10008:	
	movlw	low(064h)
	movwf	(___CMS_CheckKeyOldValue@1004)
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l10010:	
	
l10012:	
	movlw	low(04h)
	movwf	(___CMS_CheckKeyOldValue@1005)
	goto	l3540
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
	
l10018:	
	movlw	low(04Bh)
	movwf	(___CMS_CheckKeyOldValue@1004)
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l10020:	
	btfss	(_925/8),(_925)&7	;volatile
	goto	u8731
	goto	u8730
u8731:
	goto	l10024
u8730:
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	116
	
l10022:	
	movlw	low(06h)
	movwf	(___CMS_CheckKeyOldValue@1005)
	line	1
	goto	l3540
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l10024:	
	goto	l10012
	
l3540:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10028:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_CheckKeyOldValue@1009),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_CheckKeyOldValue@1009+1),w
	movwf	indf
	
l10030:	
	movf	(___CMS_CheckKeyOldValue@1003),w
	fcall	___CMS_KeyIsIn
	xorlw	0
	skipz
	goto	u8741
	goto	u8740
u8741:
	goto	l10044
u8740:
	
l10032:	
	movf	(___CMS_CheckKeyOldValue@1004),w
	movwf	(??___CMS_CheckKeyOldValue+0)+0
	clrf	(??___CMS_CheckKeyOldValue+0)+0+1
	movf	(___CMS_CheckKeyOldValue@1006+1),w
	subwf	1+(??___CMS_CheckKeyOldValue+0)+0,w
	skipz
	goto	u8755
	movf	(___CMS_CheckKeyOldValue@1006),w
	subwf	0+(??___CMS_CheckKeyOldValue+0)+0,w
u8755:
	skipc
	goto	u8751
	goto	u8750
u8751:
	goto	l10044
u8750:
	
l10034:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10036:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	movf	(___CMS_CheckKeyOldValue@1005),w
	subwf	(indf),w
	skipc
	goto	u8761
	goto	u8760
u8761:
	goto	l10048
u8760:
	
l10038:	
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l10040:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10042:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_CheckKeyOldValue@1007),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_CheckKeyOldValue@1007+1),w
	movwf	indf
	goto	l10048
	
l10044:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10046:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l10048:	
	movlw	low(02h)
	incf	(___CMS_CheckKeyOldValue@1003),f
	subwf	((___CMS_CheckKeyOldValue@1003)),w
	skipc
	goto	u8771
	goto	u8770
u8771:
	goto	l9938
u8770:
	
l3547:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text27
	
l3548:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CheckKeyOldValue
	__end_of___CMS_CheckKeyOldValue:
	signat	___CMS_CheckKeyOldValue,89
	global	_abs

;; *************** function _abs *****************
;; Defined at:
;;		line 4 in file "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\abs.c"
;; Parameters:    Size  Location     Type
;;  a               2    4[COMMON] int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  2    4[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       2       0       0
;;      Totals:         2       2       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckKeyOldValue
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=2
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\abs.c"
	line	4
global __ptext28
__ptext28:	;psect for function _abs
psect	text28
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\abs.c"
	line	4
	global	__size_of_abs
	__size_of_abs	equ	__end_of_abs-_abs
	
_abs:	
;incstack = 0
	opt	stack 5
; Regs used in _abs: [wreg+status,2+status,0]
	line	6
	
l9236:	
	btfss	(abs@a+1),7
	goto	u7561
	goto	u7560
u7561:
	goto	l3759
u7560:
	line	7
	
l9238:	
	comf	(abs@a),w
	movwf	(??_abs+0)+0
	comf	(abs@a+1),w
	movwf	((??_abs+0)+0+1)
	incf	(??_abs+0)+0,f
	skipnz
	incf	((??_abs+0)+0+1),f
	movf	0+(??_abs+0)+0,w
	movwf	(?_abs)
	movf	1+(??_abs+0)+0,w
	movwf	(?_abs+1)
	goto	l3760
	
l3759:	
	line	8
	line	9
	
l3760:	
	return
	opt stack 0
GLOBAL	__end_of_abs
	__end_of_abs:
	signat	_abs,4218
	global	___CMS_KeyIsIn

;; *************** function ___CMS_KeyIsIn *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;  946             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  946             1    5[COMMON] unsigned char 
;;  947             1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         2       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckOnceResult
;;		___CMS_CheckKeyOldValue
;; This function uses a non-reentrant model
;;
psect	text29,local,class=CODE,delta=2,merge=1,group=1
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
global __ptext29
__ptext29:	;psect for function ___CMS_KeyIsIn
psect	text29
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyIsIn
	__size_of___CMS_KeyIsIn	equ	__end_of___CMS_KeyIsIn-___CMS_KeyIsIn
	
___CMS_KeyIsIn:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_KeyIsIn: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
;___CMS_KeyIsIn@946 stored from wreg
	movwf	(___CMS_KeyIsIn@946)
	
l9180:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text29
	
l9182:	
	movf	(___CMS_KeyIsIn@946),w
	andlw	07h
	addlw	low(((_sc_Table_KeyFalg)|8000h))
	movwf	fsr0
	movlw	high(((_sc_Table_KeyFalg)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	movwf	(___CMS_KeyIsIn@947)
	
l9184:	
	btfss	(___CMS_KeyIsIn@946),(3)&7
	goto	u7521
	goto	u7520
u7521:
	goto	l9188
u7520:
	
l9186:	
	movf	0+(_g_KeyFlag)+01h,w	;volatile
	andwf	(___CMS_KeyIsIn@947),f
	goto	l9190
	
l9188:	
	movf	(_g_KeyFlag),w	;volatile
	andwf	(___CMS_KeyIsIn@947),f
	
l9190:	
	movf	(___CMS_KeyIsIn@947),w
	
l3429:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyIsIn
	__end_of___CMS_KeyIsIn:
	signat	___CMS_KeyIsIn,4217
	global	_Tx_Display

;; *************** function _Tx_Display *****************
;; Defined at:
;;		line 2203 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               2    2[BANK0 ] unsigned int 
;;  Temp1           1    1[BANK0 ] unsigned char 
;;  Sum_Tot         1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       4       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text30,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	2203
global __ptext30
__ptext30:	;psect for function _Tx_Display
psect	text30
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	2203
	global	__size_of_Tx_Display
	__size_of_Tx_Display	equ	__end_of_Tx_Display-_Tx_Display
	
_Tx_Display:	
;incstack = 0
	opt	stack 7
; Regs used in _Tx_Display: [wreg-fsr0h+status,2+status,0]
	line	2206
	
l10886:	
;main.c: 2205: unsigned int i;
;main.c: 2206: U8_T Sum_Tot=0;
	clrf	(Tx_Display@Sum_Tot)
	line	2207
;main.c: 2207: U8_T Temp1=0;
	clrf	(Tx_Display@Temp1)
	line	2209
	
l10888:	
;main.c: 2209: if((FilterROState==3)||(FilterPCFState==3))
		movlw	3
	xorwf	((_FilterROState)),w
	btfsc	status,2
	goto	u10181
	goto	u10180
u10181:
	goto	l10892
u10180:
	
l10890:	
		movlw	3
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u10191
	goto	u10190
u10191:
	goto	l10894
u10190:
	line	2211
	
l10892:	
;main.c: 2210: {
;main.c: 2211: Temp1=0x03;
	movlw	low(03h)
	movwf	(Tx_Display@Temp1)
	line	2212
;main.c: 2212: }
	goto	l10906
	line	2213
	
l10894:	
;main.c: 2213: else if((FilterROState==2)||(FilterPCFState==2))
		movlw	2
	xorwf	((_FilterROState)),w
	btfsc	status,2
	goto	u10201
	goto	u10200
u10201:
	goto	l10898
u10200:
	
l10896:	
		movlw	2
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u10211
	goto	u10210
u10211:
	goto	l10900
u10210:
	line	2215
	
l10898:	
;main.c: 2214: {
;main.c: 2215: Temp1=0x07;
	movlw	low(07h)
	movwf	(Tx_Display@Temp1)
	line	2216
;main.c: 2216: }
	goto	l10906
	line	2217
	
l10900:	
;main.c: 2217: else if((FilterROState==1)&&(FilterPCFState==1)){
		decf	((_FilterROState)),w
	btfss	status,2
	goto	u10221
	goto	u10220
u10221:
	goto	l10906
u10220:
	
l10902:	
		decf	((_FilterPCFState)),w
	btfss	status,2
	goto	u10231
	goto	u10230
u10231:
	goto	l10906
u10230:
	line	2218
	
l10904:	
;main.c: 2218: Temp1=0x01;
	clrf	(Tx_Display@Temp1)
	incf	(Tx_Display@Temp1),f
	line	2221
	
l10906:	
;main.c: 2219: }
;main.c: 2221: Tx_Type.TxType.Tx_FilterLed=Temp1;
	movf	(Tx_Display@Temp1),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	0+(_Tx_Type)^0100h+03h
	line	2225
	
l10908:	
;main.c: 2225: if(!_BITS1.Bits.bit_7){
	bcf	status, 6	;RP1=0, select bank0
	btfsc	(__BITS1),7
	goto	u10241
	goto	u10240
u10241:
	goto	l10912
u10240:
	line	2228
	
l10910:	
;main.c: 2228: Tx_Type.TxType.Tx_TdsData_1=0x03;
	movlw	low(03h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	0+(_Tx_Type)^0100h+06h
	line	2229
;main.c: 2229: Tx_Type.TxType.Tx_TdsData_2=0xE7;
	movlw	low(0E7h)
	movwf	0+(_Tx_Type)^0100h+07h
	line	2230
;main.c: 2230: }
	goto	l10914
	line	2233
	
l10912:	
;main.c: 2231: else
;main.c: 2232: {
;main.c: 2233: Tx_Type.TxType.Tx_TdsData_1=PureTDSTyp.TdsData>>8;
	bsf	status, 6	;RP1=1, select bank2
	movf	1+(_PureTDSTyp)^0100h+0Fh,w
	movwf	0+(_Tx_Type)^0100h+06h
	line	2234
;main.c: 2234: Tx_Type.TxType.Tx_TdsData_2=PureTDSTyp.TdsData;
	movf	0+(_PureTDSTyp)^0100h+0Fh,w
	movwf	0+(_Tx_Type)^0100h+07h
	line	2236
	
l10914:	
;main.c: 2235: }
;main.c: 2236: Tx_Type.TxType.Tx_TdsLed=1;
	clrf	0+(_Tx_Type)^0100h+05h
	incf	0+(_Tx_Type)^0100h+05h,f
	line	2237
	
l10916:	
;main.c: 2237: if(_BITS.Bits.bit_5==0x00){
	btfsc	(__BITS),5
	goto	u10251
	goto	u10250
u10251:
	goto	l1455
u10250:
	line	2239
	
l10918:	
;main.c: 2239: Tx_Type.TxType.Tx_TdsLed=0;
	clrf	0+(_Tx_Type)^0100h+05h
	line	2240
	
l10920:	
;main.c: 2240: Tx_Type.TxType.Tx_TdsData_1=0xff;
	movlw	low(0FFh)
	movwf	0+(_Tx_Type)^0100h+06h
	line	2241
	
l10922:	
;main.c: 2241: Tx_Type.TxType.Tx_TdsData_2=0x00;
	clrf	0+(_Tx_Type)^0100h+07h
	line	2243
	
l1455:	
	line	2249
;main.c: 2243: }
;main.c: 2249: Tx_Type.TxType.Tx_ErrorState=ErrorVar;
	bcf	status, 6	;RP1=0, select bank0
	movf	(_ErrorVar),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	0+(_Tx_Type)^0100h+09h
	line	2250
	
l10924:	
;main.c: 2250: if(ErrorVar==0x02){
		movlw	2
	bcf	status, 6	;RP1=0, select bank0
	xorwf	((_ErrorVar)),w
	btfss	status,2
	goto	u10261
	goto	u10260
u10261:
	goto	l10928
u10260:
	line	2251
	
l10926:	
;main.c: 2251: Tx_Type.TxType.Tx_ErrorLed=0x07;
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	0+(_Tx_Type)^0100h+08h
	line	2252
;main.c: 2252: }
	goto	l10930
	line	2255
	
l10928:	
;main.c: 2253: else
;main.c: 2254: {
;main.c: 2255: Tx_Type.TxType.Tx_ErrorLed=0x00;
	bsf	status, 6	;RP1=1, select bank2
	clrf	0+(_Tx_Type)^0100h+08h
	line	2257
	
l10930:	
;main.c: 2256: }
;main.c: 2257: Tx_Type.TxType.Tx_Mode=_BITS.Bits.bit_5;
	movlw	0
	btfsc	(__BITS),5
	movlw	1
	movwf	0+(_Tx_Type)^0100h+0Ah
	line	2258
	
l10932:	
;main.c: 2258: if(Read_Word_Buff[11]==0)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(0+(_Read_Word_Buff)^080h+0Bh),w
	btfss	status,2
	goto	u10271
	goto	u10270
u10271:
	goto	l10940
u10270:
	line	2260
	
l10934:	
;main.c: 2259: {
;main.c: 2260: Tx_Type.TxType.Tx_Wifi=0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	clrf	0+(_Tx_Type)^0100h+04h
	line	2261
;main.c: 2261: Tx_Type.TxType.Tx_TdsLed=0;
	clrf	0+(_Tx_Type)^0100h+05h
	line	2262
	
l10936:	
;main.c: 2262: Tx_Type.TxType.Tx_TdsData_1=0xff;
	movlw	low(0FFh)
	movwf	0+(_Tx_Type)^0100h+06h
	line	2263
	
l10938:	
;main.c: 2263: Tx_Type.TxType.Tx_TdsData_2=0x00;
	clrf	0+(_Tx_Type)^0100h+07h
	line	2264
;main.c: 2264: }
	goto	l1459
	line	2267
	
l10940:	
;main.c: 2265: else
;main.c: 2266: {
;main.c: 2267: Tx_Type.TxType.Tx_Wifi=2;
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	movwf	0+(_Tx_Type)^0100h+04h
	line	2268
	
l1459:	
	line	2271
;main.c: 2268: }
;main.c: 2271: for(i=2;i<0x11U-1;i++){
	movlw	02h
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Tx_Display@i)
	clrf	(Tx_Display@i+1)
	line	2272
	
l10944:	
;main.c: 2272: Sum_Tot+=Tx_Type.Tx_Tab[i];
	movf	(Tx_Display@i),w
	addlw	low(_Tx_Type|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	addwf	(Tx_Display@Sum_Tot),f
	line	2271
	
l10946:	
	incf	(Tx_Display@i),f
	skipnz
	incf	(Tx_Display@i+1),f
	
l10948:	
	movlw	0
	subwf	(Tx_Display@i+1),w
	movlw	010h
	skipnz
	subwf	(Tx_Display@i),w
	skipc
	goto	u10281
	goto	u10280
u10281:
	goto	l10944
u10280:
	line	2274
	
l10950:	
;main.c: 2273: }
;main.c: 2274: Tx_Type.TxType.Tx_Check=Sum_Tot+0x11U;
	movf	(Tx_Display@Sum_Tot),w
	addlw	011h
	bsf	status, 6	;RP1=1, select bank2
	movwf	0+(_Tx_Type)^0100h+010h
	line	2275
	
l10952:	
;main.c: 2275: for(i=0;i<0x11U;i++){
	bcf	status, 6	;RP1=0, select bank0
	clrf	(Tx_Display@i)
	clrf	(Tx_Display@i+1)
	line	2276
	
l10958:	
;main.c: 2276: TXREG1=Tx_Type.Tx_Tab[i];
	movf	(Tx_Display@i),w
	addlw	low(_Tx_Type|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(285)^0100h	;volatile
	line	2277
;main.c: 2277: do{
	
l1464:	
	line	2278
# 2278 "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text30
	line	2280
	
l10960:	
;main.c: 2279: }
;main.c: 2280: while(TRMT1==0);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	btfss	(2297/8)^0100h,(2297)&7	;volatile
	goto	u10291
	goto	u10290
u10291:
	goto	l1464
u10290:
	line	2275
	
l10962:	
	bcf	status, 6	;RP1=0, select bank0
	incf	(Tx_Display@i),f
	skipnz
	incf	(Tx_Display@i+1),f
	
l10964:	
	movlw	0
	subwf	(Tx_Display@i+1),w
	movlw	011h
	skipnz
	subwf	(Tx_Display@i),w
	skipc
	goto	u10301
	goto	u10300
u10301:
	goto	l10958
u10300:
	line	2285
	
l1466:	
	return
	opt stack 0
GLOBAL	__end_of_Tx_Display
	__end_of_Tx_Display:
	signat	_Tx_Display,89
	global	_TaskAlarmHandle

;; *************** function _TaskAlarmHandle *****************
;; Defined at:
;;		line 1597 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          2       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text31,local,class=CODE,delta=2,merge=1,group=0
	line	1597
global __ptext31
__ptext31:	;psect for function _TaskAlarmHandle
psect	text31
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	1597
	global	__size_of_TaskAlarmHandle
	__size_of_TaskAlarmHandle	equ	__end_of_TaskAlarmHandle-_TaskAlarmHandle
	
_TaskAlarmHandle:	
;incstack = 0
	opt	stack 7
; Regs used in _TaskAlarmHandle: [wreg+status,2+status,0]
	line	1601
	
l10660:	
;main.c: 1601: if(BeepAlmCnt)
	bcf	status, 5	;RP0=0, select bank0
	movf	((_BeepAlmCnt)),w
	btfsc	status,2
	goto	u9841
	goto	u9840
u9841:
	goto	l1310
u9840:
	line	1603
	
l10662:	
;main.c: 1602: {
;main.c: 1603: if(BeepOnTimeCnt)
	bsf	status, 5	;RP0=1, select bank1
	movf	((_BeepOnTimeCnt)^080h),w
iorwf	((_BeepOnTimeCnt+1)^080h),w
	btfsc	status,2
	goto	u9851
	goto	u9850
u9851:
	goto	l10670
u9850:
	line	1605
	
l10664:	
;main.c: 1604: {
;main.c: 1605: BeepOnTimeCnt--;
	movlw	01h
	subwf	(_BeepOnTimeCnt)^080h,f
	movlw	0
	skipc
	decf	(_BeepOnTimeCnt+1)^080h,f
	subwf	(_BeepOnTimeCnt+1)^080h,f
	line	1607
	
l10666:	
;main.c: 1607: if(BeepOnTimeCnt>=(BuzzerFilter>>1)){PWM1EN=1;}
	movf	(_BuzzerFilter+1)^080h,w
	movwf	(??_TaskAlarmHandle+0)+0+1
	movf	(_BuzzerFilter)^080h,w
	movwf	(??_TaskAlarmHandle+0)+0
	clrc
	rrf	(??_TaskAlarmHandle+0)+1,f
	rrf	(??_TaskAlarmHandle+0)+0,f
	movf	1+(??_TaskAlarmHandle+0)+0,w
	subwf	(_BeepOnTimeCnt+1)^080h,w
	skipz
	goto	u9865
	movf	0+(??_TaskAlarmHandle+0)+0,w
	subwf	(_BeepOnTimeCnt)^080h,w
u9865:
	skipc
	goto	u9861
	goto	u9860
u9861:
	goto	l1312
u9860:
	
l10668:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2097/8)^0100h,(2097)&7	;volatile
	goto	l1316
	line	1610
	
l1312:	
;main.c: 1610: else {PWM1EN=0;}
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2097/8)^0100h,(2097)&7	;volatile
	goto	l1316
	line	1614
	
l10670:	
;main.c: 1612: else
;main.c: 1613: {
;main.c: 1614: BeepAlmCnt--;
	bcf	status, 5	;RP0=0, select bank0
	decf	(_BeepAlmCnt),f
	line	1615
	
l10672:	
;main.c: 1615: BeepOnTimeCnt=BuzzerFilter;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_BuzzerFilter+1)^080h,w
	movwf	(_BeepOnTimeCnt+1)^080h
	movf	(_BuzzerFilter)^080h,w
	movwf	(_BeepOnTimeCnt)^080h
	goto	l1316
	line	1618
	
l1310:	
	line	1620
;main.c: 1618: else
;main.c: 1619: {
;main.c: 1620: _BITS.Bits.bit_7=0;
	bcf	(__BITS),7
	line	1622
	
l1316:	
	return
	opt stack 0
GLOBAL	__end_of_TaskAlarmHandle
	__end_of_TaskAlarmHandle:
	signat	_TaskAlarmHandle,89
	global	_TDS_Handle

;; *************** function _TDS_Handle *****************
;; Defined at:
;;		line 439 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  TDSTyp          1    wreg     PTR struct .
;;		 -> PureTDSTyp(17), 
;;  Type            1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  TDSTyp          1   21[BANK0 ] PTR struct .
;;		 -> PureTDSTyp(17), 
;;  i               2   19[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         0       3       0       0
;;      Temps:          0       4       0       0
;;      Totals:         1       7       0       0
;;Total ram usage:        8 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_GetCurTdsHz
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text32,local,class=CODE,delta=2,merge=1,group=0
	line	439
global __ptext32
__ptext32:	;psect for function _TDS_Handle
psect	text32
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	439
	global	__size_of_TDS_Handle
	__size_of_TDS_Handle	equ	__end_of_TDS_Handle-_TDS_Handle
	
_TDS_Handle:	
;incstack = 0
	opt	stack 6
; Regs used in _TDS_Handle: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
;TDS_Handle@TDSTyp stored from wreg
	movwf	(TDS_Handle@TDSTyp)
	line	447
	
l10364:	
	line	448
	
l10366:	
;main.c: 448: Temp_Ntc=25;
	movlw	low(019h)
	movwf	(_Temp_Ntc)
	line	449
	
l10368:	
;main.c: 449: NTC_=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(TDS_Handle@NTC_)^080h
	clrf	(TDS_Handle@NTC_+1)^080h
	clrf	(TDS_Handle@NTC_+2)^080h
	clrf	(TDS_Handle@NTC_+3)^080h
	line	450
	
l10370:	
;main.c: 450: Muni_c=0;
	clrf	(TDS_Handle@Muni_c)^080h
	clrf	(TDS_Handle@Muni_c+1)^080h
	clrf	(TDS_Handle@Muni_c+2)^080h
	clrf	(TDS_Handle@Muni_c+3)^080h
	line	451
	
l10372:	
;main.c: 451: (TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)])=(TDSTyp->HzCount);
	bcf	status, 5	;RP0=0, select bank0
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Dh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+1
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	clrc
	rlf	indf,w
	addwf	(TDS_Handle@TDSTyp),w
	movwf	(??_TDS_Handle+2)+0
	movf	0+(??_TDS_Handle+2)+0,w
	movwf	fsr0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	indf
	line	452
	
l10374:	
;main.c: 452: (TDSTyp->HzCount)=0;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Dh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	454
	
l10376:	
;main.c: 454: if(Mode!=5){
		movlw	5
	xorwf	((_Mode)),w
	btfsc	status,2
	goto	u9281
	goto	u9280
u9281:
	goto	l10394
u9280:
	line	455
	
l10378:	
;main.c: 455: if(Type==1){
		decf	((TDS_Handle@Type)),w
	btfss	status,2
	goto	u9291
	goto	u9290
u9291:
	goto	l1058
u9290:
	line	457
	
l10380:	
;main.c: 457: if(Temp_Ntc >= 25){
	movlw	low(019h)
	subwf	(_Temp_Ntc),w
	skipc
	goto	u9301
	goto	u9300
u9301:
	goto	l10384
u9300:
	line	458
	
l10382:	
;main.c: 458: NTC_ = (U32_T)(Temp_Ntc -25);
	movf	(_Temp_Ntc),w
	addlw	low(-25)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(TDS_Handle@NTC_)^080h
	movlw	high(-25)
	skipnc
	movlw	(high(-25)+1)&0ffh
	movwf	((TDS_Handle@NTC_)^080h)+1
	clrf	(TDS_Handle@NTC_)^080h+2
	btfsc	(TDS_Handle@NTC_)^080h+1,7
	decf	2+(TDS_Handle@NTC_)^080h,f
	movf	(TDS_Handle@NTC_)^080h+2,w
	movwf	3+(TDS_Handle@NTC_)^080h
	line	459
;main.c: 459: NTC_ += 100;
	movlw	064h
	addwf	(TDS_Handle@NTC_)^080h,f
	movlw	1
	skipnc
	addwf	(TDS_Handle@NTC_+1)^080h,f
	skipnc
	addwf	(TDS_Handle@NTC_+2)^080h,f
	skipnc
	addwf	(TDS_Handle@NTC_+3)^080h,f
	line	460
;main.c: 460: }
	goto	l10386
	line	462
	
l10384:	
;main.c: 461: else {
;main.c: 462: NTC_ = (U32_T)(25-Temp_Ntc);
	movlw	019h
	movwf	(??_TDS_Handle+0)+0
	movf	(_Temp_Ntc),w
	subwf	(??_TDS_Handle+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(TDS_Handle@NTC_)^080h
	clrf	(TDS_Handle@NTC_)^080h+1
	skipc
	decf	1+(TDS_Handle@NTC_)^080h,f
	
	clrf	(TDS_Handle@NTC_)^080h+2
	btfsc	(TDS_Handle@NTC_)^080h+1,7
	decf	2+(TDS_Handle@NTC_)^080h,f
	movf	(TDS_Handle@NTC_)^080h+2,w
	movwf	3+(TDS_Handle@NTC_)^080h
	line	463
;main.c: 463: NTC_ = 100-NTC_;
	movlw	064h
	bcf	status, 5	;RP0=0, select bank0
	movwf	((??_TDS_Handle+0)+0)
	movlw	0
	movwf	((??_TDS_Handle+0)+0+1)
	movlw	0
	movwf	((??_TDS_Handle+0)+0+2)
	movlw	0
	movwf	((??_TDS_Handle+0)+0+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	(TDS_Handle@NTC_)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(??_TDS_Handle+0)+0,f
	bsf	status, 5	;RP0=1, select bank1
	movf	(TDS_Handle@NTC_+1)^080h,w
	skipc
	incfsz	(TDS_Handle@NTC_+1)^080h,w
	goto	u9311
	goto	u9312
u9311:
	bcf	status, 5	;RP0=0, select bank0
	subwf	(??_TDS_Handle+0)+1,f
u9312:
	bsf	status, 5	;RP0=1, select bank1
	movf	(TDS_Handle@NTC_+2)^080h,w
	skipc
	incfsz	(TDS_Handle@NTC_+2)^080h,w
	goto	u9313
	goto	u9314
u9313:
	bcf	status, 5	;RP0=0, select bank0
	subwf	(??_TDS_Handle+0)+2,f
u9314:
	bsf	status, 5	;RP0=1, select bank1
	movf	(TDS_Handle@NTC_+3)^080h,w
	skipc
	incfsz	(TDS_Handle@NTC_+3)^080h,w
	goto	u9315
	goto	u9316
u9315:
	bcf	status, 5	;RP0=0, select bank0
	subwf	(??_TDS_Handle+0)+3,f
u9316:
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 5	;RP0=0, select bank0

	movf	3+(??_TDS_Handle+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(TDS_Handle@NTC_+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	2+(??_TDS_Handle+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(TDS_Handle@NTC_+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_TDS_Handle+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(TDS_Handle@NTC_+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_TDS_Handle+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(TDS_Handle@NTC_)^080h

	line	466
	
l10386:	
;main.c: 464: }
;main.c: 466: Muni_c = TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)];
	bcf	status, 5	;RP0=0, select bank0
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	clrc
	rlf	indf,w
	addwf	(TDS_Handle@TDSTyp),w
	movwf	(??_TDS_Handle+0)+0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+1)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+1)+0+1
	movf	0+(??_TDS_Handle+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(TDS_Handle@Muni_c)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	1+(??_TDS_Handle+1)+0,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	((TDS_Handle@Muni_c)^080h)+1
	clrf	2+((TDS_Handle@Muni_c)^080h)
	clrf	3+((TDS_Handle@Muni_c)^080h)
	line	467
	
l10388:	
;main.c: 467: Muni_c *= 100;
	movlw	064h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplier)
	clrf	(___lmul@multiplier+1)
	clrf	(___lmul@multiplier+2)
	clrf	(___lmul@multiplier+3)

	bsf	status, 5	;RP0=1, select bank1
	movf	(TDS_Handle@Muni_c+3)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplicand+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	(TDS_Handle@Muni_c+2)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplicand+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	(TDS_Handle@Muni_c+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplicand+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(TDS_Handle@Muni_c)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(TDS_Handle@Muni_c+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(TDS_Handle@Muni_c+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(TDS_Handle@Muni_c+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lmul)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(TDS_Handle@Muni_c)^080h

	line	468
	
l10390:	
;main.c: 468: Muni_c /= NTC_;
	movf	(TDS_Handle@NTC_+3)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	(TDS_Handle@NTC_+2)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	(TDS_Handle@NTC_+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(TDS_Handle@NTC_)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@divisor)

	bsf	status, 5	;RP0=1, select bank1
	movf	(TDS_Handle@Muni_c+3)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend+3)
	bsf	status, 5	;RP0=1, select bank1
	movf	(TDS_Handle@Muni_c+2)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend+2)
	bsf	status, 5	;RP0=1, select bank1
	movf	(TDS_Handle@Muni_c+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(TDS_Handle@Muni_c)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(TDS_Handle@Muni_c+3)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(2+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(TDS_Handle@Muni_c+2)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(1+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(TDS_Handle@Muni_c+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(?___lldiv)),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(TDS_Handle@Muni_c)^080h

	line	469
	
l10392:	
;main.c: 469: TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)] = Muni_c;
	bcf	status, 5	;RP0=0, select bank0
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	clrc
	rlf	indf,w
	addwf	(TDS_Handle@TDSTyp),w
	movwf	(??_TDS_Handle+0)+0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(TDS_Handle@Muni_c)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(TDS_Handle@Muni_c+1)^080h,w
	movwf	indf
	line	470
;main.c: 470: }
	goto	l10394
	line	471
	
l1058:	
	line	473
;main.c: 471: else
;main.c: 472: {
;main.c: 473: Muni_c=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(TDS_Handle@Muni_c)^080h
	clrf	(TDS_Handle@Muni_c+1)^080h
	clrf	(TDS_Handle@Muni_c+2)^080h
	clrf	(TDS_Handle@Muni_c+3)^080h
	line	499
	
l10394:	
;main.c: 474: }
;main.c: 475: }
;main.c: 499: (TDSTyp->TdsTime)++;
	bcf	status, 5	;RP0=0, select bank0
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	incf	indf,f
	line	500
;main.c: 500: if((TDSTyp->TdsTime)>=5){
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u9321
	goto	u9320
u9321:
	goto	l1087
u9320:
	line	501
	
l10396:	
;main.c: 501: (TDSTyp->TdsTime)=0;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	clrf	indf
	line	503
;main.c: 503: (TDSTyp->TdsHz)=0;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	504
	
l10398:	
;main.c: 504: for(i=0;i<5;i++)
	clrf	(TDS_Handle@i)
	clrf	(TDS_Handle@i+1)
	line	506
	
l10404:	
;main.c: 505: {
;main.c: 506: TDSTyp->TdsHz+=TDSTyp->TdsHz_Tab[i];
	clrc
	rlf	(TDS_Handle@i),w
	addwf	(TDS_Handle@TDSTyp),w
	movwf	(??_TDS_Handle+0)+0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+1)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+1)+0+1
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	movf	0+(??_TDS_Handle+1)+0,w
	addwf	indf,f
	incfsz	fsr0,f
	movf	indf,w
	skipnc
	incf	indf,w
	movwf	btemp+1
	movf	1+(??_TDS_Handle+1)+0,w
	addwf	btemp+1,w
	movwf	indf
	decf	fsr0,f
	line	504
	
l10406:	
	incf	(TDS_Handle@i),f
	skipnz
	incf	(TDS_Handle@i+1),f
	
l10408:	
	movlw	0
	subwf	(TDS_Handle@i+1),w
	movlw	05h
	skipnz
	subwf	(TDS_Handle@i),w
	skipc
	goto	u9331
	goto	u9330
u9331:
	goto	l10404
u9330:
	line	508
	
l10410:	
;main.c: 507: }
;main.c: 508: (TDSTyp->TdsHz)/=5;
	movlw	05h
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	movf	indf,w
	movwf	(___lwdiv@dividend)
	incf	fsr0,f
	movf	indf,w
	movwf	(___lwdiv@dividend+1)
	fcall	___lwdiv
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	movf	(0+(?___lwdiv)),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(1+(?___lwdiv)),w
	movwf	indf
	line	515
	
l10412:	
;main.c: 515: if(TDSTyp->TdsHz>PureHz_Tab[189])
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+1
	movlw	low(((_PureHz_Tab+017Ah)|8000h))
	movwf	fsr0
	movlw	high(((_PureHz_Tab+017Ah)|8000h))
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_TDS_Handle+2)+0
	fcall	stringtab
	movwf	(??_TDS_Handle+2)+0+1
	movf	1+(??_TDS_Handle+0)+0,w
	subwf	1+(??_TDS_Handle+2)+0,w
	skipz
	goto	u9345
	movf	0+(??_TDS_Handle+0)+0,w
	subwf	0+(??_TDS_Handle+2)+0,w
u9345:
	skipnc
	goto	u9341
	goto	u9340
u9341:
	goto	l10416
u9340:
	line	517
	
l10414:	
;main.c: 516: {
;main.c: 517: TDSTyp->TdsData=189+(TDSTyp->TdsHz-PureHz_Tab[189])/5;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(___lwdiv@dividend)
	incf	fsr0,f
	movf	indf,w
	movwf	(___lwdiv@dividend+1)
	movlw	low(((_PureHz_Tab+017Ah)|8000h))
	movwf	fsr0
	movlw	high(((_PureHz_Tab+017Ah)|8000h))
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_TDS_Handle+0)+0
	fcall	stringtab
	movwf	(??_TDS_Handle+0)+0+1
	movf	0+(??_TDS_Handle+0)+0,w
	subwf	(___lwdiv@dividend),f
	movf	1+(??_TDS_Handle+0)+0,w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	movlw	05h
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	fcall	___lwdiv
	movf	(0+(?___lwdiv)),w
	addlw	low(0BDh)
	movwf	(??_TDS_Handle+2)+0
	movf	(1+(?___lwdiv)),w
	skipnc
	addlw	1
	addlw	high(0BDh)
	movwf	1+(??_TDS_Handle+2)+0
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	0+(??_TDS_Handle+2)+0,w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+2)+0,w
	movwf	indf
	line	518
;main.c: 518: }
	goto	l10418
	line	521
	
l10416:	
;main.c: 519: else
;main.c: 520: {
;main.c: 521: TDSTyp->TdsData=GetCurTdsHz(TDSTyp,(U16_T *)PureHz_Tab,189);
	movlw	low(((_PureHz_Tab)|8000h))
	movwf	(GetCurTdsHz@Tab)
	movlw	high(((_PureHz_Tab)|8000h))
	movwf	((GetCurTdsHz@Tab))+1
	movlw	0BDh
	movwf	(GetCurTdsHz@index)
	clrf	(GetCurTdsHz@index+1)
	movf	(TDS_Handle@TDSTyp),w
	fcall	_GetCurTdsHz
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	(0+(?_GetCurTdsHz)),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(1+(?_GetCurTdsHz)),w
	movwf	indf
	line	524
	
l10418:	
;main.c: 522: }
;main.c: 524: if(TDSTyp->TdsData>999)
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+1
	movlw	03h
	subwf	1+(??_TDS_Handle+0)+0,w
	movlw	0E8h
	skipnz
	subwf	0+(??_TDS_Handle+0)+0,w
	skipc
	goto	u9351
	goto	u9350
u9351:
	goto	l10422
u9350:
	line	526
	
l10420:	
;main.c: 525: {
;main.c: 526: TDSTyp->TdsData=999;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movlw	0E7h
	movwf	indf
	incf	fsr0,f
	movlw	03h
	movwf	indf
	line	527
;main.c: 527: }
	goto	l10426
	line	528
	
l10422:	
;main.c: 528: else if(TDSTyp->TdsData<3)
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+1
	movlw	0
	subwf	1+(??_TDS_Handle+0)+0,w
	movlw	03h
	skipnz
	subwf	0+(??_TDS_Handle+0)+0,w
	skipnc
	goto	u9361
	goto	u9360
u9361:
	goto	l10426
u9360:
	line	530
	
l10424:	
;main.c: 529: {
;main.c: 530: TDSTyp->TdsData=3;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movlw	03h
	movwf	indf
	incf	fsr0,f
	movlw	0
	movwf	indf
	line	533
	
l10426:	
;main.c: 531: }
;main.c: 533: if(Mode!=5)
		movlw	5
	xorwf	((_Mode)),w
	btfsc	status,2
	goto	u9371
	goto	u9370
u9371:
	goto	l1070
u9370:
	line	551
	
l10428:	
;main.c: 534: {
;main.c: 551: if(_BITS.Bits.bit_6==0)
	btfsc	(__BITS),6
	goto	u9381
	goto	u9380
u9381:
	goto	l1070
u9380:
	line	553
	
l10430:	
;main.c: 552: {
;main.c: 553: if(TDSTyp->TdsData>=PreTdsData){
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+1
	movf	(_PreTdsData+1),w
	subwf	1+(??_TDS_Handle+0)+0,w
	skipz
	goto	u9395
	movf	(_PreTdsData),w
	subwf	0+(??_TDS_Handle+0)+0,w
u9395:
	skipc
	goto	u9391
	goto	u9390
u9391:
	goto	l1072
u9390:
	line	554
	
l10432:	
;main.c: 554: TdsCk60sFlag+=1;
	incf	(_TdsCk60sFlag),f
	line	555
	
l10434:	
;main.c: 555: if(TdsCk60sFlag>=4){
	movlw	low(04h)
	subwf	(_TdsCk60sFlag),w
	skipc
	goto	u9401
	goto	u9400
u9401:
	goto	l10438
u9400:
	line	556
	
l10436:	
;main.c: 556: TdsCk60sFlag=0;
	clrf	(_TdsCk60sFlag)
	line	558
	
l10438:	
;main.c: 557: }
;main.c: 558: if(TdsCk60sFlag==1){
		decf	((_TdsCk60sFlag)),w
	btfss	status,2
	goto	u9411
	goto	u9410
u9411:
	goto	l10442
u9410:
	line	559
	
l10440:	
;main.c: 559: TDSTyp->TdsData=PreTdsData+2;
	movf	(_PreTdsData),w
	addlw	low(02h)
	movwf	(??_TDS_Handle+0)+0
	movf	(_PreTdsData+1),w
	skipnc
	addlw	1
	addlw	high(02h)
	movwf	1+(??_TDS_Handle+0)+0
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	indf
	line	560
;main.c: 560: }
	goto	l1070
	line	561
	
l10442:	
;main.c: 561: else if(TdsCk60sFlag==2)
		movlw	2
	xorwf	((_TdsCk60sFlag)),w
	btfss	status,2
	goto	u9421
	goto	u9420
u9421:
	goto	l10450
u9420:
	line	563
	
l10444:	
;main.c: 562: {
;main.c: 563: if(PreTdsData>3)
	movlw	0
	subwf	(_PreTdsData+1),w
	movlw	04h
	skipnz
	subwf	(_PreTdsData),w
	skipc
	goto	u9431
	goto	u9430
u9431:
	goto	l10448
u9430:
	line	564
	
l10446:	
;main.c: 564: TDSTyp->TdsData=PreTdsData-3;
	movf	(_PreTdsData),w
	addlw	low(0FFFDh)
	movwf	(??_TDS_Handle+0)+0
	movf	(_PreTdsData+1),w
	skipnc
	addlw	1
	addlw	high(0FFFDh)
	movwf	1+(??_TDS_Handle+0)+0
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	indf
	goto	l1070
	line	565
	
l10448:	
;main.c: 565: else TDSTyp->TdsData=1;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movlw	01h
	movwf	indf
	incf	fsr0,f
	movlw	0
	movwf	indf
	goto	l1070
	line	567
	
l10450:	
;main.c: 567: else if(TdsCk60sFlag==3)
		movlw	3
	xorwf	((_TdsCk60sFlag)),w
	btfss	status,2
	goto	u9441
	goto	u9440
u9441:
	goto	l10458
u9440:
	line	569
	
l10452:	
;main.c: 568: {
;main.c: 569: if(PreTdsData>2)
	movlw	0
	subwf	(_PreTdsData+1),w
	movlw	03h
	skipnz
	subwf	(_PreTdsData),w
	skipc
	goto	u9451
	goto	u9450
u9451:
	goto	l10456
u9450:
	line	570
	
l10454:	
;main.c: 570: TDSTyp->TdsData=PreTdsData-2;
	movf	(_PreTdsData),w
	addlw	low(0FFFEh)
	movwf	(??_TDS_Handle+0)+0
	movf	(_PreTdsData+1),w
	skipnc
	addlw	1
	addlw	high(0FFFEh)
	movwf	1+(??_TDS_Handle+0)+0
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	indf
	goto	l1070
	line	571
	
l10456:	
;main.c: 571: else TDSTyp->TdsData=1;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movlw	01h
	movwf	indf
	incf	fsr0,f
	movlw	0
	movwf	indf
	goto	l1070
	line	574
	
l10458:	
;main.c: 574: else if(TdsCk60sFlag==0)
	movf	((_TdsCk60sFlag)),w
	btfss	status,2
	goto	u9461
	goto	u9460
u9461:
	goto	l1075
u9460:
	line	576
	
l10460:	
;main.c: 575: {
;main.c: 576: TDSTyp->TdsData=PreTdsData+3;
	movf	(_PreTdsData),w
	addlw	low(03h)
	movwf	(??_TDS_Handle+0)+0
	movf	(_PreTdsData+1),w
	skipnc
	addlw	1
	addlw	high(03h)
	movwf	1+(??_TDS_Handle+0)+0
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	indf
	goto	l1070
	line	578
	
l1075:	
;main.c: 577: }
;main.c: 578: }
	goto	l1070
	line	579
	
l1072:	
	line	581
;main.c: 579: else
;main.c: 580: {
;main.c: 581: _BITS.Bits.bit_6=1;
	bsf	(__BITS),6
	line	584
	
l1070:	
	line	585
;main.c: 582: }
;main.c: 583: }
;main.c: 584: }
;main.c: 585: if(_BITS.Bits.bit_6){
	btfss	(__BITS),6
	goto	u9471
	goto	u9470
u9471:
	goto	l1087
u9470:
	line	586
	
l10462:	
;main.c: 586: PreTdsData=TDSTyp->TdsData;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	indf,w
	movwf	(_PreTdsData)
	incf	fsr0,f
	movf	indf,w
	movwf	(_PreTdsData+1)
	line	605
	
l1087:	
	return
	opt stack 0
GLOBAL	__end_of_TDS_Handle
	__end_of_TDS_Handle:
	signat	_TDS_Handle,8313
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK0 ] unsigned int 
;;  dividend        2    2[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    5[BANK0 ] unsigned int 
;;  counter         1    4[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       4       0       0
;;      Locals:         0       3       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       7       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_TDS_Handle
;; This function uses a non-reentrant model
;;
psect	text33,local,class=CODE,delta=2,merge=1,group=2
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lwdiv.c"
	line	6
global __ptext33
__ptext33:	;psect for function ___lwdiv
psect	text33
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 6
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l10318:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l10320:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u9181
	goto	u9180
u9181:
	goto	l10340
u9180:
	line	16
	
l10322:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l10326
	line	18
	
l10324:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l10326:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u9191
	goto	u9190
u9191:
	goto	l10324
u9190:
	line	22
	
l10328:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l10330:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u9205
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u9205:
	skipc
	goto	u9201
	goto	u9200
u9201:
	goto	l10336
u9200:
	line	24
	
l10332:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l10334:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l10336:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l10338:	
	decfsz	(___lwdiv@counter),f
	goto	u9211
	goto	u9210
u9211:
	goto	l10328
u9210:
	line	30
	
l10340:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l4053:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    0[BANK0 ] unsigned long 
;;  multiplicand    4    4[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4    8[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    0[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       8       0       0
;;      Locals:         0       4       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_TDS_Handle
;; This function uses a non-reentrant model
;;
psect	text34,local,class=CODE,delta=2,merge=1,group=2
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul32.c"
	line	15
global __ptext34
__ptext34:	;psect for function ___lmul
psect	text34
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 6
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l10280:	
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l3721:	
	line	121
	btfss	(___lmul@multiplier),(0)&7
	goto	u9111
	goto	u9110
u9111:
	goto	l10284
u9110:
	line	122
	
l10282:	
	movf	(___lmul@multiplicand),w
	addwf	(___lmul@product),f
	movf	(___lmul@multiplicand+1),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u9121
	addwf	(___lmul@product+1),f
u9121:
	movf	(___lmul@multiplicand+2),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u9122
	addwf	(___lmul@product+2),f
u9122:
	movf	(___lmul@multiplicand+3),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u9123
	addwf	(___lmul@product+3),f
u9123:

	line	123
	
l10284:	
	clrc
	rlf	(___lmul@multiplicand),f
	rlf	(___lmul@multiplicand+1),f
	rlf	(___lmul@multiplicand+2),f
	rlf	(___lmul@multiplicand+3),f
	line	124
	
l10286:	
	clrc
	rrf	(___lmul@multiplier+3),f
	rrf	(___lmul@multiplier+2),f
	rrf	(___lmul@multiplier+1),f
	rrf	(___lmul@multiplier),f
	line	125
	movf	(___lmul@multiplier+3),w
	iorwf	(___lmul@multiplier+2),w
	iorwf	(___lmul@multiplier+1),w
	iorwf	(___lmul@multiplier),w
	skipz
	goto	u9131
	goto	u9130
u9131:
	goto	l3721
u9130:
	line	128
	
l10288:	
	movf	(___lmul@product+3),w
	movwf	(?___lmul+3)
	movf	(___lmul@product+2),w
	movwf	(?___lmul+2)
	movf	(___lmul@product+1),w
	movwf	(?___lmul+1)
	movf	(___lmul@product),w
	movwf	(?___lmul)

	line	129
	
l3724:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    0[BANK0 ] unsigned long 
;;  dividend        4    4[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4    8[BANK0 ] unsigned long 
;;  counter         1   12[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    0[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       8       0       0
;;      Locals:         0       5       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0      13       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_TDS_Handle
;; This function uses a non-reentrant model
;;
psect	text35,local,class=CODE,delta=2,merge=1,group=2
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lldiv.c"
	line	6
global __ptext35
__ptext35:	;psect for function ___lldiv
psect	text35
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 6
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l10292:	
	clrf	(___lldiv@quotient)
	clrf	(___lldiv@quotient+1)
	clrf	(___lldiv@quotient+2)
	clrf	(___lldiv@quotient+3)
	line	15
	
l10294:	
	movf	(___lldiv@divisor+3),w
	iorwf	(___lldiv@divisor+2),w
	iorwf	(___lldiv@divisor+1),w
	iorwf	(___lldiv@divisor),w
	skipnz
	goto	u9141
	goto	u9140
u9141:
	goto	l10314
u9140:
	line	16
	
l10296:	
	clrf	(___lldiv@counter)
	incf	(___lldiv@counter),f
	line	17
	goto	l10300
	line	18
	
l10298:	
	clrc
	rlf	(___lldiv@divisor),f
	rlf	(___lldiv@divisor+1),f
	rlf	(___lldiv@divisor+2),f
	rlf	(___lldiv@divisor+3),f
	line	19
	incf	(___lldiv@counter),f
	line	17
	
l10300:	
	btfss	(___lldiv@divisor+3),(31)&7
	goto	u9151
	goto	u9150
u9151:
	goto	l10298
u9150:
	line	22
	
l10302:	
	clrc
	rlf	(___lldiv@quotient),f
	rlf	(___lldiv@quotient+1),f
	rlf	(___lldiv@quotient+2),f
	rlf	(___lldiv@quotient+3),f
	line	23
	
l10304:	
	movf	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),w
	skipz
	goto	u9165
	movf	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),w
	skipz
	goto	u9165
	movf	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),w
	skipz
	goto	u9165
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),w
u9165:
	skipc
	goto	u9161
	goto	u9160
u9161:
	goto	l10310
u9160:
	line	24
	
l10306:	
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),f
	movf	(___lldiv@divisor+1),w
	skipc
	incfsz	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),f
	movf	(___lldiv@divisor+2),w
	skipc
	incfsz	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),f
	movf	(___lldiv@divisor+3),w
	skipc
	incfsz	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),f
	line	25
	
l10308:	
	bsf	(___lldiv@quotient)+(0/8),(0)&7
	line	27
	
l10310:	
	clrc
	rrf	(___lldiv@divisor+3),f
	rrf	(___lldiv@divisor+2),f
	rrf	(___lldiv@divisor+1),f
	rrf	(___lldiv@divisor),f
	line	28
	
l10312:	
	decfsz	(___lldiv@counter),f
	goto	u9171
	goto	u9170
u9171:
	goto	l10302
u9170:
	line	30
	
l10314:	
	movf	(___lldiv@quotient+3),w
	movwf	(?___lldiv+3)
	movf	(___lldiv@quotient+2),w
	movwf	(?___lldiv+2)
	movf	(___lldiv@quotient+1),w
	movwf	(?___lldiv+1)
	movf	(___lldiv@quotient),w
	movwf	(?___lldiv)

	line	31
	
l4000:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	_GetCurTdsHz

;; *************** function _GetCurTdsHz *****************
;; Defined at:
;;		line 364 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  AdPtr           1    wreg     PTR struct .
;;		 -> PureTDSTyp(17), 
;;  Tab             2    0[BANK0 ] PTR unsigned int 
;;		 -> PureHz_Tab(380), 
;;  index           2    2[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  AdPtr           1   14[BANK0 ] PTR struct .
;;		 -> PureTDSTyp(17), 
;;  tmp             2   12[BANK0 ] unsigned int 
;;  i               2   10[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2    0[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       4       0       0
;;      Locals:         0       5       0       0
;;      Temps:          0       6       0       0
;;      Totals:         0      15       0       0
;;Total ram usage:       15 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_TDS_Handle
;; This function uses a non-reentrant model
;;
psect	text36,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	364
global __ptext36
__ptext36:	;psect for function _GetCurTdsHz
psect	text36
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	364
	global	__size_of_GetCurTdsHz
	__size_of_GetCurTdsHz	equ	__end_of_GetCurTdsHz-_GetCurTdsHz
	
_GetCurTdsHz:	
;incstack = 0
	opt	stack 6
; Regs used in _GetCurTdsHz: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
;GetCurTdsHz@AdPtr stored from wreg
	movwf	(GetCurTdsHz@AdPtr)
	line	367
	
l9368:	
;main.c: 366: U16_T tmp, i;
;main.c: 367: tmp=0x00;
	clrf	(GetCurTdsHz@tmp)
	clrf	(GetCurTdsHz@tmp+1)
	line	369
	
l9370:	
;main.c: 369: if(AdPtr->TdsHz<Tab[0])
	movf	(GetCurTdsHz@Tab+1),w
	movwf	btemp+1
	movf	(GetCurTdsHz@Tab),w
	movwf	fsr0
	fcall	stringtab
	movwf	(??_GetCurTdsHz+0)+0
	fcall	stringtab
	movwf	(??_GetCurTdsHz+0)+0+1
	movf	(GetCurTdsHz@AdPtr),w
	addlw	0Bh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_GetCurTdsHz+2)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_GetCurTdsHz+2)+0+1
	movf	1+(??_GetCurTdsHz+0)+0,w
	subwf	1+(??_GetCurTdsHz+2)+0,w
	skipz
	goto	u7665
	movf	0+(??_GetCurTdsHz+0)+0,w
	subwf	0+(??_GetCurTdsHz+2)+0,w
u7665:
	skipnc
	goto	u7661
	goto	u7660
u7661:
	goto	l9374
u7660:
	goto	l1016
	line	372
	
l9374:	
;main.c: 372: else if(AdPtr->TdsHz>=Tab[index]){tmp=index;}
	movf	(GetCurTdsHz@index+1),w
	movwf	(??_GetCurTdsHz+0)+0+1
	movf	(GetCurTdsHz@index),w
	movwf	(??_GetCurTdsHz+0)+0
	clrc
	rlf	(??_GetCurTdsHz+0)+0,f
	rlf	(??_GetCurTdsHz+0)+1,f
	movf	0+(??_GetCurTdsHz+0)+0,w
	addwf	(GetCurTdsHz@Tab),w
	movwf	fsr0
	movf	1+(??_GetCurTdsHz+0)+0,w
	skipnc
	incf	1+(??_GetCurTdsHz+0)+0,w
	addwf	(GetCurTdsHz@Tab+1),w
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_GetCurTdsHz+2)+0
	fcall	stringtab
	movwf	(??_GetCurTdsHz+2)+0+1
	movf	(GetCurTdsHz@AdPtr),w
	addlw	0Bh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_GetCurTdsHz+4)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_GetCurTdsHz+4)+0+1
	movf	1+(??_GetCurTdsHz+2)+0,w
	subwf	1+(??_GetCurTdsHz+4)+0,w
	skipz
	goto	u7675
	movf	0+(??_GetCurTdsHz+2)+0,w
	subwf	0+(??_GetCurTdsHz+4)+0,w
u7675:
	skipc
	goto	u7671
	goto	u7670
u7671:
	goto	l9378
u7670:
	
l9376:	
	movf	(GetCurTdsHz@index+1),w
	movwf	(GetCurTdsHz@tmp+1)
	movf	(GetCurTdsHz@index),w
	movwf	(GetCurTdsHz@tmp)
	goto	l1016
	line	375
	
l9378:	
;main.c: 373: else
;main.c: 374: {
;main.c: 375: for(i = 10; i < index; )
	movlw	0Ah
	movwf	(GetCurTdsHz@i)
	clrf	(GetCurTdsHz@i+1)
	goto	l1019
	line	377
	
l9380:	
;main.c: 376: {
;main.c: 377: if(AdPtr->TdsHz >= Tab[i]){tmp = i;}
	movf	(GetCurTdsHz@i+1),w
	movwf	(??_GetCurTdsHz+0)+0+1
	movf	(GetCurTdsHz@i),w
	movwf	(??_GetCurTdsHz+0)+0
	clrc
	rlf	(??_GetCurTdsHz+0)+0,f
	rlf	(??_GetCurTdsHz+0)+1,f
	movf	0+(??_GetCurTdsHz+0)+0,w
	addwf	(GetCurTdsHz@Tab),w
	movwf	fsr0
	movf	1+(??_GetCurTdsHz+0)+0,w
	skipnc
	incf	1+(??_GetCurTdsHz+0)+0,w
	addwf	(GetCurTdsHz@Tab+1),w
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_GetCurTdsHz+2)+0
	fcall	stringtab
	movwf	(??_GetCurTdsHz+2)+0+1
	movf	(GetCurTdsHz@AdPtr),w
	addlw	0Bh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_GetCurTdsHz+4)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_GetCurTdsHz+4)+0+1
	movf	1+(??_GetCurTdsHz+2)+0,w
	subwf	1+(??_GetCurTdsHz+4)+0,w
	skipz
	goto	u7685
	movf	0+(??_GetCurTdsHz+2)+0,w
	subwf	0+(??_GetCurTdsHz+4)+0,w
u7685:
	skipc
	goto	u7681
	goto	u7680
u7681:
	goto	l1021
u7680:
	
l9382:	
	movf	(GetCurTdsHz@i+1),w
	movwf	(GetCurTdsHz@tmp+1)
	movf	(GetCurTdsHz@i),w
	movwf	(GetCurTdsHz@tmp)
	
l1021:	
	line	378
;main.c: 378: i += 10;
	movlw	0Ah
	addwf	(GetCurTdsHz@i),f
	skipnc
	incf	(GetCurTdsHz@i+1),f
	line	375
	
l1019:	
	movf	(GetCurTdsHz@index+1),w
	subwf	(GetCurTdsHz@i+1),w
	skipz
	goto	u7695
	movf	(GetCurTdsHz@index),w
	subwf	(GetCurTdsHz@i),w
u7695:
	skipc
	goto	u7691
	goto	u7690
u7691:
	goto	l9380
u7690:
	line	380
	
l9384:	
	movf	(GetCurTdsHz@AdPtr),w
	addlw	0Bh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_GetCurTdsHz+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_GetCurTdsHz+0)+0+1
	movf	(GetCurTdsHz@tmp+1),w
	movwf	(??_GetCurTdsHz+2)+0+1
	movf	(GetCurTdsHz@tmp),w
	movwf	(??_GetCurTdsHz+2)+0
	incf	(GetCurTdsHz@tmp),f
	skipnz
	incf	(GetCurTdsHz@tmp+1),f
	clrc
	rlf	(??_GetCurTdsHz+2)+0,f
	rlf	(??_GetCurTdsHz+2)+1,f
	movf	0+(??_GetCurTdsHz+2)+0,w
	addwf	(GetCurTdsHz@Tab),w
	movwf	fsr0
	movf	1+(??_GetCurTdsHz+2)+0,w
	skipnc
	incf	1+(??_GetCurTdsHz+2)+0,w
	addwf	(GetCurTdsHz@Tab+1),w
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_GetCurTdsHz+4)+0
	fcall	stringtab
	movwf	(??_GetCurTdsHz+4)+0+1
	movf	1+(??_GetCurTdsHz+0)+0,w
	subwf	1+(??_GetCurTdsHz+4)+0,w
	skipz
	goto	u7705
	movf	0+(??_GetCurTdsHz+0)+0,w
	subwf	0+(??_GetCurTdsHz+4)+0,w
u7705:
	skipc
	goto	u7701
	goto	u7700
u7701:
	goto	l9384
u7700:
	line	381
	
l9386:	
;main.c: 381: if(tmp){tmp--;}
	movf	((GetCurTdsHz@tmp)),w
iorwf	((GetCurTdsHz@tmp+1)),w
	btfsc	status,2
	goto	u7711
	goto	u7710
u7711:
	goto	l1016
u7710:
	
l9388:	
	movlw	01h
	subwf	(GetCurTdsHz@tmp),f
	movlw	0
	skipc
	decf	(GetCurTdsHz@tmp+1),f
	subwf	(GetCurTdsHz@tmp+1),f
	line	382
	
l1016:	
	line	383
;main.c: 382: }
;main.c: 383: return(tmp);
	movf	(GetCurTdsHz@tmp+1),w
	movwf	(?_GetCurTdsHz+1)
	movf	(GetCurTdsHz@tmp),w
	movwf	(?_GetCurTdsHz)
	line	385
	
l1027:	
	return
	opt stack 0
GLOBAL	__end_of_GetCurTdsHz
	__end_of_GetCurTdsHz:
	signat	_GetCurTdsHz,12410
	global	_Page_ProgramData

;; *************** function _Page_ProgramData *****************
;; Defined at:
;;		line 2684 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               2    3[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       2       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Memory_Write
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text37,local,class=CODE,delta=2,merge=1,group=0
	line	2684
global __ptext37
__ptext37:	;psect for function _Page_ProgramData
psect	text37
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	2684
	global	__size_of_Page_ProgramData
	__size_of_Page_ProgramData	equ	__end_of_Page_ProgramData-_Page_ProgramData
	
_Page_ProgramData:	
;incstack = 0
	opt	stack 6
; Regs used in _Page_ProgramData: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	2685
	
l10996:	
;main.c: 2685: unsigned int i=0;
	clrf	(Page_ProgramData@i)
	clrf	(Page_ProgramData@i+1)
	line	2686
;main.c: 2686: for(i=0;i<12;i++){
	clrf	(Page_ProgramData@i)
	clrf	(Page_ProgramData@i+1)
	line	2687
	
l11002:	
;main.c: 2687: Memory_Write(i,Read_Word_Buff[i]);
	movf	(Page_ProgramData@i+1),w
	movwf	(Memory_Write@Addr+1)
	movf	(Page_ProgramData@i),w
	movwf	(Memory_Write@Addr)
	movf	(Page_ProgramData@i),w
	addlw	low(_Read_Word_Buff|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(Memory_Write@Value)
	fcall	_Memory_Write
	line	2686
	
l11004:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(Page_ProgramData@i),f
	skipnz
	incf	(Page_ProgramData@i+1),f
	
l11006:	
	movlw	0
	subwf	(Page_ProgramData@i+1),w
	movlw	0Ch
	skipnz
	subwf	(Page_ProgramData@i),w
	skipc
	goto	u10361
	goto	u10360
u10361:
	goto	l11002
u10360:
	line	2689
	
l1534:	
	return
	opt stack 0
GLOBAL	__end_of_Page_ProgramData
	__end_of_Page_ProgramData:
	signat	_Page_ProgramData,89
	global	_Memory_Write

;; *************** function _Memory_Write *****************
;; Defined at:
;;		line 1774 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Addr            2    0[BANK0 ] unsigned int 
;;  Value           1    2[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  i               1    4[COMMON] volatile unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       3       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       3       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Page_ProgramData
;; This function uses a non-reentrant model
;;
psect	text38,local,class=CODE,delta=2,merge=1,group=0
	line	1774
global __ptext38
__ptext38:	;psect for function _Memory_Write
psect	text38
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	1774
	global	__size_of_Memory_Write
	__size_of_Memory_Write	equ	__end_of_Memory_Write-_Memory_Write
	
_Memory_Write:	
;incstack = 0
	opt	stack 6
; Regs used in _Memory_Write: [wreg+status,2]
	line	1777
	
l9598:	
;main.c: 1777: volatile unsigned char i = 0;
	clrf	(Memory_Write@i)	;volatile
	line	1780
	
l9600:	
;main.c: 1780: EEADR = Addr;
	movf	(Memory_Write@Addr),w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(391)^0180h	;volatile
	line	1781
	
l9602:	
;main.c: 1781: EEDAT= Value;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Memory_Write@Value),w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(390)^0180h	;volatile
	line	1782
;main.c: 1782: EECON1 = 0;
	clrf	(396)^0180h	;volsfr
	line	1783
	
l9604:	
;main.c: 1783: EEPGD = 0;
	bcf	(3175/8)^0180h,(3175)&7	;volsfr
	line	1784
	
l9606:	
;main.c: 1784: EECON1 | = 0x10;
	bsf	(396)^0180h+(4/8),(4)&7	;volsfr
	line	1785
# 1785 "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text38
	line	1788
	
l9608:	
;main.c: 1788: WREN = 1;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	bsf	(3170/8)^0180h,(3170)&7	;volsfr
	line	1789
	
l9610:	
;main.c: 1789: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	1790
	
l9612:	
;main.c: 1790: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	1791
	
l9614:	
;main.c: 1791: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	1792
;main.c: 1792: while(GIE)
	goto	l1357
	
l1358:	
	line	1794
;main.c: 1793: {
;main.c: 1794: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	1795
;main.c: 1795: if(0 == --i)
	decfsz	(Memory_Write@i),f	;volatile
	goto	u8091
	goto	u8090
u8091:
	goto	l1357
u8090:
	line	1798
	
l9616:	
;main.c: 1796: {
;main.c: 1798: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	1799
;main.c: 1799: return 0;
;	Return value of _Memory_Write is never used
	goto	l1360
	line	1801
	
l1357:	
	line	1792
	btfsc	(95/8),(95)&7	;volatile
	goto	u8101
	goto	u8100
u8101:
	goto	l1358
u8100:
	
l1361:	
	line	1802
# 1802 "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text38
	line	1804
	
l9618:	
;main.c: 1804: EECON2 = 0x55;
	movlw	low(055h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(397)^0180h	;volsfr
	line	1805
;main.c: 1805: EECON2 = 0xaa;
	movlw	low(0AAh)
	movwf	(397)^0180h	;volsfr
	line	1806
	
l9620:	
;main.c: 1806: WR = 1;
	bsf	(3169/8)^0180h,(3169)&7	;volsfr
	line	1807
# 1807 "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	1808
# 1808 "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	1809
# 1809 "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text38
	line	1810
	
l9622:	
;main.c: 1810: WREN = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	bcf	(3170/8)^0180h,(3170)&7	;volsfr
	line	1812
	
l9624:	
;main.c: 1812: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	1814
	
l9626:	
;main.c: 1814: if(WRERR) return 0;
	line	1816
	
l1360:	
	return
	opt stack 0
GLOBAL	__end_of_Memory_Write
	__end_of_Memory_Write:
	signat	_Memory_Write,8313
	global	_Led_Handle

;; *************** function _Led_Handle *****************
;; Defined at:
;;		line 975 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               2    4[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       2       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_LedControlSt
;;		___bmul
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text39,local,class=CODE,delta=2,merge=1,group=0
	line	975
global __ptext39
__ptext39:	;psect for function _Led_Handle
psect	text39
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	975
	global	__size_of_Led_Handle
	__size_of_Led_Handle	equ	__end_of_Led_Handle-_Led_Handle
	
_Led_Handle:	
;incstack = 0
	opt	stack 6
; Regs used in _Led_Handle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	976
	
l10674:	
;main.c: 976: unsigned int i=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(Led_Handle@i)
	clrf	(Led_Handle@i+1)
	line	978
;main.c: 978: for(i=0;i<6;i++){
	clrf	(Led_Handle@i)
	clrf	(Led_Handle@i+1)
	line	979
	
l10680:	
;main.c: 979: LedMod[i].LedTime++;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	bsf	status, 7	;select IRP bank2
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	980
;main.c: 980: switch(LedMod[i].LedState){
	goto	l10724
	line	982
	
l10682:	
;main.c: 982: LedControlSt(i,0);
	clrf	(LedControlSt@Sta)
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	983
;main.c: 983: break;
	goto	l10726
	line	985
	
l10684:	
;main.c: 985: LedControlSt(i,1);
	clrf	(LedControlSt@Sta)
	incf	(LedControlSt@Sta),f
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	986
;main.c: 986: break;
	goto	l10726
	line	988
	
l10686:	
;main.c: 988: if(LedMod[i].LedFlashNum){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movf	((??_Led_Handle+0)+0),w
iorwf	((??_Led_Handle+0)+1),w
	btfsc	status,2
	goto	u9871
	goto	u9870
u9871:
	goto	l1165
u9870:
	line	989
	
l10688:	
;main.c: 989: if(LedMod[i].LedTime<=25){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	01Ah
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9881
	goto	u9880
u9881:
	goto	l10692
u9880:
	line	990
	
l10690:	
;main.c: 990: LedControlSt(i,0);
	clrf	(LedControlSt@Sta)
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	991
;main.c: 991: }
	goto	l10726
	line	992
	
l10692:	
;main.c: 992: else if(LedMod[i].LedTime<=25*2)
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	033h
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9891
	goto	u9890
u9891:
	goto	l10696
u9890:
	line	994
	
l10694:	
;main.c: 993: {
;main.c: 994: LedControlSt(i,1);
	clrf	(LedControlSt@Sta)
	incf	(LedControlSt@Sta),f
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	995
;main.c: 995: }
	goto	l10726
	line	998
	
l10696:	
;main.c: 996: else
;main.c: 997: {
;main.c: 998: LedMod[i].LedFlashNum--;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	movlw	low(01h)
	bsf	status, 7	;select IRP bank2
	subwf	indf,f
	incfsz	fsr0,f
	movlw	high(01h)
	skipc
	decf	indf,f
	subwf	indf,f
	decf	fsr0,f
	line	999
;main.c: 999: LedMod[i].LedTime=0;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l10726
	line	1002
	
l1165:	
	line	1004
;main.c: 1002: else
;main.c: 1003: {
;main.c: 1004: _BITS.Bits.bit_0=0;
	bcf	(__BITS),0
	goto	l10726
	line	1008
	
l10698:	
;main.c: 1008: if(LedMod[i].LedTime<=100){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	065h
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9901
	goto	u9900
u9901:
	goto	l10702
u9900:
	line	1009
	
l10700:	
;main.c: 1009: LedControlSt(i,1);
	clrf	(LedControlSt@Sta)
	incf	(LedControlSt@Sta),f
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	1010
;main.c: 1010: }
	goto	l10726
	line	1011
	
l10702:	
;main.c: 1011: else if(LedMod[i].LedTime<=100*2)
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	0C9h
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9911
	goto	u9910
u9911:
	goto	l10706
u9910:
	line	1013
	
l10704:	
;main.c: 1012: {
;main.c: 1013: LedControlSt(i,0);
	clrf	(LedControlSt@Sta)
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	1014
;main.c: 1014: }
	goto	l10726
	line	1017
	
l10706:	
;main.c: 1015: else
;main.c: 1016: {
;main.c: 1017: LedMod[i].LedTime=0;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l10726
	line	1022
	
l10708:	
;main.c: 1022: if(LedMod[i].LedFlashNum){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movf	((??_Led_Handle+0)+0),w
iorwf	((??_Led_Handle+0)+1),w
	btfsc	status,2
	goto	u9921
	goto	u9920
u9921:
	goto	l1177
u9920:
	line	1023
	
l10710:	
;main.c: 1023: if(LedMod[i].LedTime<=100){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	065h
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9931
	goto	u9930
u9931:
	goto	l10714
u9930:
	line	1024
	
l10712:	
;main.c: 1024: LedControlSt(i,0);
	clrf	(LedControlSt@Sta)
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	1025
;main.c: 1025: }
	goto	l10726
	line	1026
	
l10714:	
;main.c: 1026: else if(LedMod[i].LedTime<=100*2)
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	0C9h
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9941
	goto	u9940
u9941:
	goto	l10718
u9940:
	line	1028
	
l10716:	
;main.c: 1027: {
;main.c: 1028: LedControlSt(i,1);
	clrf	(LedControlSt@Sta)
	incf	(LedControlSt@Sta),f
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	1029
;main.c: 1029: }
	goto	l10726
	line	1032
	
l10718:	
;main.c: 1030: else
;main.c: 1031: {
;main.c: 1032: LedMod[i].LedFlashNum--;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	movlw	low(01h)
	bsf	status, 7	;select IRP bank2
	subwf	indf,f
	incfsz	fsr0,f
	movlw	high(01h)
	skipc
	decf	indf,f
	subwf	indf,f
	decf	fsr0,f
	line	1033
;main.c: 1033: LedMod[i].LedTime=0;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l10726
	line	1036
	
l1177:	
	line	1038
;main.c: 1036: else
;main.c: 1037: {
;main.c: 1038: _BITS.Bits.bit_0=0;
	bcf	(__BITS),0
	line	1039
	
l10720:	
;main.c: 1039: LedControlSt(i,0);
	clrf	(LedControlSt@Sta)
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	1040
;main.c: 1040: LedMod[i].LedState=0;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	goto	l10726
	line	980
	
l10724:	
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	; Switch size 1, requested type "space"
; Number of cases is 5, Range of values is 0 to 5
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           16     9 (average)
; direct_byte           26     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l10682
	xorlw	1^0	; case 1
	skipnz
	goto	l10684
	xorlw	2^1	; case 2
	skipnz
	goto	l10686
	xorlw	3^2	; case 3
	skipnz
	goto	l10698
	xorlw	5^3	; case 5
	skipnz
	goto	l10708
	goto	l10726
	opt asmopt_pop

	line	978
	
l10726:	
	incf	(Led_Handle@i),f
	skipnz
	incf	(Led_Handle@i+1),f
	
l10728:	
	movlw	0
	subwf	(Led_Handle@i+1),w
	movlw	06h
	skipnz
	subwf	(Led_Handle@i),w
	skipc
	goto	u9951
	goto	u9950
u9951:
	goto	l10680
u9950:
	line	1050
	
l1183:	
	return
	opt stack 0
GLOBAL	__end_of_Led_Handle
	__end_of_Led_Handle:
	signat	_Led_Handle,89
	global	_LedControlSt

;; *************** function _LedControlSt *****************
;; Defined at:
;;		line 893 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Num             1    wreg     unsigned char 
;;  Sta             1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  Num             1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Led_Handle
;; This function uses a non-reentrant model
;;
psect	text40,local,class=CODE,delta=2,merge=1,group=0
	line	893
global __ptext40
__ptext40:	;psect for function _LedControlSt
psect	text40
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	893
	global	__size_of_LedControlSt
	__size_of_LedControlSt	equ	__end_of_LedControlSt-_LedControlSt
	
_LedControlSt:	
;incstack = 0
	opt	stack 6
; Regs used in _LedControlSt: [wreg-fsr0h+status,2+status,0]
;LedControlSt@Num stored from wreg
	movwf	(LedControlSt@Num)
	line	895
	
l9436:	
;main.c: 895: switch(Num){
	goto	l9472
	line	897
	
l9438:	
;main.c: 897: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7751
	goto	u7750
u7751:
	goto	l1131
u7750:
	line	898
	
l9440:	
;main.c: 898: RB6=0;
	bcf	(54/8),(54)&7	;volatile
	line	899
;main.c: 899: }
	goto	l1155
	line	900
	
l1131:	
	line	902
;main.c: 900: else
;main.c: 901: {
;main.c: 902: RB6=1;
	bsf	(54/8),(54)&7	;volatile
	goto	l1155
	line	906
	
l9442:	
;main.c: 906: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7761
	goto	u7760
u7761:
	goto	l1135
u7760:
	line	907
	
l9444:	
;main.c: 907: RB3=0;
	bcf	(51/8),(51)&7	;volatile
	line	908
;main.c: 908: }
	goto	l1155
	line	909
	
l1135:	
	line	911
;main.c: 909: else
;main.c: 910: {
;main.c: 911: RB3=1;
	bsf	(51/8),(51)&7	;volatile
	goto	l1155
	line	915
	
l9446:	
;main.c: 915: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7771
	goto	u7770
u7771:
	goto	l1138
u7770:
	line	916
	
l9448:	
;main.c: 916: RA6=0;
	bcf	(46/8),(46)&7	;volatile
	line	917
;main.c: 917: }
	goto	l1155
	line	918
	
l1138:	
	line	920
;main.c: 918: else
;main.c: 919: {
;main.c: 920: RA6=1;
	bsf	(46/8),(46)&7	;volatile
	goto	l1155
	line	924
	
l9450:	
;main.c: 924: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7781
	goto	u7780
u7781:
	goto	l1141
u7780:
	line	925
	
l9452:	
;main.c: 925: RA7=0;
	bcf	(47/8),(47)&7	;volatile
	line	926
;main.c: 926: }
	goto	l1155
	line	927
	
l1141:	
	line	929
;main.c: 927: else
;main.c: 928: {
;main.c: 929: RA7=1;
	bsf	(47/8),(47)&7	;volatile
	goto	l1155
	line	933
	
l9454:	
;main.c: 933: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7791
	goto	u7790
u7791:
	goto	l1144
u7790:
	line	934
	
l9456:	
;main.c: 934: RB0=0;
	bcf	(48/8),(48)&7	;volatile
	line	935
;main.c: 935: }
	goto	l1155
	line	936
	
l1144:	
	line	938
;main.c: 936: else
;main.c: 937: {
;main.c: 938: RB0=1;
	bsf	(48/8),(48)&7	;volatile
	goto	l1155
	line	942
	
l9458:	
;main.c: 942: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7801
	goto	u7800
u7801:
	goto	l1147
u7800:
	line	943
	
l9460:	
;main.c: 943: RB2=0;
	bcf	(50/8),(50)&7	;volatile
	line	944
;main.c: 944: }
	goto	l1155
	line	945
	
l1147:	
	line	947
;main.c: 945: else
;main.c: 946: {
;main.c: 947: RB2=1;
	bsf	(50/8),(50)&7	;volatile
	goto	l1155
	line	951
	
l9462:	
;main.c: 951: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7811
	goto	u7810
u7811:
	goto	l1150
u7810:
	line	952
	
l9464:	
;main.c: 952: RB5=0;
	bcf	(53/8),(53)&7	;volatile
	line	953
;main.c: 953: }
	goto	l1155
	line	954
	
l1150:	
	line	956
;main.c: 954: else
;main.c: 955: {
;main.c: 956: RB5=1;
	bsf	(53/8),(53)&7	;volatile
	goto	l1155
	line	960
	
l9466:	
;main.c: 960: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7821
	goto	u7820
u7821:
	goto	l1153
u7820:
	line	961
	
l9468:	
;main.c: 961: RB4=0;
	bcf	(52/8),(52)&7	;volatile
	line	962
;main.c: 962: }
	goto	l1155
	line	963
	
l1153:	
	line	965
;main.c: 963: else
;main.c: 964: {
;main.c: 965: RB4=1;
	bsf	(52/8),(52)&7	;volatile
	goto	l1155
	line	895
	
l9472:	
	movf	(LedControlSt@Num),w
	; Switch size 1, requested type "space"
; Number of cases is 8, Range of values is 0 to 7
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           25    13 (average)
; direct_byte           32     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l9438
	xorlw	1^0	; case 1
	skipnz
	goto	l9442
	xorlw	2^1	; case 2
	skipnz
	goto	l9446
	xorlw	3^2	; case 3
	skipnz
	goto	l9450
	xorlw	4^3	; case 4
	skipnz
	goto	l9454
	xorlw	5^4	; case 5
	skipnz
	goto	l9458
	xorlw	6^5	; case 6
	skipnz
	goto	l9462
	xorlw	7^6	; case 7
	skipnz
	goto	l9466
	goto	l1155
	opt asmopt_pop

	line	971
	
l1155:	
	return
	opt stack 0
GLOBAL	__end_of_LedControlSt
	__end_of_LedControlSt:
	signat	_LedControlSt,8313
	global	_GetDelayFilterFlag

;; *************** function _GetDelayFilterFlag *****************
;; Defined at:
;;		line 412 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  PtrMin          1    wreg     PTR struct .
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;; Auto vars:     Size  Location     Type
;;  PtrMin          1    5[BANK0 ] PTR struct .
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0       3       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Dec
;;		_DecF
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text41,local,class=CODE,delta=2,merge=1,group=0
	line	412
global __ptext41
__ptext41:	;psect for function _GetDelayFilterFlag
psect	text41
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	412
	global	__size_of_GetDelayFilterFlag
	__size_of_GetDelayFilterFlag	equ	__end_of_GetDelayFilterFlag-_GetDelayFilterFlag
	
_GetDelayFilterFlag:	
;incstack = 0
	opt	stack 6
; Regs used in _GetDelayFilterFlag: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;GetDelayFilterFlag@PtrMin stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(GetDelayFilterFlag@PtrMin)
	line	415
	
l10344:	
;main.c: 415: if(Dec(&PtrMin->u8Second,59))
	movlw	low(03Bh)
	movwf	(Dec@max)
	movf	(GetDelayFilterFlag@PtrMin),w
	fcall	_Dec
	xorlw	0
	skipnz
	goto	u9221
	goto	u9220
u9221:
	goto	l10354
u9220:
	line	417
	
l10346:	
;main.c: 416: {
;main.c: 417: if(Dec(&PtrMin->u8Minute,59))
	movlw	low(03Bh)
	movwf	(Dec@max)
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	01h
	fcall	_Dec
	xorlw	0
	skipnz
	goto	u9231
	goto	u9230
u9231:
	goto	l10354
u9230:
	line	419
	
l10348:	
;main.c: 418: {
;main.c: 419: if(Dec(&PtrMin->u8Hour,23))
	movlw	low(017h)
	movwf	(Dec@max)
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	02h
	fcall	_Dec
	xorlw	0
	skipnz
	goto	u9241
	goto	u9240
u9241:
	goto	l10354
u9240:
	line	421
	
l10350:	
;main.c: 420: {
;main.c: 421: if(DecF(&PtrMin->u16Day,65535))
	movlw	0FFh
	movwf	(DecF@max)
	movlw	0FFh
	movwf	((DecF@max))+1
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	03h
	fcall	_DecF
	xorlw	0
	skipnz
	goto	u9251
	goto	u9250
u9251:
	goto	l1044
u9250:
	goto	l1047
	line	426
	
l1044:	
	line	428
	
l10354:	
;main.c: 424: }
;main.c: 425: }
;main.c: 426: }
;main.c: 427: }
;main.c: 428: if(FilterFastCheck==1){
		decf	((_FilterFastCheck)),w
	btfss	status,2
	goto	u9261
	goto	u9260
u9261:
	goto	l1047
u9260:
	line	429
	
l10356:	
;main.c: 429: if(PtrMin->u16Day>=1)
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	03h
	movwf	fsr0
	movf	indf,w
	movwf	(??_GetDelayFilterFlag+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_GetDelayFilterFlag+0)+0+1
	movf	((??_GetDelayFilterFlag+0)+0),w
iorwf	((??_GetDelayFilterFlag+0)+1),w
	btfsc	status,2
	goto	u9271
	goto	u9270
u9271:
	goto	l10360
u9270:
	line	430
	
l10358:	
;main.c: 430: PtrMin->u16Day-=1;
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	03h
	movwf	fsr0
	movlw	low(01h)
	subwf	indf,f
	incfsz	fsr0,f
	movlw	high(01h)
	skipc
	decf	indf,f
	subwf	indf,f
	decf	fsr0,f
	goto	l1047
	line	432
	
l10360:	
;main.c: 431: else
;main.c: 432: PtrMin->u16Day=0;
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	03h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	436
	
l1047:	
	return
	opt stack 0
GLOBAL	__end_of_GetDelayFilterFlag
	__end_of_GetDelayFilterFlag:
	signat	_GetDelayFilterFlag,4217
	global	_DecF

;; *************** function _DecF *****************
;; Defined at:
;;		line 396 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  var             1    wreg     PTR unsigned int 
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;;  max             2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  var             1    2[BANK0 ] PTR unsigned int 
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       2       0       0
;;      Totals:         2       3       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_GetDelayFilterFlag
;; This function uses a non-reentrant model
;;
psect	text42,local,class=CODE,delta=2,merge=1,group=0
	line	396
global __ptext42
__ptext42:	;psect for function _DecF
psect	text42
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	396
	global	__size_of_DecF
	__size_of_DecF	equ	__end_of_DecF-_DecF
	
_DecF:	
;incstack = 0
	opt	stack 6
; Regs used in _DecF: [wreg-fsr0h+status,2+status,0]
;DecF@var stored from wreg
	movwf	(DecF@var)
	line	398
	
l9406:	
;main.c: 398: if((*var)){(*var)--;}
	movf	(DecF@var),w
	movwf	fsr0
	movf	indf,w
	movwf	(??_DecF+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_DecF+0)+0+1
	movf	((??_DecF+0)+0),w
iorwf	((??_DecF+0)+1),w
	btfsc	status,2
	goto	u7731
	goto	u7730
u7731:
	goto	l9410
u7730:
	
l9408:	
	movf	(DecF@var),w
	movwf	fsr0
	movlw	low(01h)
	subwf	indf,f
	incfsz	fsr0,f
	movlw	high(01h)
	skipc
	decf	indf,f
	subwf	indf,f
	decf	fsr0,f
	goto	l9414
	line	399
	
l9410:	
;main.c: 399: else{return(1);}
	movlw	low(01h)
	goto	l1037
	line	401
	
l9414:	
;main.c: 401: return(0);
	movlw	low(0)
	line	402
	
l1037:	
	return
	opt stack 0
GLOBAL	__end_of_DecF
	__end_of_DecF:
	signat	_DecF,8313
	global	_Dec

;; *************** function _Dec *****************
;; Defined at:
;;		line 388 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  var             1    wreg     PTR unsigned char 
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;;  max             1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  var             1    5[COMMON] PTR unsigned char 
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : B00/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_GetDelayFilterFlag
;; This function uses a non-reentrant model
;;
psect	text43,local,class=CODE,delta=2,merge=1,group=0
	line	388
global __ptext43
__ptext43:	;psect for function _Dec
psect	text43
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	388
	global	__size_of_Dec
	__size_of_Dec	equ	__end_of_Dec-_Dec
	
_Dec:	
;incstack = 0
	opt	stack 6
; Regs used in _Dec: [wreg-fsr0h+status,2+status,0]
;Dec@var stored from wreg
	movwf	(Dec@var)
	line	390
	
l9392:	
;main.c: 390: if((*var)){(*var)--;}
	movf	(Dec@var),w
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	(indf),w
	btfsc	status,2
	goto	u7721
	goto	u7720
u7721:
	goto	l9396
u7720:
	
l9394:	
	movf	(Dec@var),w
	movwf	fsr0
	decf	indf,f
	goto	l9402
	line	391
	
l9396:	
;main.c: 391: else{(*var)=max;return(1);}
	movf	(Dec@var),w
	movwf	fsr0
	movf	(Dec@max),w
	movwf	indf
	
l9398:	
	movlw	low(01h)
	goto	l1032
	line	393
	
l9402:	
;main.c: 393: return(0);
	movlw	low(0)
	line	394
	
l1032:	
	return
	opt stack 0
GLOBAL	__end_of_Dec
	__end_of_Dec:
	signat	_Dec,8313
	global	_FilterLifeFunc

;; *************** function _FilterLifeFunc *****************
;; Defined at:
;;		line 1262 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_BuzzerSet
;;		_FilterTimeHandle
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text44,local,class=CODE,delta=2,merge=1,group=0
	line	1262
global __ptext44
__ptext44:	;psect for function _FilterLifeFunc
psect	text44
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	1262
	global	__size_of_FilterLifeFunc
	__size_of_FilterLifeFunc	equ	__end_of_FilterLifeFunc-_FilterLifeFunc
	
_FilterLifeFunc:	
;incstack = 0
	opt	stack 4
; Regs used in _FilterLifeFunc: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1266
	
l10642:	
;main.c: 1266: if((Mode!=0)&&(Mode!=3)&&(_BITS.Bits.bit_0==0)){
	movf	((_Mode)),w
	btfsc	status,2
	goto	u9781
	goto	u9780
u9781:
	goto	l1227
u9780:
	
l10644:	
		movlw	3
	xorwf	((_Mode)),w
	btfsc	status,2
	goto	u9791
	goto	u9790
u9791:
	goto	l1227
u9790:
	
l10646:	
	btfsc	(__BITS),0
	goto	u9801
	goto	u9800
u9801:
	goto	l1227
u9800:
	line	1267
	
l10648:	
;main.c: 1267: FilterTimeHandle(FilterRO_time,&FilterROState,1,&FilterROGetWater);
	movlw	(FilterTimeHandle@Filter_time)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_FilterRO_time)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterRO_time)^080h+1,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterRO_time)^080h+2,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterRO_time)^080h+3,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterRO_time)^080h+4,w
	movwf	indf
	movlw	(low(_FilterROState|((0x0)<<8)))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	movwf	(FilterTimeHandle@FilterState)
	clrf	(FilterTimeHandle@Type)
	incf	(FilterTimeHandle@Type),f
	movlw	(low(_FilterROGetWater|((0x0)<<8)))&0ffh
	movwf	(FilterTimeHandle@FilterGetWater)
	fcall	_FilterTimeHandle
	line	1270
;main.c: 1270: FilterTimeHandle(FilterPCF_time,&FilterPCFState,0,&FilterPCFGetWater);
	movlw	(FilterTimeHandle@Filter_time)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_FilterPCF_time)^080h,w
	bcf	status, 7	;select IRP bank0
	movwf	indf
	incf	fsr0,f
	movf	(_FilterPCF_time)^080h+1,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterPCF_time)^080h+2,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterPCF_time)^080h+3,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterPCF_time)^080h+4,w
	movwf	indf
	movlw	(low(_FilterPCFState|((0x0)<<8)))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	movwf	(FilterTimeHandle@FilterState)
	clrf	(FilterTimeHandle@Type)
	movlw	(low(_FilterPCFGetWater|((0x0)<<8)))&0ffh
	movwf	(FilterTimeHandle@FilterGetWater)
	fcall	_FilterTimeHandle
	line	1271
	
l10650:	
;main.c: 1271: if(FilterFastCheck==1)
	bcf	status, 5	;RP0=0, select bank0
		decf	((_FilterFastCheck)),w
	btfss	status,2
	goto	u9811
	goto	u9810
u9811:
	goto	l1227
u9810:
	line	1273
	
l10652:	
;main.c: 1272: {
;main.c: 1273: if((FilterPCFState==3)&&(FilterROState==3)){
		movlw	3
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u9821
	goto	u9820
u9821:
	goto	l1227
u9820:
	
l10654:	
		movlw	3
	xorwf	((_FilterROState)),w
	btfss	status,2
	goto	u9831
	goto	u9830
u9831:
	goto	l1227
u9830:
	line	1274
	
l10656:	
;main.c: 1274: FilterFastCheck=2;
	movlw	low(02h)
	movwf	(_FilterFastCheck)
	line	1275
	
l10658:	
;main.c: 1275: BuzzerSet(3, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(03h)
	fcall	_BuzzerSet
	line	1282
	
l1227:	
	return
	opt stack 0
GLOBAL	__end_of_FilterLifeFunc
	__end_of_FilterLifeFunc:
	signat	_FilterLifeFunc,89
	global	_FilterTimeHandle

;; *************** function _FilterTimeHandle *****************
;; Defined at:
;;		line 1152 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Filter_time     5    3[BANK0 ] struct .
;;  FilterState     1    8[BANK0 ] PTR unsigned char 
;;		 -> FilterPCFState(1), FilterROState(1), 
;;  Type            1    9[BANK0 ] unsigned char 
;;  FilterGetWat    1   10[BANK0 ] PTR unsigned int 
;;		 -> FilterPCFGetWater(2), FilterROGetWater(2), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       8       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       4       0       0
;;      Totals:         0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_LedSetSt
;; This function is called by:
;;		_FilterLifeFunc
;; This function uses a non-reentrant model
;;
psect	text45,local,class=CODE,delta=2,merge=1,group=0
	line	1152
global __ptext45
__ptext45:	;psect for function _FilterTimeHandle
psect	text45
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	1152
	global	__size_of_FilterTimeHandle
	__size_of_FilterTimeHandle	equ	__end_of_FilterTimeHandle-_FilterTimeHandle
	
_FilterTimeHandle:	
;incstack = 0
	opt	stack 4
; Regs used in _FilterTimeHandle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1155
	
l9474:	
;main.c: 1155: Date_Temp=14;
	movlw	0Eh
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Date_Temp)^080h
	clrf	(_Date_Temp+1)^080h
	line	1156
	
l9476:	
;main.c: 1156: if(_BITS.Bits.bit_1==1) return;
	btfss	(__BITS),1
	goto	u7831
	goto	u7830
u7831:
	goto	l9480
u7830:
	goto	l1191
	line	1157
	
l9480:	
;main.c: 1157: if(Type==0){
	bcf	status, 5	;RP0=0, select bank0
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7841
	goto	u7840
u7841:
	goto	l9484
u7840:
	line	1158
	
l9482:	
;main.c: 1158: ML_Temp=3650;
	movlw	042h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_ML_Temp)^080h
	movlw	0Eh
	movwf	((_ML_Temp)^080h)+1
	line	1159
;main.c: 1159: }
	goto	l9486
	line	1162
	
l9484:	
;main.c: 1160: else
;main.c: 1161: {
;main.c: 1162: ML_Temp=18250;
	movlw	04Ah
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_ML_Temp)^080h
	movlw	047h
	movwf	((_ML_Temp)^080h)+1
	line	1165
	
l9486:	
;main.c: 1163: }
;main.c: 1165: if(Filter_time.u16Day<=0){
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(FilterTimeHandle@Filter_time)+03h),w
iorwf	(1+(FilterTimeHandle@Filter_time)+03h),w
	btfss	status,2
	goto	u7851
	goto	u7850
u7851:
	goto	l9496
u7850:
	line	1167
	
l9488:	
;main.c: 1167: *FilterState=3;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(03h)
	movwf	indf
	line	1168
	
l9490:	
;main.c: 1168: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7861
	goto	u7860
u7861:
	goto	l9494
u7860:
	line	1169
	
l9492:	
;main.c: 1169: LedSetSt(4,1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(04h)
	fcall	_LedSetSt
	line	1170
;main.c: 1170: LedSetSt(5, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1171
;main.c: 1171: }
	goto	l1197
	line	1174
	
l9494:	
;main.c: 1172: else
;main.c: 1173: {
;main.c: 1174: LedSetSt(2, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(02h)
	fcall	_LedSetSt
	line	1175
;main.c: 1175: LedSetSt(3, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	goto	l1197
	line	1178
	
l9496:	
;main.c: 1178: else if(Filter_time.u16Day<=Date_Temp)
	movlw	0
	subwf	1+(FilterTimeHandle@Filter_time)+03h,w
	movlw	0Fh
	skipnz
	subwf	0+(FilterTimeHandle@Filter_time)+03h,w
	skipnc
	goto	u7871
	goto	u7870
u7871:
	goto	l9510
u7870:
	line	1180
	
l9498:	
;main.c: 1179: {
;main.c: 1180: if(*FilterState!=2){
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
		movlw	2
	xorwf	(indf),w
	btfsc	status,2
	goto	u7881
	goto	u7880
u7881:
	goto	l9506
u7880:
	line	1181
	
l9500:	
;main.c: 1181: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7891
	goto	u7890
u7891:
	goto	l9504
u7890:
	line	1182
	
l9502:	
;main.c: 1182: LedSetSt(4, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1183
;main.c: 1183: LedSetSt(5, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1184
;main.c: 1184: }
	goto	l9506
	line	1187
	
l9504:	
;main.c: 1185: else
;main.c: 1186: {
;main.c: 1187: LedSetSt(2, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1188
;main.c: 1188: LedSetSt(3, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1191
	
l9506:	
;main.c: 1189: }
;main.c: 1190: }
;main.c: 1191: if(*FilterState<=2)
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(03h)
	bcf	status, 7	;select IRP bank0
	subwf	indf,w
	skipnc
	goto	u7901
	goto	u7900
u7901:
	goto	l1197
u7900:
	line	1192
	
l9508:	
;main.c: 1192: *FilterState=2;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(02h)
	movwf	indf
	goto	l1197
	line	1196
	
l9510:	
;main.c: 1194: else
;main.c: 1195: {
;main.c: 1196: if(*FilterState==1){
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
		decf	(indf),w
	btfss	status,2
	goto	u7911
	goto	u7910
u7911:
	goto	l9518
u7910:
	line	1197
	
l9512:	
;main.c: 1197: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7921
	goto	u7920
u7921:
	goto	l9516
u7920:
	line	1198
	
l9514:	
;main.c: 1198: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1199
;main.c: 1199: LedSetSt(5, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(05h)
	fcall	_LedSetSt
	line	1200
;main.c: 1200: }
	goto	l9518
	line	1203
	
l9516:	
;main.c: 1201: else
;main.c: 1202: {
;main.c: 1203: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1204
;main.c: 1204: LedSetSt(3, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(03h)
	fcall	_LedSetSt
	line	1207
	
l9518:	
;main.c: 1205: }
;main.c: 1206: }
;main.c: 1207: if(*FilterState<=1)
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(02h)
	bcf	status, 7	;select IRP bank0
	subwf	indf,w
	skipnc
	goto	u7931
	goto	u7930
u7931:
	goto	l1197
u7930:
	line	1208
	
l9520:	
;main.c: 1208: *FilterState=1;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	1209
	
l1197:	
	line	1212
;main.c: 1209: }
;main.c: 1212: if(*FilterGetWater>=ML_Temp){
	movf	(FilterTimeHandle@FilterGetWater),w
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	movwf	(??_FilterTimeHandle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_FilterTimeHandle+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(_ML_Temp+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_FilterTimeHandle+0)+0,w
	skipz
	goto	u7945
	bsf	status, 5	;RP0=1, select bank1
	movf	(_ML_Temp)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_FilterTimeHandle+0)+0,w
u7945:
	skipc
	goto	u7941
	goto	u7940
u7941:
	goto	l9530
u7940:
	line	1214
	
l9522:	
;main.c: 1214: *FilterState=3;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(03h)
	movwf	indf
	line	1215
	
l9524:	
;main.c: 1215: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7951
	goto	u7950
u7951:
	goto	l9528
u7950:
	line	1216
	
l9526:	
;main.c: 1216: LedSetSt(4, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(04h)
	fcall	_LedSetSt
	line	1217
;main.c: 1217: LedSetSt(5, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1218
;main.c: 1218: }
	goto	l1191
	line	1221
	
l9528:	
;main.c: 1219: else
;main.c: 1220: {
;main.c: 1221: LedSetSt(2, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(02h)
	fcall	_LedSetSt
	line	1222
;main.c: 1222: LedSetSt(3, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	goto	l1191
	line	1225
	
l9530:	
;main.c: 1225: else if(*FilterGetWater>=ML_Temp-140)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_ML_Temp)^080h,w
	addlw	low(0FF74h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_FilterTimeHandle+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_ML_Temp+1)^080h,w
	skipnc
	addlw	1
	addlw	high(0FF74h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_FilterTimeHandle+0)+0
	movf	(FilterTimeHandle@FilterGetWater),w
	movwf	fsr0
	movf	indf,w
	movwf	(??_FilterTimeHandle+2)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_FilterTimeHandle+2)+0+1
	movf	1+(??_FilterTimeHandle+0)+0,w
	subwf	1+(??_FilterTimeHandle+2)+0,w
	skipz
	goto	u7965
	movf	0+(??_FilterTimeHandle+0)+0,w
	subwf	0+(??_FilterTimeHandle+2)+0,w
u7965:
	skipc
	goto	u7961
	goto	u7960
u7961:
	goto	l9544
u7960:
	line	1228
	
l9532:	
;main.c: 1227: {
;main.c: 1228: if(*FilterState!=2){
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
		movlw	2
	xorwf	(indf),w
	btfsc	status,2
	goto	u7971
	goto	u7970
u7971:
	goto	l9540
u7970:
	line	1229
	
l9534:	
;main.c: 1229: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7981
	goto	u7980
u7981:
	goto	l9538
u7980:
	line	1230
	
l9536:	
;main.c: 1230: LedSetSt(4, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1231
;main.c: 1231: LedSetSt(5, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1232
;main.c: 1232: }
	goto	l9540
	line	1235
	
l9538:	
;main.c: 1233: else
;main.c: 1234: {
;main.c: 1235: LedSetSt(2, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1236
;main.c: 1236: LedSetSt(3, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1239
	
l9540:	
;main.c: 1237: }
;main.c: 1238: }
;main.c: 1239: if(*FilterState<=2)
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(03h)
	bcf	status, 7	;select IRP bank0
	subwf	indf,w
	skipnc
	goto	u7991
	goto	u7990
u7991:
	goto	l1191
u7990:
	line	1240
	
l9542:	
;main.c: 1240: *FilterState=2;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(02h)
	movwf	indf
	goto	l1191
	line	1244
	
l9544:	
;main.c: 1242: else
;main.c: 1243: {
;main.c: 1244: if(*FilterState==1){
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
		decf	(indf),w
	btfss	status,2
	goto	u8001
	goto	u8000
u8001:
	goto	l9552
u8000:
	line	1245
	
l9546:	
;main.c: 1245: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u8011
	goto	u8010
u8011:
	goto	l9550
u8010:
	line	1246
	
l9548:	
;main.c: 1246: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1247
;main.c: 1247: LedSetSt(5, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(05h)
	fcall	_LedSetSt
	line	1248
;main.c: 1248: }
	goto	l9552
	line	1251
	
l9550:	
;main.c: 1249: else
;main.c: 1250: {
;main.c: 1251: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1252
;main.c: 1252: LedSetSt(3, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(03h)
	fcall	_LedSetSt
	line	1255
	
l9552:	
;main.c: 1253: }
;main.c: 1254: }
;main.c: 1255: if(*FilterState<=1)
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(02h)
	bcf	status, 7	;select IRP bank0
	subwf	indf,w
	skipnc
	goto	u8021
	goto	u8020
u8021:
	goto	l1191
u8020:
	line	1256
	
l9554:	
;main.c: 1256: *FilterState=1;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	1259
	
l1191:	
	return
	opt stack 0
GLOBAL	__end_of_FilterTimeHandle
	__end_of_FilterTimeHandle:
	signat	_FilterTimeHandle,16505
	global	_FilterKeyInputRest

;; *************** function _FilterKeyInputRest *****************
;; Defined at:
;;		line 1624 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_BuzzerSet
;;		_LedSetSt
;;		_SetFilterDelayReset
;;		_ShiftMode_Handle
;;		_WrterEEP
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text46,local,class=CODE,delta=2,merge=1,group=0
	line	1624
global __ptext46
__ptext46:	;psect for function _FilterKeyInputRest
psect	text46
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	1624
	global	__size_of_FilterKeyInputRest
	__size_of_FilterKeyInputRest	equ	__end_of_FilterKeyInputRest-_FilterKeyInputRest
	
_FilterKeyInputRest:	
;incstack = 0
	opt	stack 4
; Regs used in _FilterKeyInputRest: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1628
	
l10730:	
;main.c: 1625: static U16_T FilterSelect_10ms;
;main.c: 1626: static U16_T PreFilterPCFGetWater;
;main.c: 1627: static U16_T PreFilterROGetWater;
;main.c: 1628: if((Mode==0)||(Mode==3)) return;
	movf	((_Mode)),w
	btfsc	status,2
	goto	u9961
	goto	u9960
u9961:
	goto	l1328
u9960:
	
l10732:	
		movlw	3
	xorwf	((_Mode)),w
	btfss	status,2
	goto	u9971
	goto	u9970
u9971:
	goto	l10734
u9970:
	goto	l1328
	
l1327:	
	goto	l1328
	line	1630
	
l10734:	
;main.c: 1629: if((KeyPacket_y[1].KeyState==LongPressDown)
;main.c: 1630: &&(KeyPacket_y[2].KeyState==NotPress))
		movlw	2
	xorwf	(0+(_KeyPacket_y)+03h),w
	btfss	status,2
	goto	u9981
	goto	u9980
u9981:
	goto	l10792
u9980:
	
l10736:	
	movf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u9991
	goto	u9990
u9991:
	goto	l10792
u9990:
	line	1632
	
l10738:	
;main.c: 1631: {
;main.c: 1632: KeyPacket_y[1].KeyState=SuperPressDown;
	movlw	low(03h)
	movwf	0+(_KeyPacket_y)+03h
	line	1633
;main.c: 1633: if(Time_Power_1s<=10){
	movlw	low(0Bh)
	subwf	(_Time_Power_1s),w
	skipnc
	goto	u10001
	goto	u10000
u10001:
	goto	l10744
u10000:
	line	1634
	
l10740:	
;main.c: 1634: ShiftMode_Handle(5);
	movlw	low(05h)
	fcall	_ShiftMode_Handle
	line	1635
	
l10742:	
;main.c: 1635: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1636
;main.c: 1636: }
	goto	l10790
	line	1639
	
l10744:	
;main.c: 1637: else
;main.c: 1638: {
;main.c: 1639: _BITS.Bits.bit_1^=1;
	movlw	1<<1
	xorwf	(__BITS),f
	line	1640
	
l10746:	
;main.c: 1640: if(_BITS.Bits.bit_1==0){
	btfsc	(__BITS),1
	goto	u10011
	goto	u10010
u10011:
	goto	l1332
u10010:
	line	1641
	
l10748:	
;main.c: 1641: FilterSelect_10ms=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(FilterKeyInputRest@FilterSelect_10ms)^080h
	clrf	(FilterKeyInputRest@FilterSelect_10ms+1)^080h
	line	1642
	
l10750:	
;main.c: 1642: if(_BITS.Bits.bit_3==0)
	btfsc	(__BITS),3
	goto	u10021
	goto	u10020
u10021:
	goto	l10768
u10020:
	line	1644
	
l10752:	
;main.c: 1643: {
;main.c: 1644: PrePCFu16Day=FilterPCF_time.u16Day;
	movf	1+(_FilterPCF_time)^080h+03h,w
	movwf	(_PrePCFu16Day+1)^080h
	movf	0+(_FilterPCF_time)^080h+03h,w
	movwf	(_PrePCFu16Day)^080h
	line	1645
	
l10754:	
;main.c: 1645: SetFilterDelayReset(&FilterPCF_time, 365, 0, 0, 0);
	movlw	06Dh
	bcf	status, 5	;RP0=0, select bank0
	movwf	(SetFilterDelayReset@Day)
	movlw	01h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterPCF_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	1646
	
l10756:	
;main.c: 1646: PreFilterPCFGetWater=FilterPCFGetWater;
	movf	(_FilterPCFGetWater+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(FilterKeyInputRest@PreFilterPCFGetWater+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_FilterPCFGetWater),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(FilterKeyInputRest@PreFilterPCFGetWater)^080h
	line	1647
	
l10758:	
;main.c: 1647: FilterPCFGetWater=0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_FilterPCFGetWater)
	clrf	(_FilterPCFGetWater+1)
	line	1648
	
l10760:	
;main.c: 1648: FilterPCFState=1;
	clrf	(_FilterPCFState)
	incf	(_FilterPCFState),f
	line	1649
	
l10762:	
;main.c: 1649: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1650
	
l10764:	
;main.c: 1650: LedSetSt(5, 2);
	movlw	low(02h)
	movwf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1651
	
l10766:	
;main.c: 1651: _BITS1.Bits.bit_3=1;
	bsf	(__BITS1),3
	line	1652
;main.c: 1652: }
	goto	l10784
	line	1655
	
l10768:	
;main.c: 1653: else
;main.c: 1654: {
;main.c: 1655: PreROu16Day=FilterRO_time.u16Day;
	movf	1+(_FilterRO_time)^080h+03h,w
	movwf	(_PreROu16Day+1)^080h
	movf	0+(_FilterRO_time)^080h+03h,w
	movwf	(_PreROu16Day)^080h
	line	1656
	
l10770:	
;main.c: 1656: SetFilterDelayReset(&FilterRO_time, 1825, 0, 0, 0);
	movlw	021h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(SetFilterDelayReset@Day)
	movlw	07h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterRO_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	1657
	
l10772:	
;main.c: 1657: PreFilterROGetWater=FilterROGetWater;
	movf	(_FilterROGetWater+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(FilterKeyInputRest@PreFilterROGetWater+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(_FilterROGetWater),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(FilterKeyInputRest@PreFilterROGetWater)^080h
	line	1658
	
l10774:	
;main.c: 1658: FilterROGetWater=0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_FilterROGetWater)
	clrf	(_FilterROGetWater+1)
	line	1659
	
l10776:	
;main.c: 1659: FilterROState=1;
	clrf	(_FilterROState)
	incf	(_FilterROState),f
	line	1660
	
l10778:	
;main.c: 1660: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1661
	
l10780:	
;main.c: 1661: LedSetSt(3, 2);
	movlw	low(02h)
	movwf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1662
	
l10782:	
;main.c: 1662: _BITS1.Bits.bit_2=1;
	bsf	(__BITS1),2
	line	1664
	
l10784:	
;main.c: 1663: }
;main.c: 1664: _BITS1.Bits.bit_7=0;
	bcf	(__BITS1),7
	line	1665
	
l10786:	
;main.c: 1665: FilterRst_1s=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_FilterRst_1s)^080h
	clrf	(_FilterRst_1s+1)^080h
	line	1666
	
l10788:	
;main.c: 1666: WrterEEP();
	fcall	_WrterEEP
	line	1667
;main.c: 1667: }
	goto	l10790
	line	1668
	
l1332:	
	line	1670
;main.c: 1668: else
;main.c: 1669: {
;main.c: 1670: _BITS.Bits.bit_3=1;
	bsf	(__BITS),3
	line	1673
	
l10790:	
;main.c: 1671: }
;main.c: 1672: }
;main.c: 1673: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1675
	
l10792:	
;main.c: 1674: }
;main.c: 1675: if(_BITS.Bits.bit_1==1){
	btfss	(__BITS),1
	goto	u10031
	goto	u10030
u10031:
	goto	l10830
u10030:
	line	1676
	
l10794:	
;main.c: 1676: if(++FilterSelect_10ms>=1000){
	bsf	status, 5	;RP0=1, select bank1
	incf	(FilterKeyInputRest@FilterSelect_10ms)^080h,f
	skipnz
	incf	(FilterKeyInputRest@FilterSelect_10ms+1)^080h,f
	movlw	03h
	subwf	((FilterKeyInputRest@FilterSelect_10ms+1)^080h),w
	movlw	0E8h
	skipnz
	subwf	((FilterKeyInputRest@FilterSelect_10ms)^080h),w
	skipc
	goto	u10041
	goto	u10040
u10041:
	goto	l10804
u10040:
	line	1677
	
l10796:	
;main.c: 1677: FilterSelect_10ms=0;
	clrf	(FilterKeyInputRest@FilterSelect_10ms)^080h
	clrf	(FilterKeyInputRest@FilterSelect_10ms+1)^080h
	line	1678
	
l10798:	
;main.c: 1678: BuzzerSet(1, 50);
	movlw	032h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1679
	
l10800:	
;main.c: 1679: _BITS.Bits.bit_1=0;
	bcf	(__BITS),1
	goto	l1328
	line	1683
	
l10804:	
;main.c: 1682: }
;main.c: 1683: if(KeyPacket_y[1].KeyState==ShortRelease)
		movlw	6
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(0+(_KeyPacket_y)+03h),w
	btfss	status,2
	goto	u10051
	goto	u10050
u10051:
	goto	l10812
u10050:
	line	1686
	
l10806:	
;main.c: 1686: BuzzerSet(1, 50);
	movlw	032h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1687
	
l10808:	
;main.c: 1687: FilterSelect_10ms=0;
	clrf	(FilterKeyInputRest@FilterSelect_10ms)^080h
	clrf	(FilterKeyInputRest@FilterSelect_10ms+1)^080h
	line	1688
	
l10810:	
;main.c: 1688: _BITS.Bits.bit_3^=1;
	movlw	1<<3
	xorwf	(__BITS),f
	line	1691
	
l10812:	
;main.c: 1689: }
;main.c: 1691: if(_BITS.Bits.bit_3==0){
	btfsc	(__BITS),3
	goto	u10061
	goto	u10060
u10061:
	goto	l10822
u10060:
	line	1692
	
l10814:	
;main.c: 1692: LedSetSt(3,0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1693
;main.c: 1693: LedSetSt(2,0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1694
	
l10816:	
;main.c: 1694: if(FilterPCFState==1){
		decf	((_FilterPCFState)),w
	btfss	status,2
	goto	u10071
	goto	u10070
u10071:
	goto	l10820
u10070:
	line	1695
	
l10818:	
;main.c: 1695: LedSetSt(5, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1696
;main.c: 1696: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1697
;main.c: 1697: }
	goto	l10830
	line	1700
	
l10820:	
;main.c: 1698: else
;main.c: 1699: {
;main.c: 1700: LedSetSt(4, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1701
;main.c: 1701: LedSetSt(5, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	goto	l10830
	line	1706
	
l10822:	
;main.c: 1704: else
;main.c: 1705: {
;main.c: 1706: LedSetSt(5,0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1707
;main.c: 1707: LedSetSt(4,0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1708
	
l10824:	
;main.c: 1708: if(FilterROState==1){
		decf	((_FilterROState)),w
	btfss	status,2
	goto	u10081
	goto	u10080
u10081:
	goto	l10828
u10080:
	line	1709
	
l10826:	
;main.c: 1709: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1710
;main.c: 1710: LedSetSt(3, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1711
;main.c: 1711: }
	goto	l10830
	line	1714
	
l10828:	
;main.c: 1712: else
;main.c: 1713: {
;main.c: 1714: LedSetSt(3, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1715
;main.c: 1715: LedSetSt(2, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1721
	
l10830:	
;main.c: 1716: }
;main.c: 1717: }
;main.c: 1718: }
;main.c: 1720: if((KeyPacket_y[2].KeyState==LongPressDown)
;main.c: 1721: &&(KeyPacket_y[1].KeyState==LongPressDown))
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u10091
	goto	u10090
u10091:
	goto	l1328
u10090:
	
l10832:	
		movlw	2
	xorwf	(0+(_KeyPacket_y)+03h),w
	btfss	status,2
	goto	u10101
	goto	u10100
u10101:
	goto	l1328
u10100:
	line	1723
	
l10834:	
;main.c: 1722: {
;main.c: 1723: KeyPacket_y[2].KeyState=SuperPressDown;
	movlw	low(03h)
	movwf	0+(_KeyPacket_y)+06h
	line	1724
;main.c: 1724: KeyPacket_y[1].KeyState=SuperPressDown;
	movlw	low(03h)
	movwf	0+(_KeyPacket_y)+03h
	line	1726
;main.c: 1726: if(Time_Power_1s<=10){
	movlw	low(0Bh)
	subwf	(_Time_Power_1s),w
	skipnc
	goto	u10111
	goto	u10110
u10111:
	goto	l10856
u10110:
	line	1727
	
l10836:	
;main.c: 1727: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1729
	
l10838:	
;main.c: 1729: ShiftMode_Handle(0);
	movlw	low(0)
	fcall	_ShiftMode_Handle
	line	1730
	
l10840:	
;main.c: 1730: PowerStep=3;
	movlw	low(03h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_PowerStep)
	line	1731
	
l10842:	
;main.c: 1731: SetFilterDelayReset(&FilterPCF_time, 365, 0, 0, 0);
	movlw	06Dh
	movwf	(SetFilterDelayReset@Day)
	movlw	01h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterPCF_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	1732
	
l10844:	
;main.c: 1732: SetFilterDelayReset(&FilterRO_time, 1825, 0, 0, 0);
	movlw	021h
	movwf	(SetFilterDelayReset@Day)
	movlw	07h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterRO_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	1733
	
l10846:	
;main.c: 1733: FilterROGetWater=0;
	clrf	(_FilterROGetWater)
	clrf	(_FilterROGetWater+1)
	line	1734
	
l10848:	
;main.c: 1734: FilterPCFGetWater=0;
	clrf	(_FilterPCFGetWater)
	clrf	(_FilterPCFGetWater+1)
	line	1735
	
l10850:	
;main.c: 1735: _BITS1.Bits.bit_7=0;
	bcf	(__BITS1),7
	line	1736
	
l10852:	
;main.c: 1736: Read_Word_Buff[11]=1;
	bsf	status, 5	;RP0=1, select bank1
	clrf	0+(_Read_Word_Buff)^080h+0Bh
	incf	0+(_Read_Word_Buff)^080h+0Bh,f
	line	1737
	
l10854:	
;main.c: 1737: WrterEEP();
	fcall	_WrterEEP
	line	1738
;main.c: 1738: }
	goto	l1328
	line	1742
	
l10856:	
;main.c: 1739: else
;main.c: 1740: {
;main.c: 1742: if((FilterRst_1s<300)&&((_BITS1.Bits.bit_3)||(_BITS1.Bits.bit_2))){
	movlw	01h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_FilterRst_1s+1)^080h,w
	movlw	02Ch
	skipnz
	subwf	(_FilterRst_1s)^080h,w
	skipnc
	goto	u10121
	goto	u10120
u10121:
	goto	l1348
u10120:
	
l10858:	
	bcf	status, 5	;RP0=0, select bank0
	btfsc	(__BITS1),3
	goto	u10131
	goto	u10130
u10131:
	goto	l1350
u10130:
	
l10860:	
	btfss	(__BITS1),2
	goto	u10141
	goto	u10140
u10141:
	goto	l1348
u10140:
	
l1350:	
	line	1743
;main.c: 1743: if(_BITS.Bits.bit_1==0){
	btfsc	(__BITS),1
	goto	u10151
	goto	u10150
u10151:
	goto	l1327
u10150:
	line	1745
	
l10862:	
;main.c: 1745: BuzzerSet(3, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(03h)
	fcall	_BuzzerSet
	line	1748
	
l10864:	
;main.c: 1748: if(_BITS1.Bits.bit_3){
	bcf	status, 5	;RP0=0, select bank0
	btfss	(__BITS1),3
	goto	u10161
	goto	u10160
u10161:
	goto	l10874
u10160:
	line	1749
	
l10866:	
;main.c: 1749: _BITS1.Bits.bit_3=0;
	bcf	(__BITS1),3
	line	1750
	
l10868:	
;main.c: 1750: FilterPCF_time.u16Day=PrePCFu16Day;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_PrePCFu16Day+1)^080h,w
	movwf	1+(_FilterPCF_time)^080h+03h
	movf	(_PrePCFu16Day)^080h,w
	movwf	0+(_FilterPCF_time)^080h+03h
	line	1751
;main.c: 1751: FilterPCFGetWater=PreFilterPCFGetWater;
	movf	(FilterKeyInputRest@PreFilterPCFGetWater+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_FilterPCFGetWater+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(FilterKeyInputRest@PreFilterPCFGetWater)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_FilterPCFGetWater)
	line	1752
	
l10870:	
;main.c: 1752: LedSetSt(5, 5);
	movlw	low(05h)
	movwf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1753
	
l10872:	
;main.c: 1753: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1755
	
l10874:	
;main.c: 1754: }
;main.c: 1755: if(_BITS1.Bits.bit_2){
	btfss	(__BITS1),2
	goto	u10171
	goto	u10170
u10171:
	goto	l10854
u10170:
	line	1756
	
l10876:	
;main.c: 1756: _BITS1.Bits.bit_2=0;
	bcf	(__BITS1),2
	line	1757
	
l10878:	
;main.c: 1757: FilterRO_time.u16Day=PreROu16Day;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_PreROu16Day+1)^080h,w
	movwf	1+(_FilterRO_time)^080h+03h
	movf	(_PreROu16Day)^080h,w
	movwf	0+(_FilterRO_time)^080h+03h
	line	1758
;main.c: 1758: FilterROGetWater=PreFilterROGetWater;
	movf	(FilterKeyInputRest@PreFilterROGetWater+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_FilterROGetWater+1)
	bsf	status, 5	;RP0=1, select bank1
	movf	(FilterKeyInputRest@PreFilterROGetWater)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_FilterROGetWater)
	line	1759
	
l10880:	
;main.c: 1759: LedSetSt(3, 5);
	movlw	low(05h)
	movwf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1760
	
l10882:	
;main.c: 1760: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	goto	l10854
	line	1765
	
l1348:	
	line	1767
;main.c: 1765: else
;main.c: 1766: {
;main.c: 1767: _BITS1.Bits.bit_3=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(__BITS1),3
	line	1768
;main.c: 1768: _BITS1.Bits.bit_2=0;
	bcf	(__BITS1),2
	line	1772
	
l1328:	
	return
	opt stack 0
GLOBAL	__end_of_FilterKeyInputRest
	__end_of_FilterKeyInputRest:
	signat	_FilterKeyInputRest,89
	global	_ErrorHandle

;; *************** function _ErrorHandle *****************
;; Defined at:
;;		line 2166 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_AllLedFlash
;;		_BuzzerSet
;;		_GetStop
;;		_LedSetSt
;;		_ShiftMode_Handle
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text47,local,class=CODE,delta=2,merge=1,group=0
	line	2166
global __ptext47
__ptext47:	;psect for function _ErrorHandle
psect	text47
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	2166
	global	__size_of_ErrorHandle
	__size_of_ErrorHandle	equ	__end_of_ErrorHandle-_ErrorHandle
	
_ErrorHandle:	
;incstack = 0
	opt	stack 4
; Regs used in _ErrorHandle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	2171
	
l10966:	
;main.c: 2171: if(Timer_LongGetWater_1s>=1800){
	movlw	07h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_LongGetWater_1s+1)^080h,w
	movlw	08h
	skipnz
	subwf	(_Timer_LongGetWater_1s)^080h,w
	skipc
	goto	u10311
	goto	u10310
u10311:
	goto	l10986
u10310:
	line	2174
	
l10968:	
;main.c: 2174: ShiftMode_Handle(3);
	movlw	low(03h)
	fcall	_ShiftMode_Handle
	line	2177
	
l10970:	
;main.c: 2177: if(ErrorVar==0x00){
	bcf	status, 5	;RP0=0, select bank0
	movf	((_ErrorVar)),w
	btfss	status,2
	goto	u10321
	goto	u10320
u10321:
	goto	l10982
u10320:
	line	2178
	
l10972:	
;main.c: 2178: Timer_ErrorLong_1s=0;
	clrf	(_Timer_ErrorLong_1s)
	line	2179
	
l10974:	
;main.c: 2179: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	2180
	
l10976:	
;main.c: 2180: LedSetSt(4, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	2181
	
l10978:	
;main.c: 2181: LedSetSt(2, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	2182
	
l10980:	
;main.c: 2182: LedSetSt(0, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(0)
	fcall	_LedSetSt
	line	2184
	
l10982:	
;main.c: 2183: }
;main.c: 2184: ErrorVar=0x02;
	movlw	low(02h)
	movwf	(_ErrorVar)
	line	2185
	
l10984:	
;main.c: 2185: GetStop();
	fcall	_GetStop
	line	2188
	
l10986:	
;main.c: 2186: }
;main.c: 2188: if((Timer_ErrorLong_1s<=30)&&(Mode==3)){
	movlw	low(01Fh)
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_Timer_ErrorLong_1s),w
	skipnc
	goto	u10331
	goto	u10330
u10331:
	goto	l1441
u10330:
	
l10988:	
		movlw	3
	xorwf	((_Mode)),w
	btfss	status,2
	goto	u10341
	goto	u10340
u10341:
	goto	l1441
u10340:
	line	2189
	
l10990:	
;main.c: 2189: Timer_ErrorLong_1s++;
	incf	(_Timer_ErrorLong_1s),f
	line	2190
	
l10992:	
;main.c: 2190: if(Timer_ErrorLong_1s%2==0){
	btfsc	(_Timer_ErrorLong_1s),(0)&7
	goto	u10351
	goto	u10350
u10351:
	goto	l1441
u10350:
	line	2191
	
l10994:	
;main.c: 2191: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	2197
	
l1441:	
	return
	opt stack 0
GLOBAL	__end_of_ErrorHandle
	__end_of_ErrorHandle:
	signat	_ErrorHandle,89
	global	_ShiftMode_Handle

;; *************** function _ShiftMode_Handle *****************
;; Defined at:
;;		line 1297 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Mod             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  Mod             1    3[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       1       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_BuzzerSet
;;		_LedSetSt
;;		_SetStandbyState
;; This function is called by:
;;		_GetMode_Handle
;;		_FilterKeyInputRest
;;		_StandbyMode_Handle
;;		_Run_Mode
;;		_ErrorHandle
;; This function uses a non-reentrant model
;;
psect	text48,local,class=CODE,delta=2,merge=1,group=0
	line	1297
global __ptext48
__ptext48:	;psect for function _ShiftMode_Handle
psect	text48
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	1297
	global	__size_of_ShiftMode_Handle
	__size_of_ShiftMode_Handle	equ	__end_of_ShiftMode_Handle-_ShiftMode_Handle
	
_ShiftMode_Handle:	
;incstack = 0
	opt	stack 4
; Regs used in _ShiftMode_Handle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;ShiftMode_Handle@Mod stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ShiftMode_Handle@Mod)
	line	1299
	
l9558:	
;main.c: 1299: Mode=Mod;
	movf	(ShiftMode_Handle@Mod),w
	movwf	(_Mode)
	line	1300
	
l9560:	
;main.c: 1300: RA1=0;
	bcf	(41/8),(41)&7	;volatile
	line	1301
	
l9562:	
;main.c: 1301: RC2=0;
	bcf	(58/8),(58)&7	;volatile
	line	1302
;main.c: 1302: switch(Mod){
	goto	l9588
	line	1304
;main.c: 1304: case 2:
	
l1234:	
	line	1305
;main.c: 1305: RC3=0;
	bcf	(59/8),(59)&7	;volatile
	line	1306
;main.c: 1306: {RA2=0;_BITS2.Bits.bit_1=0;};
	bcf	(42/8),(42)&7	;volatile
	bcf	(__BITS2),1
	line	1309
;main.c: 1309: _BITS.Bits.bit_5=0x00;
	bcf	(__BITS),5
	line	1310
	
l9564:	
;main.c: 1310: PreTdsData=PureTDSTyp.TdsData;
	bsf	status, 6	;RP1=1, select bank2
	movf	1+(_PureTDSTyp)^0100h+0Fh,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_PreTdsData+1)
	bsf	status, 6	;RP1=1, select bank2
	movf	0+(_PureTDSTyp)^0100h+0Fh,w
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_PreTdsData)
	line	1311
	
l9566:	
;main.c: 1311: LedSetSt(1, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1312
	
l9568:	
;main.c: 1312: if(StandByStatus==WashState){
		decf	((_StandByStatus)),w
	btfss	status,2
	goto	u8031
	goto	u8030
u8031:
	goto	l1245
u8030:
	line	1313
	
l9570:	
;main.c: 1313: LedSetSt(1, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1314
;main.c: 1314: SetStandbyState(WashState,&WashRunTime, WashRunTime-Timer_WashRun_1s);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_Timer_WashRun_1s)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_WashRunTime),w
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	goto	l1245
	line	1317
;main.c: 1317: case 4:
	
l1237:	
	line	1318
;main.c: 1318: _BITS.Bits.bit_5=0x01;
	bsf	(__BITS),5
	line	1321
;main.c: 1321: RC3=1;
	bsf	(59/8),(59)&7	;volatile
	line	1322
;main.c: 1322: {RA2=1;_BITS2.Bits.bit_1=1;};
	bsf	(42/8),(42)&7	;volatile
	bsf	(__BITS2),1
	line	1323
	
l9572:	
;main.c: 1323: LedSetSt(1, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(01h)
	fcall	_LedSetSt
	line	1324
	
l9574:	
;main.c: 1324: if((FilterROState==3)||(FilterPCFState==3)){
		movlw	3
	xorwf	((_FilterROState)),w
	btfsc	status,2
	goto	u8041
	goto	u8040
u8041:
	goto	l9578
u8040:
	
l9576:	
		movlw	3
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u8051
	goto	u8050
u8051:
	goto	l9580
u8050:
	line	1325
	
l9578:	
;main.c: 1325: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1326
;main.c: 1326: }
	goto	l1245
	line	1327
	
l9580:	
;main.c: 1327: else if((FilterROState==2)||(FilterPCFState==2)){
		movlw	2
	xorwf	((_FilterROState)),w
	btfsc	status,2
	goto	u8061
	goto	u8060
u8061:
	goto	l9584
u8060:
	
l9582:	
		movlw	2
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u8071
	goto	u8070
u8071:
	goto	l1245
u8070:
	line	1328
	
l9584:	
;main.c: 1328: BuzzerSet(1, 1200);
	movlw	0B0h
	movwf	(BuzzerSet@filter)
	movlw	04h
	movwf	((BuzzerSet@filter))+1
	movlw	low(01h)
	fcall	_BuzzerSet
	goto	l1245
	line	1302
	
l9588:	
	movf	(ShiftMode_Handle@Mod),w
	; Switch size 1, requested type "space"
; Number of cases is 2, Range of values is 2 to 4
; switch strategies available:
; Name         Instructions Cycles
; simple_byte            7     4 (average)
; direct_byte           20    11 (fixed)
; jumptable            263     9 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	2^0	; case 2
	skipnz
	goto	l1234
	xorlw	4^2	; case 4
	skipnz
	goto	l1237
	goto	l1245
	opt asmopt_pop

	line	1335
	
l1245:	
	return
	opt stack 0
GLOBAL	__end_of_ShiftMode_Handle
	__end_of_ShiftMode_Handle:
	signat	_ShiftMode_Handle,4217
	global	_SetStandbyState

;; *************** function _SetStandbyState *****************
;; Defined at:
;;		line 1399 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  STY             1    wreg     enum E897
;;  Time            1    4[COMMON] PTR unsigned char 
;;		 -> WashRunTime(1), 
;;  Da              1    5[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  STY             1    0[BANK0 ] enum E897
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : B00/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       1       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_Count_Func
;;		_ShiftMode_Handle
;;		_WashHandle
;;		_StatusFun_Handle
;;		_StandbyMode_Handle
;;		_Run_Mode
;; This function uses a non-reentrant model
;;
psect	text49,local,class=CODE,delta=2,merge=1,group=0
	line	1399
global __ptext49
__ptext49:	;psect for function _SetStandbyState
psect	text49
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	1399
	global	__size_of_SetStandbyState
	__size_of_SetStandbyState	equ	__end_of_SetStandbyState-_SetStandbyState
	
_SetStandbyState:	
;incstack = 0
	opt	stack 7
; Regs used in _SetStandbyState: [wreg-fsr0h+status,2+status,0]
;SetStandbyState@STY stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(SetStandbyState@STY)
	line	1400
	
l9152:	
;main.c: 1400: *Time=Da;
	movf	(SetStandbyState@Time),w
	movwf	fsr0
	movf	(SetStandbyState@Da),w
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	1401
	
l9154:	
;main.c: 1401: StandByStatus=STY;
	movf	(SetStandbyState@STY),w
	movwf	(_StandByStatus)
	line	1407
	
l9156:	
;main.c: 1407: if(STY==WashState){
		decf	((SetStandbyState@STY)),w
	btfss	status,2
	goto	u7471
	goto	u7470
u7471:
	goto	l9160
u7470:
	line	1409
	
l9158:	
;main.c: 1409: {RA2=1;_BITS2.Bits.bit_1=1;};
	bsf	(42/8),(42)&7	;volatile
	bsf	(__BITS2),1
	line	1410
;main.c: 1410: RC3=1;
	bsf	(59/8),(59)&7	;volatile
	line	1411
;main.c: 1411: RC2=1;
	bsf	(58/8),(58)&7	;volatile
	line	1413
;main.c: 1413: }
	goto	l9164
	line	1414
	
l9160:	
;main.c: 1414: else if(STY==BackState){
		movlw	3
	xorwf	((SetStandbyState@STY)),w
	btfss	status,2
	goto	u7481
	goto	u7480
u7481:
	goto	l1260
u7480:
	line	1416
	
l9162:	
;main.c: 1416: {RA2=1;_BITS2.Bits.bit_1=1;};
	bsf	(42/8),(42)&7	;volatile
	bsf	(__BITS2),1
	line	1417
;main.c: 1417: RC3=1;
	bsf	(59/8),(59)&7	;volatile
	line	1418
;main.c: 1418: RA1=1;
	bsf	(41/8),(41)&7	;volatile
	line	1420
;main.c: 1420: }
	goto	l9164
	line	1421
	
l1260:	
	line	1423
;main.c: 1421: else
;main.c: 1422: {
;main.c: 1423: RC2=0;
	bcf	(58/8),(58)&7	;volatile
	line	1424
;main.c: 1424: {RA2=0;_BITS2.Bits.bit_1=0;};
	bcf	(42/8),(42)&7	;volatile
	bcf	(__BITS2),1
	line	1425
;main.c: 1425: RC3=0;
	bcf	(59/8),(59)&7	;volatile
	line	1426
;main.c: 1426: RA1=0;
	bcf	(41/8),(41)&7	;volatile
	line	1431
	
l9164:	
;main.c: 1430: }
;main.c: 1431: Timer_WashRun_1s=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_Timer_WashRun_1s)^080h
	clrf	(_Timer_WashRun_1s+1)^080h
	line	1434
	
l1262:	
	return
	opt stack 0
GLOBAL	__end_of_SetStandbyState
	__end_of_SetStandbyState:
	signat	_SetStandbyState,12409
	global	_GetStop

;; *************** function _GetStop *****************
;; Defined at:
;;		line 1292 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ErrorHandle
;; This function uses a non-reentrant model
;;
psect	text50,local,class=CODE,delta=2,merge=1,group=0
	line	1292
global __ptext50
__ptext50:	;psect for function _GetStop
psect	text50
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	1292
	global	__size_of_GetStop
	__size_of_GetStop	equ	__end_of_GetStop-_GetStop
	
_GetStop:	
;incstack = 0
	opt	stack 6
; Regs used in _GetStop: []
	line	1293
	
l9556:	
;main.c: 1293: _BITS.Bits.bit_5=0x00;
	bcf	(__BITS),5
	line	1295
	
l1230:	
	return
	opt stack 0
GLOBAL	__end_of_GetStop
	__end_of_GetStop:
	signat	_GetStop,89
	global	_AllLedFlash

;; *************** function _AllLedFlash *****************
;; Defined at:
;;		line 842 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Type            1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  Type            1    3[BANK0 ] unsigned char 
;;  i               2    4[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       3       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       3       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_LedSetSt
;; This function is called by:
;;		_FactoryMode_Handle
;;		_Run_Mode
;;		_ErrorHandle
;; This function uses a non-reentrant model
;;
psect	text51,local,class=CODE,delta=2,merge=1,group=0
	line	842
global __ptext51
__ptext51:	;psect for function _AllLedFlash
psect	text51
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	842
	global	__size_of_AllLedFlash
	__size_of_AllLedFlash	equ	__end_of_AllLedFlash-_AllLedFlash
	
_AllLedFlash:	
;incstack = 0
	opt	stack 4
; Regs used in _AllLedFlash: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;AllLedFlash@Type stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(AllLedFlash@Type)
	line	844
	
l9424:	
;main.c: 843: unsigned int i;
;main.c: 844: for(i=0;i<6;i++){
	clrf	(AllLedFlash@i)
	clrf	(AllLedFlash@i+1)
	line	845
	
l9430:	
;main.c: 845: LedSetSt(i, Type);
	movf	(AllLedFlash@Type),w
	movwf	(LedSetSt@Sta)
	movf	(AllLedFlash@i),w
	fcall	_LedSetSt
	line	844
	
l9432:	
	incf	(AllLedFlash@i),f
	skipnz
	incf	(AllLedFlash@i+1),f
	
l9434:	
	movlw	0
	subwf	(AllLedFlash@i+1),w
	movlw	06h
	skipnz
	subwf	(AllLedFlash@i),w
	skipc
	goto	u7741
	goto	u7740
u7741:
	goto	l9430
u7740:
	line	847
	
l1119:	
	return
	opt stack 0
GLOBAL	__end_of_AllLedFlash
	__end_of_AllLedFlash:
	signat	_AllLedFlash,4217
	global	_LedSetSt

;; *************** function _LedSetSt *****************
;; Defined at:
;;		line 877 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Num             1    wreg     unsigned char 
;;  Sta             1    5[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  Num             1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       1       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___bmul
;; This function is called by:
;;		_AllLedFlash
;;		_FilterTimeHandle
;;		_ShiftMode_Handle
;;		_WashHandle
;;		_FactoryMode_Handle
;;		_FilterKeyInputRest
;;		_StandbyMode_Handle
;;		_Run_Mode
;;		_ErrorHandle
;; This function uses a non-reentrant model
;;
psect	text52,local,class=CODE,delta=2,merge=1,group=0
	line	877
global __ptext52
__ptext52:	;psect for function _LedSetSt
psect	text52
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	877
	global	__size_of_LedSetSt
	__size_of_LedSetSt	equ	__end_of_LedSetSt-_LedSetSt
	
_LedSetSt:	
;incstack = 0
	opt	stack 4
; Regs used in _LedSetSt: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;LedSetSt@Num stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(LedSetSt@Num)
	line	879
	
l9166:	
;main.c: 879: if(LedMod[Num].LedState!=Sta){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	xorwf	(LedSetSt@Sta),w
	skipnz
	goto	u7491
	goto	u7490
u7491:
	goto	l1126
u7490:
	line	880
	
l9168:	
;main.c: 880: LedMod[Num].LedState=Sta;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(LedSetSt@Sta),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	line	881
;main.c: 881: if(LedMod[Num].LedState==2){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
		movlw	2
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfss	status,2
	goto	u7501
	goto	u7500
u7501:
	goto	l9174
u7500:
	line	882
	
l9170:	
;main.c: 882: LedMod[Num].LedFlashNum=2;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	movlw	02h
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movlw	0
	movwf	indf
	line	883
	
l9172:	
;main.c: 883: _BITS.Bits.bit_0=1;
	bsf	(__BITS),0
	line	884
;main.c: 884: }
	goto	l1124
	line	885
	
l9174:	
;main.c: 885: else if(LedMod[Num].LedState==5){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
		movlw	5
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfss	status,2
	goto	u7511
	goto	u7510
u7511:
	goto	l1124
u7510:
	line	886
	
l9176:	
;main.c: 886: LedMod[Num].LedFlashNum=3;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	movlw	03h
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movlw	0
	movwf	indf
	goto	l9172
	line	889
	
l1124:	
;main.c: 888: }
;main.c: 889: LedMod[Num].LedTime=0;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	891
	
l1126:	
	return
	opt stack 0
GLOBAL	__end_of_LedSetSt
	__end_of_LedSetSt:
	signat	_LedSetSt,8313
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    1[BANK0 ] unsigned char 
;;  product         1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         0       2       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       2       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_LedSetSt
;;		_Led_Handle
;; This function uses a non-reentrant model
;;
psect	text53,local,class=CODE,delta=2,merge=1,group=2
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul8.c"
	line	4
global __ptext53
__ptext53:	;psect for function ___bmul
psect	text53
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 6
; Regs used in ___bmul: [wreg+status,2+status,0]
;___bmul@multiplier stored from wreg
	movwf	(___bmul@multiplier)
	line	6
	
l9136:	
	clrf	(___bmul@product)
	line	43
	
l9138:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u7451
	goto	u7450
u7451:
	goto	l9142
u7450:
	line	44
	
l9140:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l9142:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l9144:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u7461
	goto	u7460
u7461:
	goto	l9138
u7460:
	line	50
	
l9146:	
	movf	(___bmul@product),w
	line	51
	
l3730:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	_CheckKey

;; *************** function _CheckKey *****************
;; Defined at:
;;		line 2075 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               2    7[BANK0 ] unsigned int 
;;  St              1    6[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       3       0       0
;;      Temps:          0       1       0       0
;;      Totals:         0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_KeyScan
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text54,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	2075
global __ptext54
__ptext54:	;psect for function _CheckKey
psect	text54
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	2075
	global	__size_of_CheckKey
	__size_of_CheckKey	equ	__end_of_CheckKey-_CheckKey
	
_CheckKey:	
;incstack = 0
	opt	stack 5
; Regs used in _CheckKey: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	2077
	
l10604:	
	line	2083
	
l10606:	
;main.c: 2078: static U8_T temp;
;main.c: 2081: static unsigned int KeyOldFlag = 0;
;main.c: 2083: unsigned int i = (unsigned int)((g_KeyFlag[1]<<8) | g_KeyFlag[0]);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	0+(_g_KeyFlag)+01h,w	;volatile
	movwf	(CheckKey@i+1)
	movf	(_g_KeyFlag),w	;volatile
	movwf	(CheckKey@i)
	line	2085
	
l10608:	
;main.c: 2085: if(i)
	movf	((CheckKey@i)),w
iorwf	((CheckKey@i+1)),w
	btfsc	status,2
	goto	u9711
	goto	u9710
u9711:
	goto	l10620
u9710:
	line	2087
	
l10610:	
;main.c: 2086: {
;main.c: 2087: if(i != KeyOldFlag)
	bsf	status, 5	;RP0=1, select bank1
	movf	(CheckKey@KeyOldFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(CheckKey@i+1),w
	skipz
	goto	u9725
	bsf	status, 5	;RP0=1, select bank1
	movf	(CheckKey@KeyOldFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(CheckKey@i),w
u9725:

	skipnz
	goto	u9721
	goto	u9720
u9721:
	goto	l10624
u9720:
	line	2089
	
l10612:	
;main.c: 2088: {
;main.c: 2089: KeyOldFlag = i;
	movf	(CheckKey@i+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(CheckKey@KeyOldFlag+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(CheckKey@i),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(CheckKey@KeyOldFlag)^080h
	line	2091
	
l10614:	
;main.c: 2091: if(0x01 & i){temp |= 0x02;}
	bcf	status, 5	;RP0=0, select bank0
	btfss	(CheckKey@i),(0)&7
	goto	u9731
	goto	u9730
u9731:
	goto	l1427
u9730:
	
l10616:	
	bsf	(CheckKey@temp)+(1/8),(1)&7
	
l1427:	
	line	2092
;main.c: 2092: if(0x02 & i){temp |= 0x04;}
	btfss	(CheckKey@i),(1)&7
	goto	u9741
	goto	u9740
u9741:
	goto	l10624
u9740:
	
l10618:	
	bsf	(CheckKey@temp)+(2/8),(2)&7
	goto	l10624
	line	2097
	
l10620:	
;main.c: 2095: else
;main.c: 2096: {
;main.c: 2097: KeyOldFlag = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(CheckKey@KeyOldFlag)^080h
	clrf	(CheckKey@KeyOldFlag+1)^080h
	line	2099
	
l10622:	
;main.c: 2099: temp&=0x01;
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(CheckKey@temp),f
	line	2143
	
l10624:	
;main.c: 2100: }
;main.c: 2143: if(RC1==0){
	btfsc	(57/8),(57)&7	;volatile
	goto	u9751
	goto	u9750
u9751:
	goto	l1430
u9750:
	line	2146
	
l10626:	
;main.c: 2146: temp |= 0x01;
	bsf	(CheckKey@temp)+(0/8),(0)&7
	line	2148
;main.c: 2148: }
	goto	l10628
	line	2149
	
l1430:	
	line	2153
;main.c: 2149: else
;main.c: 2150: {
;main.c: 2153: temp &= ~(0x01);
	bcf	(CheckKey@temp)+(0/8),(0)&7
	line	2158
	
l10628:	
;main.c: 2155: }
;main.c: 2158: for(i=0;i<3;i++){
	clrf	(CheckKey@i)
	clrf	(CheckKey@i+1)
	line	2159
	
l10634:	
;main.c: 2159: St=(U8_T)(temp>>i);
	movf	(CheckKey@temp),w
	movwf	(??_CheckKey+0)+0
	incf	(CheckKey@i),w
	goto	u9764
u9765:
	clrc
	rrf	(??_CheckKey+0)+0,f
u9764:
	addlw	-1
	skipz
	goto	u9765
	movf	0+(??_CheckKey+0)+0,w
	movwf	(CheckKey@St)
	line	2160
;main.c: 2160: St&=0x01;
	movlw	low(01h)
	andwf	(CheckKey@St),f
	line	2161
	
l10636:	
;main.c: 2161: KeyScan(St,i);
	movf	(CheckKey@i),w
	movwf	(KeyScan@num)
	movf	(CheckKey@St),w
	fcall	_KeyScan
	line	2158
	
l10638:	
	incf	(CheckKey@i),f
	skipnz
	incf	(CheckKey@i+1),f
	
l10640:	
	movlw	0
	subwf	(CheckKey@i+1),w
	movlw	03h
	skipnz
	subwf	(CheckKey@i),w
	skipc
	goto	u9771
	goto	u9770
u9771:
	goto	l10634
u9770:
	line	2163
	
l1434:	
	return
	opt stack 0
GLOBAL	__end_of_CheckKey
	__end_of_CheckKey:
	signat	_CheckKey,89
	global	_KeyScan

;; *************** function _KeyScan *****************
;; Defined at:
;;		line 8 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\KeyFunc.c"
;; Parameters:    Size  Location     Type
;;  sw_port         1    wreg     unsigned char 
;;  num             1    1[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  sw_port         1    4[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       1       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_BuzzerSet
;; This function is called by:
;;		_CheckKey
;; This function uses a non-reentrant model
;;
psect	text55,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\KeyFunc.c"
	line	8
global __ptext55
__ptext55:	;psect for function _KeyScan
psect	text55
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\KeyFunc.c"
	line	8
	global	__size_of_KeyScan
	__size_of_KeyScan	equ	__end_of_KeyScan-_KeyScan
	
_KeyScan:	
;incstack = 0
	opt	stack 5
; Regs used in _KeyScan: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;KeyScan@sw_port stored from wreg
	movwf	(KeyScan@sw_port)
	line	10
	
l9632:	
;KeyFunc.c: 10: if(sw_port)
	movf	((KeyScan@sw_port)),w
	btfsc	status,2
	goto	u8111
	goto	u8110
u8111:
	goto	l9706
u8110:
	goto	l9668
	line	16
	
l9636:	
;KeyFunc.c: 16: if(KeyPacket_y[num].KeyTime<2200){KeyPacket_y[num].KeyTime++;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	098h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipnc
	goto	u8121
	goto	u8120
u8121:
	goto	l2430
u8120:
	
l9638:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	
l2430:	
	line	17
;KeyFunc.c: 17: if(KeyPacket_y[num].KeyTime>=3){KeyPacket_y[num].KeyState=ShortPressDown;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	0
	subwf	1+(??_KeyScan+0)+0,w
	movlw	03h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipc
	goto	u8131
	goto	u8130
u8131:
	goto	l2452
u8130:
	
l9640:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	goto	l2452
	line	22
	
l9642:	
;KeyFunc.c: 22: if(KeyPacket_y[num].KeyTime<2200){KeyPacket_y[num].KeyTime++;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	098h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipnc
	goto	u8141
	goto	u8140
u8141:
	goto	l2434
u8140:
	
l9644:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	
l2434:	
	line	23
;KeyFunc.c: 23: if(KeyPacket_y[num].KeyTime>=300) {KeyPacket_y[num].KeyState=LongPressDown;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	01h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	02Ch
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipc
	goto	u8151
	goto	u8150
u8151:
	goto	l2452
u8150:
	
l9646:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	movwf	indf
	goto	l2452
	line	28
	
l9648:	
;KeyFunc.c: 28: if(KeyPacket_y[num].KeyTime<2200){KeyPacket_y[num].KeyTime++;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	098h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipnc
	goto	u8161
	goto	u8160
u8161:
	goto	l2437
u8160:
	
l9650:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	
l2437:	
	line	29
;KeyFunc.c: 29: if(KeyPacket_y[num].KeyTime>=1000) {KeyPacket_y[num].KeyState=SuperPressDown;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	03h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	0E8h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipc
	goto	u8171
	goto	u8170
u8171:
	goto	l2452
u8170:
	
l9652:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(03h)
	movwf	indf
	goto	l2452
	line	32
	
l9654:	
;KeyFunc.c: 32: if(KeyPacket_y[num].KeyTime<2200){KeyPacket_y[num].KeyTime++;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	098h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipnc
	goto	u8181
	goto	u8180
u8181:
	goto	l2440
u8180:
	
l9656:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	
l2440:	
	line	33
;KeyFunc.c: 33: if(KeyPacket_y[num].KeyTime>=2100) {KeyPacket_y[num].KeyState=SuperLongPressDown;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	034h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipc
	goto	u8191
	goto	u8190
u8191:
	goto	l2452
u8190:
	
l9658:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(04h)
	movwf	indf
	goto	l2452
	line	36
	
l9660:	
;KeyFunc.c: 36: if(KeyPacket_y[num].KeyTime<2200){KeyPacket_y[num].KeyTime++;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	098h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipnc
	goto	u8201
	goto	u8200
u8201:
	goto	l2452
u8200:
	
l9662:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	goto	l2452
	line	44
	
l9664:	
;KeyFunc.c: 44: KeyPacket_y[num].KeyTime=0;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	45
;KeyFunc.c: 45: KeyPacket_y[num].KeyState=NotPress;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	46
;KeyFunc.c: 46: break;
	goto	l2452
	line	13
	
l9668:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	; Switch size 1, requested type "space"
; Number of cases is 5, Range of values is 0 to 4
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           16     9 (average)
; direct_byte           23     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l9636
	xorlw	1^0	; case 1
	skipnz
	goto	l9642
	xorlw	2^1	; case 2
	skipnz
	goto	l9648
	xorlw	3^2	; case 3
	skipnz
	goto	l9654
	xorlw	4^3	; case 4
	skipnz
	goto	l9660
	goto	l9664
	opt asmopt_pop

	line	55
	
l9670:	
;KeyFunc.c: 55: KeyPacket_y[num].KeyTime=0;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	56
;KeyFunc.c: 56: break;
	goto	l2452
	line	59
	
l9672:	
;KeyFunc.c: 59: KeyPacket_y[num].KeyState=ShortRelease;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(06h)
	movwf	indf
	line	60
	
l9674:	
;KeyFunc.c: 60: if(num!=1)
		decf	((KeyScan@num)),w
	btfsc	status,2
	goto	u8211
	goto	u8210
u8211:
	goto	l9686
u8210:
	line	62
	
l9676:	
;KeyFunc.c: 61: {
;KeyFunc.c: 62: if(_BITS.Bits.bit_1==1){
	btfss	(__BITS),1
	goto	u8221
	goto	u8220
u8221:
	goto	l9686
u8220:
	line	63
	
l9678:	
;KeyFunc.c: 63: _BITS.Bits.bit_1=0;
	bcf	(__BITS),1
	line	65
	
l9680:	
;KeyFunc.c: 65: BuzzerSet(1, 50);
	movlw	032h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	66
	
l9682:	
;KeyFunc.c: 66: KeyPacket_y[num].KeyState=NotPress;
	bcf	status, 5	;RP0=0, select bank0
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	clrf	indf
	goto	l2452
	line	70
	
l9686:	
;KeyFunc.c: 68: }
;KeyFunc.c: 69: }
;KeyFunc.c: 70: if((FilterFastCheck==1)&&(num!=0)){
		decf	((_FilterFastCheck)),w
	btfss	status,2
	goto	u8231
	goto	u8230
u8231:
	goto	l2452
u8230:
	
l9688:	
	movf	((KeyScan@num)),w
	btfsc	status,2
	goto	u8241
	goto	u8240
u8241:
	goto	l2452
u8240:
	line	71
	
l9690:	
;KeyFunc.c: 71: FilterFastCheck=2;
	movlw	low(02h)
	movwf	(_FilterFastCheck)
	line	72
	
l9692:	
;KeyFunc.c: 72: BuzzerSet(3, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(03h)
	fcall	_BuzzerSet
	goto	l9682
	line	78
	
l9698:	
;KeyFunc.c: 78: KeyPacket_y[num].KeyState=LongRelease;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	79
;KeyFunc.c: 79: break;
	goto	l2452
	line	81
	
l9700:	
;KeyFunc.c: 81: KeyPacket_y[num].KeyState=SuperRelease;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(08h)
	movwf	indf
	line	82
;KeyFunc.c: 82: break;
	goto	l2452
	line	52
	
l9706:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	; Switch size 1, requested type "space"
; Number of cases is 4, Range of values is 0 to 3
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           13     7 (average)
; direct_byte           20     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l9670
	xorlw	1^0	; case 1
	skipnz
	goto	l9672
	xorlw	2^1	; case 2
	skipnz
	goto	l9698
	xorlw	3^2	; case 3
	skipnz
	goto	l9700
	goto	l9664
	opt asmopt_pop

	line	90
	
l2452:	
	return
	opt stack 0
GLOBAL	__end_of_KeyScan
	__end_of_KeyScan:
	signat	_KeyScan,8313
	global	_BuzzerSet

;; *************** function _BuzzerSet *****************
;; Defined at:
;;		line 1590 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  cnt             1    wreg     unsigned char 
;;  filter          2    4[COMMON] unsigned short 
;; Auto vars:     Size  Location     Type
;;  cnt             1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       1       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_Count_Func
;;		_FilterLifeFunc
;;		_ShiftMode_Handle
;;		_FactoryMode_Handle
;;		_FilterKeyInputRest
;;		_StandbyMode_Handle
;;		_Run_Mode
;;		_ErrorHandle
;;		_KeyScan
;; This function uses a non-reentrant model
;;
psect	text56,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	1590
global __ptext56
__ptext56:	;psect for function _BuzzerSet
psect	text56
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	1590
	global	__size_of_BuzzerSet
	__size_of_BuzzerSet	equ	__end_of_BuzzerSet-_BuzzerSet
	
_BuzzerSet:	
;incstack = 0
	opt	stack 6
; Regs used in _BuzzerSet: [wreg]
;BuzzerSet@cnt stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(BuzzerSet@cnt)
	line	1592
	
l9150:	
;main.c: 1592: BeepAlmCnt = cnt;
	movf	(BuzzerSet@cnt),w
	movwf	(_BeepAlmCnt)
	line	1593
;main.c: 1593: BuzzerFilter = filter;
	movf	(BuzzerSet@filter+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_BuzzerFilter+1)^080h
	movf	(BuzzerSet@filter),w
	movwf	(_BuzzerFilter)^080h
	line	1594
;main.c: 1594: BeepOnTimeCnt=BuzzerFilter;
	movf	(_BuzzerFilter+1)^080h,w
	movwf	(_BeepOnTimeCnt+1)^080h
	movf	(_BuzzerFilter)^080h,w
	movwf	(_BeepOnTimeCnt)^080h
	line	1595
	
l1307:	
	return
	opt stack 0
GLOBAL	__end_of_BuzzerSet
	__end_of_BuzzerSet:
	signat	_BuzzerSet,8313
	global	_AD_Testing

;; *************** function _AD_Testing *****************
;; Defined at:
;;		line 2438 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  ad_fd           1    wreg     unsigned char 
;;  ad_ch           1    4[COMMON] unsigned char 
;;  ad_lr           1    5[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  ad_fd           1    2[BANK0 ] unsigned char 
;;  data            2    6[BANK0 ] volatile unsigned int 
;;  AD_Result       2    3[BANK0 ] volatile unsigned int 
;;  i               1    5[BANK0 ] volatile unsigned char 
;; Return value:  Size  Location     Type
;;                  2    4[COMMON] unsigned int 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       6       0       0
;;      Temps:          0       2       0       0
;;      Totals:         2       8       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text57,local,class=CODE,delta=2,merge=1,group=0
	line	2438
global __ptext57
__ptext57:	;psect for function _AD_Testing
psect	text57
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	2438
	global	__size_of_AD_Testing
	__size_of_AD_Testing	equ	__end_of_AD_Testing-_AD_Testing
	
_AD_Testing:	
;incstack = 0
	opt	stack 7
; Regs used in _AD_Testing: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
;AD_Testing@ad_fd stored from wreg
	movwf	(AD_Testing@ad_fd)
	line	2446
	
l10464:	
;main.c: 2441: static volatile unsigned char adtimes;
;main.c: 2442: static volatile unsigned int admin,admax, adsum;
;main.c: 2443: volatile unsigned int data;
;main.c: 2444: volatile unsigned int AD_Result;
;main.c: 2446: volatile unsigned char i = 0;
	clrf	(AD_Testing@i)	;volatile
	line	2448
	
l10466:	
;main.c: 2448: if(!ad_lr)
	movf	((AD_Testing@ad_lr)),w
	btfss	status,2
	goto	u9481
	goto	u9480
u9481:
	goto	l10470
u9480:
	line	2449
	
l10468:	
;main.c: 2449: ADCON1 = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(159)^080h	;volatile
	goto	l10472
	line	2451
	
l10470:	
;main.c: 2450: else
;main.c: 2451: ADCON1 = 0x80;
	movlw	low(080h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(159)^080h	;volatile
	line	2453
	
l10472:	
;main.c: 2453: if(ad_ch & 0x10)
	btfss	(AD_Testing@ad_ch),(4)&7
	goto	u9491
	goto	u9490
u9491:
	goto	l10476
u9490:
	line	2454
	
l10474:	
;main.c: 2454: ADCON1 |= 0x40;
	bsf	(159)^080h+(6/8),(6)&7	;volatile
	line	2456
	
l10476:	
;main.c: 2456: ADCON0 = 0;
	clrf	(158)^080h	;volatile
	line	2457
	
l10478:	
;main.c: 2457: ad_ch &= 0x0f;
	movlw	low(0Fh)
	andwf	(AD_Testing@ad_ch),f
	line	2458
	
l10480:	
;main.c: 2458: ADCON0 |= (unsigned char)(ad_fd << 6);
	bcf	status, 5	;RP0=0, select bank0
	movf	(AD_Testing@ad_fd),w
	movwf	(??_AD_Testing+0)+0
	rrf	(??_AD_Testing+0)+0,f
	rrf	(??_AD_Testing+0)+0,f
	rrf	(??_AD_Testing+0)+0,w
	andlw	0c0h
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(158)^080h,f	;volatile
	line	2459
	
l10482:	
;main.c: 2459: ADCON0 |= (unsigned char)(ad_ch << 2);
	movf	(AD_Testing@ad_ch),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_AD_Testing+0)+0
	movlw	(02h)-1
u9505:
	clrc
	rlf	(??_AD_Testing+0)+0,f
	addlw	-1
	skipz
	goto	u9505
	clrc
	rlf	(??_AD_Testing+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(158)^080h,f	;volatile
	line	2460
	
l10484:	
;main.c: 2460: ADCON0 |= 0x01;
	bsf	(158)^080h+(0/8),(0)&7	;volatile
	line	2462
# 2462 "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	2463
# 2463 "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
nop ;# 
psect	text57
	line	2464
	
l10486:	
;main.c: 2464: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1265/8)^080h,(1265)&7	;volatile
	line	2466
;main.c: 2466: while(GODONE)
	goto	l1495
	
l1496:	
	line	2468
# 2468 "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	2469
# 2469 "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
nop ;# 
psect	text57
	line	2470
;main.c: 2470: if((--i) == 0)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(AD_Testing@i),f	;volatile
	goto	u9511
	goto	u9510
u9511:
	goto	l1495
u9510:
	goto	l1498
	line	2472
	
l1495:	
	line	2466
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1265/8)^080h,(1265)&7	;volatile
	goto	u9521
	goto	u9520
u9521:
	goto	l1496
u9520:
	line	2474
	
l10490:	
;main.c: 2472: }
;main.c: 2474: if(!ad_lr)
	movf	((AD_Testing@ad_lr)),w
	btfss	status,2
	goto	u9531
	goto	u9530
u9531:
	goto	l10496
u9530:
	line	2476
	
l10492:	
;main.c: 2475: {
;main.c: 2476: data = (unsigned int)(ADRESH<<4);
	movf	(157)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(AD_Testing@data)	;volatile
	clrf	(AD_Testing@data+1)	;volatile
	swapf	(AD_Testing@data),f	;volatile
	swapf	(AD_Testing@data+1),f	;volatile
	movlw	0f0h
	andwf	(AD_Testing@data+1),f	;volatile
	movf	(AD_Testing@data),w	;volatile
	andlw	0fh
	iorwf	(AD_Testing@data+1),f	;volatile
	movlw	0f0h
	andwf	(AD_Testing@data),f	;volatile
	line	2477
	
l10494:	
;main.c: 2477: data |= (unsigned int)(ADRESL>>4);
	bsf	status, 5	;RP0=1, select bank1
	swapf	(156)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(AD_Testing@data),f	;volatile
	line	2478
;main.c: 2478: }
	goto	l10498
	line	2481
	
l10496:	
;main.c: 2479: else
;main.c: 2480: {
;main.c: 2481: data = (unsigned int)(ADRESH<<8);
	movf	(157)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(AD_Testing@data+1)	;volatile
	clrf	(AD_Testing@data)	;volatile
	line	2482
;main.c: 2482: data |= (unsigned int)ADRESL;
	bsf	status, 5	;RP0=1, select bank1
	movf	(156)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(AD_Testing@data),f	;volatile
	line	2485
	
l10498:	
;main.c: 2483: }
;main.c: 2485: if(adtimes == 0)
	movf	((AD_Testing@adtimes)),w	;volatile
	btfss	status,2
	goto	u9541
	goto	u9540
u9541:
	goto	l10502
u9540:
	line	2487
	
l10500:	
;main.c: 2486: {
;main.c: 2487: admax = data;
	movf	(AD_Testing@data+1),w	;volatile
	movwf	(AD_Testing@admax+1)	;volatile
	movf	(AD_Testing@data),w	;volatile
	movwf	(AD_Testing@admax)	;volatile
	line	2488
;main.c: 2488: admin = data;
	movf	(AD_Testing@data+1),w	;volatile
	movwf	(AD_Testing@admin+1)	;volatile
	movf	(AD_Testing@data),w	;volatile
	movwf	(AD_Testing@admin)	;volatile
	line	2489
;main.c: 2489: }
	goto	l1503
	line	2490
	
l10502:	
;main.c: 2490: else if(data > admax)
	movf	(AD_Testing@data+1),w	;volatile
	subwf	(AD_Testing@admax+1),w	;volatile
	skipz
	goto	u9555
	movf	(AD_Testing@data),w	;volatile
	subwf	(AD_Testing@admax),w	;volatile
u9555:
	skipnc
	goto	u9551
	goto	u9550
u9551:
	goto	l10506
u9550:
	line	2492
	
l10504:	
;main.c: 2491: {
;main.c: 2492: admax = data;
	movf	(AD_Testing@data+1),w	;volatile
	movwf	(AD_Testing@admax+1)	;volatile
	movf	(AD_Testing@data),w	;volatile
	movwf	(AD_Testing@admax)	;volatile
	line	2493
;main.c: 2493: }
	goto	l1503
	line	2494
	
l10506:	
;main.c: 2494: else if(data < admin)
	movf	(AD_Testing@admin+1),w	;volatile
	subwf	(AD_Testing@data+1),w	;volatile
	skipz
	goto	u9565
	movf	(AD_Testing@admin),w	;volatile
	subwf	(AD_Testing@data),w	;volatile
u9565:
	skipnc
	goto	u9561
	goto	u9560
u9561:
	goto	l1503
u9560:
	line	2496
	
l10508:	
;main.c: 2495: {
;main.c: 2496: admin = data;
	movf	(AD_Testing@data+1),w	;volatile
	movwf	(AD_Testing@admin+1)	;volatile
	movf	(AD_Testing@data),w	;volatile
	movwf	(AD_Testing@admin)	;volatile
	line	2499
	
l1503:	
;main.c: 2497: }
;main.c: 2499: adsum += data;
	movf	(AD_Testing@data),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	addwf	(AD_Testing@adsum)^080h,f	;volatile
	skipnc
	incf	(AD_Testing@adsum+1)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(AD_Testing@data+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	addwf	(AD_Testing@adsum+1)^080h,f	;volatile
	line	2500
	
l10510:	
;main.c: 2500: if(++adtimes >= 10)
	movlw	low(0Ah)
	bcf	status, 5	;RP0=0, select bank0
	incf	(AD_Testing@adtimes),f	;volatile
	subwf	((AD_Testing@adtimes)),w	;volatile
	skipc
	goto	u9571
	goto	u9570
u9571:
	goto	l1498
u9570:
	line	2502
	
l10512:	
;main.c: 2501: {
;main.c: 2502: adsum -= admax;
	movf	(AD_Testing@admax),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	subwf	(AD_Testing@adsum)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(AD_Testing@admax+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	skipc
	decf	(AD_Testing@adsum+1)^080h,f	;volatile
	subwf	(AD_Testing@adsum+1)^080h,f	;volatile
	line	2503
;main.c: 2503: adsum -= admin;
	bcf	status, 5	;RP0=0, select bank0
	movf	(AD_Testing@admin),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	subwf	(AD_Testing@adsum)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(AD_Testing@admin+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	skipc
	decf	(AD_Testing@adsum+1)^080h,f	;volatile
	subwf	(AD_Testing@adsum+1)^080h,f	;volatile
	line	2505
	
l10514:	
;main.c: 2505: AD_Result = adsum >> 3;
	movf	(AD_Testing@adsum+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_AD_Testing+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(AD_Testing@adsum)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_AD_Testing+0)+0
	clrc
	rrf	(??_AD_Testing+0)+1,f
	rrf	(??_AD_Testing+0)+0,f
	clrc
	rrf	(??_AD_Testing+0)+1,f
	rrf	(??_AD_Testing+0)+0,f
	clrc
	rrf	(??_AD_Testing+0)+1,f
	rrf	(??_AD_Testing+0)+0,f
	movf	0+(??_AD_Testing+0)+0,w
	movwf	(AD_Testing@AD_Result)	;volatile
	movf	1+(??_AD_Testing+0)+0,w
	movwf	(AD_Testing@AD_Result+1)	;volatile
	line	2507
	
l10516:	
;main.c: 2507: adsum = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(AD_Testing@adsum)^080h	;volatile
	clrf	(AD_Testing@adsum+1)^080h	;volatile
	line	2508
	
l10518:	
;main.c: 2508: admin = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(AD_Testing@admin)	;volatile
	clrf	(AD_Testing@admin+1)	;volatile
	line	2509
	
l10520:	
;main.c: 2509: admax = 0;
	clrf	(AD_Testing@admax)	;volatile
	clrf	(AD_Testing@admax+1)	;volatile
	line	2510
	
l10522:	
;main.c: 2510: adtimes = 0;
	clrf	(AD_Testing@adtimes)	;volatile
	line	2511
	
l10524:	
;main.c: 2511: for(i=0;i<50;i++){
	clrf	(AD_Testing@i)	;volatile
	
l10526:	
	movlw	low(032h)
	subwf	(AD_Testing@i),w	;volatile
	skipc
	goto	u9581
	goto	u9580
u9581:
	goto	l10530
u9580:
	goto	l1498
	line	2512
	
l10530:	
;main.c: 2512: if(NTC_Tab[i]<=AD_Result){
	clrc
	rlf	(AD_Testing@i),w	;volatile
	addlw	low(((_NTC_Tab)|8000h))
	movwf	fsr0
	movlw	high(((_NTC_Tab)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_AD_Testing+0)+0
	fcall	stringtab
	movwf	(??_AD_Testing+0)+0+1
	movf	1+(??_AD_Testing+0)+0,w
	subwf	(AD_Testing@AD_Result+1),w	;volatile
	skipz
	goto	u9595
	movf	0+(??_AD_Testing+0)+0,w
	subwf	(AD_Testing@AD_Result),w	;volatile
u9595:
	skipc
	goto	u9591
	goto	u9590
u9591:
	goto	l10534
u9590:
	line	2513
	
l10532:	
;main.c: 2513: Temp_Ntc=i;
	movf	(AD_Testing@i),w	;volatile
	movwf	(_Temp_Ntc)
	line	2514
;main.c: 2514: break;
	goto	l1498
	line	2511
	
l10534:	
	incf	(AD_Testing@i),f	;volatile
	
l10536:	
	movlw	low(032h)
	subwf	(AD_Testing@i),w	;volatile
	skipc
	goto	u9601
	goto	u9600
u9601:
	goto	l10530
u9600:
	line	2521
	
l1498:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Testing
	__end_of_AD_Testing:
	signat	_AD_Testing,12410
	global	_Initialize

;; *************** function _Initialize *****************
;; Defined at:
;;		line 2593 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Init_ram
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text58,local,class=CODE,delta=2,merge=1,group=0
	line	2593
global __ptext58
__ptext58:	;psect for function _Initialize
psect	text58
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	2593
	global	__size_of_Initialize
	__size_of_Initialize	equ	__end_of_Initialize-_Initialize
	
_Initialize:	
;incstack = 0
	opt	stack 7
; Regs used in _Initialize: [wreg+status,2+status,0+pclath+cstack]
	line	2595
	
l8974:	
# 2595 "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	2596
# 2596 "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text58
	line	2599
	
l8976:	
;main.c: 2599: OSCCON = 0X70;
	movlw	low(070h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(143)^080h	;volatile
	line	2603
;main.c: 2603: PORTA=0B11111111;
	movlw	low(0FFh)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	line	2604
;main.c: 2604: PORTB=0B11111111;
	movlw	low(0FFh)
	movwf	(6)	;volatile
	line	2605
;main.c: 2605: PORTC=0x01;
	movlw	low(01h)
	movwf	(7)	;volatile
	line	2607
;main.c: 2607: TRISA = 0B00111000;
	movlw	low(038h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	line	2608
;main.c: 2608: TRISB = 0B00000010;
	movlw	low(02h)
	movwf	(134)^080h	;volatile
	line	2609
;main.c: 2609: TRISC = 0B00100011;
	movlw	low(023h)
	movwf	(135)^080h	;volatile
	line	2610
;main.c: 2610: TRISD = 0B00000100;
	movlw	low(04h)
	movwf	(136)^080h	;volatile
	line	2612
;main.c: 2612: WPUA = 0B00000001;
	movlw	low(01h)
	movwf	(153)^080h	;volatile
	line	2613
;main.c: 2613: WPUB = 0B00000010;
	movlw	low(02h)
	movwf	(149)^080h	;volatile
	line	2614
;main.c: 2614: WPUC = 0B00000001;
	movlw	low(01h)
	movwf	(154)^080h	;volatile
	line	2616
;main.c: 2616: OPTION_REG = 0x02;
	movlw	low(02h)
	movwf	(129)^080h	;volatile
	line	2617
;main.c: 2617: TMR0 = 255-125;
	movlw	low(082h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(1)	;volatile
	line	2619
;main.c: 2619: TMR1L = (65535-32000)%256;
	movlw	low(0FFh)
	movwf	(14)	;volatile
	line	2620
;main.c: 2620: TMR1H = (65535-32000)/256;
	movlw	low(082h)
	movwf	(15)	;volatile
	line	2621
	
l8978:	
;main.c: 2621: TMR1IF = 0;
	bcf	(96/8),(96)&7	;volatile
	line	2622
	
l8980:	
;main.c: 2622: TMR1IE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1120/8)^080h,(1120)&7	;volatile
	line	2623
;main.c: 2623: T1CON = 0x01;
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(16)	;volatile
	line	2624
;main.c: 2624: ANSEL1 = 0B10000000;
	movlw	low(080h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(137)^080h	;volatile
	line	2626
	
l8982:	
;main.c: 2626: Init_ram();
	fcall	_Init_ram
	line	2627
	
l8984:	
;main.c: 2627: INTEDG = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1038/8)^080h,(1038)&7	;volatile
	line	2628
	
l8986:	
;main.c: 2628: INTCON = 0xe0;
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	2631
	
l1516:	
	return
	opt stack 0
GLOBAL	__end_of_Initialize
	__end_of_Initialize:
	signat	_Initialize,89
	global	_Init_ram

;; *************** function _Init_ram *****************
;; Defined at:
;;		line 2579 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Initialize
;; This function uses a non-reentrant model
;;
psect	text59,local,class=CODE,delta=2,merge=1,group=0
	line	2579
global __ptext59
__ptext59:	;psect for function _Init_ram
psect	text59
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	2579
	global	__size_of_Init_ram
	__size_of_Init_ram	equ	__end_of_Init_ram-_Init_ram
	
_Init_ram:	
;incstack = 0
	opt	stack 7
; Regs used in _Init_ram: [wreg+status,2]
	line	2581
	
l8870:	
# 2581 "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text59
	line	2582
	
l8872:	
;main.c: 2582: PIE2 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(141)^080h	;volatile
	line	2583
	
l8874:	
;main.c: 2583: PIE1 = 0B00000010;
	movlw	low(02h)
	movwf	(140)^080h	;volatile
	line	2584
	
l8876:	
;main.c: 2584: PR2 = 125;
	movlw	low(07Dh)
	movwf	(146)^080h	;volatile
	line	2585
	
l8878:	
;main.c: 2585: T2CON = 5;
	movlw	low(05h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(18)	;volatile
	line	2588
	
l1513:	
	return
	opt stack 0
GLOBAL	__end_of_Init_ram
	__end_of_Init_ram:
	signat	_Init_ram,89
	global	_EEPROM_Page

;; *************** function _EEPROM_Page *****************
;; Defined at:
;;		line 2383 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_ReadDataArry
;;		_SetFilterDelayReset
;;		_WrterEEP
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text60,local,class=CODE,delta=2,merge=1,group=0
	line	2383
global __ptext60
__ptext60:	;psect for function _EEPROM_Page
psect	text60
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	2383
	global	__size_of_EEPROM_Page
	__size_of_EEPROM_Page	equ	__end_of_EEPROM_Page-_EEPROM_Page
	
_EEPROM_Page:	
;incstack = 0
	opt	stack 6
; Regs used in _EEPROM_Page: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	2385
	
l11454:	
;main.c: 2385: ReadDataArry();
	fcall	_ReadDataArry
	line	2387
	
l11456:	
;main.c: 2387: if(Read_Word_Buff[0]==0xA5){
		movlw	165
	bsf	status, 5	;RP0=1, select bank1
	xorwf	((_Read_Word_Buff)^080h),w
	btfss	status,2
	goto	u11041
	goto	u11040
u11041:
	goto	l1478
u11040:
	line	2388
	
l11458:	
;main.c: 2388: FilterPCF_time.u8Hour=Read_Word_Buff[1];
	movf	0+(_Read_Word_Buff)^080h+01h,w
	movwf	0+(_FilterPCF_time)^080h+02h
	line	2389
;main.c: 2389: FilterPCF_time.u16Day=(U16_T)Read_Word_Buff[2]<<8;
	movf	0+(_Read_Word_Buff)^080h+02h,w
	movwf	1+(_FilterPCF_time)^080h+03h
	clrf	0+(_FilterPCF_time)^080h+03h
	line	2390
;main.c: 2390: FilterPCF_time.u16Day|=Read_Word_Buff[3];
	movf	0+(_Read_Word_Buff)^080h+03h,w
	iorwf	0+(_FilterPCF_time)^080h+03h,f
	line	2392
;main.c: 2392: FilterRO_time.u8Hour=Read_Word_Buff[4];
	movf	0+(_Read_Word_Buff)^080h+04h,w
	movwf	0+(_FilterRO_time)^080h+02h
	line	2393
;main.c: 2393: FilterRO_time.u16Day=(U16_T)Read_Word_Buff[5]<<8;
	movf	0+(_Read_Word_Buff)^080h+05h,w
	movwf	1+(_FilterRO_time)^080h+03h
	clrf	0+(_FilterRO_time)^080h+03h
	line	2394
;main.c: 2394: FilterRO_time.u16Day|=Read_Word_Buff[6];
	movf	0+(_Read_Word_Buff)^080h+06h,w
	iorwf	0+(_FilterRO_time)^080h+03h,f
	line	2396
;main.c: 2396: FilterPCFGetWater=Read_Word_Buff[7];
	movf	0+(_Read_Word_Buff)^080h+07h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_FilterPCFGetWater)
	clrf	(_FilterPCFGetWater+1)
	line	2397
;main.c: 2397: FilterPCFGetWater=FilterPCFGetWater<<8;
	movf	(_FilterPCFGetWater),w
	movwf	(_FilterPCFGetWater+1)
	clrf	(_FilterPCFGetWater)
	line	2398
;main.c: 2398: FilterPCFGetWater|=Read_Word_Buff[8];
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_Read_Word_Buff)^080h+08h,w
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(_FilterPCFGetWater),f
	line	2400
;main.c: 2400: FilterROGetWater=Read_Word_Buff[9];
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_Read_Word_Buff)^080h+09h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_FilterROGetWater)
	clrf	(_FilterROGetWater+1)
	line	2401
;main.c: 2401: FilterROGetWater=FilterROGetWater<<8;
	movf	(_FilterROGetWater),w
	movwf	(_FilterROGetWater+1)
	clrf	(_FilterROGetWater)
	line	2402
;main.c: 2402: FilterROGetWater|=Read_Word_Buff[10];
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_Read_Word_Buff)^080h+0Ah,w
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(_FilterROGetWater),f
	line	2407
;main.c: 2407: }
	goto	l11474
	line	2408
	
l1478:	
	line	2410
;main.c: 2408: else
;main.c: 2409: {
;main.c: 2410: _BITS1.Bits.bit_1=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(__BITS1),1
	line	2411
	
l11460:	
;main.c: 2411: Read_Word_Buff[0]=0xA5;
	movlw	low(0A5h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Read_Word_Buff)^080h
	line	2413
	
l11462:	
;main.c: 2413: Read_Word_Buff[11]=1;
	clrf	0+(_Read_Word_Buff)^080h+0Bh
	incf	0+(_Read_Word_Buff)^080h+0Bh,f
	line	2414
	
l11464:	
;main.c: 2414: SetFilterDelayReset(&FilterPCF_time, 365, 0, 0, 0);
	movlw	06Dh
	bcf	status, 5	;RP0=0, select bank0
	movwf	(SetFilterDelayReset@Day)
	movlw	01h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterPCF_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	2415
	
l11466:	
;main.c: 2415: SetFilterDelayReset(&FilterRO_time, 1825, 0, 0, 0);
	movlw	021h
	movwf	(SetFilterDelayReset@Day)
	movlw	07h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterRO_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	2416
	
l11468:	
;main.c: 2416: FilterROGetWater=0;
	clrf	(_FilterROGetWater)
	clrf	(_FilterROGetWater+1)
	line	2417
	
l11470:	
;main.c: 2417: FilterPCFGetWater=0;
	clrf	(_FilterPCFGetWater)
	clrf	(_FilterPCFGetWater+1)
	line	2418
	
l11472:	
;main.c: 2418: WrterEEP();
	fcall	_WrterEEP
	line	2420
	
l11474:	
;main.c: 2419: }
;main.c: 2420: _BITS1.Bits.bit_0=1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(__BITS1),0
	line	2421
	
l11476:	
;main.c: 2421: PreROu16Day=FilterRO_time.u16Day;
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_FilterRO_time)^080h+03h,w
	movwf	(_PreROu16Day+1)^080h
	movf	0+(_FilterRO_time)^080h+03h,w
	movwf	(_PreROu16Day)^080h
	line	2422
	
l11478:	
;main.c: 2422: PrePCFu16Day=FilterPCF_time.u16Day;
	movf	1+(_FilterPCF_time)^080h+03h,w
	movwf	(_PrePCFu16Day+1)^080h
	movf	0+(_FilterPCF_time)^080h+03h,w
	movwf	(_PrePCFu16Day)^080h
	line	2423
	
l11480:	
;main.c: 2423: _BITS1.Bits.bit_7=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(__BITS1),7
	line	2431
	
l11482:	
;main.c: 2430: if((FilterROGetWater>=(21*2))
;main.c: 2431: &&(FilterPCFGetWater>=(21*2))){
	movlw	0
	subwf	(_FilterROGetWater+1),w
	movlw	02Ah
	skipnz
	subwf	(_FilterROGetWater),w
	skipc
	goto	u11051
	goto	u11050
u11051:
	goto	l1481
u11050:
	
l11484:	
	movlw	0
	subwf	(_FilterPCFGetWater+1),w
	movlw	02Ah
	skipnz
	subwf	(_FilterPCFGetWater),w
	skipc
	goto	u11061
	goto	u11060
u11061:
	goto	l1481
u11060:
	line	2434
	
l11486:	
;main.c: 2434: _BITS1.Bits.bit_7=1;
	bsf	(__BITS1),7
	line	2436
	
l1481:	
	return
	opt stack 0
GLOBAL	__end_of_EEPROM_Page
	__end_of_EEPROM_Page:
	signat	_EEPROM_Page,89
	global	_WrterEEP

;; *************** function _WrterEEP *****************
;; Defined at:
;;		line 2357 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_GetMode_Handle
;;		_FilterKeyInputRest
;;		_StandbyMode_Handle
;;		_EEPROM_Page
;; This function uses a non-reentrant model
;;
psect	text61,local,class=CODE,delta=2,merge=1,group=0
	line	2357
global __ptext61
__ptext61:	;psect for function _WrterEEP
psect	text61
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	2357
	global	__size_of_WrterEEP
	__size_of_WrterEEP	equ	__end_of_WrterEEP-_WrterEEP
	
_WrterEEP:	
;incstack = 0
	opt	stack 6
; Regs used in _WrterEEP: [wreg+status,2+status,0]
	line	2358
	
l9590:	
;main.c: 2358: if(FilterFastCheck) return;
	bcf	status, 5	;RP0=0, select bank0
	movf	((_FilterFastCheck)),w
	btfsc	status,2
	goto	u8081
	goto	u8080
u8081:
	goto	l9594
u8080:
	goto	l1470
	line	2360
	
l9594:	
;main.c: 2360: Read_Word_Buff[1]=FilterPCF_time.u8Hour;
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_FilterPCF_time)^080h+02h,w
	movwf	0+(_Read_Word_Buff)^080h+01h
	line	2361
;main.c: 2361: Read_Word_Buff[2]=FilterPCF_time.u16Day>>8;
	movf	1+(_FilterPCF_time)^080h+03h,w
	movwf	0+(_Read_Word_Buff)^080h+02h
	line	2362
;main.c: 2362: Read_Word_Buff[3]=FilterPCF_time.u16Day&0X00FF;
	movf	0+(_FilterPCF_time)^080h+03h,w
	movwf	0+(_Read_Word_Buff)^080h+03h
	line	2364
;main.c: 2364: Read_Word_Buff[4]=FilterRO_time.u8Hour;
	movf	0+(_FilterRO_time)^080h+02h,w
	movwf	0+(_Read_Word_Buff)^080h+04h
	line	2365
;main.c: 2365: Read_Word_Buff[5]=FilterRO_time.u16Day>>8;
	movf	1+(_FilterRO_time)^080h+03h,w
	movwf	0+(_Read_Word_Buff)^080h+05h
	line	2366
;main.c: 2366: Read_Word_Buff[6]=FilterRO_time.u16Day&0X00FF;
	movf	0+(_FilterRO_time)^080h+03h,w
	movwf	0+(_Read_Word_Buff)^080h+06h
	line	2368
;main.c: 2368: Read_Word_Buff[7]=FilterPCFGetWater>>8;
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(_FilterPCFGetWater)+01h,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_Read_Word_Buff)^080h+07h
	line	2369
;main.c: 2369: Read_Word_Buff[8]=FilterPCFGetWater&0X00FF;
	bcf	status, 5	;RP0=0, select bank0
	movf	(_FilterPCFGetWater),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_Read_Word_Buff)^080h+08h
	line	2371
;main.c: 2371: Read_Word_Buff[9]=FilterROGetWater>>8;
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(_FilterROGetWater)+01h,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_Read_Word_Buff)^080h+09h
	line	2372
;main.c: 2372: Read_Word_Buff[10]=FilterROGetWater&0X00FF;
	bcf	status, 5	;RP0=0, select bank0
	movf	(_FilterROGetWater),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_Read_Word_Buff)^080h+0Ah
	line	2374
	
l9596:	
;main.c: 2374: _BITS.Bits.bit_4=1;
	bsf	(__BITS),4
	line	2375
	
l1470:	
	return
	opt stack 0
GLOBAL	__end_of_WrterEEP
	__end_of_WrterEEP:
	signat	_WrterEEP,89
	global	_SetFilterDelayReset

;; *************** function _SetFilterDelayReset *****************
;; Defined at:
;;		line 404 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  TimPtr          1    wreg     PTR struct .
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;;  Day             2    0[BANK0 ] unsigned int 
;;  hour            1    2[BANK0 ] unsigned char 
;;  min             1    3[BANK0 ] unsigned char 
;;  sec             2    4[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  TimPtr          1    4[COMMON] PTR struct .
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       6       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       6       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_FilterKeyInputRest
;;		_EEPROM_Page
;; This function uses a non-reentrant model
;;
psect	text62,local,class=CODE,delta=2,merge=1,group=0
	line	404
global __ptext62
__ptext62:	;psect for function _SetFilterDelayReset
psect	text62
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	404
	global	__size_of_SetFilterDelayReset
	__size_of_SetFilterDelayReset	equ	__end_of_SetFilterDelayReset-_SetFilterDelayReset
	
_SetFilterDelayReset:	
;incstack = 0
	opt	stack 6
; Regs used in _SetFilterDelayReset: [wreg-fsr0h+status,2+status,0]
;SetFilterDelayReset@TimPtr stored from wreg
	movwf	(SetFilterDelayReset@TimPtr)
	line	406
	
l9418:	
;main.c: 406: TimPtr->u16Day=Day;
	movf	(SetFilterDelayReset@TimPtr),w
	addlw	03h
	movwf	fsr0
	movf	(SetFilterDelayReset@Day),w
	bcf	status, 7	;select IRP bank0
	movwf	indf
	incf	fsr0,f
	movf	(SetFilterDelayReset@Day+1),w
	movwf	indf
	line	407
;main.c: 407: TimPtr->u8Hour=hour;
	movf	(SetFilterDelayReset@TimPtr),w
	addlw	02h
	movwf	fsr0
	movf	(SetFilterDelayReset@hour),w
	movwf	indf
	line	408
	
l9420:	
;main.c: 408: TimPtr->u8Minute=min;
	incf	(SetFilterDelayReset@TimPtr),w
	movwf	fsr0
	movf	(SetFilterDelayReset@min),w
	movwf	indf
	line	409
	
l9422:	
;main.c: 409: TimPtr->u8Second=sec;
	movf	(SetFilterDelayReset@TimPtr),w
	movwf	fsr0
	movf	(SetFilterDelayReset@sec),w
	movwf	indf
	line	410
	
l1040:	
	return
	opt stack 0
GLOBAL	__end_of_SetFilterDelayReset
	__end_of_SetFilterDelayReset:
	signat	_SetFilterDelayReset,20601
	global	_ReadDataArry

;; *************** function _ReadDataArry *****************
;; Defined at:
;;		line 2376 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               2    0[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       2       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Memory_Read
;; This function is called by:
;;		_EEPROM_Page
;; This function uses a non-reentrant model
;;
psect	text63,local,class=CODE,delta=2,merge=1,group=0
	line	2376
global __ptext63
__ptext63:	;psect for function _ReadDataArry
psect	text63
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	2376
	global	__size_of_ReadDataArry
	__size_of_ReadDataArry	equ	__end_of_ReadDataArry-_ReadDataArry
	
_ReadDataArry:	
;incstack = 0
	opt	stack 6
; Regs used in _ReadDataArry: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	2378
	
l11382:	
;main.c: 2378: unsigned int i=0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ReadDataArry@i)
	clrf	(ReadDataArry@i+1)
	line	2379
;main.c: 2379: for(i=0;i<12;i++){
	clrf	(ReadDataArry@i)
	clrf	(ReadDataArry@i+1)
	line	2380
	
l11388:	
;main.c: 2380: Read_Word_Buff[i]=Memory_Read(i);
	movf	(ReadDataArry@i),w
	addlw	low(_Read_Word_Buff|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(ReadDataArry@i+1),w
	movwf	(Memory_Read@Addr+1)
	movf	(ReadDataArry@i),w
	movwf	(Memory_Read@Addr)
	fcall	_Memory_Read
	movf	(0+(?_Memory_Read)),w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	line	2379
	
l11390:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(ReadDataArry@i),f
	skipnz
	incf	(ReadDataArry@i+1),f
	
l11392:	
	movlw	0
	subwf	(ReadDataArry@i+1),w
	movlw	0Ch
	skipnz
	subwf	(ReadDataArry@i),w
	skipc
	goto	u10991
	goto	u10990
u10991:
	goto	l11388
u10990:
	line	2382
	
l1475:	
	return
	opt stack 0
GLOBAL	__end_of_ReadDataArry
	__end_of_ReadDataArry:
	signat	_ReadDataArry,89
	global	_Memory_Read

;; *************** function _Memory_Read *****************
;; Defined at:
;;		line 1827 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Addr            2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  2    4[COMMON] unsigned int 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/300
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ReadDataArry
;; This function uses a non-reentrant model
;;
psect	text64,local,class=CODE,delta=2,merge=1,group=0
	line	1827
global __ptext64
__ptext64:	;psect for function _Memory_Read
psect	text64
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	1827
	global	__size_of_Memory_Read
	__size_of_Memory_Read	equ	__end_of_Memory_Read-_Memory_Read
	
_Memory_Read:	
;incstack = 0
	opt	stack 6
; Regs used in _Memory_Read: [wreg]
	line	1830
	
l11158:	
;main.c: 1830: EEADR = Addr;
	movf	(Memory_Read@Addr),w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(391)^0180h	;volatile
	line	1831
	
l11160:	
;main.c: 1831: EEPGD = 0;
	bcf	(3175/8)^0180h,(3175)&7	;volsfr
	line	1838
	
l11162:	
;main.c: 1838: RD=1;
	bsf	(3168/8)^0180h,(3168)&7	;volsfr
	line	1839
# 1839 "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	1840
# 1840 "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
nop ;# 
psect	text64
	line	1843
;main.c: 1843: return (EEDAT);
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(390)^0180h,w	;volatile
	movwf	(?_Memory_Read)
	clrf	(?_Memory_Read+1)
	line	1847
	
l1366:	
	return
	opt stack 0
GLOBAL	__end_of_Memory_Read
	__end_of_Memory_Read:
	signat	_Memory_Read,4218
	global	_Timer1_Isr

;; *************** function _Timer1_Isr *****************
;; Defined at:
;;		line 2634 in file "E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          4       0       0       0
;;      Totals:         4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		___CMS_TouchKeyValue
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text65,local,class=CODE,delta=2,merge=1,group=0
	line	2634
global __ptext65
__ptext65:	;psect for function _Timer1_Isr
psect	text65
	file	"E:\Project\Sbaak_9321_9322_UpdatedVersion\Sbaak_738B\Sbaake\main.c"
	line	2634
	global	__size_of_Timer1_Isr
	__size_of_Timer1_Isr	equ	__end_of_Timer1_Isr-_Timer1_Isr
	
_Timer1_Isr:	
;incstack = 0
	opt	stack 2
; Regs used in _Timer1_Isr: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	movwf	(??_Timer1_Isr+0)
	movf	fsr0,w
	movwf	(??_Timer1_Isr+1)
	movf	pclath,w
	movwf	(??_Timer1_Isr+2)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	btemp+1,w
	movwf	(??_Timer1_Isr+3)
	ljmp	_Timer1_Isr
psect	text65
	line	2637
	
i1l9076:	
;main.c: 2636: static U8_T T1_1ms=0;
;main.c: 2637: if(T0IF)
	btfss	(90/8),(90)&7	;volatile
	goto	u739_21
	goto	u739_20
u739_21:
	goto	i1l9082
u739_20:
	line	2640
	
i1l9078:	
;main.c: 2638: {
;main.c: 2640: TMR0 += 255-125;
	movlw	low(082h)
	addwf	(1),f	;volatile
	line	2643
	
i1l9080:	
;main.c: 2643: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	2654
	
i1l9082:	
;main.c: 2652: }
;main.c: 2654: if(TMR1IF)
	btfss	(96/8),(96)&7	;volatile
	goto	u740_21
	goto	u740_20
u740_21:
	goto	i1l9092
u740_20:
	line	2657
	
i1l9084:	
;main.c: 2655: {
;main.c: 2657: TMR1L += (65535-32000)%256;
	movlw	low(0FFh)
	addwf	(14),f	;volatile
	line	2658
;main.c: 2658: TMR1H += (65535-32000)/256;
	movlw	low(082h)
	addwf	(15),f	;volatile
	line	2662
;main.c: 2662: if(++T1_1ms>=10){
	movlw	low(0Ah)
	incf	(Timer1_Isr@T1_1ms),f
	subwf	((Timer1_Isr@T1_1ms)),w
	skipc
	goto	u741_21
	goto	u741_20
u741_21:
	goto	i1l9090
u741_20:
	line	2663
	
i1l9086:	
;main.c: 2663: T1_1ms=0;
	clrf	(Timer1_Isr@T1_1ms)
	line	2664
	
i1l9088:	
;main.c: 2664: _BITS2.Bits.bit_0=1;
	bsf	(__BITS2),0
	line	2667
	
i1l9090:	
;main.c: 2665: }
;main.c: 2667: TMR1IF = 0;
	bcf	(96/8),(96)&7	;volatile
	line	2669
	
i1l9092:	
;main.c: 2668: }
;main.c: 2669: if(TMR2IF)
	btfss	(97/8),(97)&7	;volatile
	goto	u742_21
	goto	u742_20
u742_21:
	goto	i1l9098
u742_20:
	line	2671
	
i1l9094:	
;main.c: 2670: {
;main.c: 2671: TMR2IF = 0;
	bcf	(97/8),(97)&7	;volatile
	line	2673
	
i1l9096:	
;main.c: 2673: __CMS_TouchKeyValue();
	fcall	___CMS_TouchKeyValue
	line	2675
	
i1l9098:	
;main.c: 2674: }
;main.c: 2675: if(INTF)
	btfss	(89/8),(89)&7	;volatile
	goto	u743_21
	goto	u743_20
u743_21:
	goto	i1l1529
u743_20:
	line	2677
	
i1l9100:	
;main.c: 2676: {
;main.c: 2677: INTF = 0;
	bcf	(89/8),(89)&7	;volatile
	line	2678
	
i1l9102:	
;main.c: 2678: if(PureTDSTyp.HzCount<0xfff0)
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	1+(_PureTDSTyp)^0100h+0Dh,w
	movlw	0F0h
	skipnz
	subwf	0+(_PureTDSTyp)^0100h+0Dh,w
	skipnc
	goto	u744_21
	goto	u744_20
u744_21:
	goto	i1l1529
u744_20:
	line	2679
	
i1l9104:	
;main.c: 2679: PureTDSTyp.HzCount++;
	incf	0+(_PureTDSTyp)^0100h+0Dh,f
	skipnz
	incf	1+(_PureTDSTyp)^0100h+0Dh,f
	line	2682
	
i1l1529:	
	movf	(??_Timer1_Isr+3),w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	movf	(??_Timer1_Isr+2),w
	movwf	pclath
	movf	(??_Timer1_Isr+1),w
	movwf	fsr0
	swapf	(??_Timer1_Isr+0)^0FFFFFF80h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Timer1_Isr
	__end_of_Timer1_Isr:
	signat	_Timer1_Isr,89
	global	___CMS_TouchKeyValue

;; *************** function ___CMS_TouchKeyValue *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Timer1_Isr
;; This function uses a non-reentrant model
;;
psect	text66,local,class=CODE,delta=2,merge=1,group=1
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
global __ptext66
__ptext66:	;psect for function ___CMS_TouchKeyValue
psect	text66
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_TouchKeyValue
	__size_of___CMS_TouchKeyValue	equ	__end_of___CMS_TouchKeyValue-___CMS_TouchKeyValue
	
___CMS_TouchKeyValue:	
;incstack = 0
	opt	stack 2
; Regs used in ___CMS_TouchKeyValue: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
	
i1l8988:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text66
	btfss	(_926/8),(_926)&7	;volatile
	goto	u734_21
	goto	u734_20
u734_21:
	goto	i1l3697
u734_20:
	
i1l8990:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(13),(6)&7	;volatile
	goto	u735_21
	goto	u735_20
u735_21:
	goto	i1l3697
u735_20:
	
i1l8992:	
	bcf	(13)+(6/8),(6)&7	;volatile
	
i1l8994:	
	movf	((_918)),w	;volatile
	btfss	status,2
	goto	u736_21
	goto	u736_20
u736_21:
	goto	i1l3697
u736_20:
	
i1l8996:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(415)^0180h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_922)	;volatile
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
i1l8998:	
	clrc
	rlf	(_919),w	;volatile
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(411)^0180h,w	;volatile
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(412)^0180h,w	;volatile
	movwf	indf
	
i1l9000:	
	clrc
	rlf	(_919),w	;volatile
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(409)^0180h,w	;volatile
	movwf	indf
	incf	fsr0,f
	movf	(410)^0180h,w	;volatile
	movwf	indf
	movlw	low(08h)
	movwf	(415)^0180h	;volatile
	
i1l9002:	
	clrc
	rlf	(_919),w	;volatile
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(413)^0180h,w	;volatile
	movwf	indf
	incf	fsr0,f
	movf	(414)^0180h,w	;volatile
	movwf	indf
	
i1l9004:	
	movlw	low(02h)
	incf	(_919),f	;volatile
	subwf	((_919)),w	;volatile
	skipc
	goto	u737_21
	goto	u737_20
u737_21:
	goto	i1l9010
u737_20:
	
i1l9006:	
	clrf	(_919)	;volatile
	
i1l9008:	
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_918)	;volatile
	goto	i1l9044
	
i1l9010:	
	movlw	low(0C2h)
	andwf	(400)^0180h,f	;volatile
	movlw	low(0E0h)
	andwf	(401)^0180h,f	;volatile
	
i1l9012:	
	movf	(_919),w
	addlw	low(((_gc_Table_KeyChannel)|8000h))
	movwf	fsr0
	movlw	high(((_gc_Table_KeyChannel)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	andlw	01Fh
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(401)^0180h,f	;volatile
	
i1l9014:	
	movlw	low(010h)
	movwf	(415)^0180h	;volatile
	
i1l9016:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u738_21
	goto	u738_20
u738_21:
	goto	i1l9028
u738_20:
	
i1l9018:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(_923)	;volatile
	
i1l9020:	
	movlw	low(0Fh)
	andwf	(_923),f	;volatile
	
i1l9022:	
	movlw	low(0F1h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(405)^0180h,f	;volatile
	
i1l9024:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_923),w
	addlw	low(((_sc_CurStep_Table)|8000h))
	movwf	fsr0
	movlw	high(((_sc_CurStep_Table)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(405)^0180h,f	;volatile
	
i1l9026:	
	movf	(_919),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(406)^0180h	;volatile
	goto	i1l9038
	
i1l9028:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	swapf	indf,w
	andlw	(0ffh shr 4) & 0ffh
	movwf	(_923)	;volatile
	
i1l9030:	
	movlw	low(0Fh)
	andwf	(_923),f	;volatile
	
i1l9032:	
	movlw	low(0F1h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(405)^0180h,f	;volatile
	
i1l9034:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_923),w
	addlw	low(((_sc_CurStep_Table)|8000h))
	movwf	fsr0
	movlw	high(((_sc_CurStep_Table)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(405)^0180h,f	;volatile
	
i1l9036:	
	movf	(_919),w
	addlw	low(432|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(406)^0180h	;volatile
	
i1l9038:	
	movf	(406)^0180h,w	;volatile
	movwf	(407)^0180h	;volatile
	
i1l9042:	
	bsf	(400)^0180h+(0/8),(0)&7	;volatile
	
i1l9044:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_922),w	;volatile
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
i1l3697:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text66
	
i1l3706:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_TouchKeyValue
	__end_of___CMS_TouchKeyValue:
	signat	___CMS_TouchKeyValue,89
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end

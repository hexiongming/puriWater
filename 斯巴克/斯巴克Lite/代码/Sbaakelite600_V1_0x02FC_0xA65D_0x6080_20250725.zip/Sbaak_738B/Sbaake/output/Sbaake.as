opt subtitle "Microchip Technology Omniscient Code Generator v1.45 (PRO mode) build 201711160504"

opt pagewidth 120

	opt pm

	processor	79F738B
opt include "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\include\79f738b.cgen.inc"
clrc	macro
	bcf	3,0
	endm
clrz	macro
	bcf	3,2
	endm
setc	macro
	bsf	3,0
	endm
setz	macro
	bsf	3,2
	endm
skipc	macro
	btfss	3,0
	endm
skipz	macro
	btfss	3,2
	endm
skipnc	macro
	btfsc	3,0
	endm
skipnz	macro
	btfsc	3,2
	endm
	FNCALL	_main,_EEPROM_Page
	FNCALL	_main,_Initialize
	FNCALL	_main,_Run_Mode
	FNCALL	_main,_Set_PWM
	FNCALL	_main,_Set_Usart_Async
	FNCALL	_main,_Time_Count_Func
	FNCALL	_Run_Mode,_AllLedFlash
	FNCALL	_Run_Mode,_BuzzerSet
	FNCALL	_Run_Mode,_FactoryMode_Handle
	FNCALL	_Run_Mode,_GetMode_Handle
	FNCALL	_Run_Mode,_LedSetSt
	FNCALL	_Run_Mode,_SetStandbyState
	FNCALL	_Run_Mode,_ShiftMode_Handle
	FNCALL	_Run_Mode,_StandbyMode_Handle
	FNCALL	_StandbyMode_Handle,_BuzzerSet
	FNCALL	_StandbyMode_Handle,_LedSetSt
	FNCALL	_StandbyMode_Handle,_SetStandbyState
	FNCALL	_StandbyMode_Handle,_ShiftMode_Handle
	FNCALL	_StandbyMode_Handle,_StatusFun_Handle
	FNCALL	_StandbyMode_Handle,_WrterEEP
	FNCALL	_StatusFun_Handle,_SetStandbyState
	FNCALL	_StatusFun_Handle,_WashHandle
	FNCALL	_WashHandle,_LedSetSt
	FNCALL	_WashHandle,_SetStandbyState
	FNCALL	_GetMode_Handle,_ShiftMode_Handle
	FNCALL	_GetMode_Handle,_WrterEEP
	FNCALL	_FactoryMode_Handle,_AllLedFlash
	FNCALL	_FactoryMode_Handle,_BuzzerSet
	FNCALL	_FactoryMode_Handle,_LedSetSt
	FNCALL	_FactoryMode_Handle,_Time_Count_Func
	FNCALL	_Time_Count_Func,_AD_Testing
	FNCALL	_Time_Count_Func,_BuzzerSet
	FNCALL	_Time_Count_Func,_CheckKey
	FNCALL	_Time_Count_Func,_ErrorHandle
	FNCALL	_Time_Count_Func,_FilterKeyInputRest
	FNCALL	_Time_Count_Func,_FilterLifeFunc
	FNCALL	_Time_Count_Func,_GetDelayFilterFlag
	FNCALL	_Time_Count_Func,_Led_Handle
	FNCALL	_Time_Count_Func,_Page_ProgramData
	FNCALL	_Time_Count_Func,_SetStandbyState
	FNCALL	_Time_Count_Func,_TDS_Handle
	FNCALL	_Time_Count_Func,_TaskAlarmHandle
	FNCALL	_Time_Count_Func,_Tx_Display
	FNCALL	_Time_Count_Func,___CMS_CheckTouchKey
	FNCALL	___CMS_CheckTouchKey,___CMS_CheckKeyOldValue
	FNCALL	___CMS_CheckTouchKey,___CMS_CheckOnceResult
	FNCALL	___CMS_CheckTouchKey,___CMS_CheckValidTime
	FNCALL	___CMS_CheckTouchKey,___CMS_CurAdjust
	FNCALL	___CMS_CheckTouchKey,___CMS_KeyDatIIR
	FNCALL	___CMS_CheckTouchKey,___CMS_KeyModeSet
	FNCALL	___CMS_CheckTouchKey,___CMS_KeyStart
	FNCALL	___CMS_CheckTouchKey,___CMS_KeyStopClear
	FNCALL	___CMS_CheckTouchKey,___CMS_Key_UNNOL_Check
	FNCALL	___CMS_CheckTouchKey,___CMS_NewRAMClr
	FNCALL	___CMS_CheckTouchKey,___CMS_Noise_check
	FNCALL	___CMS_CheckTouchKey,___GET_32M_FREDAT
	FNCALL	___CMS_KeyStopClear,___CMS_KeyClearOne
	FNCALL	___CMS_CurAdjust,___CMS_CurAdjMode
	FNCALL	___CMS_CurAdjust,___CMS_CurJudge
	FNCALL	___CMS_CurAdjust,___CMS_KeyModeSet
	FNCALL	___CMS_CurAdjust,___CMS_KeyStart
	FNCALL	___CMS_CheckOnceResult,___CMS_KeyHaveDown
	FNCALL	___CMS_CheckOnceResult,___CMS_KeyIsIn
	FNCALL	___CMS_CheckOnceResult,___CMS_KeyOpen
	FNCALL	___CMS_CheckKeyOldValue,___CMS_KeyIsIn
	FNCALL	___CMS_CheckKeyOldValue,_abs
	FNCALL	_TDS_Handle,_GetCurTdsHz
	FNCALL	_TDS_Handle,___lldiv
	FNCALL	_TDS_Handle,___lmul
	FNCALL	_TDS_Handle,___lwdiv
	FNCALL	_Page_ProgramData,_Memory_Write
	FNCALL	_Led_Handle,_LedControlSt
	FNCALL	_Led_Handle,___bmul
	FNCALL	_GetDelayFilterFlag,_Dec
	FNCALL	_GetDelayFilterFlag,_DecF
	FNCALL	_FilterLifeFunc,_BuzzerSet
	FNCALL	_FilterLifeFunc,_FilterTimeHandle
	FNCALL	_FilterTimeHandle,_LedSetSt
	FNCALL	_FilterKeyInputRest,_BuzzerSet
	FNCALL	_FilterKeyInputRest,_LedSetSt
	FNCALL	_FilterKeyInputRest,_SetFilterDelayReset
	FNCALL	_FilterKeyInputRest,_ShiftMode_Handle
	FNCALL	_FilterKeyInputRest,_WrterEEP
	FNCALL	_ErrorHandle,_AllLedFlash
	FNCALL	_ErrorHandle,_BuzzerSet
	FNCALL	_ErrorHandle,_GetStop
	FNCALL	_ErrorHandle,_LedSetSt
	FNCALL	_ErrorHandle,_ShiftMode_Handle
	FNCALL	_ShiftMode_Handle,_BuzzerSet
	FNCALL	_ShiftMode_Handle,_LedSetSt
	FNCALL	_ShiftMode_Handle,_SetStandbyState
	FNCALL	_AllLedFlash,_LedSetSt
	FNCALL	_LedSetSt,___bmul
	FNCALL	_CheckKey,_KeyScan
	FNCALL	_KeyScan,_BuzzerSet
	FNCALL	_Initialize,_Init_ram
	FNCALL	_EEPROM_Page,_ReadDataArry
	FNCALL	_EEPROM_Page,_SetFilterDelayReset
	FNCALL	_EEPROM_Page,_WrterEEP
	FNCALL	_ReadDataArry,_Memory_Read
	FNROOT	_main
	FNCALL	_Timer1_Isr,___CMS_TouchKeyValue
	FNCALL	intlevel1,_Timer1_Isr
	global	intlevel1
	FNROOT	intlevel1
	global	_NTC_Tab
psect	stringtext,class=STRCODE,delta=2,reloc=256,noexec
global __pstringtext
__pstringtext:
stringtab:
	global    __stringtab
__stringtab:
;	String table - string pointers are 2 bytes each
	btfsc	(btemp+1),7
	ljmp	stringcode
	bcf	status,7
	btfsc	(btemp+1),0
	bsf	status,7
	movf	indf,w
	incf fsr
skipnz
incf btemp+1
	return
stringcode:
	movf btemp+1,w
andlw 7Fh
movwf	pclath
	movf	fsr,w
incf fsr
skipnz
incf btemp+1
	movwf pc
	global __stringbase
__stringbase:
	global    __end_of__stringtab
__end_of__stringtab:
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	135
_NTC_Tab:
	retlw	0BCh
	retlw	0Bh

	retlw	098h
	retlw	0Bh

	retlw	075h
	retlw	0Bh

	retlw	051h
	retlw	0Bh

	retlw	02Ch
	retlw	0Bh

	retlw	07h
	retlw	0Bh

	retlw	0E2h
	retlw	0Ah

	retlw	0BCh
	retlw	0Ah

	retlw	097h
	retlw	0Ah

	retlw	070h
	retlw	0Ah

	retlw	04Ah
	retlw	0Ah

	retlw	023h
	retlw	0Ah

	retlw	0FCh
	retlw	09h

	retlw	0D5h
	retlw	09h

	retlw	0AEh
	retlw	09h

	retlw	087h
	retlw	09h

	retlw	060h
	retlw	09h

	retlw	038h
	retlw	09h

	retlw	011h
	retlw	09h

	retlw	0EAh
	retlw	08h

	retlw	0C3h
	retlw	08h

	retlw	09Bh
	retlw	08h

	retlw	074h
	retlw	08h

	retlw	04Dh
	retlw	08h

	retlw	027h
	retlw	08h

	retlw	0
	retlw	08h

	retlw	0DAh
	retlw	07h

	retlw	0B4h
	retlw	07h

	retlw	08Eh
	retlw	07h

	retlw	068h
	retlw	07h

	retlw	043h
	retlw	07h

	retlw	01Eh
	retlw	07h

	retlw	0F9h
	retlw	06h

	retlw	0D5h
	retlw	06h

	retlw	0B1h
	retlw	06h

	retlw	08Eh
	retlw	06h

	retlw	06Bh
	retlw	06h

	retlw	049h
	retlw	06h

	retlw	026h
	retlw	06h

	retlw	05h
	retlw	06h

	retlw	0E4h
	retlw	05h

	retlw	0C3h
	retlw	05h

	retlw	0A3h
	retlw	05h

	retlw	083h
	retlw	05h

	retlw	064h
	retlw	05h

	retlw	045h
	retlw	05h

	retlw	027h
	retlw	05h

	retlw	09h
	retlw	05h

	retlw	0ECh
	retlw	04h

	retlw	low(0)
	retlw	high(0)

	global __end_of_NTC_Tab
__end_of_NTC_Tab:
	global	_sc_FreScanTable1
psect	stringtext
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
_sc_FreScanTable1:
	retlw	low(0)
	retlw	01h
	retlw	low(0)
	retlw	01h
	retlw	low(0)
	retlw	01h
	retlw	low(0)
	retlw	01h
	global __end_of_sc_FreScanTable1
__end_of_sc_FreScanTable1:
	global	_sc_FreScanTable
psect	stringtext
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
_sc_FreScanTable:
	retlw	low(0)
	retlw	01h
	retlw	01h
	retlw	01h
	retlw	01h
	retlw	01h
	retlw	01h
	retlw	01h
	global __end_of_sc_FreScanTable
__end_of_sc_FreScanTable:
	global	_sc_Table_KeyFalg
psect	stringtext
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
_sc_Table_KeyFalg:
	retlw	01h
	retlw	02h
	retlw	04h
	retlw	08h
	retlw	010h
	retlw	020h
	retlw	040h
	retlw	080h
	global __end_of_sc_Table_KeyFalg
__end_of_sc_Table_KeyFalg:
	global	_sc_CurStep_Table
psect	stringtext
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
_sc_CurStep_Table:
	retlw	low(0)
	retlw	02h
	retlw	04h
	retlw	06h
	retlw	08h
	retlw	0Ah
	global __end_of_sc_CurStep_Table
__end_of_sc_CurStep_Table:
	global	_gc_Table_KeyDown
psect	stringtext
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	36
_gc_Table_KeyDown:
	retlw	03Ch
	retlw	0

	retlw	03Ch
	retlw	0

	global __end_of_gc_Table_KeyDown
__end_of_gc_Table_KeyDown:
	global	_gc_Table_KeyChannel
psect	stringtext
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	28
_gc_Table_KeyChannel:
	retlw	04h
	retlw	05h
	global __end_of_gc_Table_KeyChannel
__end_of_gc_Table_KeyChannel:
	global	_PureHz_Tab
psect	stringtext
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	59
_PureHz_Tab:
	retlw	01Ch
	retlw	0

	retlw	026h
	retlw	0

	retlw	030h
	retlw	0

	retlw	03Ah
	retlw	0

	retlw	044h
	retlw	0

	retlw	04Eh
	retlw	0

	retlw	058h
	retlw	0

	retlw	062h
	retlw	0

	retlw	06Ch
	retlw	0

	retlw	076h
	retlw	0

	retlw	083h
	retlw	0

	retlw	090h
	retlw	0

	retlw	09Ch
	retlw	0

	retlw	0A9h
	retlw	0

	retlw	0B6h
	retlw	0

	retlw	0C3h
	retlw	0

	retlw	0D0h
	retlw	0

	retlw	0DDh
	retlw	0

	retlw	0EAh
	retlw	0

	retlw	0F7h
	retlw	0

	retlw	0FFh
	retlw	0

	retlw	07h
	retlw	01h

	retlw	0Fh
	retlw	01h

	retlw	019h
	retlw	01h

	retlw	023h
	retlw	01h

	retlw	02Dh
	retlw	01h

	retlw	037h
	retlw	01h

	retlw	041h
	retlw	01h

	retlw	04Bh
	retlw	01h

	retlw	055h
	retlw	01h

	retlw	05Eh
	retlw	01h

	retlw	06Bh
	retlw	01h

	retlw	077h
	retlw	01h

	retlw	081h
	retlw	01h

	retlw	08Bh
	retlw	01h

	retlw	095h
	retlw	01h

	retlw	09Fh
	retlw	01h

	retlw	0A9h
	retlw	01h

	retlw	0B3h
	retlw	01h

	retlw	0BDh
	retlw	01h

	retlw	0C9h
	retlw	01h

	retlw	0D6h
	retlw	01h

	retlw	0E2h
	retlw	01h

	retlw	0EDh
	retlw	01h

	retlw	0F7h
	retlw	01h

	retlw	01h
	retlw	02h

	retlw	0Bh
	retlw	02h

	retlw	015h
	retlw	02h

	retlw	01Fh
	retlw	02h

	retlw	029h
	retlw	02h

	retlw	033h
	retlw	02h

	retlw	03Ah
	retlw	02h

	retlw	044h
	retlw	02h

	retlw	04Eh
	retlw	02h

	retlw	058h
	retlw	02h

	retlw	062h
	retlw	02h

	retlw	06Ch
	retlw	02h

	retlw	077h
	retlw	02h

	retlw	082h
	retlw	02h

	retlw	08Dh
	retlw	02h

	retlw	09Bh
	retlw	02h

	retlw	0A9h
	retlw	02h

	retlw	0B7h
	retlw	02h

	retlw	0C6h
	retlw	02h

	retlw	0D3h
	retlw	02h

	retlw	0E1h
	retlw	02h

	retlw	0EBh
	retlw	02h

	retlw	0F5h
	retlw	02h

	retlw	0FFh
	retlw	02h

	retlw	09h
	retlw	03h

	retlw	013h
	retlw	03h

	retlw	01Dh
	retlw	03h

	retlw	027h
	retlw	03h

	retlw	031h
	retlw	03h

	retlw	03Bh
	retlw	03h

	retlw	043h
	retlw	03h

	retlw	04Bh
	retlw	03h

	retlw	053h
	retlw	03h

	retlw	057h
	retlw	03h

	retlw	05Ch
	retlw	03h

	retlw	05Fh
	retlw	03h

	retlw	064h
	retlw	03h

	retlw	06Ch
	retlw	03h

	retlw	074h
	retlw	03h

	retlw	07Ch
	retlw	03h

	retlw	084h
	retlw	03h

	retlw	08Ch
	retlw	03h

	retlw	094h
	retlw	03h

	retlw	09Ch
	retlw	03h

	retlw	0A4h
	retlw	03h

	retlw	0ACh
	retlw	03h

	retlw	0B4h
	retlw	03h

	retlw	0BCh
	retlw	03h

	retlw	0C4h
	retlw	03h

	retlw	0CCh
	retlw	03h

	retlw	0D4h
	retlw	03h

	retlw	0DCh
	retlw	03h

	retlw	0E4h
	retlw	03h

	retlw	0ECh
	retlw	03h

	retlw	0F4h
	retlw	03h

	retlw	0FCh
	retlw	03h

	retlw	0Bh
	retlw	04h

	retlw	01Ah
	retlw	04h

	retlw	022h
	retlw	04h

	retlw	029h
	retlw	04h

	retlw	031h
	retlw	04h

	retlw	038h
	retlw	04h

	retlw	040h
	retlw	04h

	retlw	048h
	retlw	04h

	retlw	04Fh
	retlw	04h

	retlw	057h
	retlw	04h

	retlw	05Eh
	retlw	04h

	retlw	066h
	retlw	04h

	retlw	06Eh
	retlw	04h

	retlw	075h
	retlw	04h

	retlw	07Dh
	retlw	04h

	retlw	084h
	retlw	04h

	retlw	08Ch
	retlw	04h

	retlw	094h
	retlw	04h

	retlw	09Bh
	retlw	04h

	retlw	0A3h
	retlw	04h

	retlw	0AAh
	retlw	04h

	retlw	0B2h
	retlw	04h

	retlw	0BAh
	retlw	04h

	retlw	0C1h
	retlw	04h

	retlw	0C9h
	retlw	04h

	retlw	0D0h
	retlw	04h

	retlw	0D8h
	retlw	04h

	retlw	0E0h
	retlw	04h

	retlw	0E7h
	retlw	04h

	retlw	0EFh
	retlw	04h

	retlw	0F6h
	retlw	04h

	retlw	0FEh
	retlw	04h

	retlw	06h
	retlw	05h

	retlw	0Dh
	retlw	05h

	retlw	015h
	retlw	05h

	retlw	01Ch
	retlw	05h

	retlw	024h
	retlw	05h

	retlw	02Ch
	retlw	05h

	retlw	033h
	retlw	05h

	retlw	03Bh
	retlw	05h

	retlw	042h
	retlw	05h

	retlw	04Ah
	retlw	05h

	retlw	052h
	retlw	05h

	retlw	059h
	retlw	05h

	retlw	061h
	retlw	05h

	retlw	068h
	retlw	05h

	retlw	06Ch
	retlw	05h

	retlw	070h
	retlw	05h

	retlw	074h
	retlw	05h

	retlw	078h
	retlw	05h

	retlw	07Ch
	retlw	05h

	retlw	080h
	retlw	05h

	retlw	084h
	retlw	05h

	retlw	088h
	retlw	05h

	retlw	08Ch
	retlw	05h

	retlw	090h
	retlw	05h

	retlw	094h
	retlw	05h

	retlw	098h
	retlw	05h

	retlw	09Ch
	retlw	05h

	retlw	0A0h
	retlw	05h

	retlw	0A4h
	retlw	05h

	retlw	0A8h
	retlw	05h

	retlw	0ACh
	retlw	05h

	retlw	0B0h
	retlw	05h

	retlw	0B4h
	retlw	05h

	retlw	0B8h
	retlw	05h

	retlw	0BCh
	retlw	05h

	retlw	0C0h
	retlw	05h

	retlw	0C4h
	retlw	05h

	retlw	0C8h
	retlw	05h

	retlw	0CCh
	retlw	05h

	retlw	0D0h
	retlw	05h

	retlw	0D4h
	retlw	05h

	retlw	0D8h
	retlw	05h

	retlw	0DCh
	retlw	05h

	retlw	0E0h
	retlw	05h

	retlw	0E4h
	retlw	05h

	retlw	0E8h
	retlw	05h

	retlw	0ECh
	retlw	05h

	retlw	0F0h
	retlw	05h

	retlw	0F4h
	retlw	05h

	retlw	0F8h
	retlw	05h

	retlw	0FCh
	retlw	05h

	retlw	0
	retlw	06h

	retlw	04h
	retlw	06h

	retlw	08h
	retlw	06h

	retlw	0Ch
	retlw	06h

	retlw	010h
	retlw	06h

	retlw	014h
	retlw	06h

	global __end_of_PureHz_Tab
__end_of_PureHz_Tab:
psect	stringtext
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	124
_gc_KeyLDOSel:
	retlw	03h
	global __end_of_gc_KeyLDOSel
__end_of_gc_KeyLDOSel:
psect	stringtext
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	122
_gc_LMDValue:
	retlw	01h
	global __end_of_gc_LMDValue
__end_of_gc_LMDValue:
psect	stringtext
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	116
_gc_CmBase:
	retlw	06h
	global __end_of_gc_CmBase
__end_of_gc_CmBase:
psect	stringtext
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
_gc_VolValue:
	retlw	032h
	global __end_of_gc_VolValue
__end_of_gc_VolValue:
	global	_NTC_Tab
	global	_sc_FreScanTable1
	global	_sc_FreScanTable
	global	_sc_Table_KeyFalg
	global	_sc_CurStep_Table
	global	_gc_Table_KeyDown
	global	_gc_Table_KeyChannel
	global	_PureHz_Tab
	global	_919
	global	_Mode
	global	__BITS
	global	_927
	global	_926
	global	_925
	global	_924
	global	_gf_kerr
	global	_KeyPacket_y
	global	AD_Testing@admax
	global	AD_Testing@admin
	global	_g_KeyFlag
	global	_923
	global	_922
	global	_921
	global	_920
	global	_918
	global	_917
	global	_916
	global	AD_Testing@adtimes
	global	CheckKey@temp
	global	StandbyMode_Handle@Ti_1h
	global	_BeepAlmCnt
	global	_ErrorVar
	global	_Time_Power_1s
	global	_Temp_Ntc
	global	_FilterBuzzer_1s
	global	_PowerStep
	global	_Time_100ms
	global	_Time_GetWater_1s
	global	_Time_1s
	global	_Timer_Power_100ms
	global	_StandByStatus
	global	_Timer_TdsMake_1s
	global	_FilterFastCheck
	global	_Timer_ErrorLong_1s
	global	__BITS2
	global	__BITS1
	global	_FilterROGetWater
	global	_FilterPCFGetWater
	global	_FilterROState
	global	_FilterPCFState
	global	_WashRunTime
	global	_Read_Word_Buff
	global	___CMS_CheckValidTime@F1029
	global	___CMS_Noise_check@F969
	global	___CMS_Noise_check@F968
	global	AD_Testing@adsum
	global	CheckKey@KeyOldFlag
	global	FilterKeyInputRest@FilterSelect_10ms
	global	_BeepOnTimeCnt
	global	_BuzzerFilter
	global	_ML_Temp
	global	_Date_Temp
	global	_Timer_Standby_1H
	global	_Timer_Standby_1s
	global	_Timer_WashRun_1s
	global	_FilterRst_1s
	global	_PreROu16Day
	global	_PrePCFu16Day
	global	_Timer_LongGetWater_1s
	global	_GetWater_ML
	global	_Time_made_1s
	global	___CMS_CheckTouchKey@F1073
	global	___CMS_CurAdjust@F1044
	global	___CMS_Key_UNNOL_Check@F1016
	global	___CMS_Noise_check@F967
	global	___CMS_Noise_check@F966
	global	___CMS_Noise_check@F965
	global	___CMS_Noise_check@F964
	global	Timer1_Isr@T1_1ms
	global	_FilterRO_time
	global	_FilterPCF_time
	global	_LedMod
	global	_Tx_Type
	global	_PureTDSTyp
	global	_887
_887	set	13
	global	_T2CON
_T2CON	set	18
	global	_T1CON
_T1CON	set	16
	global	_TMR1H
_TMR1H	set	15
	global	_TMR1L
_TMR1L	set	14
	global	_INTCON
_INTCON	set	11
	global	_PORTC
_PORTC	set	7
	global	_PORTB
_PORTB	set	6
	global	_PORTA
_PORTA	set	5
	global	_TMR0
_TMR0	set	1
	global	_TMR1IF
_TMR1IF	set	96
	global	_TMR2IF
_TMR2IF	set	97
	global	_INTF
_INTF	set	89
	global	_T0IF
_T0IF	set	90
	global	_GIE
_GIE	set	95
	global	_RC1
_RC1	set	57
	global	_RC2
_RC2	set	58
	global	_RC3
_RC3	set	59
	global	_RB0
_RB0	set	48
	global	_RB2
_RB2	set	50
	global	_RB3
_RB3	set	51
	global	_RB4
_RB4	set	52
	global	_RB5
_RB5	set	53
	global	_RB6
_RB6	set	54
	global	_RA0
_RA0	set	40
	global	_RA1
_RA1	set	41
	global	_RA2
_RA2	set	42
	global	_RA6
_RA6	set	46
	global	_RA7
_RA7	set	47
	global	_ADCON1
_ADCON1	set	159
	global	_ADCON0
_ADCON0	set	158
	global	_ADRESH
_ADRESH	set	157
	global	_ADRESL
_ADRESL	set	156
	global	_WPUC
_WPUC	set	154
	global	_WPUA
_WPUA	set	153
	global	_SPBRG1
_SPBRG1	set	152
	global	_WPUB
_WPUB	set	149
	global	_PR2
_PR2	set	146
	global	_OSCCON
_OSCCON	set	143
	global	_PIE2
_PIE2	set	141
	global	_PIE1
_PIE1	set	140
	global	_ANSEL1
_ANSEL1	set	137
	global	_TRISD
_TRISD	set	136
	global	_TRISC
_TRISC	set	135
	global	_TRISB
_TRISB	set	134
	global	_TRISA
_TRISA	set	133
	global	_OPTION_REG
_OPTION_REG	set	129
	global	_GODONE
_GODONE	set	1265
	global	_RC1IE
_RC1IE	set	1129
	global	_TX1IE
_TX1IE	set	1130
	global	_TMR1IE
_TMR1IE	set	1120
	global	_INTEDG
_INTEDG	set	1038
	global	_TXREG1
_TXREG1	set	285
	global	_PWMTH
_PWMTH	set	284
	global	_PWMTL
_PWMTL	set	283
	global	_PWMD01H
_PWMD01H	set	273
	global	_PWMD1L
_PWMD1L	set	269
	global	_PWMCON1
_PWMCON1	set	263
	global	_PWMCON0
_PWMCON0	set	262
	global	_TRMT1
_TRMT1	set	2297
	global	_SCKP1
_SCKP1	set	2299
	global	_SYNC1
_SYNC1	set	2300
	global	_TXEN1
_TXEN1	set	2301
	global	_TX9EN1
_TX9EN1	set	2302
	global	_PWM1EN
_PWM1EN	set	2097
	global	_CREN1
_CREN1	set	2092
	global	_RX9EN1
_RX9EN1	set	2094
	global	_SPEN1
_SPEN1	set	2095
	global	_914
_914	set	416
	global	_905
_905	set	416
	global	_903
_903	set	448
	global	_902
_902	set	416
	global	_900
_900	set	448
	global	_899
_899	set	416
	global	_897
_897	set	448
	global	_896
_896	set	416
	global	_913
_913	set	480
	global	_912
_912	set	464
	global	_911
_911	set	448
	global	_910
_910	set	432
	global	_909
_909	set	416
	global	_904
_904	set	480
	global	_901
_901	set	480
	global	_898
_898	set	480
	global	_886
_886	set	415
	global	_885
_885	set	412
	global	_884
_884	set	411
	global	_883
_883	set	414
	global	_882
_882	set	413
	global	_881
_881	set	410
	global	_880
_880	set	409
	global	_879
_879	set	408
	global	_878
_878	set	407
	global	_877
_877	set	406
	global	_876
_876	set	405
	global	_875
_875	set	404
	global	_874
_874	set	403
	global	_873
_873	set	402
	global	_872
_872	set	401
	global	_871
_871	set	400
	global	_EECON2
_EECON2	set	397
	global	_EECON1
_EECON1	set	396
	global	_EEADR
_EEADR	set	391
	global	_EEDAT
_EEDAT	set	390
	global	_RD
_RD	set	3168
	global	_WR
_WR	set	3169
	global	_WREN
_WREN	set	3170
	global	_WRERR
_WRERR	set	3171
	global	_EEPGD
_EEPGD	set	3175
; #config settings
	file	"Sbaake.as"
	line	#
psect cinit,class=CODE,delta=2
global start_initialization
start_initialization:

global __initialization
__initialization:
psect	bitbssCOMMON,class=COMMON,bit,space=1,noexec
global __pbitbssCOMMON
__pbitbssCOMMON:
_927:
       ds      1

_926:
       ds      1

_925:
       ds      1

_924:
       ds      1

_gf_kerr:
       ds      1

psect	bssCOMMON,class=COMMON,space=1,noexec
global __pbssCOMMON
__pbssCOMMON:
_919:
       ds      1

_Mode:
       ds      1

__BITS:
       ds      1

psect	bssBANK0,class=BANK0,space=1,noexec
global __pbssBANK0
__pbssBANK0:
_KeyPacket_y:
       ds      9

AD_Testing@admax:
       ds      2

AD_Testing@admin:
       ds      2

_g_KeyFlag:
       ds      2

_923:
       ds      1

_922:
       ds      1

_921:
       ds      1

_920:
       ds      1

_918:
       ds      1

_917:
       ds      1

_916:
       ds      1

AD_Testing@adtimes:
       ds      1

CheckKey@temp:
       ds      1

StandbyMode_Handle@Ti_1h:
       ds      1

_BeepAlmCnt:
       ds      1

_ErrorVar:
       ds      1

_Time_Power_1s:
       ds      1

_Temp_Ntc:
       ds      1

_FilterBuzzer_1s:
       ds      1

_PowerStep:
       ds      1

_Time_100ms:
       ds      1

_Time_GetWater_1s:
       ds      1

_Time_1s:
       ds      1

_Timer_Power_100ms:
       ds      1

_StandByStatus:
       ds      1

_Timer_TdsMake_1s:
       ds      1

_FilterFastCheck:
       ds      1

_Timer_ErrorLong_1s:
       ds      1

__BITS2:
       ds      1

__BITS1:
       ds      1

_FilterROGetWater:
       ds      2

_FilterPCFGetWater:
       ds      2

_FilterROState:
       ds      1

_FilterPCFState:
       ds      1

_WashRunTime:
       ds      1

psect	bssBANK1,class=BANK1,space=1,noexec
global __pbssBANK1
__pbssBANK1:
_Read_Word_Buff:
       ds      12

___CMS_CheckValidTime@F1029:
       ds      2

___CMS_Noise_check@F969:
       ds      2

___CMS_Noise_check@F968:
       ds      2

AD_Testing@adsum:
       ds      2

CheckKey@KeyOldFlag:
       ds      2

FilterKeyInputRest@FilterSelect_10ms:
       ds      2

_BeepOnTimeCnt:
       ds      2

_BuzzerFilter:
       ds      2

_ML_Temp:
       ds      2

_Date_Temp:
       ds      2

_Timer_Standby_1H:
       ds      2

_Timer_Standby_1s:
       ds      2

_Timer_WashRun_1s:
       ds      2

_FilterRst_1s:
       ds      2

_PreROu16Day:
       ds      2

_PrePCFu16Day:
       ds      2

_Timer_LongGetWater_1s:
       ds      2

_GetWater_ML:
       ds      2

_Time_made_1s:
       ds      2

___CMS_CheckTouchKey@F1073:
       ds      1

___CMS_CurAdjust@F1044:
       ds      1

___CMS_Key_UNNOL_Check@F1016:
       ds      1

___CMS_Noise_check@F967:
       ds      1

___CMS_Noise_check@F966:
       ds      1

___CMS_Noise_check@F965:
       ds      1

___CMS_Noise_check@F964:
       ds      1

Timer1_Isr@T1_1ms:
       ds      1

_FilterRO_time:
       ds      5

_FilterPCF_time:
       ds      5

psect	bssBANK2,class=BANK2,space=1,noexec
global __pbssBANK2
__pbssBANK2:
_LedMod:
       ds      30

_Tx_Type:
       ds      17

_PureTDSTyp:
       ds      17

	file	"Sbaake.as"
	line	#
psect clrtext,class=CODE,delta=2
global clear_ram0
;	Called with FSR containing the base address, and
;	W with the last address+1
clear_ram0:
	clrwdt			;clear the watchdog before getting into this loop
clrloop0:
	clrf	indf		;clear RAM location pointed to by FSR
	incf	fsr,f		;increment pointer
	xorwf	fsr,w		;XOR with final address
	btfsc	status,2	;have we reached the end yet?
	retlw	0		;all done for this memory range, return
	xorwf	fsr,w		;XOR again to restore value
	goto	clrloop0		;do the next byte

; Clear objects allocated to BITCOMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbitbssCOMMON/8)+0)&07Fh
; Clear objects allocated to COMMON
psect cinit,class=CODE,delta=2,merge=1
	clrf	((__pbssCOMMON)+0)&07Fh
	clrf	((__pbssCOMMON)+1)&07Fh
	clrf	((__pbssCOMMON)+2)&07Fh
; Clear objects allocated to BANK0
psect cinit,class=CODE,delta=2,merge=1
	bcf	status, 7	;select IRP bank0
	movlw	low(__pbssBANK0)
	movwf	fsr
	movlw	low((__pbssBANK0)+030h)
	fcall	clear_ram0
; Clear objects allocated to BANK1
psect cinit,class=CODE,delta=2,merge=1
	movlw	low(__pbssBANK1)
	movwf	fsr
	movlw	low((__pbssBANK1)+044h)
	fcall	clear_ram0
; Clear objects allocated to BANK2
psect cinit,class=CODE,delta=2,merge=1
	bsf	status, 7	;select IRP bank2
	movlw	low(__pbssBANK2)
	movwf	fsr
	movlw	low((__pbssBANK2)+040h)
	fcall	clear_ram0
psect cinit,class=CODE,delta=2,merge=1
global end_of_initialization,__end_of__initialization

;End of C runtime variable initialization code

end_of_initialization:
__end_of__initialization:
clrf status
ljmp _main	;jump to C main() function
psect	cstackBANK1,class=BANK1,space=1,noexec
global __pcstackBANK1
__pcstackBANK1:
??_Time_Count_Func:	; 1 bytes @ 0x0
	ds	3
	global	FactoryMode_Handle@Step
FactoryMode_Handle@Step:	; 1 bytes @ 0x3
	ds	1
psect	cstackCOMMON,class=COMMON,space=1,noexec
global __pcstackCOMMON
__pcstackCOMMON:
?___CMS_CheckTouchKey:	; 1 bytes @ 0x0
?_CheckKey:	; 1 bytes @ 0x0
?_FilterLifeFunc:	; 1 bytes @ 0x0
?_TaskAlarmHandle:	; 1 bytes @ 0x0
?_Led_Handle:	; 1 bytes @ 0x0
?_FilterKeyInputRest:	; 1 bytes @ 0x0
?_Tx_Display:	; 1 bytes @ 0x0
?_ErrorHandle:	; 1 bytes @ 0x0
?_Page_ProgramData:	; 1 bytes @ 0x0
?_WrterEEP:	; 1 bytes @ 0x0
?___CMS_TouchKeyValue:	; 1 bytes @ 0x0
??___CMS_TouchKeyValue:	; 1 bytes @ 0x0
?_GetDelayFilterFlag:	; 1 bytes @ 0x0
?_Time_Count_Func:	; 1 bytes @ 0x0
?_AllLedFlash:	; 1 bytes @ 0x0
?_GetStop:	; 1 bytes @ 0x0
?_ShiftMode_Handle:	; 1 bytes @ 0x0
?_GetMode_Handle:	; 1 bytes @ 0x0
?_WashHandle:	; 1 bytes @ 0x0
?_StatusFun_Handle:	; 1 bytes @ 0x0
?_FactoryMode_Handle:	; 1 bytes @ 0x0
?_StandbyMode_Handle:	; 1 bytes @ 0x0
?_Run_Mode:	; 1 bytes @ 0x0
?_ReadDataArry:	; 1 bytes @ 0x0
?_EEPROM_Page:	; 1 bytes @ 0x0
?_Init_ram:	; 1 bytes @ 0x0
?_Initialize:	; 1 bytes @ 0x0
?_Timer1_Isr:	; 1 bytes @ 0x0
??_Timer1_Isr:	; 1 bytes @ 0x0
?_Set_Usart_Async:	; 1 bytes @ 0x0
?_Set_PWM:	; 1 bytes @ 0x0
?_main:	; 1 bytes @ 0x0
?___CMS_KeyIsIn:	; 1 bytes @ 0x0
?___CMS_KeyClearOne:	; 1 bytes @ 0x0
?___CMS_KeyStopClear:	; 1 bytes @ 0x0
?___CMS_Noise_check:	; 1 bytes @ 0x0
?___CMS_CheckOnceResult:	; 1 bytes @ 0x0
?___CMS_CheckKeyOldValue:	; 1 bytes @ 0x0
?___CMS_Key_UNNOL_Check:	; 1 bytes @ 0x0
?___CMS_KeyDatIIR:	; 1 bytes @ 0x0
?___CMS_CheckValidTime:	; 1 bytes @ 0x0
?___CMS_CurAdjMode:	; 1 bytes @ 0x0
?___CMS_KeyModeSet:	; 1 bytes @ 0x0
?___CMS_KeyStart:	; 1 bytes @ 0x0
?___CMS_CurJudge:	; 1 bytes @ 0x0
?___CMS_CurAdjust:	; 1 bytes @ 0x0
?___CMS_NewRAMClr:	; 1 bytes @ 0x0
?___GET_32M_FREDAT:	; 1 bytes @ 0x0
	ds	4
??_TaskAlarmHandle:	; 1 bytes @ 0x4
??_Tx_Display:	; 1 bytes @ 0x4
?_BuzzerSet:	; 1 bytes @ 0x4
?_SetStandbyState:	; 1 bytes @ 0x4
??_WrterEEP:	; 1 bytes @ 0x4
?_Dec:	; 1 bytes @ 0x4
?_DecF:	; 1 bytes @ 0x4
??_SetFilterDelayReset:	; 1 bytes @ 0x4
?_TDS_Handle:	; 1 bytes @ 0x4
?_LedControlSt:	; 1 bytes @ 0x4
??_GetStop:	; 1 bytes @ 0x4
??_Memory_Write:	; 1 bytes @ 0x4
??_Init_ram:	; 1 bytes @ 0x4
??_Initialize:	; 1 bytes @ 0x4
??_Set_Usart_Async:	; 1 bytes @ 0x4
??_Set_PWM:	; 1 bytes @ 0x4
??___CMS_KeyIsIn:	; 1 bytes @ 0x4
?___CMS_KeyOpen:	; 1 bytes @ 0x4
?___CMS_KeyHaveDown:	; 1 bytes @ 0x4
??___CMS_KeyClearOne:	; 1 bytes @ 0x4
??___CMS_Key_UNNOL_Check:	; 1 bytes @ 0x4
??___CMS_KeyDatIIR:	; 1 bytes @ 0x4
??___CMS_CheckValidTime:	; 1 bytes @ 0x4
??___CMS_CurAdjMode:	; 1 bytes @ 0x4
??___CMS_KeyModeSet:	; 1 bytes @ 0x4
??___CMS_KeyStart:	; 1 bytes @ 0x4
??___CMS_CurJudge:	; 1 bytes @ 0x4
??___CMS_NewRAMClr:	; 1 bytes @ 0x4
??___GET_32M_FREDAT:	; 1 bytes @ 0x4
??___lmul:	; 1 bytes @ 0x4
?___bmul:	; 1 bytes @ 0x4
??___lldiv:	; 1 bytes @ 0x4
??___lwdiv:	; 1 bytes @ 0x4
?_AD_Testing:	; 2 bytes @ 0x4
	global	?_abs
?_abs:	; 2 bytes @ 0x4
	global	?_Memory_Read
?_Memory_Read:	; 2 bytes @ 0x4
	global	Dec@max
Dec@max:	; 1 bytes @ 0x4
	global	SetFilterDelayReset@TimPtr
SetFilterDelayReset@TimPtr:	; 1 bytes @ 0x4
	global	TDS_Handle@Type
TDS_Handle@Type:	; 1 bytes @ 0x4
	global	LedControlSt@Sta
LedControlSt@Sta:	; 1 bytes @ 0x4
	global	SetStandbyState@Time
SetStandbyState@Time:	; 1 bytes @ 0x4
	global	Memory_Write@i
Memory_Write@i:	; 1 bytes @ 0x4
	global	AD_Testing@ad_ch
AD_Testing@ad_ch:	; 1 bytes @ 0x4
	global	___CMS_KeyIsIn@947
___CMS_KeyIsIn@947:	; 1 bytes @ 0x4
	global	___CMS_KeyOpen@952
___CMS_KeyOpen@952:	; 1 bytes @ 0x4
	global	___CMS_KeyHaveDown@956
___CMS_KeyHaveDown@956:	; 1 bytes @ 0x4
	global	___CMS_CurAdjMode@1032
___CMS_CurAdjMode@1032:	; 1 bytes @ 0x4
	global	___CMS_KeyModeSet@1035
___CMS_KeyModeSet@1035:	; 1 bytes @ 0x4
	global	___CMS_KeyStart@1038
___CMS_KeyStart@1038:	; 1 bytes @ 0x4
	global	___CMS_NewRAMClr@1051
___CMS_NewRAMClr@1051:	; 1 bytes @ 0x4
	global	___bmul@multiplicand
___bmul@multiplicand:	; 1 bytes @ 0x4
	global	DecF@max
DecF@max:	; 2 bytes @ 0x4
	global	BuzzerSet@filter
BuzzerSet@filter:	; 2 bytes @ 0x4
	global	Memory_Read@Addr
Memory_Read@Addr:	; 2 bytes @ 0x4
	global	abs@a
abs@a:	; 2 bytes @ 0x4
	ds	1
??_Page_ProgramData:	; 1 bytes @ 0x5
?_LedSetSt:	; 1 bytes @ 0x5
??_Dec:	; 1 bytes @ 0x5
??_LedControlSt:	; 1 bytes @ 0x5
??___CMS_KeyOpen:	; 1 bytes @ 0x5
??___CMS_KeyHaveDown:	; 1 bytes @ 0x5
??___bmul:	; 1 bytes @ 0x5
	global	Dec@var
Dec@var:	; 1 bytes @ 0x5
	global	LedSetSt@Sta
LedSetSt@Sta:	; 1 bytes @ 0x5
	global	LedControlSt@Num
LedControlSt@Num:	; 1 bytes @ 0x5
	global	SetStandbyState@Da
SetStandbyState@Da:	; 1 bytes @ 0x5
	global	AD_Testing@ad_lr
AD_Testing@ad_lr:	; 1 bytes @ 0x5
	global	___CMS_KeyIsIn@946
___CMS_KeyIsIn@946:	; 1 bytes @ 0x5
	global	___CMS_KeyOpen@951
___CMS_KeyOpen@951:	; 1 bytes @ 0x5
	global	___CMS_KeyHaveDown@955
___CMS_KeyHaveDown@955:	; 1 bytes @ 0x5
	ds	1
??___CMS_CheckTouchKey:	; 1 bytes @ 0x6
??_FilterLifeFunc:	; 1 bytes @ 0x6
??_FilterKeyInputRest:	; 1 bytes @ 0x6
??_ErrorHandle:	; 1 bytes @ 0x6
??_BuzzerSet:	; 1 bytes @ 0x6
??_SetStandbyState:	; 1 bytes @ 0x6
??_LedSetSt:	; 1 bytes @ 0x6
??_AllLedFlash:	; 1 bytes @ 0x6
??_ShiftMode_Handle:	; 1 bytes @ 0x6
??_GetMode_Handle:	; 1 bytes @ 0x6
??_StatusFun_Handle:	; 1 bytes @ 0x6
??_FactoryMode_Handle:	; 1 bytes @ 0x6
??_Memory_Read:	; 1 bytes @ 0x6
??_StandbyMode_Handle:	; 1 bytes @ 0x6
??_Run_Mode:	; 1 bytes @ 0x6
??_ReadDataArry:	; 1 bytes @ 0x6
??_EEPROM_Page:	; 1 bytes @ 0x6
??_main:	; 1 bytes @ 0x6
??___CMS_KeyStopClear:	; 1 bytes @ 0x6
psect	cstackBANK0,class=BANK0,space=1,noexec
global __pcstackBANK0
__pcstackBANK0:
??_AD_Testing:	; 1 bytes @ 0x0
??_abs:	; 1 bytes @ 0x0
??_DecF:	; 1 bytes @ 0x0
?_SetFilterDelayReset:	; 1 bytes @ 0x0
?_Memory_Write:	; 1 bytes @ 0x0
??___CMS_Noise_check:	; 1 bytes @ 0x0
??___CMS_CheckOnceResult:	; 1 bytes @ 0x0
??___CMS_CurAdjust:	; 1 bytes @ 0x0
	global	?_GetCurTdsHz
?_GetCurTdsHz:	; 2 bytes @ 0x0
	global	?___lwdiv
?___lwdiv:	; 2 bytes @ 0x0
	global	?___lmul
?___lmul:	; 4 bytes @ 0x0
	global	?___lldiv
?___lldiv:	; 4 bytes @ 0x0
	global	SetStandbyState@STY
SetStandbyState@STY:	; 1 bytes @ 0x0
	global	BuzzerSet@cnt
BuzzerSet@cnt:	; 1 bytes @ 0x0
	global	Tx_Display@Sum_Tot
Tx_Display@Sum_Tot:	; 1 bytes @ 0x0
	global	___CMS_KeyClearOne@958
___CMS_KeyClearOne@958:	; 1 bytes @ 0x0
	global	___CMS_Key_UNNOL_Check@1018
___CMS_Key_UNNOL_Check@1018:	; 1 bytes @ 0x0
	global	___bmul@product
___bmul@product:	; 1 bytes @ 0x0
	global	GetCurTdsHz@Tab
GetCurTdsHz@Tab:	; 2 bytes @ 0x0
	global	SetFilterDelayReset@Day
SetFilterDelayReset@Day:	; 2 bytes @ 0x0
	global	Memory_Write@Addr
Memory_Write@Addr:	; 2 bytes @ 0x0
	global	ReadDataArry@i
ReadDataArry@i:	; 2 bytes @ 0x0
	global	___CMS_KeyDatIIR@1023
___CMS_KeyDatIIR@1023:	; 2 bytes @ 0x0
	global	___lwdiv@divisor
___lwdiv@divisor:	; 2 bytes @ 0x0
	global	___lmul@multiplier
___lmul@multiplier:	; 4 bytes @ 0x0
	global	___lldiv@divisor
___lldiv@divisor:	; 4 bytes @ 0x0
	ds	1
?_KeyScan:	; 1 bytes @ 0x1
	global	Tx_Display@Temp1
Tx_Display@Temp1:	; 1 bytes @ 0x1
	global	KeyScan@num
KeyScan@num:	; 1 bytes @ 0x1
	global	___CMS_KeyStopClear@961
___CMS_KeyStopClear@961:	; 1 bytes @ 0x1
	global	___CMS_Key_UNNOL_Check@1017
___CMS_Key_UNNOL_Check@1017:	; 1 bytes @ 0x1
	global	___bmul@multiplier
___bmul@multiplier:	; 1 bytes @ 0x1
	ds	1
??_Led_Handle:	; 1 bytes @ 0x2
??_KeyScan:	; 1 bytes @ 0x2
??___CMS_CheckKeyOldValue:	; 1 bytes @ 0x2
	global	DecF@var
DecF@var:	; 1 bytes @ 0x2
	global	SetFilterDelayReset@hour
SetFilterDelayReset@hour:	; 1 bytes @ 0x2
	global	LedSetSt@Num
LedSetSt@Num:	; 1 bytes @ 0x2
	global	Memory_Write@Value
Memory_Write@Value:	; 1 bytes @ 0x2
	global	AD_Testing@ad_fd
AD_Testing@ad_fd:	; 1 bytes @ 0x2
	global	___CMS_CurAdjust@1046
___CMS_CurAdjust@1046:	; 1 bytes @ 0x2
	global	GetCurTdsHz@index
GetCurTdsHz@index:	; 2 bytes @ 0x2
	global	Tx_Display@i
Tx_Display@i:	; 2 bytes @ 0x2
	global	___CMS_KeyDatIIR@1024
___CMS_KeyDatIIR@1024:	; 2 bytes @ 0x2
	global	___lwdiv@dividend
___lwdiv@dividend:	; 2 bytes @ 0x2
	ds	1
??_GetDelayFilterFlag:	; 1 bytes @ 0x3
?_FilterTimeHandle:	; 1 bytes @ 0x3
??_WashHandle:	; 1 bytes @ 0x3
	global	SetFilterDelayReset@min
SetFilterDelayReset@min:	; 1 bytes @ 0x3
	global	AllLedFlash@Type
AllLedFlash@Type:	; 1 bytes @ 0x3
	global	ShiftMode_Handle@Mod
ShiftMode_Handle@Mod:	; 1 bytes @ 0x3
	global	___CMS_CurAdjust@1045
___CMS_CurAdjust@1045:	; 1 bytes @ 0x3
	global	AD_Testing@AD_Result
AD_Testing@AD_Result:	; 2 bytes @ 0x3
	global	Page_ProgramData@i
Page_ProgramData@i:	; 2 bytes @ 0x3
	global	___CMS_Noise_check@974
___CMS_Noise_check@974:	; 2 bytes @ 0x3
	global	FilterTimeHandle@Filter_time
FilterTimeHandle@Filter_time:	; 5 bytes @ 0x3
	ds	1
??_GetCurTdsHz:	; 1 bytes @ 0x4
	global	KeyScan@sw_port
KeyScan@sw_port:	; 1 bytes @ 0x4
	global	___lwdiv@counter
___lwdiv@counter:	; 1 bytes @ 0x4
	global	SetFilterDelayReset@sec
SetFilterDelayReset@sec:	; 2 bytes @ 0x4
	global	AllLedFlash@i
AllLedFlash@i:	; 2 bytes @ 0x4
	global	Led_Handle@i
Led_Handle@i:	; 2 bytes @ 0x4
	global	___CMS_CheckKeyOldValue@1006
___CMS_CheckKeyOldValue@1006:	; 2 bytes @ 0x4
	global	___CMS_KeyDatIIR@1022
___CMS_KeyDatIIR@1022:	; 2 bytes @ 0x4
	global	___CMS_CurAdjust@1047
___CMS_CurAdjust@1047:	; 2 bytes @ 0x4
	global	___lmul@multiplicand
___lmul@multiplicand:	; 4 bytes @ 0x4
	global	___lldiv@dividend
___lldiv@dividend:	; 4 bytes @ 0x4
	ds	1
??_CheckKey:	; 1 bytes @ 0x5
	global	GetDelayFilterFlag@PtrMin
GetDelayFilterFlag@PtrMin:	; 1 bytes @ 0x5
	global	AD_Testing@i
AD_Testing@i:	; 1 bytes @ 0x5
	global	___CMS_Noise_check@971
___CMS_Noise_check@971:	; 1 bytes @ 0x5
	global	___CMS_CheckOnceResult@989
___CMS_CheckOnceResult@989:	; 2 bytes @ 0x5
	global	___lwdiv@quotient
___lwdiv@quotient:	; 2 bytes @ 0x5
	ds	1
	global	CheckKey@St
CheckKey@St:	; 1 bytes @ 0x6
	global	___CMS_Noise_check@972
___CMS_Noise_check@972:	; 1 bytes @ 0x6
	global	___CMS_CheckKeyOldValue@1004
___CMS_CheckKeyOldValue@1004:	; 1 bytes @ 0x6
	global	AD_Testing@data
AD_Testing@data:	; 2 bytes @ 0x6
	global	___CMS_KeyDatIIR@1025
___CMS_KeyDatIIR@1025:	; 2 bytes @ 0x6
	ds	1
	global	___CMS_CheckOnceResult@980
___CMS_CheckOnceResult@980:	; 1 bytes @ 0x7
	global	CheckKey@i
CheckKey@i:	; 2 bytes @ 0x7
	global	___CMS_Noise_check@975
___CMS_Noise_check@975:	; 2 bytes @ 0x7
	global	___CMS_CheckKeyOldValue@1007
___CMS_CheckKeyOldValue@1007:	; 2 bytes @ 0x7
	ds	1
	global	FilterTimeHandle@FilterState
FilterTimeHandle@FilterState:	; 1 bytes @ 0x8
	global	___CMS_CheckOnceResult@981
___CMS_CheckOnceResult@981:	; 1 bytes @ 0x8
	global	___CMS_KeyDatIIR@1026
___CMS_KeyDatIIR@1026:	; 2 bytes @ 0x8
	global	___lmul@product
___lmul@product:	; 4 bytes @ 0x8
	global	___lldiv@quotient
___lldiv@quotient:	; 4 bytes @ 0x8
	ds	1
	global	FilterTimeHandle@Type
FilterTimeHandle@Type:	; 1 bytes @ 0x9
	global	___CMS_CheckOnceResult@985
___CMS_CheckOnceResult@985:	; 1 bytes @ 0x9
	global	___CMS_Noise_check@973
___CMS_Noise_check@973:	; 2 bytes @ 0x9
	global	___CMS_CheckKeyOldValue@1008
___CMS_CheckKeyOldValue@1008:	; 2 bytes @ 0x9
	ds	1
	global	FilterTimeHandle@FilterGetWater
FilterTimeHandle@FilterGetWater:	; 1 bytes @ 0xA
	global	___CMS_CheckOnceResult@986
___CMS_CheckOnceResult@986:	; 1 bytes @ 0xA
	global	___CMS_KeyDatIIR@1021
___CMS_KeyDatIIR@1021:	; 1 bytes @ 0xA
	global	GetCurTdsHz@i
GetCurTdsHz@i:	; 2 bytes @ 0xA
	ds	1
??_FilterTimeHandle:	; 1 bytes @ 0xB
	global	___CMS_Noise_check@970
___CMS_Noise_check@970:	; 1 bytes @ 0xB
	global	___CMS_CheckOnceResult@982
___CMS_CheckOnceResult@982:	; 1 bytes @ 0xB
	global	___CMS_CheckKeyOldValue@1009
___CMS_CheckKeyOldValue@1009:	; 2 bytes @ 0xB
	ds	1
	global	___lldiv@counter
___lldiv@counter:	; 1 bytes @ 0xC
	global	GetCurTdsHz@tmp
GetCurTdsHz@tmp:	; 2 bytes @ 0xC
	global	___CMS_CheckOnceResult@990
___CMS_CheckOnceResult@990:	; 2 bytes @ 0xC
	ds	1
	global	___CMS_CheckKeyOldValue@1005
___CMS_CheckKeyOldValue@1005:	; 1 bytes @ 0xD
	ds	1
	global	GetCurTdsHz@AdPtr
GetCurTdsHz@AdPtr:	; 1 bytes @ 0xE
	global	___CMS_CheckKeyOldValue@1003
___CMS_CheckKeyOldValue@1003:	; 1 bytes @ 0xE
	global	___CMS_CheckOnceResult@991
___CMS_CheckOnceResult@991:	; 2 bytes @ 0xE
	ds	1
??_TDS_Handle:	; 1 bytes @ 0xF
	ds	1
	global	___CMS_CheckOnceResult@983
___CMS_CheckOnceResult@983:	; 1 bytes @ 0x10
	ds	1
	global	___CMS_CheckOnceResult@984
___CMS_CheckOnceResult@984:	; 1 bytes @ 0x11
	ds	1
	global	___CMS_CheckOnceResult@988
___CMS_CheckOnceResult@988:	; 1 bytes @ 0x12
	ds	1
	global	___CMS_CheckOnceResult@987
___CMS_CheckOnceResult@987:	; 1 bytes @ 0x13
	global	TDS_Handle@NTC_
TDS_Handle@NTC_:	; 4 bytes @ 0x13
	ds	1
	global	___CMS_CheckOnceResult@979
___CMS_CheckOnceResult@979:	; 1 bytes @ 0x14
	ds	3
	global	TDS_Handle@PreTdsData
TDS_Handle@PreTdsData:	; 2 bytes @ 0x17
	ds	2
	global	TDS_Handle@i
TDS_Handle@i:	; 2 bytes @ 0x19
	ds	2
	global	TDS_Handle@Muni_c
TDS_Handle@Muni_c:	; 4 bytes @ 0x1B
	ds	4
	global	TDS_Handle@TDSTyp
TDS_Handle@TDSTyp:	; 1 bytes @ 0x1F
	ds	1
;!
;!Data Sizes:
;!    Strings     0
;!    Constant    520
;!    Data        0
;!    BSS         183
;!    Persistent  0
;!    Stack       0
;!
;!Auto Spaces:
;!    Space          Size  Autos    Used
;!    COMMON           14      6      10
;!    BANK0            80     32      80
;!    BANK1            80      4      72
;!    BANK2            80      0      64

;!
;!Pointer List with Targets:
;!
;!    SetStandbyState@Time	PTR unsigned char  size(1) Largest target is 1
;!		 -> WashRunTime(BANK0[1]), 
;!
;!    FilterTimeHandle@FilterGetWater	PTR unsigned int  size(1) Largest target is 2
;!		 -> FilterPCFGetWater(BANK0[2]), FilterROGetWater(BANK0[2]), 
;!
;!    FilterTimeHandle@FilterState	PTR unsigned char  size(1) Largest target is 1
;!		 -> FilterPCFState(BANK0[1]), FilterROState(BANK0[1]), 
;!
;!    TDS_Handle@TDSTyp	PTR struct . size(1) Largest target is 17
;!		 -> PureTDSTyp(BANK2[17]), 
;!
;!    GetDelayFilterFlag@PtrMin	PTR struct . size(1) Largest target is 5
;!		 -> FilterRO_time(BANK1[5]), FilterPCF_time(BANK1[5]), 
;!
;!    SetFilterDelayReset@TimPtr	PTR struct . size(1) Largest target is 5
;!		 -> FilterRO_time(BANK1[5]), FilterPCF_time(BANK1[5]), 
;!
;!    DecF@var	PTR unsigned int  size(1) Largest target is 5
;!		 -> FilterRO_time(BANK1[5]), FilterPCF_time(BANK1[5]), 
;!
;!    Dec@var	PTR unsigned char  size(1) Largest target is 5
;!		 -> FilterRO_time(BANK1[5]), FilterPCF_time(BANK1[5]), 
;!
;!    GetCurTdsHz@Tab	PTR unsigned int  size(2) Largest target is 380
;!		 -> PureHz_Tab(CODE[380]), 
;!
;!    GetCurTdsHz@AdPtr	PTR struct . size(1) Largest target is 17
;!		 -> PureTDSTyp(BANK2[17]), 
;!


;!
;!Critical Paths under _main in COMMON
;!
;!    _Run_Mode->_BuzzerSet
;!    _Run_Mode->_LedSetSt
;!    _Run_Mode->_SetStandbyState
;!    _StandbyMode_Handle->_BuzzerSet
;!    _StandbyMode_Handle->_LedSetSt
;!    _StandbyMode_Handle->_SetStandbyState
;!    _StatusFun_Handle->_SetStandbyState
;!    _WashHandle->_LedSetSt
;!    _WashHandle->_SetStandbyState
;!    _FactoryMode_Handle->_BuzzerSet
;!    _FactoryMode_Handle->_LedSetSt
;!    _Time_Count_Func->_AD_Testing
;!    _Time_Count_Func->_BuzzerSet
;!    _Time_Count_Func->_SetStandbyState
;!    _Time_Count_Func->_TaskAlarmHandle
;!    ___CMS_CheckTouchKey->___CMS_Key_UNNOL_Check
;!    ___CMS_KeyStopClear->___CMS_KeyClearOne
;!    ___CMS_CurAdjust->___CMS_CurJudge
;!    ___CMS_CheckOnceResult->___CMS_KeyHaveDown
;!    ___CMS_CheckOnceResult->___CMS_KeyIsIn
;!    ___CMS_CheckOnceResult->___CMS_KeyOpen
;!    ___CMS_CheckKeyOldValue->___CMS_KeyIsIn
;!    ___CMS_CheckKeyOldValue->_abs
;!    _Page_ProgramData->_Memory_Write
;!    _Led_Handle->_LedControlSt
;!    _GetDelayFilterFlag->_Dec
;!    _GetDelayFilterFlag->_DecF
;!    _FilterLifeFunc->_BuzzerSet
;!    _FilterTimeHandle->_LedSetSt
;!    _FilterKeyInputRest->_BuzzerSet
;!    _FilterKeyInputRest->_LedSetSt
;!    _ErrorHandle->_BuzzerSet
;!    _ErrorHandle->_LedSetSt
;!    _ShiftMode_Handle->_BuzzerSet
;!    _ShiftMode_Handle->_LedSetSt
;!    _ShiftMode_Handle->_SetStandbyState
;!    _AllLedFlash->_LedSetSt
;!    _LedSetSt->___bmul
;!    _KeyScan->_BuzzerSet
;!    _ReadDataArry->_Memory_Read
;!
;!Critical Paths under _Timer1_Isr in COMMON
;!
;!    None.
;!
;!Critical Paths under _main in BANK0
;!
;!    _StatusFun_Handle->_WashHandle
;!    _WashHandle->_LedSetSt
;!    _GetMode_Handle->_ShiftMode_Handle
;!    _Time_Count_Func->_TDS_Handle
;!    ___CMS_CheckTouchKey->___CMS_CheckOnceResult
;!    ___CMS_KeyStopClear->___CMS_KeyClearOne
;!    ___CMS_CheckKeyOldValue->_abs
;!    _TDS_Handle->_GetCurTdsHz
;!    _Page_ProgramData->_Memory_Write
;!    _Led_Handle->___bmul
;!    _GetDelayFilterFlag->_DecF
;!    _FilterLifeFunc->_FilterTimeHandle
;!    _FilterTimeHandle->_LedSetSt
;!    _FilterKeyInputRest->_SetFilterDelayReset
;!    _ErrorHandle->_AllLedFlash
;!    _ShiftMode_Handle->_LedSetSt
;!    _AllLedFlash->_LedSetSt
;!    _LedSetSt->___bmul
;!    _CheckKey->_KeyScan
;!    _KeyScan->_BuzzerSet
;!    _EEPROM_Page->_SetFilterDelayReset
;!
;!Critical Paths under _Timer1_Isr in BANK0
;!
;!    None.
;!
;!Critical Paths under _main in BANK1
;!
;!    _Run_Mode->_FactoryMode_Handle
;!    _FactoryMode_Handle->_Time_Count_Func
;!
;!Critical Paths under _Timer1_Isr in BANK1
;!
;!    None.
;!
;!Critical Paths under _main in BANK2
;!
;!    None.
;!
;!Critical Paths under _Timer1_Isr in BANK2
;!
;!    None.

;;
;;Main: autosize = 0, tempsize = 0, incstack = 0, save=0
;;

;!
;!Call Graph Tables:
;!
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (0) _main                                                 0     0      0  247017
;!                        _EEPROM_Page
;!                         _Initialize
;!                           _Run_Mode
;!                            _Set_PWM
;!                    _Set_Usart_Async
;!                    _Time_Count_Func
;! ---------------------------------------------------------------------------------
;! (1) _Set_Usart_Async                                      0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Set_PWM                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _Run_Mode                                             0     0      0  165165
;!                        _AllLedFlash
;!                          _BuzzerSet
;!                 _FactoryMode_Handle
;!                     _GetMode_Handle
;!                           _LedSetSt
;!                    _SetStandbyState
;!                   _ShiftMode_Handle
;!                 _StandbyMode_Handle
;! ---------------------------------------------------------------------------------
;! (2) _StandbyMode_Handle                                   0     0      0   31339
;!                          _BuzzerSet
;!                           _LedSetSt
;!                    _SetStandbyState
;!                   _ShiftMode_Handle
;!                   _StatusFun_Handle
;!                           _WrterEEP
;! ---------------------------------------------------------------------------------
;! (3) _StatusFun_Handle                                     0     0      0   10539
;!                    _SetStandbyState
;!                         _WashHandle
;! ---------------------------------------------------------------------------------
;! (4) _WashHandle                                           2     2      0    8844
;!                                              3 BANK0      2     2      0
;!                           _LedSetSt
;!                    _SetStandbyState
;! ---------------------------------------------------------------------------------
;! (2) _GetMode_Handle                                       0     0      0   10431
;!                   _ShiftMode_Handle
;!                           _WrterEEP
;! ---------------------------------------------------------------------------------
;! (2) _FactoryMode_Handle                                   1     1      0   95316
;!                                              3 BANK1      1     1      0
;!                        _AllLedFlash
;!                          _BuzzerSet
;!                           _LedSetSt
;!                    _Time_Count_Func
;! ---------------------------------------------------------------------------------
;! (1) _Time_Count_Func                                      3     3      0   79317
;!                                              0 BANK1      3     3      0
;!                         _AD_Testing
;!                          _BuzzerSet
;!                           _CheckKey
;!                        _ErrorHandle
;!                 _FilterKeyInputRest
;!                     _FilterLifeFunc
;!                 _GetDelayFilterFlag
;!                         _Led_Handle
;!                   _Page_ProgramData
;!                    _SetStandbyState
;!                         _TDS_Handle
;!                    _TaskAlarmHandle
;!                         _Tx_Display
;!                ___CMS_CheckTouchKey
;! ---------------------------------------------------------------------------------
;! (2) ___CMS_CheckTouchKey                                  1     1      0    7129
;!             ___CMS_CheckKeyOldValue
;!              ___CMS_CheckOnceResult
;!               ___CMS_CheckValidTime
;!                    ___CMS_CurAdjust
;!                    ___CMS_KeyDatIIR
;!                   ___CMS_KeyModeSet
;!                     ___CMS_KeyStart
;!                 ___CMS_KeyStopClear
;!              ___CMS_Key_UNNOL_Check
;!                    ___CMS_NewRAMClr
;!                  ___CMS_Noise_check
;!                   ___GET_32M_FREDAT
;! ---------------------------------------------------------------------------------
;! (3) ___GET_32M_FREDAT                                     0     0      0       0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_Noise_check                                   12    12      0     380
;!                                              0 BANK0     12    12      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_NewRAMClr                                      1     1      0     223
;!                                              4 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_Key_UNNOL_Check                                4     4      0     359
;!                                              4 COMMON     2     2      0
;!                                              0 BANK0      2     2      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_KeyStopClear                                   1     1      0     347
;!                                              1 BANK0      1     1      0
;!                  ___CMS_KeyClearOne
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_KeyClearOne                                    3     3      0     248
;!                                              4 COMMON     2     2      0
;!                                              0 BANK0      1     1      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_KeyDatIIR                                     11    11      0     656
;!                                              0 BANK0     11    11      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_CurAdjust                                      6     6      0     528
;!                                              0 BANK0      6     6      0
;!                   ___CMS_CurAdjMode
;!                     ___CMS_CurJudge
;!                   ___CMS_KeyModeSet
;!                     ___CMS_KeyStart
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_KeyStart                                       1     1      0      74
;!                                              4 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_KeyModeSet                                     1     1      0      34
;!                                              4 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_CurJudge                                       2     2      0       0
;!                                              4 COMMON     2     2      0
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_CurAdjMode                                     1     1      0     145
;!                                              4 COMMON     1     1      0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_CheckValidTime                                 0     0      0       0
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_CheckOnceResult                               21    21      0    2549
;!                                              0 BANK0     21    21      0
;!                  ___CMS_KeyHaveDown
;!                      ___CMS_KeyIsIn
;!                      ___CMS_KeyOpen
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_KeyOpen                                        2     1      1     173
;!                                              4 COMMON     2     1      1
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_KeyHaveDown                                    2     1      1     401
;!                                              4 COMMON     2     1      1
;! ---------------------------------------------------------------------------------
;! (3) ___CMS_CheckKeyOldValue                              13    13      0    1979
;!                                              2 BANK0     13    13      0
;!                      ___CMS_KeyIsIn
;!                                _abs
;! ---------------------------------------------------------------------------------
;! (4) _abs                                                  4     2      2     537
;!                                              4 COMMON     2     0      2
;!                                              0 BANK0      2     2      0
;! ---------------------------------------------------------------------------------
;! (4) ___CMS_KeyIsIn                                        2     2      0     102
;!                                              4 COMMON     2     2      0
;! ---------------------------------------------------------------------------------
;! (2) _Tx_Display                                           4     4      0     278
;!                                              0 BANK0      4     4      0
;! ---------------------------------------------------------------------------------
;! (2) _TaskAlarmHandle                                      2     2      0       0
;!                                              4 COMMON     2     2      0
;! ---------------------------------------------------------------------------------
;! (2) _TDS_Handle                                          18    17      1    3083
;!                                              4 COMMON     1     0      1
;!                                             15 BANK0     17    17      0
;!                        _GetCurTdsHz
;!                            ___lldiv
;!                             ___lmul
;!                            ___lwdiv
;! ---------------------------------------------------------------------------------
;! (3) ___lwdiv                                              7     3      4     395
;!                                              0 BANK0      7     3      4
;! ---------------------------------------------------------------------------------
;! (3) ___lmul                                              12     4      8     290
;!                                              0 BANK0     12     4      8
;! ---------------------------------------------------------------------------------
;! (3) ___lldiv                                             13     5      8     395
;!                                              0 BANK0     13     5      8
;! ---------------------------------------------------------------------------------
;! (3) _GetCurTdsHz                                         15    11      4     732
;!                                              0 BANK0     15    11      4
;! ---------------------------------------------------------------------------------
;! (2) _Page_ProgramData                                     2     2      0     383
;!                                              3 BANK0      2     2      0
;!                       _Memory_Write
;! ---------------------------------------------------------------------------------
;! (3) _Memory_Write                                         4     1      3     250
;!                                              4 COMMON     1     1      0
;!                                              0 BANK0      3     0      3
;! ---------------------------------------------------------------------------------
;! (2) _Led_Handle                                           4     4      0    2759
;!                                              2 BANK0      4     4      0
;!                       _LedControlSt
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (3) _LedControlSt                                         2     1      1     972
;!                                              4 COMMON     2     1      1
;! ---------------------------------------------------------------------------------
;! (2) _GetDelayFilterFlag                                   3     3      0     909
;!                                              3 BANK0      3     3      0
;!                                _Dec
;!                               _DecF
;! ---------------------------------------------------------------------------------
;! (3) _DecF                                                 5     3      2     172
;!                                              4 COMMON     2     0      2
;!                                              0 BANK0      3     3      0
;! ---------------------------------------------------------------------------------
;! (3) _Dec                                                  2     1      1     454
;!                                              4 COMMON     2     1      1
;! ---------------------------------------------------------------------------------
;! (2) _FilterLifeFunc                                       0     0      0   10071
;!                          _BuzzerSet
;!                   _FilterTimeHandle
;! ---------------------------------------------------------------------------------
;! (3) _FilterTimeHandle                                    12     4      8    8546
;!                                              3 BANK0     12     4      8
;!                           _LedSetSt
;! ---------------------------------------------------------------------------------
;! (2) _FilterKeyInputRest                                   0     0      0   21399
;!                          _BuzzerSet
;!                           _LedSetSt
;!                _SetFilterDelayReset
;!                   _ShiftMode_Handle
;!                           _WrterEEP
;! ---------------------------------------------------------------------------------
;! (2) _ErrorHandle                                          0     0      0   26384
;!                        _AllLedFlash
;!                          _BuzzerSet
;!                            _GetStop
;!                           _LedSetSt
;!                   _ShiftMode_Handle
;! ---------------------------------------------------------------------------------
;! (3) _ShiftMode_Handle                                     1     1      0   10431
;!                                              3 BANK0      1     1      0
;!                          _BuzzerSet
;!                           _LedSetSt
;!                    _SetStandbyState
;! ---------------------------------------------------------------------------------
;! (2) _SetStandbyState                                      3     1      2    1695
;!                                              4 COMMON     2     0      2
;!                                              0 BANK0      1     1      0
;! ---------------------------------------------------------------------------------
;! (3) _GetStop                                              0     0      0       0
;! ---------------------------------------------------------------------------------
;! (3) _AllLedFlash                                          3     3      0    7279
;!                                              3 BANK0      3     3      0
;!                           _LedSetSt
;! ---------------------------------------------------------------------------------
;! (4) _LedSetSt                                             2     1      1    7149
;!                                              5 COMMON     1     0      1
;!                                              2 BANK0      1     1      0
;!                             ___bmul
;! ---------------------------------------------------------------------------------
;! (3) ___bmul                                               3     2      1     941
;!                                              4 COMMON     1     0      1
;!                                              0 BANK0      2     2      0
;! ---------------------------------------------------------------------------------
;! (2) _CheckKey                                             4     4      0    2953
;!                                              5 BANK0      4     4      0
;!                            _KeyScan
;! ---------------------------------------------------------------------------------
;! (3) _KeyScan                                              4     3      1    2625
;!                                              1 BANK0      4     3      1
;!                          _BuzzerSet
;! ---------------------------------------------------------------------------------
;! (3) _BuzzerSet                                            3     1      2    1525
;!                                              4 COMMON     2     0      2
;!                                              0 BANK0      1     1      0
;! ---------------------------------------------------------------------------------
;! (2) _AD_Testing                                          10     8      2     749
;!                                              4 COMMON     2     0      2
;!                                              0 BANK0      8     8      0
;! ---------------------------------------------------------------------------------
;! (1) _Initialize                                           0     0      0       0
;!                           _Init_ram
;! ---------------------------------------------------------------------------------
;! (2) _Init_ram                                             0     0      0       0
;! ---------------------------------------------------------------------------------
;! (1) _EEPROM_Page                                          0     0      0    2535
;!                       _ReadDataArry
;!                _SetFilterDelayReset
;!                           _WrterEEP
;! ---------------------------------------------------------------------------------
;! (3) _WrterEEP                                             0     0      0       0
;! ---------------------------------------------------------------------------------
;! (3) _SetFilterDelayReset                                  7     1      6    2294
;!                                              4 COMMON     1     1      0
;!                                              0 BANK0      6     0      6
;! ---------------------------------------------------------------------------------
;! (2) _ReadDataArry                                         2     2      0     241
;!                                              0 BANK0      2     2      0
;!                        _Memory_Read
;! ---------------------------------------------------------------------------------
;! (3) _Memory_Read                                          2     0      2     108
;!                                              4 COMMON     2     0      2
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 4
;! ---------------------------------------------------------------------------------
;! (Depth) Function   	        Calls       Base Space   Used Autos Params    Refs
;! ---------------------------------------------------------------------------------
;! (8) _Timer1_Isr                                           4     4      0       0
;!                                              0 COMMON     4     4      0
;!                ___CMS_TouchKeyValue
;! ---------------------------------------------------------------------------------
;! (10) ___CMS_TouchKeyValue                                 0     0      0       0
;! ---------------------------------------------------------------------------------
;! Estimated maximum stack depth 10
;! ---------------------------------------------------------------------------------
;!
;! Call Graph Graphs:
;!
;! _main (ROOT)
;!   _EEPROM_Page
;!     _ReadDataArry
;!       _Memory_Read
;!     _SetFilterDelayReset
;!     _WrterEEP
;!   _Initialize
;!     _Init_ram
;!   _Run_Mode
;!     _AllLedFlash
;!       _LedSetSt
;!         ___bmul
;!     _BuzzerSet
;!     _FactoryMode_Handle
;!       _AllLedFlash
;!         _LedSetSt
;!           ___bmul
;!       _BuzzerSet
;!       _LedSetSt
;!         ___bmul
;!       _Time_Count_Func
;!         _AD_Testing
;!         _BuzzerSet
;!         _CheckKey
;!           _KeyScan
;!             _BuzzerSet
;!         _ErrorHandle
;!           _AllLedFlash
;!             _LedSetSt
;!               ___bmul
;!           _BuzzerSet
;!           _GetStop
;!           _LedSetSt
;!             ___bmul
;!           _ShiftMode_Handle
;!             _BuzzerSet
;!             _LedSetSt
;!               ___bmul
;!             _SetStandbyState
;!         _FilterKeyInputRest
;!           _BuzzerSet
;!           _LedSetSt
;!             ___bmul
;!           _SetFilterDelayReset
;!           _ShiftMode_Handle
;!             _BuzzerSet
;!             _LedSetSt
;!               ___bmul
;!             _SetStandbyState
;!           _WrterEEP
;!         _FilterLifeFunc
;!           _BuzzerSet
;!           _FilterTimeHandle
;!             _LedSetSt
;!               ___bmul
;!         _GetDelayFilterFlag
;!           _Dec
;!           _DecF
;!         _Led_Handle
;!           _LedControlSt
;!           ___bmul
;!         _Page_ProgramData
;!           _Memory_Write
;!         _SetStandbyState
;!         _TDS_Handle
;!           _GetCurTdsHz
;!           ___lldiv
;!           ___lmul
;!           ___lwdiv
;!         _TaskAlarmHandle
;!         _Tx_Display
;!         ___CMS_CheckTouchKey
;!           ___CMS_CheckKeyOldValue
;!             ___CMS_KeyIsIn
;!             _abs
;!           ___CMS_CheckOnceResult
;!             ___CMS_KeyHaveDown
;!             ___CMS_KeyIsIn
;!             ___CMS_KeyOpen
;!           ___CMS_CheckValidTime
;!           ___CMS_CurAdjust
;!             ___CMS_CurAdjMode
;!             ___CMS_CurJudge
;!             ___CMS_KeyModeSet
;!             ___CMS_KeyStart
;!           ___CMS_KeyDatIIR
;!           ___CMS_KeyModeSet
;!           ___CMS_KeyStart
;!           ___CMS_KeyStopClear
;!             ___CMS_KeyClearOne
;!           ___CMS_Key_UNNOL_Check
;!           ___CMS_NewRAMClr
;!           ___CMS_Noise_check
;!           ___GET_32M_FREDAT
;!     _GetMode_Handle
;!       _ShiftMode_Handle
;!         _BuzzerSet
;!         _LedSetSt
;!           ___bmul
;!         _SetStandbyState
;!       _WrterEEP
;!     _LedSetSt
;!       ___bmul
;!     _SetStandbyState
;!     _ShiftMode_Handle
;!       _BuzzerSet
;!       _LedSetSt
;!         ___bmul
;!       _SetStandbyState
;!     _StandbyMode_Handle
;!       _BuzzerSet
;!       _LedSetSt
;!         ___bmul
;!       _SetStandbyState
;!       _ShiftMode_Handle
;!         _BuzzerSet
;!         _LedSetSt
;!           ___bmul
;!         _SetStandbyState
;!       _StatusFun_Handle
;!         _SetStandbyState
;!         _WashHandle
;!           _LedSetSt
;!             ___bmul
;!           _SetStandbyState
;!       _WrterEEP
;!   _Set_PWM
;!   _Set_Usart_Async
;!   _Time_Count_Func
;!     _AD_Testing
;!     _BuzzerSet
;!     _CheckKey
;!       _KeyScan
;!         _BuzzerSet
;!     _ErrorHandle
;!       _AllLedFlash
;!         _LedSetSt
;!           ___bmul
;!       _BuzzerSet
;!       _GetStop
;!       _LedSetSt
;!         ___bmul
;!       _ShiftMode_Handle
;!         _BuzzerSet
;!         _LedSetSt
;!           ___bmul
;!         _SetStandbyState
;!     _FilterKeyInputRest
;!       _BuzzerSet
;!       _LedSetSt
;!         ___bmul
;!       _SetFilterDelayReset
;!       _ShiftMode_Handle
;!         _BuzzerSet
;!         _LedSetSt
;!           ___bmul
;!         _SetStandbyState
;!       _WrterEEP
;!     _FilterLifeFunc
;!       _BuzzerSet
;!       _FilterTimeHandle
;!         _LedSetSt
;!           ___bmul
;!     _GetDelayFilterFlag
;!       _Dec
;!       _DecF
;!     _Led_Handle
;!       _LedControlSt
;!       ___bmul
;!     _Page_ProgramData
;!       _Memory_Write
;!     _SetStandbyState
;!     _TDS_Handle
;!       _GetCurTdsHz
;!       ___lldiv
;!       ___lmul
;!       ___lwdiv
;!     _TaskAlarmHandle
;!     _Tx_Display
;!     ___CMS_CheckTouchKey
;!       ___CMS_CheckKeyOldValue
;!         ___CMS_KeyIsIn
;!         _abs
;!       ___CMS_CheckOnceResult
;!         ___CMS_KeyHaveDown
;!         ___CMS_KeyIsIn
;!         ___CMS_KeyOpen
;!       ___CMS_CheckValidTime
;!       ___CMS_CurAdjust
;!         ___CMS_CurAdjMode
;!         ___CMS_CurJudge
;!         ___CMS_KeyModeSet
;!         ___CMS_KeyStart
;!       ___CMS_KeyDatIIR
;!       ___CMS_KeyModeSet
;!       ___CMS_KeyStart
;!       ___CMS_KeyStopClear
;!         ___CMS_KeyClearOne
;!       ___CMS_Key_UNNOL_Check
;!       ___CMS_NewRAMClr
;!       ___CMS_Noise_check
;!       ___GET_32M_FREDAT
;!
;! _Timer1_Isr (ROOT)
;!   ___CMS_TouchKeyValue
;!

;! Address spaces:

;!Name               Size   Autos  Total    Cost      Usage
;!BITCOMMON            E      0       1       0        7.1%
;!NULL                 0      0       0       0        0.0%
;!CODE                 0      0       0       0        0.0%
;!COMMON               E      6       A       1       71.4%
;!BITSFR0              0      0       0       1        0.0%
;!SFR0                 0      0       0       1        0.0%
;!BITSFR1              0      0       0       2        0.0%
;!SFR1                 0      0       0       2        0.0%
;!STACK                0      0       0       2        0.0%
;!BITBANK0            50      0       0       3        0.0%
;!BANK0               50     20      50       4      100.0%
;!BITSFR3              0      0       0       4        0.0%
;!SFR3                 0      0       0       4        0.0%
;!BITBANK1            50      0       0       5        0.0%
;!BITSFR2              0      0       0       5        0.0%
;!SFR2                 0      0       0       5        0.0%
;!BANK1               50      4      48       6       90.0%
;!BANK2               50      0      40       7       80.0%
;!ABS                  0      0      E2       8        0.0%
;!DATA                 0      0      E2       9        0.0%
;!BITBANK2            50      0       0      10        0.0%

	global	_main

;; *************** function _main *****************
;; Defined at:
;;		line 2700 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels required when called:   10
;; This function calls:
;;		_EEPROM_Page
;;		_Initialize
;;		_Run_Mode
;;		_Set_PWM
;;		_Set_Usart_Async
;;		_Time_Count_Func
;; This function is called by:
;;		Startup code after reset
;; This function uses a non-reentrant model
;;
psect	maintext,global,class=CODE,delta=2,split=1,group=0
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	2700
global __pmaintext
__pmaintext:	;psect for function _main
psect	maintext
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	2700
	global	__size_of_main
	__size_of_main	equ	__end_of_main-_main
	
_main:	
;incstack = 0
	opt	stack 2
; Regs used in _main: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	2703
	
l11163:	
# 2703 "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	2704
# 2704 "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	maintext
	line	2705
	
l11165:	
;main.c: 2705: Initialize();
	fcall	_Initialize
	line	2706
	
l11167:	
;main.c: 2706: EEPROM_Page();
	fcall	_EEPROM_Page
	line	2708
	
l11169:	
;main.c: 2708: Set_PWM();
	fcall	_Set_PWM
	line	2709
	
l11171:	
;main.c: 2709: Set_Usart_Async();
	fcall	_Set_Usart_Async
	line	2711
	
l11173:	
;main.c: 2711: Tx_Type.TxType.Tx_FH1=0xa5;
	movlw	low(0A5h)
	movwf	(_Tx_Type)^0100h
	line	2712
	
l11175:	
;main.c: 2712: Tx_Type.TxType.Tx_FH2=0xa6;
	movlw	low(0A6h)
	movwf	0+(_Tx_Type)^0100h+01h
	line	2713
	
l11177:	
;main.c: 2713: Tx_Type.TxType.Tx_TotalLength=0x11U;
	movlw	low(011h)
	movwf	0+(_Tx_Type)^0100h+02h
	line	2715
	
l11179:	
;main.c: 2715: PureTDSTyp.TdsData=0x03;
	movlw	03h
	movwf	0+(_PureTDSTyp)^0100h+0Fh
	clrf	1+(_PureTDSTyp)^0100h+0Fh
	line	2722
	
l11181:	
;main.c: 2722: RC2=0;
	bcf	status, 6	;RP1=0, select bank0
	bcf	(58/8),(58)&7	;volatile
	line	2723
	
l11183:	
;main.c: 2723: {RA2=0;_BITS2.Bits.bit_1=0;};
	bcf	(42/8),(42)&7	;volatile
	
l11185:	
	bcf	(__BITS2),1
	line	2724
	
l11187:	
;main.c: 2724: RC3=0;
	bcf	(59/8),(59)&7	;volatile
	line	2732
;main.c: 2732: while(1)
	
l1506:	
	line	2736
# 2736 "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	maintext
	line	2738
	
l11189:	
;main.c: 2738: Time_Count_Func();
	fcall	_Time_Count_Func
	line	2741
	
l11191:	
;main.c: 2741: Run_Mode();
	fcall	_Run_Mode
	goto	l1506
	global	start
	ljmp	start
	opt stack 0
	line	2749
GLOBAL	__end_of_main
	__end_of_main:
	signat	_main,89
	global	_Set_Usart_Async

;; *************** function _Set_Usart_Async *****************
;; Defined at:
;;		line 2643 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/200
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text1,local,class=CODE,delta=2,merge=1,group=0
	line	2643
global __ptext1
__ptext1:	;psect for function _Set_Usart_Async
psect	text1
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	2643
	global	__size_of_Set_Usart_Async
	__size_of_Set_Usart_Async	equ	__end_of_Set_Usart_Async-_Set_Usart_Async
	
_Set_Usart_Async:	
;incstack = 0
	opt	stack 8
; Regs used in _Set_Usart_Async: [wreg]
	line	2659
	
l8817:	
;main.c: 2659: SPBRG1 = 103;
	movlw	low(067h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(152)^080h	;volatile
	line	2660
	
l8819:	
;main.c: 2660: SYNC1 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2300/8)^0100h,(2300)&7	;volatile
	line	2661
	
l8821:	
;main.c: 2661: SCKP1 = 0;
	bcf	(2299/8)^0100h,(2299)&7	;volatile
	line	2663
	
l8823:	
;main.c: 2663: SPEN1 = 1;
	bsf	(2095/8)^0100h,(2095)&7	;volatile
	line	2664
	
l8825:	
;main.c: 2664: RC1IE = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bcf	(1129/8)^080h,(1129)&7	;volatile
	line	2665
	
l8827:	
;main.c: 2665: TX1IE = 0;
	bcf	(1130/8)^080h,(1130)&7	;volatile
	line	2666
	
l8829:	
;main.c: 2666: RX9EN1 = 0;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2094/8)^0100h,(2094)&7	;volatile
	line	2667
	
l8831:	
;main.c: 2667: TX9EN1 = 0;
	bcf	(2302/8)^0100h,(2302)&7	;volatile
	line	2668
	
l8833:	
;main.c: 2668: CREN1 = 0;
	bcf	(2092/8)^0100h,(2092)&7	;volatile
	line	2669
	
l8835:	
;main.c: 2669: TXEN1 = 1;
	bsf	(2301/8)^0100h,(2301)&7	;volatile
	line	2670
	
l1498:	
	return
	opt stack 0
GLOBAL	__end_of_Set_Usart_Async
	__end_of_Set_Usart_Async:
	signat	_Set_Usart_Async,89
	global	_Set_PWM

;; *************** function _Set_PWM *****************
;; Defined at:
;;		line 2671 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/200
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text2,local,class=CODE,delta=2,merge=1,group=0
	line	2671
global __ptext2
__ptext2:	;psect for function _Set_PWM
psect	text2
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	2671
	global	__size_of_Set_PWM
	__size_of_Set_PWM	equ	__end_of_Set_PWM-_Set_PWM
	
_Set_PWM:	
;incstack = 0
	opt	stack 8
; Regs used in _Set_PWM: [wreg+status,2]
	line	2673
	
l8837:	
;main.c: 2673: PWMTL = 0xfa;
	movlw	low(0FAh)
	bsf	status, 6	;RP1=1, select bank2
	movwf	(283)^0100h	;volatile
	line	2675
;main.c: 2675: PWMTH = 0B00000100;
	movlw	low(04h)
	movwf	(284)^0100h	;volatile
	line	2680
	
l8839:	
;main.c: 2680: PWMD01H = 0x00;
	clrf	(273)^0100h	;volatile
	line	2684
	
l8841:	
;main.c: 2684: PWMD1L = 0x7d;
	movlw	low(07Dh)
	movwf	(269)^0100h	;volatile
	line	2696
	
l8843:	
;main.c: 2696: PWMCON1 = 0B01000000;
	movlw	low(040h)
	movwf	(263)^0100h	;volatile
	line	2697
	
l8845:	
;main.c: 2697: PWMCON0 = 0B10100000;
	movlw	low(0A0h)
	movwf	(262)^0100h	;volatile
	line	2699
	
l1501:	
	return
	opt stack 0
GLOBAL	__end_of_Set_PWM
	__end_of_Set_PWM:
	signat	_Set_PWM,89
	global	_Run_Mode

;; *************** function _Run_Mode *****************
;; Defined at:
;;		line 1944 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    9
;; This function calls:
;;		_AllLedFlash
;;		_BuzzerSet
;;		_FactoryMode_Handle
;;		_GetMode_Handle
;;		_LedSetSt
;;		_SetStandbyState
;;		_ShiftMode_Handle
;;		_StandbyMode_Handle
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text3,local,class=CODE,delta=2,merge=1,group=0
	line	1944
global __ptext3
__ptext3:	;psect for function _Run_Mode
psect	text3
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	1944
	global	__size_of_Run_Mode
	__size_of_Run_Mode	equ	__end_of_Run_Mode-_Run_Mode
	
_Run_Mode:	
;incstack = 0
	opt	stack 2
; Regs used in _Run_Mode: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1946
	
l11069:	
;main.c: 1946: switch(Mode){
	goto	l11127
	line	1950
	
l11071:	
;main.c: 1950: AllLedFlash(1);
	movlw	low(01h)
	fcall	_AllLedFlash
	line	1951
	
l11073:	
;main.c: 1951: _BITS.Bits.bit_5=0x01;
	bsf	(__BITS),5
	line	1952
	
l11075:	
;main.c: 1952: Timer_Power_100ms=0;
	clrf	(_Timer_Power_100ms)
	line	1953
	
l11077:	
;main.c: 1953: PowerStep=1;
	clrf	(_PowerStep)
	incf	(_PowerStep),f
	line	1954
	
l11079:	
;main.c: 1954: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	line	1955
	
l11081:	
;main.c: 1955: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1957
;main.c: 1957: break;
	goto	l1382
	line	1959
	
l11083:	
;main.c: 1959: if(Timer_Power_100ms>=30){
	movlw	low(01Eh)
	subwf	(_Timer_Power_100ms),w
	skipc
	goto	u10471
	goto	u10470
u10471:
	goto	l1382
u10470:
	line	1960
	
l11085:	
;main.c: 1960: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1961
	
l11087:	
;main.c: 1961: PowerStep=2;
	movlw	low(02h)
	movwf	(_PowerStep)
	goto	l1382
	line	1967
	
l11089:	
;main.c: 1967: if(Timer_Power_100ms>=31){
	movlw	low(01Fh)
	subwf	(_Timer_Power_100ms),w
	skipc
	goto	u10481
	goto	u10480
u10481:
	goto	l1382
u10480:
	line	1968
	
l11091:	
;main.c: 1968: ShiftMode_Handle(2);
	movlw	low(02h)
	fcall	_ShiftMode_Handle
	line	1970
;main.c: 1970: SetStandbyState(WashState,&WashRunTime, 18);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(012h)
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	goto	l1382
	line	1974
	
l11093:	
;main.c: 1974: Timer_Power_100ms=0;
	clrf	(_Timer_Power_100ms)
	line	1975
	
l11095:	
;main.c: 1975: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1979
	
l11097:	
;main.c: 1979: LedSetSt(1, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(01h)
	fcall	_LedSetSt
	line	1980
	
l11099:	
;main.c: 1980: LedSetSt(5, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(05h)
	fcall	_LedSetSt
	line	1981
	
l11101:	
;main.c: 1981: LedSetSt(3, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(03h)
	fcall	_LedSetSt
	line	1988
	
l11103:	
;main.c: 1988: PowerStep=4;
	movlw	low(04h)
	movwf	(_PowerStep)
	line	1989
;main.c: 1989: break;
	goto	l1382
	line	1991
	
l11105:	
;main.c: 1991: if(Timer_Power_100ms>=10){
	movlw	low(0Ah)
	subwf	(_Timer_Power_100ms),w
	skipc
	goto	u10491
	goto	u10490
u10491:
	goto	l1382
u10490:
	line	1992
	
l11107:	
;main.c: 1992: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1993
;main.c: 1993: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	line	1994
;main.c: 1994: LedSetSt(4, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(04h)
	fcall	_LedSetSt
	line	1995
;main.c: 1995: LedSetSt(2, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(02h)
	fcall	_LedSetSt
	line	2006
	
l11109:	
;main.c: 2006: PowerStep=5;
	movlw	low(05h)
	movwf	(_PowerStep)
	goto	l1382
	line	2012
	
l11111:	
;main.c: 2012: if(Timer_Power_100ms>=20){
	movlw	low(014h)
	subwf	(_Timer_Power_100ms),w
	skipc
	goto	u10501
	goto	u10500
u10501:
	goto	l1382
u10500:
	line	2013
	
l11113:	
;main.c: 2013: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	2014
;main.c: 2014: ShiftMode_Handle(2);
	movlw	low(02h)
	fcall	_ShiftMode_Handle
	goto	l1382
	line	1948
	
l11117:	
	movf	(_PowerStep),w
	; Switch size 1, requested type "space"
; Number of cases is 6, Range of values is 0 to 5
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           19    10 (average)
; direct_byte           26     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l11071
	xorlw	1^0	; case 1
	skipnz
	goto	l11083
	xorlw	2^1	; case 2
	skipnz
	goto	l11089
	xorlw	3^2	; case 3
	skipnz
	goto	l11093
	xorlw	4^3	; case 4
	skipnz
	goto	l11105
	xorlw	5^4	; case 5
	skipnz
	goto	l11111
	goto	l1382
	opt asmopt_pop

	line	2022
	
l11119:	
;main.c: 2022: StandbyMode_Handle();
	fcall	_StandbyMode_Handle
	line	2023
;main.c: 2023: break;
	goto	l1382
	line	2025
	
l11121:	
;main.c: 2025: GetMode_Handle();
	fcall	_GetMode_Handle
	line	2026
;main.c: 2026: break;
	goto	l1382
	line	2028
	
l11123:	
;main.c: 2028: FactoryMode_Handle();
	fcall	_FactoryMode_Handle
	line	2029
;main.c: 2029: break;
	goto	l1382
	line	2030
;main.c: 2030: case 3:
	
l1381:	
	line	2031
;main.c: 2031: {RA2=0;_BITS2.Bits.bit_1=0;};
	bcf	(42/8),(42)&7	;volatile
	bcf	(__BITS2),1
	line	2032
;main.c: 2032: RC3=0;
	bcf	(59/8),(59)&7	;volatile
	line	2033
;main.c: 2033: RC2=0;
	bcf	(58/8),(58)&7	;volatile
	line	2034
;main.c: 2034: break;
	goto	l1382
	line	1946
	
l11127:	
	movf	(_Mode),w
	; Switch size 1, requested type "space"
; Number of cases is 5, Range of values is 0 to 5
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           16     9 (average)
; direct_byte           26     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l11117
	xorlw	2^0	; case 2
	skipnz
	goto	l11119
	xorlw	3^2	; case 3
	skipnz
	goto	l1381
	xorlw	4^3	; case 4
	skipnz
	goto	l11121
	xorlw	5^4	; case 5
	skipnz
	goto	l11123
	goto	l1382
	opt asmopt_pop

	line	2036
	
l1382:	
	return
	opt stack 0
GLOBAL	__end_of_Run_Mode
	__end_of_Run_Mode:
	signat	_Run_Mode,89
	global	_StandbyMode_Handle

;; *************** function _StandbyMode_Handle *****************
;; Defined at:
;;		line 1807 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    7
;; This function calls:
;;		_BuzzerSet
;;		_LedSetSt
;;		_SetStandbyState
;;		_ShiftMode_Handle
;;		_StatusFun_Handle
;;		_WrterEEP
;; This function is called by:
;;		_Run_Mode
;; This function uses a non-reentrant model
;;
psect	text4,local,class=CODE,delta=2,merge=1,group=0
	line	1807
global __ptext4
__ptext4:	;psect for function _StandbyMode_Handle
psect	text4
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	1807
	global	__size_of_StandbyMode_Handle
	__size_of_StandbyMode_Handle	equ	__end_of_StandbyMode_Handle-_StandbyMode_Handle
	
_StandbyMode_Handle:	
;incstack = 0
	opt	stack 3
; Regs used in _StandbyMode_Handle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1841
	
l11001:	
;main.c: 1811: static U8_T Ti_1h=0;
;main.c: 1841: if(Timer_Standby_1s>=3600)
	movlw	0Eh
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_Standby_1s+1)^080h,w
	movlw	010h
	skipnz
	subwf	(_Timer_Standby_1s)^080h,w
	skipc
	goto	u10321
	goto	u10320
u10321:
	goto	l11015
u10320:
	line	1844
	
l11003:	
;main.c: 1843: {
;main.c: 1844: Timer_Standby_1s=0;
	clrf	(_Timer_Standby_1s)^080h
	clrf	(_Timer_Standby_1s+1)^080h
	line	1845
	
l11005:	
;main.c: 1845: if(Timer_Standby_1H<0xf0)
	movlw	0
	subwf	(_Timer_Standby_1H+1)^080h,w
	movlw	0F0h
	skipnz
	subwf	(_Timer_Standby_1H)^080h,w
	skipnc
	goto	u10331
	goto	u10330
u10331:
	goto	l11009
u10330:
	line	1846
	
l11007:	
;main.c: 1846: Timer_Standby_1H++;
	incf	(_Timer_Standby_1H)^080h,f
	skipnz
	incf	(_Timer_Standby_1H+1)^080h,f
	line	1848
	
l11009:	
;main.c: 1848: if(++Ti_1h>=10){
	movlw	low(0Ah)
	bcf	status, 5	;RP0=0, select bank0
	incf	(StandbyMode_Handle@Ti_1h),f
	subwf	((StandbyMode_Handle@Ti_1h)),w
	skipc
	goto	u10341
	goto	u10340
u10341:
	goto	l11015
u10340:
	line	1849
	
l11011:	
;main.c: 1849: Ti_1h=0;
	clrf	(StandbyMode_Handle@Ti_1h)
	line	1850
	
l11013:	
;main.c: 1850: WrterEEP();
	fcall	_WrterEEP
	line	1856
	
l11015:	
;main.c: 1851: }
;main.c: 1852: }
;main.c: 1856: if(Timer_Standby_1H>=72)
	movlw	0
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_Standby_1H+1)^080h,w
	movlw	048h
	skipnz
	subwf	(_Timer_Standby_1H)^080h,w
	skipc
	goto	u10351
	goto	u10350
u10351:
	goto	l11025
u10350:
	line	1860
	
l11017:	
;main.c: 1858: {
;main.c: 1860: Timer_Standby_1H=0;
	clrf	(_Timer_Standby_1H)^080h
	clrf	(_Timer_Standby_1H+1)^080h
	line	1861
	
l11019:	
;main.c: 1861: if(_BITS2.Bits.bit_2==0){
	bcf	status, 5	;RP0=0, select bank0
	btfsc	(__BITS2),2
	goto	u10361
	goto	u10360
u10361:
	goto	l11025
u10360:
	line	1863
	
l11021:	
;main.c: 1863: if(StandByStatus==NornalStopState){
	movf	((_StandByStatus)),w
	btfss	status,2
	goto	u10371
	goto	u10370
u10371:
	goto	l11025
u10370:
	line	1864
	
l11023:	
;main.c: 1864: SetStandbyState(WashState,&WashRunTime, 30);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(01Eh)
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	line	1874
	
l11025:	
;main.c: 1865: }
;main.c: 1866: }
;main.c: 1867: }
;main.c: 1873: if((KeyPacket_y[2].KeyState==LongPressDown)
;main.c: 1874: &&(KeyPacket_y[1].KeyState==NotPress))
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u10381
	goto	u10380
u10381:
	goto	l11035
u10380:
	
l11027:	
	movf	(0+(_KeyPacket_y)+03h),w
	btfss	status,2
	goto	u10391
	goto	u10390
u10391:
	goto	l11035
u10390:
	line	1876
	
l11029:	
;main.c: 1875: {
;main.c: 1876: KeyPacket_y[2].KeyState=SuperPressDown;
	movlw	low(03h)
	movwf	0+(_KeyPacket_y)+06h
	line	1877
;main.c: 1877: if(Time_Power_1s<=10){
	movlw	low(0Bh)
	subwf	(_Time_Power_1s),w
	skipnc
	goto	u10401
	goto	u10400
u10401:
	goto	l11035
u10400:
	line	1878
	
l11031:	
;main.c: 1878: BuzzerSet(3, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(03h)
	fcall	_BuzzerSet
	line	1879
	
l11033:	
;main.c: 1879: FilterFastCheck=1;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_FilterFastCheck)
	incf	(_FilterFastCheck),f
	line	1910
;main.c: 1880: }
	
l11035:	
;main.c: 1907: }
;main.c: 1908: }
;main.c: 1910: if(KeyPacket_y[2].KeyState==ShortRelease)
		movlw	6
	xorwf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u10411
	goto	u10410
u10411:
	goto	l11049
u10410:
	line	1912
	
l11037:	
;main.c: 1911: {
;main.c: 1912: KeyPacket_y[2].KeyState=NotPress;
	clrf	0+(_KeyPacket_y)+06h
	line	1913
	
l11039:	
;main.c: 1913: if(_BITS1.Bits.bit_0==0){
	btfsc	(__BITS1),0
	goto	u10421
	goto	u10420
u10421:
	goto	l11049
u10420:
	line	1914
	
l11041:	
;main.c: 1914: BuzzerSet(1, 50);
	movlw	032h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1915
	
l11043:	
;main.c: 1915: if(StandByStatus==WashState)
	bcf	status, 5	;RP0=0, select bank0
		decf	((_StandByStatus)),w
	btfss	status,2
	goto	u10431
	goto	u10430
u10431:
	goto	l11047
u10430:
	line	1917
	
l11045:	
;main.c: 1916: {
;main.c: 1917: LedSetSt(1, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1918
;main.c: 1918: SetStandbyState(NornalStopState,&WashRunTime, 0);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	clrf	(SetStandbyState@Da)
	movlw	low(0)
	fcall	_SetStandbyState
	line	1919
;main.c: 1919: }
	goto	l11049
	line	1922
	
l11047:	
;main.c: 1920: else
;main.c: 1921: {
;main.c: 1922: SetStandbyState(WashState,&WashRunTime, 180);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(0B4h)
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	line	1931
	
l11049:	
;main.c: 1923: }
;main.c: 1924: }
;main.c: 1926: }
;main.c: 1931: if(KeyPacket_y[0].KeyState==NotPress){
	bcf	status, 5	;RP0=0, select bank0
	movf	((_KeyPacket_y)),w
	btfss	status,2
	goto	u10441
	goto	u10440
u10441:
	goto	l11053
u10440:
	line	1932
	
l11051:	
;main.c: 1932: StatusFun_Handle();
	fcall	_StatusFun_Handle
	line	1933
;main.c: 1933: }
	goto	l1360
	line	1936
	
l11053:	
;main.c: 1934: else
;main.c: 1935: {
;main.c: 1936: if(StandByStatus==BackState)
		movlw	3
	xorwf	((_StandByStatus)),w
	btfss	status,2
	goto	u10451
	goto	u10450
u10451:
	goto	l1359
u10450:
	line	1938
	
l11055:	
;main.c: 1937: {
;main.c: 1938: SetStandbyState(NornalStopState,&WashRunTime, 0);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	clrf	(SetStandbyState@Da)
	movlw	low(0)
	fcall	_SetStandbyState
	line	1939
	
l1359:	
	line	1940
;main.c: 1939: }
;main.c: 1940: ShiftMode_Handle(4);
	movlw	low(04h)
	fcall	_ShiftMode_Handle
	line	1943
	
l1360:	
	return
	opt stack 0
GLOBAL	__end_of_StandbyMode_Handle
	__end_of_StandbyMode_Handle:
	signat	_StandbyMode_Handle,89
	global	_StatusFun_Handle

;; *************** function _StatusFun_Handle *****************
;; Defined at:
;;		line 1420 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_SetStandbyState
;;		_WashHandle
;; This function is called by:
;;		_StandbyMode_Handle
;; This function uses a non-reentrant model
;;
psect	text5,local,class=CODE,delta=2,merge=1,group=0
	line	1420
global __ptext5
__ptext5:	;psect for function _StatusFun_Handle
psect	text5
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	1420
	global	__size_of_StatusFun_Handle
	__size_of_StatusFun_Handle	equ	__end_of_StatusFun_Handle-_StatusFun_Handle
	
_StatusFun_Handle:	
;incstack = 0
	opt	stack 3
; Regs used in _StatusFun_Handle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1422
	
l10869:	
;main.c: 1422: switch(StandByStatus){
	goto	l10877
	line	1426
	
l10871:	
;main.c: 1425: case BackState:
;main.c: 1426: WashHandle();
	fcall	_WashHandle
	line	1427
;main.c: 1427: break;
	goto	l1252
	line	1429
	
l10873:	
;main.c: 1429: SetStandbyState(NornalStopState,&WashRunTime, 0);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	clrf	(SetStandbyState@Da)
	movlw	low(0)
	fcall	_SetStandbyState
	line	1430
;main.c: 1430: break;
	goto	l1252
	line	1422
	
l10877:	
	movf	(_StandByStatus),w
	; Switch size 1, requested type "space"
; Number of cases is 3, Range of values is 0 to 3
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           10     6 (average)
; direct_byte           20     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l10873
	xorlw	1^0	; case 1
	skipnz
	goto	l10871
	xorlw	3^1	; case 3
	skipnz
	goto	l10871
	goto	l1252
	opt asmopt_pop

	line	1432
	
l1252:	
	return
	opt stack 0
GLOBAL	__end_of_StatusFun_Handle
	__end_of_StatusFun_Handle:
	signat	_StatusFun_Handle,89
	global	_WashHandle

;; *************** function _WashHandle *****************
;; Defined at:
;;		line 1400 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_LedSetSt
;;		_SetStandbyState
;; This function is called by:
;;		_StatusFun_Handle
;; This function uses a non-reentrant model
;;
psect	text6,local,class=CODE,delta=2,merge=1,group=0
	line	1400
global __ptext6
__ptext6:	;psect for function _WashHandle
psect	text6
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	1400
	global	__size_of_WashHandle
	__size_of_WashHandle	equ	__end_of_WashHandle-_WashHandle
	
_WashHandle:	
;incstack = 0
	opt	stack 3
; Regs used in _WashHandle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1401
	
l10727:	
;main.c: 1401: if((LedMod[1].LedState==0)&&(StandByStatus==WashState)){
	bsf	status, 6	;RP1=1, select bank2
	movf	(0+(_LedMod)^0100h+05h),w
	btfss	status,2
	goto	u9911
	goto	u9910
u9911:
	goto	l10733
u9910:
	
l10729:	
	bcf	status, 6	;RP1=0, select bank0
		decf	((_StandByStatus)),w
	btfss	status,2
	goto	u9921
	goto	u9920
u9921:
	goto	l10733
u9920:
	line	1402
	
l10731:	
;main.c: 1402: LedSetSt(1, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1404
	
l10733:	
;main.c: 1403: }
;main.c: 1404: if(Timer_WashRun_1s>=WashRunTime){
	bcf	status, 6	;RP1=0, select bank0
	movf	(_WashRunTime),w
	movwf	(??_WashHandle+0)+0
	clrf	(??_WashHandle+0)+0+1
	movf	1+(??_WashHandle+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_WashRun_1s+1)^080h,w
	skipz
	goto	u9935
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(??_WashHandle+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_WashRun_1s)^080h,w
u9935:
	skipc
	goto	u9931
	goto	u9930
u9931:
	goto	l1244
u9930:
	line	1410
	
l10735:	
;main.c: 1410: Time_made_1s=0;
	clrf	(_Time_made_1s)^080h
	clrf	(_Time_made_1s+1)^080h
	line	1413
	
l10737:	
;main.c: 1413: _BITS1.Bits.bit_0=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(__BITS1),0
	line	1414
	
l10739:	
;main.c: 1414: LedSetSt(1, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1415
	
l10741:	
;main.c: 1415: SetStandbyState(NornalStopState,&WashRunTime, 0);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	clrf	(SetStandbyState@Da)
	movlw	low(0)
	fcall	_SetStandbyState
	line	1417
	
l1244:	
	return
	opt stack 0
GLOBAL	__end_of_WashHandle
	__end_of_WashHandle:
	signat	_WashHandle,89
	global	_GetMode_Handle

;; *************** function _GetMode_Handle *****************
;; Defined at:
;;		line 1304 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_ShiftMode_Handle
;;		_WrterEEP
;; This function is called by:
;;		_Run_Mode
;; This function uses a non-reentrant model
;;
psect	text7,local,class=CODE,delta=2,merge=1,group=0
	line	1304
global __ptext7
__ptext7:	;psect for function _GetMode_Handle
psect	text7
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	1304
	global	__size_of_GetMode_Handle
	__size_of_GetMode_Handle	equ	__end_of_GetMode_Handle-_GetMode_Handle
	
_GetMode_Handle:	
;incstack = 0
	opt	stack 4
; Regs used in _GetMode_Handle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1308
	
l10887:	
;main.c: 1308: if(KeyPacket_y[0].KeyState==NotPress)
	movf	((_KeyPacket_y)),w
	btfss	status,2
	goto	u10151
	goto	u10150
u10151:
	goto	l10893
u10150:
	line	1310
	
l10889:	
;main.c: 1309: {
;main.c: 1310: ShiftMode_Handle(2);
	movlw	low(02h)
	fcall	_ShiftMode_Handle
	line	1311
	
l10891:	
;main.c: 1311: Timer_Standby_1H=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_Timer_Standby_1H)^080h
	clrf	(_Timer_Standby_1H+1)^080h
	line	1315
	
l10893:	
;main.c: 1312: }
;main.c: 1315: if(Time_GetWater_1s>=60){
	movlw	low(03Ch)
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_Time_GetWater_1s),w
	skipc
	goto	u10161
	goto	u10160
u10161:
	goto	l10911
u10160:
	line	1316
	
l10895:	
;main.c: 1316: Time_GetWater_1s=0;
	clrf	(_Time_GetWater_1s)
	line	1317
	
l10897:	
;main.c: 1317: GetWater_ML+=21;
	movlw	015h
	bsf	status, 5	;RP0=1, select bank1
	addwf	(_GetWater_ML)^080h,f
	skipnc
	incf	(_GetWater_ML+1)^080h,f
	line	1334
	
l10899:	
;main.c: 1334: if(GetWater_ML>=(21*10)){
	movlw	0
	subwf	(_GetWater_ML+1)^080h,w
	movlw	0D2h
	skipnz
	subwf	(_GetWater_ML)^080h,w
	skipc
	goto	u10171
	goto	u10170
u10171:
	goto	l10911
u10170:
	line	1335
	
l10901:	
;main.c: 1335: GetWater_ML=0;
	clrf	(_GetWater_ML)^080h
	clrf	(_GetWater_ML+1)^080h
	line	1336
	
l10903:	
;main.c: 1336: if(FilterROGetWater<0xfff0)
	movlw	0FFh
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_FilterROGetWater+1),w
	movlw	0F0h
	skipnz
	subwf	(_FilterROGetWater),w
	skipnc
	goto	u10181
	goto	u10180
u10181:
	goto	l1228
u10180:
	line	1337
	
l10905:	
;main.c: 1337: FilterROGetWater+=21;
	movlw	015h
	addwf	(_FilterROGetWater),f
	skipnc
	incf	(_FilterROGetWater+1),f
	
l1228:	
	line	1338
;main.c: 1338: if(FilterPCFGetWater<0xfff0)
	movlw	0FFh
	subwf	(_FilterPCFGetWater+1),w
	movlw	0F0h
	skipnz
	subwf	(_FilterPCFGetWater),w
	skipnc
	goto	u10191
	goto	u10190
u10191:
	goto	l10909
u10190:
	line	1339
	
l10907:	
;main.c: 1339: FilterPCFGetWater+=21;
	movlw	015h
	addwf	(_FilterPCFGetWater),f
	skipnc
	incf	(_FilterPCFGetWater+1),f
	line	1340
	
l10909:	
;main.c: 1340: WrterEEP();
	fcall	_WrterEEP
	line	1350
	
l10911:	
;main.c: 1341: }
;main.c: 1343: }
;main.c: 1349: if((FilterROGetWater>=(21*2))
;main.c: 1350: &&(FilterPCFGetWater>=(21*2))){
	movlw	0
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_FilterROGetWater+1),w
	movlw	02Ah
	skipnz
	subwf	(_FilterROGetWater),w
	skipc
	goto	u10201
	goto	u10200
u10201:
	goto	l10917
u10200:
	
l10913:	
	movlw	0
	subwf	(_FilterPCFGetWater+1),w
	movlw	02Ah
	skipnz
	subwf	(_FilterPCFGetWater),w
	skipc
	goto	u10211
	goto	u10210
u10211:
	goto	l10917
u10210:
	line	1352
	
l10915:	
;main.c: 1352: _BITS1.Bits.bit_7=1;
	bsf	(__BITS1),7
	line	1354
	
l10917:	
;main.c: 1353: }
;main.c: 1354: if(Read_Word_Buff[11]!=0)
	bsf	status, 5	;RP0=1, select bank1
	movf	(0+(_Read_Word_Buff)^080h+0Bh),w
	btfsc	status,2
	goto	u10221
	goto	u10220
u10221:
	goto	l1232
u10220:
	line	1355
	
l10919:	
;main.c: 1355: Read_Word_Buff[11]=2;
	movlw	low(02h)
	movwf	0+(_Read_Word_Buff)^080h+0Bh
	line	1357
	
l1232:	
	return
	opt stack 0
GLOBAL	__end_of_GetMode_Handle
	__end_of_GetMode_Handle:
	signat	_GetMode_Handle,89
	global	_FactoryMode_Handle

;; *************** function _FactoryMode_Handle *****************
;; Defined at:
;;		line 1434 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  Step            1    3[BANK1 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       1       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       1       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    8
;; This function calls:
;;		_AllLedFlash
;;		_BuzzerSet
;;		_LedSetSt
;;		_Time_Count_Func
;; This function is called by:
;;		_Run_Mode
;; This function uses a non-reentrant model
;;
psect	text8,local,class=CODE,delta=2,merge=1,group=0
	line	1434
global __ptext8
__ptext8:	;psect for function _FactoryMode_Handle
psect	text8
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	1434
	global	__size_of_FactoryMode_Handle
	__size_of_FactoryMode_Handle	equ	__end_of_FactoryMode_Handle-_FactoryMode_Handle
	
_FactoryMode_Handle:	
;incstack = 0
	opt	stack 2
; Regs used in _FactoryMode_Handle: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	1435
	
l10921:	
;main.c: 1435: U8_T Step=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(FactoryMode_Handle@Step)^080h
	line	1436
;main.c: 1436: Timer_Power_100ms=0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_Timer_Power_100ms)
	line	1437
	
l10923:	
;main.c: 1437: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1438
;main.c: 1438: while(1){
	
l1255:	
	line	1439
# 1439 "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text8
	line	1440
	
l10925:	
;main.c: 1440: _BITS.Bits.bit_5=0x01;
	bsf	(__BITS),5
	line	1441
;main.c: 1441: switch(Step){
	goto	l10997
	line	1456
	
l10927:	
;main.c: 1456: LedSetSt(1, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(01h)
	fcall	_LedSetSt
	line	1458
;main.c: 1458: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	line	1461
	
l10929:	
;main.c: 1461: if(Timer_Power_100ms>=10){
	movlw	low(0Ah)
	subwf	(_Timer_Power_100ms),w
	skipc
	goto	u10231
	goto	u10230
u10231:
	goto	l10999
u10230:
	line	1463
	
l10931:	
;main.c: 1463: Step=1;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(FactoryMode_Handle@Step)^080h
	incf	(FactoryMode_Handle@Step)^080h,f
	goto	l10999
	line	1466
;main.c: 1466: case 1:
	
l1260:	
	line	1467
;main.c: 1467: RC2=1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(58/8),(58)&7	;volatile
	line	1468
;main.c: 1468: {RA2=1;_BITS2.Bits.bit_1=1;};
	bsf	(42/8),(42)&7	;volatile
	bsf	(__BITS2),1
	line	1469
;main.c: 1469: RC3=1;
	bsf	(59/8),(59)&7	;volatile
	line	1470
;main.c: 1470: RA1=1;
	bsf	(41/8),(41)&7	;volatile
	line	1471
	
l10933:	
;main.c: 1471: if(KeyPacket_y[1].KeyState==ShortRelease)
		movlw	6
	xorwf	(0+(_KeyPacket_y)+03h),w
	btfss	status,2
	goto	u10241
	goto	u10240
u10241:
	goto	l10999
u10240:
	line	1473
	
l10935:	
;main.c: 1472: {
;main.c: 1473: KeyPacket_y[1].KeyState=NotPress;
	clrf	0+(_KeyPacket_y)+03h
	line	1474
	
l10937:	
;main.c: 1474: RC2=0;
	bcf	(58/8),(58)&7	;volatile
	line	1475
	
l10939:	
;main.c: 1475: {RA2=0;_BITS2.Bits.bit_1=0;};
	bcf	(42/8),(42)&7	;volatile
	
l10941:	
	bcf	(__BITS2),1
	line	1476
	
l10943:	
;main.c: 1476: RC3=0;
	bcf	(59/8),(59)&7	;volatile
	line	1477
	
l10945:	
;main.c: 1477: RA1=0;
	bcf	(41/8),(41)&7	;volatile
	line	1478
	
l10947:	
;main.c: 1478: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1479
	
l10949:	
;main.c: 1479: Step=2;
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(FactoryMode_Handle@Step)^080h
	line	1480
	
l10951:	
;main.c: 1480: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	goto	l10999
	line	1484
	
l10953:	
;main.c: 1484: if(KeyPacket_y[0].KeyState==NotPress)
	bcf	status, 5	;RP0=0, select bank0
	movf	((_KeyPacket_y)),w
	btfss	status,2
	goto	u10251
	goto	u10250
u10251:
	goto	l10957
u10250:
	line	1486
	
l10955:	
;main.c: 1485: {
;main.c: 1486: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1487
;main.c: 1487: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1488
;main.c: 1488: LedSetSt(0, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(0)
	fcall	_LedSetSt
	line	1489
;main.c: 1489: }
	goto	l10959
	line	1492
	
l10957:	
;main.c: 1490: else
;main.c: 1491: {
;main.c: 1492: LedSetSt(4, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(04h)
	fcall	_LedSetSt
	line	1493
;main.c: 1493: LedSetSt(2, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(02h)
	fcall	_LedSetSt
	line	1494
;main.c: 1494: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	line	1496
	
l10959:	
;main.c: 1495: }
;main.c: 1496: if(KeyPacket_y[2].KeyState==ShortRelease)
		movlw	6
	xorwf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u10261
	goto	u10260
u10261:
	goto	l10999
u10260:
	line	1498
	
l10961:	
;main.c: 1497: {
;main.c: 1498: KeyPacket_y[2].KeyState=NotPress;
	clrf	0+(_KeyPacket_y)+06h
	line	1499
	
l10963:	
;main.c: 1499: Step=3;
	movlw	low(03h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(FactoryMode_Handle@Step)^080h
	line	1500
	
l10965:	
;main.c: 1500: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1501
	
l10967:	
;main.c: 1501: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	goto	l10999
	line	1506
	
l10969:	
;main.c: 1506: if(PureTDSTyp.TdsData>10&&PureTDSTyp.TdsData<50){
	movlw	0
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	subwf	1+(_PureTDSTyp)^0100h+0Fh,w
	movlw	0Bh
	skipnz
	subwf	0+(_PureTDSTyp)^0100h+0Fh,w
	skipc
	goto	u10271
	goto	u10270
u10271:
	goto	l10975
u10270:
	
l10971:	
	movlw	0
	subwf	1+(_PureTDSTyp)^0100h+0Fh,w
	movlw	032h
	skipnz
	subwf	0+(_PureTDSTyp)^0100h+0Fh,w
	skipnc
	goto	u10281
	goto	u10280
u10281:
	goto	l10975
u10280:
	line	1507
	
l10973:	
;main.c: 1507: LedSetSt(5, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(05h)
	fcall	_LedSetSt
	line	1508
;main.c: 1508: LedSetSt(3, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(03h)
	fcall	_LedSetSt
	line	1509
;main.c: 1509: LedSetSt(1, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(01h)
	fcall	_LedSetSt
	line	1510
;main.c: 1510: }
	goto	l10977
	line	1513
	
l10975:	
;main.c: 1511: else
;main.c: 1512: {
;main.c: 1513: LedSetSt(4, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(04h)
	fcall	_LedSetSt
	line	1514
;main.c: 1514: LedSetSt(2, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(02h)
	fcall	_LedSetSt
	line	1515
;main.c: 1515: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	line	1517
	
l10977:	
;main.c: 1516: }
;main.c: 1517: if(KeyPacket_y[2].KeyState==ShortPressDown)
		decf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u10291
	goto	u10290
u10291:
	goto	l10999
u10290:
	line	1519
	
l10979:	
;main.c: 1518: {
;main.c: 1519: KeyPacket_y[2].KeyState=NotPress;
	clrf	0+(_KeyPacket_y)+06h
	line	1520
	
l10981:	
;main.c: 1520: Step=4;
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(FactoryMode_Handle@Step)^080h
	line	1521
	
l10983:	
;main.c: 1521: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	1522
	
l10985:	
;main.c: 1522: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	goto	l10999
	line	1526
	
l10987:	
;main.c: 1526: if(Temp_Ntc>15&&PureTDSTyp.TdsData<45){
	movlw	low(010h)
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_Temp_Ntc),w
	skipc
	goto	u10301
	goto	u10300
u10301:
	goto	l10993
u10300:
	
l10989:	
	movlw	0
	bsf	status, 6	;RP1=1, select bank2
	subwf	1+(_PureTDSTyp)^0100h+0Fh,w
	movlw	02Dh
	skipnz
	subwf	0+(_PureTDSTyp)^0100h+0Fh,w
	skipnc
	goto	u10311
	goto	u10310
u10311:
	goto	l10993
u10310:
	line	1528
	
l10991:	
;main.c: 1528: LedSetSt(1, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(01h)
	fcall	_LedSetSt
	line	1529
;main.c: 1529: }
	goto	l10999
	line	1532
	
l10993:	
;main.c: 1530: else
;main.c: 1531: {
;main.c: 1532: LedSetSt(0, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(0)
	fcall	_LedSetSt
	goto	l10999
	line	1441
	
l10997:	
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movf	(FactoryMode_Handle@Step)^080h,w
	; Switch size 1, requested type "space"
; Number of cases is 5, Range of values is 0 to 4
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           16     9 (average)
; direct_byte           23     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l10927
	xorlw	1^0	; case 1
	skipnz
	goto	l1260
	xorlw	2^1	; case 2
	skipnz
	goto	l10953
	xorlw	3^2	; case 3
	skipnz
	goto	l10969
	xorlw	4^3	; case 4
	skipnz
	goto	l10987
	goto	l10999
	opt asmopt_pop

	line	1536
	
l10999:	
;main.c: 1536: Time_Count_Func();
	fcall	_Time_Count_Func
	goto	l1255
	return
	opt stack 0
	line	1540
GLOBAL	__end_of_FactoryMode_Handle
	__end_of_FactoryMode_Handle:
	signat	_FactoryMode_Handle,89
	global	_Time_Count_Func

;; *************** function _Time_Count_Func *****************
;; Defined at:
;;		line 575 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       3       0
;;      Totals:         0       0       3       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    7
;; This function calls:
;;		_AD_Testing
;;		_BuzzerSet
;;		_CheckKey
;;		_ErrorHandle
;;		_FilterKeyInputRest
;;		_FilterLifeFunc
;;		_GetDelayFilterFlag
;;		_Led_Handle
;;		_Page_ProgramData
;;		_SetStandbyState
;;		_TDS_Handle
;;		_TaskAlarmHandle
;;		_Tx_Display
;;		___CMS_CheckTouchKey
;; This function is called by:
;;		_FactoryMode_Handle
;;		_main
;; This function uses a non-reentrant model
;;
psect	text9,local,class=CODE,delta=2,merge=1,group=0
	line	575
global __ptext9
__ptext9:	;psect for function _Time_Count_Func
psect	text9
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	575
	global	__size_of_Time_Count_Func
	__size_of_Time_Count_Func	equ	__end_of_Time_Count_Func-_Time_Count_Func
	
_Time_Count_Func:	
;incstack = 0
	opt	stack 4
; Regs used in _Time_Count_Func: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	line	577
	
l10743:	
;main.c: 577: if(_BITS2.Bits.bit_0){
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(__BITS2),0
	goto	u9941
	goto	u9940
u9941:
	goto	l1091
u9940:
	line	578
	
l10745:	
;main.c: 578: _BITS2.Bits.bit_0=0;
	bcf	(__BITS2),0
	line	580
	
l10747:	
;main.c: 580: AD_Testing(1,15,0);
	movlw	low(0Fh)
	movwf	(AD_Testing@ad_ch)
	clrf	(AD_Testing@ad_lr)
	movlw	low(01h)
	fcall	_AD_Testing
	line	581
;main.c: 581: __CMS_CheckTouchKey();
	fcall	___CMS_CheckTouchKey
	line	582
	
l10749:	
;main.c: 582: CheckKey();
	fcall	_CheckKey
	line	584
	
l10751:	
;main.c: 584: if(Mode!=5)
		movlw	5
	xorwf	((_Mode)),w
	btfsc	status,2
	goto	u9951
	goto	u9950
u9951:
	goto	l10755
u9950:
	line	585
	
l10753:	
;main.c: 585: FilterLifeFunc();
	fcall	_FilterLifeFunc
	line	586
	
l10755:	
;main.c: 586: TaskAlarmHandle();
	fcall	_TaskAlarmHandle
	line	587
	
l10757:	
;main.c: 587: Led_Handle();
	fcall	_Led_Handle
	line	591
	
l10759:	
;main.c: 591: FilterKeyInputRest();
	fcall	_FilterKeyInputRest
	line	592
	
l10761:	
;main.c: 592: Time_100ms++;
	bcf	status, 5	;RP0=0, select bank0
	incf	(_Time_100ms),f
	line	593
	
l10763:	
;main.c: 593: if(Time_100ms>=10){
	movlw	low(0Ah)
	subwf	(_Time_100ms),w
	skipc
	goto	u9961
	goto	u9960
u9961:
	goto	l1091
u9960:
	line	594
	
l10765:	
;main.c: 594: Time_100ms=0;
	clrf	(_Time_100ms)
	line	595
	
l10767:	
;main.c: 595: Timer_Power_100ms++;
	incf	(_Timer_Power_100ms),f
	line	597
	
l10769:	
;main.c: 597: Time_1s++;
	incf	(_Time_1s),f
	line	598
	
l10771:	
;main.c: 598: if(Time_1s>=10){
	movlw	low(0Ah)
	subwf	(_Time_1s),w
	skipc
	goto	u9971
	goto	u9970
u9971:
	goto	l1091
u9970:
	line	599
	
l10773:	
;main.c: 599: Time_1s=0;
	clrf	(_Time_1s)
	line	600
	
l10775:	
;main.c: 600: if(Mode!=0){
	movf	((_Mode)),w
	btfsc	status,2
	goto	u9981
	goto	u9980
u9981:
	goto	l10779
u9980:
	line	601
	
l10777:	
;main.c: 601: Tx_Display();
	fcall	_Tx_Display
	line	603
	
l10779:	
;main.c: 602: }
;main.c: 603: if(Mode!=0)
	movf	((_Mode)),w
	btfsc	status,2
	goto	u9991
	goto	u9990
u9991:
	goto	l10783
u9990:
	line	604
	
l10781:	
;main.c: 604: ErrorHandle();
	fcall	_ErrorHandle
	line	606
	
l10783:	
;main.c: 606: if(Time_Power_1s<0xf0)
	movlw	low(0F0h)
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_Time_Power_1s),w
	skipnc
	goto	u10001
	goto	u10000
u10001:
	goto	l10787
u10000:
	line	607
	
l10785:	
;main.c: 607: Time_Power_1s++;
	incf	(_Time_Power_1s),f
	line	608
	
l10787:	
;main.c: 608: if(_BITS.Bits.bit_4==1){
	btfss	(__BITS),4
	goto	u10011
	goto	u10010
u10011:
	goto	l10793
u10010:
	line	609
	
l10789:	
;main.c: 609: _BITS.Bits.bit_4=0;
	bcf	(__BITS),4
	line	610
	
l10791:	
;main.c: 610: Page_ProgramData();
	fcall	_Page_ProgramData
	line	612
	
l10793:	
;main.c: 611: }
;main.c: 612: if(FilterRst_1s<0xfff0)
	movlw	0FFh
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_FilterRst_1s+1)^080h,w
	movlw	0F0h
	skipnz
	subwf	(_FilterRst_1s)^080h,w
	skipnc
	goto	u10021
	goto	u10020
u10021:
	goto	l10797
u10020:
	line	613
	
l10795:	
;main.c: 613: FilterRst_1s++;
	incf	(_FilterRst_1s)^080h,f
	skipnz
	incf	(_FilterRst_1s+1)^080h,f
	line	616
	
l10797:	
;main.c: 616: if(_BITS2.Bits.bit_1==1){
	bcf	status, 5	;RP0=0, select bank0
	btfss	(__BITS2),1
	goto	u10031
	goto	u10030
u10031:
	goto	l10801
u10030:
	line	617
	
l10799:	
;main.c: 617: Timer_LongGetWater_1s++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_Timer_LongGetWater_1s)^080h,f
	skipnz
	incf	(_Timer_LongGetWater_1s+1)^080h,f
	line	618
;main.c: 618: }
	goto	l10803
	line	621
	
l10801:	
;main.c: 619: else
;main.c: 620: {
;main.c: 621: Timer_LongGetWater_1s=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_Timer_LongGetWater_1s)^080h
	clrf	(_Timer_LongGetWater_1s+1)^080h
	line	624
	
l10803:	
;main.c: 622: }
;main.c: 624: if(_BITS.Bits.bit_5==0x01){
	btfss	(__BITS),5
	goto	u10041
	goto	u10040
u10041:
	goto	l10835
u10040:
	line	625
	
l10805:	
;main.c: 625: _BITS1.Bits.bit_4=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(__BITS1),4
	line	626
;main.c: 626: _BITS1.Bits.bit_6=0;
	bcf	(__BITS1),6
	line	627
;main.c: 627: _BITS2.Bits.bit_2=0;
	bcf	(__BITS2),2
	line	628
	
l10807:	
;main.c: 628: Time_GetWater_1s++;
	incf	(_Time_GetWater_1s),f
	line	629
	
l10809:	
;main.c: 630: Timer_BackT_1H=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_Timer_Standby_1s)^080h
	clrf	(_Timer_Standby_1s+1)^080h
	line	632
	
l10811:	
;main.c: 632: if(FilterFastCheck==1){
	bcf	status, 5	;RP0=0, select bank0
		decf	((_FilterFastCheck)),w
	btfss	status,2
	goto	u10051
	goto	u10050
u10051:
	goto	l10815
u10050:
	line	633
	
l10813:	
;main.c: 633: FilterROGetWater+=21;
	movlw	015h
	addwf	(_FilterROGetWater),f
	skipnc
	incf	(_FilterROGetWater+1),f
	line	634
;main.c: 634: FilterPCFGetWater+=21;
	movlw	015h
	addwf	(_FilterPCFGetWater),f
	skipnc
	incf	(_FilterPCFGetWater+1),f
	line	637
	
l10815:	
;main.c: 635: }
;main.c: 637: Time_made_1s++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_Time_made_1s)^080h,f
	skipnz
	incf	(_Time_made_1s+1)^080h,f
	line	638
	
l10817:	
;main.c: 638: RA0=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(40/8),(40)&7	;volatile
	line	645
;main.c: 645: if(++Timer_TdsMake_1s>=60){
	movlw	low(03Ch)
	incf	(_Timer_TdsMake_1s),f
	subwf	((_Timer_TdsMake_1s)),w
	skipc
	goto	u10061
	goto	u10060
u10061:
	goto	l10821
u10060:
	line	646
	
l10819:	
;main.c: 646: _BITS.Bits.bit_6=1;
	bsf	(__BITS),6
	line	649
	
l10821:	
;main.c: 647: }
;main.c: 649: TDS_Handle(&PureTDSTyp,1);
	clrf	(TDS_Handle@Type)
	incf	(TDS_Handle@Type),f
	movlw	(low(_PureTDSTyp|((0x1)<<8)))&0ffh
	fcall	_TDS_Handle
	line	654
	
l10823:	
;main.c: 654: if((FilterROState==3)||(FilterPCFState==3)){
		movlw	3
	xorwf	((_FilterROState)),w
	btfsc	status,2
	goto	u10071
	goto	u10070
u10071:
	goto	l10827
u10070:
	
l10825:	
		movlw	3
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u10081
	goto	u10080
u10081:
	goto	l10865
u10080:
	line	655
	
l10827:	
;main.c: 655: FilterBuzzer_1s++;
	incf	(_FilterBuzzer_1s),f
	line	656
	
l10829:	
;main.c: 656: if(FilterBuzzer_1s>=2){
	movlw	low(02h)
	subwf	(_FilterBuzzer_1s),w
	skipc
	goto	u10091
	goto	u10090
u10091:
	goto	l10865
u10090:
	line	657
	
l10831:	
;main.c: 657: FilterBuzzer_1s=0;
	clrf	(_FilterBuzzer_1s)
	line	658
	
l10833:	
;main.c: 658: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	goto	l10865
	line	664
	
l10835:	
;main.c: 662: else
;main.c: 663: {
;main.c: 664: FilterBuzzer_1s=0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_FilterBuzzer_1s)
	line	665
	
l10837:	
;main.c: 665: _BITS1.Bits.bit_5=0;
	bcf	(__BITS1),5
	line	666
	
l10839:	
;main.c: 666: if((Time_made_1s>=300)&&(Mode!=3)){
	movlw	01h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Time_made_1s+1)^080h,w
	movlw	02Ch
	skipnz
	subwf	(_Time_made_1s)^080h,w
	skipc
	goto	u10101
	goto	u10100
u10101:
	goto	l10855
u10100:
	
l10841:	
		movlw	3
	xorwf	((_Mode)),w
	btfsc	status,2
	goto	u10111
	goto	u10110
u10111:
	goto	l10855
u10110:
	line	667
	
l10843:	
;main.c: 667: Time_made_1s=0;
	clrf	(_Time_made_1s)^080h
	clrf	(_Time_made_1s+1)^080h
	line	668
	
l10845:	
;main.c: 668: if(StandByStatus!=WashState){
	bcf	status, 5	;RP0=0, select bank0
		decf	((_StandByStatus)),w
	btfsc	status,2
	goto	u10121
	goto	u10120
u10121:
	goto	l10849
u10120:
	line	669
	
l10847:	
;main.c: 669: SetStandbyState(WashState,&WashRunTime, 6);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(06h)
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	line	670
;main.c: 670: }
	goto	l10855
	line	673
	
l10849:	
;main.c: 671: else
;main.c: 672: {
;main.c: 673: if(StandByStatus!=BackState){
		movlw	3
	xorwf	((_StandByStatus)),w
	btfsc	status,2
	goto	u10131
	goto	u10130
u10131:
	goto	l10855
u10130:
	line	674
	
l10851:	
;main.c: 674: if(WashRunTime-Timer_WashRun_1s<6){
	movf	(_WashRunTime),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(??_Time_Count_Func+0)^080h+0
	movf	(_Timer_WashRun_1s)^080h,w
	subwf	(??_Time_Count_Func+0)^080h+0,w
	movwf	(??_Time_Count_Func+1)^080h+0
	comf	(_Timer_WashRun_1s+1)^080h,w
	skipnc
	addlw	1
	movwf	((??_Time_Count_Func+1)^080h+0)+1
	movlw	0
	subwf	1+(??_Time_Count_Func+1)^080h+0,w
	movlw	06h
	skipnz
	subwf	0+(??_Time_Count_Func+1)^080h+0,w
	skipnc
	goto	u10141
	goto	u10140
u10141:
	goto	l1088
u10140:
	line	675
	
l10853:	
;main.c: 675: SetStandbyState(WashState,&WashRunTime, 6);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	movlw	low(06h)
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	goto	l10855
	line	678
	
l1088:	
	line	681
	
l10855:	
;main.c: 676: }
;main.c: 677: }
;main.c: 678: }
;main.c: 679: }
;main.c: 681: RA0=1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(40/8),(40)&7	;volatile
	line	682
	
l10857:	
;main.c: 682: _BITS.Bits.bit_6=0;
	bcf	(__BITS),6
	line	683
	
l10859:	
;main.c: 683: Timer_TdsMake_1s=0;
	clrf	(_Timer_TdsMake_1s)
	line	684
	
l10861:	
;main.c: 684: Timer_WashRun_1s++;
	bsf	status, 5	;RP0=1, select bank1
	incf	(_Timer_WashRun_1s)^080h,f
	skipnz
	incf	(_Timer_WashRun_1s+1)^080h,f
	line	686
	
l10863:	
;main.c: 686: Timer_Standby_1s++;
	incf	(_Timer_Standby_1s)^080h,f
	skipnz
	incf	(_Timer_Standby_1s+1)^080h,f
	line	694
	
l10865:	
;main.c: 688: }
;main.c: 694: GetDelayFilterFlag(&FilterPCF_time);
	movlw	(low(_FilterPCF_time|((0x0)<<8)))&0ffh
	fcall	_GetDelayFilterFlag
	line	695
	
l10867:	
;main.c: 695: GetDelayFilterFlag(&FilterRO_time);
	movlw	(low(_FilterRO_time|((0x0)<<8)))&0ffh
	fcall	_GetDelayFilterFlag
	line	702
	
l1091:	
	return
	opt stack 0
GLOBAL	__end_of_Time_Count_Func
	__end_of_Time_Count_Func:
	signat	_Time_Count_Func,89
	global	___CMS_CheckTouchKey

;; *************** function ___CMS_CheckTouchKey *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1074            1    0        unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		___CMS_CheckKeyOldValue
;;		___CMS_CheckOnceResult
;;		___CMS_CheckValidTime
;;		___CMS_CurAdjust
;;		___CMS_KeyDatIIR
;;		___CMS_KeyModeSet
;;		___CMS_KeyStart
;;		___CMS_KeyStopClear
;;		___CMS_Key_UNNOL_Check
;;		___CMS_NewRAMClr
;;		___CMS_Noise_check
;;		___GET_32M_FREDAT
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text10,local,class=CODE,delta=2,merge=1,group=1
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
global __ptext10
__ptext10:	;psect for function ___CMS_CheckTouchKey
psect	text10
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CheckTouchKey
	__size_of___CMS_CheckTouchKey	equ	__end_of___CMS_CheckTouchKey-___CMS_CheckTouchKey
	
___CMS_CheckTouchKey:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CheckTouchKey: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	
l10271:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text10
	btfsc	(_924/8),(_924)&7	;volatile
	goto	u9161
	goto	u9160
u9161:
	goto	l10279
u9160:
	
l10273:	
	bsf	(_924/8),(_924)&7	;volatile
	
l10275:	
	fcall	___CMS_NewRAMClr
	
l10277:	
	fcall	___GET_32M_FREDAT
	
l10279:	
	btfsc	(_926/8),(_926)&7	;volatile
	goto	u9171
	goto	u9170
u9171:
	goto	l10283
u9170:
	
l10281:	
	fcall	___CMS_CurAdjust
	goto	l10335
	
l10283:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_918)),w	;volatile
	btfsc	status,2
	goto	u9181
	goto	u9180
u9181:
	goto	l10327
u9180:
	
l10285:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_CheckTouchKey@F1073)^080h
	
l10287:	
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	xorwf	((_918)),w	;volatile
	btfsc	status,2
	goto	u9191
	goto	u9190
u9191:
	goto	l10293
u9190:
	
l10289:	
	fcall	___CMS_KeyDatIIR
	
l10291:	
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_918)	;volatile
	goto	l10335
	
l10293:	
	fcall	___CMS_Noise_check
	
l10295:	
	fcall	___CMS_CheckKeyOldValue
	
l10297:	
	fcall	___CMS_CheckOnceResult
	
l10299:	
	movlw	low(08h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_920),f	;volatile
	subwf	((_920)),w	;volatile
	skipc
	goto	u9201
	goto	u9200
u9201:
	goto	l10303
u9200:
	
l10301:	
	clrf	(_920)	;volatile
	
l10303:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u9211
	goto	u9210
u9211:
	goto	l10307
u9210:
	
l10305:	
	movf	(_920),w
	addlw	low(((_sc_FreScanTable)|8000h))
	movwf	fsr0
	movlw	high(((_sc_FreScanTable)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(_921)	;volatile
	goto	l10309
	
l10307:	
	movf	(_920),w
	addlw	low(((_sc_FreScanTable1)|8000h))
	movwf	fsr0
	movlw	high(((_sc_FreScanTable1)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(_921)	;volatile
	
l10309:	
	btfsc	(_gf_kerr/8),(_gf_kerr)&7	;volatile
	goto	u9221
	goto	u9220
u9221:
	goto	l10313
u9220:
	
l10311:	
	movlw	low(03h)
	subwf	(_917),w	;volatile
	skipc
	goto	u9231
	goto	u9230
u9231:
	goto	l10317
u9230:
	
l10313:	
	fcall	___CMS_KeyStopClear
	
l10315:	
	bcf	(_gf_kerr/8),(_gf_kerr)&7	;volatile
	
l10317:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_917)	;volatile
	
l10319:	
	fcall	___CMS_Key_UNNOL_Check
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_918)	;volatile
	
l10321:	
	btfss	(_926/8),(_926)&7	;volatile
	goto	u9241
	goto	u9240
u9241:
	goto	l3653
u9240:
	
l10323:	
	fcall	___CMS_KeyModeSet
	
l10325:	
	fcall	___CMS_KeyStart
	goto	l10335
	
l10327:	
	movlw	low(0FAh)
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_CheckTouchKey@F1073)^080h,f
	subwf	((___CMS_CheckTouchKey@F1073)^080h),w
	skipc
	goto	u9251
	goto	u9250
u9251:
	goto	l10335
u9250:
	
l10329:	
	clrf	(___CMS_CheckTouchKey@F1073)^080h
	clrf	(_919)	;volatile
	goto	l10323
	
l3653:	
	
l10335:	
	fcall	___CMS_CheckValidTime
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text10
	
l3655:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CheckTouchKey
	__end_of___CMS_CheckTouchKey:
	signat	___CMS_CheckTouchKey,89
	global	___GET_32M_FREDAT

;; *************** function ___GET_32M_FREDAT *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text11,local,class=CODE,delta=2,merge=1,group=1
global __ptext11
__ptext11:	;psect for function ___GET_32M_FREDAT
psect	text11
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___GET_32M_FREDAT
	__size_of___GET_32M_FREDAT	equ	__end_of___GET_32M_FREDAT-___GET_32M_FREDAT
	
___GET_32M_FREDAT:	
;incstack = 0
	opt	stack 6
; Regs used in ___GET_32M_FREDAT: [wreg+status,2+status,0]
	
l10033:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text11
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	bsf	(404)^0180h+(0/8),(0)&7	;volatile
	
l10035:	
	movf	(404)^0180h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_916)	;volatile
	
l10037:	
	movlw	low(070h)
	andwf	(_916),f	;volatile
	
l10039:	
	movlw	low(061h)
	subwf	(_916),w	;volatile
	skipc
	goto	u8731
	goto	u8730
u8731:
	goto	l10043
u8730:
	
l10041:	
	movlw	low(060h)
	movwf	(_916)	;volatile
	goto	l3610
	
l10043:	
	movlw	low(010h)
	subwf	(_916),w	;volatile
	skipnc
	goto	u8741
	goto	u8740
u8741:
	goto	l3610
u8740:
	
l10045:	
	movlw	low(010h)
	movwf	(_916)	;volatile
	
l3610:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text11
	
l3612:	
	return
	opt stack 0
GLOBAL	__end_of___GET_32M_FREDAT
	__end_of___GET_32M_FREDAT:
	signat	___GET_32M_FREDAT,89
	global	___CMS_Noise_check

;; *************** function ___CMS_Noise_check *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  973             2    9[BANK0 ] unsigned short 
;;  975             2    7[BANK0 ] unsigned short 
;;  974             2    3[BANK0 ] unsigned short 
;;  970             1   11[BANK0 ] unsigned char 
;;  972             1    6[BANK0 ] unsigned char 
;;  971             1    5[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       9       0       0
;;      Temps:          0       3       0       0
;;      Totals:         0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text12,local,class=CODE,delta=2,merge=1,group=1
global __ptext12
__ptext12:	;psect for function ___CMS_Noise_check
psect	text12
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_Noise_check
	__size_of___CMS_Noise_check	equ	__end_of___CMS_Noise_check-___CMS_Noise_check
	
___CMS_Noise_check:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_Noise_check: [wreg-fsr0h+status,2+status,0]
	
l9489:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text12
	
l9491:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_Noise_check@970)
	clrf	(___CMS_Noise_check@971)
	clrf	(___CMS_Noise_check@972)
	clrf	(___CMS_Noise_check@973)
	clrf	(___CMS_Noise_check@973+1)
	
l9493:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9495:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_Noise_check@970),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_Noise_check@974)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_Noise_check@974+1)
	
l9497:	
	movf	((_921)),w	;volatile
	btfsc	status,2
	goto	u7901
	goto	u7900
u7901:
	goto	l9503
u7900:
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
	
l9499:	
	clrc
	rlf	(___CMS_Noise_check@970),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_Noise_check@975)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_Noise_check@975+1)
	
l9501:	
	movlw	04Bh
	addwf	(___CMS_Noise_check@975),f
	skipnc
	incf	(___CMS_Noise_check@975+1),f
	line	1
	goto	l9507
	line	114
	
l9503:	
	clrc
	rlf	(___CMS_Noise_check@970),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_Noise_check@975)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_Noise_check@975+1)
	
l9505:	
	movlw	064h
	addwf	(___CMS_Noise_check@975),f
	skipnc
	incf	(___CMS_Noise_check@975+1),f
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9507:	
	movf	(___CMS_Noise_check@974+1),w
	subwf	(___CMS_Noise_check@975+1),w
	skipz
	goto	u7915
	movf	(___CMS_Noise_check@974),w
	subwf	(___CMS_Noise_check@975),w
u7915:
	skipnc
	goto	u7911
	goto	u7910
u7911:
	goto	l9513
u7910:
	
l9509:	
	incf	(___CMS_Noise_check@970),w
	movwf	(??___CMS_Noise_check+0)+0
	movlw	01h
	movwf	(??___CMS_Noise_check+1)+0
	movlw	0
	movwf	(??___CMS_Noise_check+1)+0+1
	goto	u7924
u7925:
	clrc
	rlf	(??___CMS_Noise_check+1)+0,f
	rlf	(??___CMS_Noise_check+1)+1,f
u7924:
	decfsz	(??___CMS_Noise_check+0)+0,f
	goto	u7925
	
	movf	0+(??___CMS_Noise_check+1)+0,w
	iorwf	(___CMS_Noise_check@973),f
	movf	1+(??___CMS_Noise_check+1)+0,w
	iorwf	(___CMS_Noise_check@973+1),f
	
l9511:	
	incf	(___CMS_Noise_check@971),f
	
l9513:	
	movlw	low(02h)
	incf	(___CMS_Noise_check@970),f
	subwf	((___CMS_Noise_check@970)),w
	skipc
	goto	u7931
	goto	u7930
u7931:
	goto	l9493
u7930:
	
l9515:	
	movlw	low(02h)
	subwf	(___CMS_Noise_check@971),w
	skipc
	goto	u7941
	goto	u7940
u7941:
	goto	l9527
u7940:
	
l9517:	
	clrf	(___CMS_Noise_check@972)
	incf	(___CMS_Noise_check@972),f
	
l9519:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_Noise_check@F967)^080h
	
l9521:	
	movlw	low(02h)
	incf	(___CMS_Noise_check@F966)^080h,f
	subwf	((___CMS_Noise_check@F966)^080h),w
	skipc
	goto	u7951
	goto	u7950
u7951:
	goto	l9531
u7950:
	
l9523:	
	clrf	(___CMS_Noise_check@F966)^080h
	
l9525:	
	bsf	(_925/8),(_925)&7	;volatile
	goto	l9531
	
l9527:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Noise_check@F967)^080h,f
	subwf	((___CMS_Noise_check@F967)^080h),w
	skipc
	goto	u7961
	goto	u7960
u7961:
	goto	l9531
u7960:
	
l9529:	
	clrf	(___CMS_Noise_check@F967)^080h
	clrf	(___CMS_Noise_check@F966)^080h
	
l9531:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___CMS_Noise_check@973),w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(___CMS_Noise_check@F969)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??___CMS_Noise_check+0)+0
	movf	(___CMS_Noise_check@973+1),w
	bsf	status, 5	;RP0=1, select bank1
	andwf	(___CMS_Noise_check@F969+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??___CMS_Noise_check+0)+0
	movf	((??___CMS_Noise_check+0)+0),w
iorwf	((??___CMS_Noise_check+0)+1),w
	btfsc	status,2
	goto	u7971
	goto	u7970
u7971:
	goto	l9543
u7970:
	
l9533:	
	clrf	(___CMS_Noise_check@972)
	incf	(___CMS_Noise_check@972),f
	
l9535:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_Noise_check@F965)^080h
	
l9537:	
	movlw	low(02h)
	incf	(___CMS_Noise_check@F964)^080h,f
	subwf	((___CMS_Noise_check@F964)^080h),w
	skipc
	goto	u7981
	goto	u7980
u7981:
	goto	l9547
u7980:
	
l9539:	
	clrf	(___CMS_Noise_check@F964)^080h
	
l9541:	
	bsf	(_925/8),(_925)&7	;volatile
	goto	l9547
	
l9543:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Noise_check@F965)^080h,f
	subwf	((___CMS_Noise_check@F965)^080h),w
	skipc
	goto	u7991
	goto	u7990
u7991:
	goto	l9547
u7990:
	
l9545:	
	clrf	(___CMS_Noise_check@F965)^080h
	clrf	(___CMS_Noise_check@F964)^080h
	
l9547:	
	bcf	status, 5	;RP0=0, select bank0
	movf	(___CMS_Noise_check@973+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___CMS_Noise_check@F969+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(___CMS_Noise_check@973),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(___CMS_Noise_check@F969)^080h
	
l9549:	
	btfss	(_925/8),(_925)&7	;volatile
	goto	u8001
	goto	u8000
u8001:
	goto	l9569
u8000:
	
l9551:	
	bcf	status, 5	;RP0=0, select bank0
	movf	((___CMS_Noise_check@972)),w
	btfss	status,2
	goto	u8011
	goto	u8010
u8011:
	goto	l9569
u8010:
	
l9553:	
	movf	((_g_KeyFlag)),w	;volatile
	btfss	status,2
	goto	u8021
	goto	u8020
u8021:
	goto	l9563
u8020:
	
l9555:	
	movf	(0+(_g_KeyFlag)+01h),w	;volatile
	btfss	status,2
	goto	u8031
	goto	u8030
u8031:
	goto	l9563
u8030:
	
l9557:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Noise_check@F968)^080h,f
	skipnz
	incf	(___CMS_Noise_check@F968+1)^080h,f
	movlw	0
	subwf	((___CMS_Noise_check@F968+1)^080h),w
	movlw	064h
	skipnz
	subwf	((___CMS_Noise_check@F968)^080h),w
	skipc
	goto	u8041
	goto	u8040
u8041:
	goto	l3442
u8040:
	
l9559:	
	clrf	(___CMS_Noise_check@F968)^080h
	clrf	(___CMS_Noise_check@F968+1)^080h
	
l9561:	
	bcf	(_925/8),(_925)&7	;volatile
	goto	l3442
	
l9563:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Noise_check@F968)^080h,f
	skipnz
	incf	(___CMS_Noise_check@F968+1)^080h,f
	movlw	01h
	subwf	((___CMS_Noise_check@F968+1)^080h),w
	movlw	02Ch
	skipnz
	subwf	((___CMS_Noise_check@F968)^080h),w
	skipc
	goto	u8051
	goto	u8050
u8051:
	goto	l3442
u8050:
	goto	l9559
	
l9569:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_Noise_check@F968)^080h
	clrf	(___CMS_Noise_check@F968+1)^080h
	
l3442:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text12
	
l3443:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_Noise_check
	__end_of___CMS_Noise_check:
	signat	___CMS_Noise_check,89
	global	___CMS_NewRAMClr

;; *************** function ___CMS_NewRAMClr *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1051            1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text13,local,class=CODE,delta=2,merge=1,group=1
global __ptext13
__ptext13:	;psect for function ___CMS_NewRAMClr
psect	text13
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_NewRAMClr
	__size_of___CMS_NewRAMClr	equ	__end_of___CMS_NewRAMClr-___CMS_NewRAMClr
	
___CMS_NewRAMClr:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_NewRAMClr: [wreg-fsr0h+status,2+status,0]
	
l10007:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text13
	
l10009:	
	clrf	(___CMS_NewRAMClr@1051)
	
l10015:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l10017:	
	movf	(___CMS_NewRAMClr@1051),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l10019:	
	movlw	low(02h)
	movwf	(415)^0180h	;volatile
	movf	(___CMS_NewRAMClr@1051),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l10021:	
	movlw	low(04h)
	movwf	(415)^0180h	;volatile
	
l10023:	
	movf	(___CMS_NewRAMClr@1051),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	movlw	low(08h)
	movwf	(415)^0180h	;volatile
	
l10025:	
	movf	(___CMS_NewRAMClr@1051),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l10027:	
	movlw	low(010h)
	movwf	(415)^0180h	;volatile
	movf	(___CMS_NewRAMClr@1051),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l10029:	
	incf	(___CMS_NewRAMClr@1051),f
	
l10031:	
	movlw	low(050h)
	subwf	(___CMS_NewRAMClr@1051),w
	skipc
	goto	u8721
	goto	u8720
u8721:
	goto	l10015
u8720:
	
l3605:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text13
	
l3606:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_NewRAMClr
	__end_of___CMS_NewRAMClr:
	signat	___CMS_NewRAMClr,89
	global	___CMS_Key_UNNOL_Check

;; *************** function ___CMS_Key_UNNOL_Check *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1017            1    1[BANK0 ] unsigned char 
;;  1018            1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       2       0       0
;;      Temps:          2       0       0       0
;;      Totals:         2       2       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text14,local,class=CODE,delta=2,merge=1,group=1
global __ptext14
__ptext14:	;psect for function ___CMS_Key_UNNOL_Check
psect	text14
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_Key_UNNOL_Check
	__size_of___CMS_Key_UNNOL_Check	equ	__end_of___CMS_Key_UNNOL_Check-___CMS_Key_UNNOL_Check
	
___CMS_Key_UNNOL_Check:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_Key_UNNOL_Check: [wreg-fsr0h+status,2+status,0]
	
l9817:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text14
	
l9819:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_Key_UNNOL_Check@1017)
	clrf	(___CMS_Key_UNNOL_Check@1018)
	
l9821:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u8421
	goto	u8420
u8421:
	goto	l3514
u8420:
	
l9823:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9825:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	movlw	0Ch
	subwf	1+(??___CMS_Key_UNNOL_Check+0)+0,w
	movlw	01h
	skipnz
	subwf	0+(??___CMS_Key_UNNOL_Check+0)+0,w
	skipnc
	goto	u8431
	goto	u8430
u8431:
	goto	l9829
u8430:
	
l9827:	
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	movlw	04h
	subwf	1+(??___CMS_Key_UNNOL_Check+0)+0,w
	movlw	0
	skipnz
	subwf	0+(??___CMS_Key_UNNOL_Check+0)+0,w
	skipnc
	goto	u8441
	goto	u8440
u8441:
	goto	l9833
u8440:
	
l9829:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Key_UNNOL_Check@F1016)^080h,f
	
l9831:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___CMS_Key_UNNOL_Check@1018)
	incf	(___CMS_Key_UNNOL_Check@1018),f
	
l9833:	
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	movlw	0Ch
	subwf	1+(??___CMS_Key_UNNOL_Check+0)+0,w
	movlw	01h
	skipnz
	subwf	0+(??___CMS_Key_UNNOL_Check+0)+0,w
	skipnc
	goto	u8451
	goto	u8450
u8451:
	goto	l9837
u8450:
	
l9835:	
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	movlw	04h
	subwf	1+(??___CMS_Key_UNNOL_Check+0)+0,w
	movlw	0
	skipnz
	subwf	0+(??___CMS_Key_UNNOL_Check+0)+0,w
	skipnc
	goto	u8461
	goto	u8460
u8461:
	goto	l9841
u8460:
	
l9837:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_Key_UNNOL_Check@F1016)^080h,f
	
l9839:	
	bcf	status, 5	;RP0=0, select bank0
	clrf	(___CMS_Key_UNNOL_Check@1018)
	incf	(___CMS_Key_UNNOL_Check@1018),f
	
l9841:	
	movlw	low(02h)
	incf	(___CMS_Key_UNNOL_Check@1017),f
	subwf	((___CMS_Key_UNNOL_Check@1017)),w
	skipc
	goto	u8471
	goto	u8470
u8471:
	goto	l9823
u8470:
	
l9843:	
	movf	((___CMS_Key_UNNOL_Check@1018)),w
	btfss	status,2
	goto	u8481
	goto	u8480
u8481:
	goto	l9847
u8480:
	
l9845:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_Key_UNNOL_Check@F1016)^080h
	goto	l3514
	
l9847:	
	movlw	low(0C8h)
	bsf	status, 5	;RP0=1, select bank1
	subwf	(___CMS_Key_UNNOL_Check@F1016)^080h,w
	skipc
	goto	u8491
	goto	u8490
u8491:
	goto	l3514
u8490:
	
l9849:	
	clrf	(___CMS_Key_UNNOL_Check@F1016)^080h
	
l9851:	
	bcf	(_926/8),(_926)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_920)	;volatile
	clrf	(_921)	;volatile
	
l9853:	
	bcf	(_927/8),(_927)&7	;volatile
	clrf	(___CMS_Key_UNNOL_Check@1017)
	
l9859:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9861:	
	movlw	0
	movwf	(??___CMS_Key_UNNOL_Check+0)+0
	movlw	0Ch
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_Key_UNNOL_Check+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_Key_UNNOL_Check+0)+1,w
	movwf	indf
	
l9863:	
	movlw	0
	movwf	(??___CMS_Key_UNNOL_Check+0)+0
	movlw	0Ch
	movwf	(??___CMS_Key_UNNOL_Check+0)+0+1
	clrc
	rlf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_Key_UNNOL_Check+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_Key_UNNOL_Check+0)+1,w
	movwf	indf
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9865:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_Key_UNNOL_Check@1017),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l9867:	
	incf	(___CMS_Key_UNNOL_Check@1017),f
	
l9869:	
	movlw	low(02h)
	subwf	(___CMS_Key_UNNOL_Check@1017),w
	skipc
	goto	u8501
	goto	u8500
u8501:
	goto	l9859
u8500:
	
l9871:	
	clrf	(_g_KeyFlag)	;volatile
	clrf	0+(_g_KeyFlag)+01h	;volatile
	
l3514:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text14
	
l3528:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_Key_UNNOL_Check
	__end_of___CMS_Key_UNNOL_Check:
	signat	___CMS_Key_UNNOL_Check,89
	global	___CMS_KeyStopClear

;; *************** function ___CMS_KeyStopClear *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  961             1    1[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       1       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___CMS_KeyClearOne
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text15,local,class=CODE,delta=2,merge=1,group=1
global __ptext15
__ptext15:	;psect for function ___CMS_KeyStopClear
psect	text15
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyStopClear
	__size_of___CMS_KeyStopClear	equ	__end_of___CMS_KeyStopClear-___CMS_KeyStopClear
	
___CMS_KeyStopClear:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_KeyStopClear: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	
l9475:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text15
	
l9477:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(_g_KeyFlag)	;volatile
	clrf	0+(_g_KeyFlag)+01h	;volatile
	clrf	(___CMS_KeyStopClear@961)
	
l9483:	
	movf	(___CMS_KeyStopClear@961),w
	fcall	___CMS_KeyClearOne
	
l9485:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(___CMS_KeyStopClear@961),f
	
l9487:	
	movlw	low(02h)
	subwf	(___CMS_KeyStopClear@961),w
	skipc
	goto	u7891
	goto	u7890
u7891:
	goto	l9483
u7890:
	
l3408:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text15
	
l3409:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyStopClear
	__end_of___CMS_KeyStopClear:
	signat	___CMS_KeyStopClear,89
	global	___CMS_KeyClearOne

;; *************** function ___CMS_KeyClearOne *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;  958             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  958             1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          2       0       0       0
;;      Totals:         2       1       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_KeyStopClear
;; This function uses a non-reentrant model
;;
psect	text16,local,class=CODE,delta=2,merge=1,group=1
global __ptext16
__ptext16:	;psect for function ___CMS_KeyClearOne
psect	text16
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyClearOne
	__size_of___CMS_KeyClearOne	equ	__end_of___CMS_KeyClearOne-___CMS_KeyClearOne
	
___CMS_KeyClearOne:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_KeyClearOne: [wreg-fsr0h+status,2+status,0]
;___CMS_KeyClearOne@958 stored from wreg
	movwf	(___CMS_KeyClearOne@958)
	
l8985:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text16
	
l8987:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l8989:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_KeyClearOne@958),w
	addlw	low(464|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l8991:	
	movf	(___CMS_KeyClearOne@958),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l8993:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyClearOne@958),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	
l8995:	
	clrc
	rlf	(___CMS_KeyClearOne@958),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l8997:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_KeyClearOne@958),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l8999:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_KeyClearOne@958),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l9001:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u7191
	goto	u7190
u7191:
	goto	l3403
u7190:
	
l9003:	
	movlw	0
	movwf	(??___CMS_KeyClearOne+0)+0
	movlw	0Ch
	movwf	(??___CMS_KeyClearOne+0)+0+1
	clrc
	rlf	(___CMS_KeyClearOne@958),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_KeyClearOne+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_KeyClearOne+0)+1,w
	movwf	indf
	movlw	0
	movwf	(??___CMS_KeyClearOne+0)+0
	movlw	0Ch
	movwf	(??___CMS_KeyClearOne+0)+0+1
	clrc
	rlf	(___CMS_KeyClearOne@958),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_KeyClearOne+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_KeyClearOne+0)+1,w
	movwf	indf
	
l3403:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text16
	
l3404:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyClearOne
	__end_of___CMS_KeyClearOne:
	signat	___CMS_KeyClearOne,4217
	global	___CMS_KeyDatIIR

;; *************** function ___CMS_KeyDatIIR *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1026            2    8[BANK0 ] unsigned short 
;;  1025            2    6[BANK0 ] unsigned short 
;;  1022            2    4[BANK0 ] unsigned short 
;;  1024            2    2[BANK0 ] unsigned short 
;;  1023            2    0[BANK0 ] unsigned short 
;;  1021            1   10[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0      11       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0      11       0       0
;;Total ram usage:       11 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text17,local,class=CODE,delta=2,merge=1,group=1
global __ptext17
__ptext17:	;psect for function ___CMS_KeyDatIIR
psect	text17
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyDatIIR
	__size_of___CMS_KeyDatIIR	equ	__end_of___CMS_KeyDatIIR-___CMS_KeyDatIIR
	
___CMS_KeyDatIIR:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_KeyDatIIR: [wreg-fsr0h+status,2+status,0]
	
l9873:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text17
	
l9875:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_KeyDatIIR@1021)
	
l9877:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9879:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1023)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1023+1)
	
l9881:	
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1024)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1024+1)
	
l9883:	
	movlw	low(08h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9885:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1022)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1022+1)
	
l9887:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9889:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u8511
	goto	u8510
u8511:
	goto	l9893
u8510:
	
l9891:	
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1025)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1025+1)
	goto	l9895
	
l9893:	
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1025)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_KeyDatIIR@1025+1)
	
l9895:	
	movf	((___CMS_KeyDatIIR@1022)),w
iorwf	((___CMS_KeyDatIIR@1022+1)),w
	btfsc	status,2
	goto	u8521
	goto	u8520
u8521:
	goto	l9919
u8520:
	
l9897:	
	movf	((___CMS_KeyDatIIR@1025)),w
iorwf	((___CMS_KeyDatIIR@1025+1)),w
	btfsc	status,2
	goto	u8531
	goto	u8530
u8531:
	goto	l9919
u8530:
	
l9899:	
	movf	(___CMS_KeyDatIIR@1025),w
	addwf	(___CMS_KeyDatIIR@1022),w
	movwf	(___CMS_KeyDatIIR@1026)
	movf	(___CMS_KeyDatIIR@1025+1),w
	skipnc
	incf	(___CMS_KeyDatIIR@1025+1),w
	addwf	(___CMS_KeyDatIIR@1022+1),w
	movwf	1+(___CMS_KeyDatIIR@1026)
	
l9901:	
	clrc
	rrf	(___CMS_KeyDatIIR@1026+1),f
	rrf	(___CMS_KeyDatIIR@1026),f
	movlw	low(08h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9903:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_KeyDatIIR@1026),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_KeyDatIIR@1026+1),w
	movwf	indf
	
l9905:	
	movf	(___CMS_KeyDatIIR@1025),w
	addwf	(___CMS_KeyDatIIR@1024),w
	movwf	(___CMS_KeyDatIIR@1026)
	movf	(___CMS_KeyDatIIR@1025+1),w
	skipnc
	incf	(___CMS_KeyDatIIR@1025+1),w
	addwf	(___CMS_KeyDatIIR@1024+1),w
	movwf	1+(___CMS_KeyDatIIR@1026)
	
l9907:	
	clrc
	rrf	(___CMS_KeyDatIIR@1026+1),f
	rrf	(___CMS_KeyDatIIR@1026),f
	
l9909:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9911:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_KeyDatIIR@1026),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_KeyDatIIR@1026+1),w
	movwf	indf
	
l9913:	
	movf	(___CMS_KeyDatIIR@1025),w
	addwf	(___CMS_KeyDatIIR@1023),w
	movwf	(___CMS_KeyDatIIR@1026)
	movf	(___CMS_KeyDatIIR@1025+1),w
	skipnc
	incf	(___CMS_KeyDatIIR@1025+1),w
	addwf	(___CMS_KeyDatIIR@1023+1),w
	movwf	1+(___CMS_KeyDatIIR@1026)
	clrc
	rrf	(___CMS_KeyDatIIR@1026+1),f
	rrf	(___CMS_KeyDatIIR@1026),f
	
l9915:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9917:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_KeyDatIIR@1021),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_KeyDatIIR@1026),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_KeyDatIIR@1026+1),w
	movwf	indf
	
l9919:	
	movlw	low(02h)
	incf	(___CMS_KeyDatIIR@1021),f
	subwf	((___CMS_KeyDatIIR@1021)),w
	skipc
	goto	u8541
	goto	u8540
u8541:
	goto	l9877
u8540:
	
l3531:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text17
	
l3537:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyDatIIR
	__end_of___CMS_KeyDatIIR:
	signat	___CMS_KeyDatIIR,89
	global	___CMS_CurAdjust

;; *************** function ___CMS_CurAdjust *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1047            2    4[BANK0 ] unsigned short 
;;  1045            1    3[BANK0 ] unsigned char 
;;  1046            1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       4       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0       6       0       0
;;Total ram usage:        6 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___CMS_CurAdjMode
;;		___CMS_CurJudge
;;		___CMS_KeyModeSet
;;		___CMS_KeyStart
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text18,local,class=CODE,delta=2,merge=1,group=1
global __ptext18
__ptext18:	;psect for function ___CMS_CurAdjust
psect	text18
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CurAdjust
	__size_of___CMS_CurAdjust	equ	__end_of___CMS_CurAdjust-___CMS_CurAdjust
	
___CMS_CurAdjust:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CurAdjust: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	
l9933:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text18
	
l9935:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_CurAdjust@1046)
	clrf	(___CMS_CurAdjust@1047)
	clrf	(___CMS_CurAdjust@1047+1)
	
l9937:	
	btfsc	(_927/8),(_927)&7	;volatile
	goto	u8571
	goto	u8570
u8571:
	goto	l9945
u8570:
	
l9939:	
	bsf	(_927/8),(_927)&7	;volatile
	
l9941:	
	fcall	___CMS_KeyModeSet
	
l9943:	
	fcall	___CMS_CurAdjMode
	goto	l3582
	
l9945:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9947:	
	btfsc	(402)^0180h,(7)&7	;volatile
	goto	u8581
	goto	u8580
u8581:
	goto	l9991
u8580:
	
l9949:	
	bcf	status, 6	;RP1=0, select bank1
	clrf	(___CMS_CurAdjust@F1044)^080h
	
l9951:	
	bsf	status, 6	;RP1=1, select bank3
	movf	(414)^0180h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(___CMS_CurAdjust@1047+1)
	clrf	(___CMS_CurAdjust@1047)
	
l9953:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(413)^0180h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	iorwf	(___CMS_CurAdjust@1047),f
	
l9955:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	btfss	(402)^0180h,(3)&7	;volatile
	goto	u8591
	goto	u8590
u8591:
	goto	l9965
u8590:
	
l9957:	
	movlw	08h
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	subwf	(___CMS_CurAdjust@1047+1),w
	movlw	081h
	skipnz
	subwf	(___CMS_CurAdjust@1047),w
	skipnc
	goto	u8601
	goto	u8600
u8601:
	goto	l9983
u8600:
	
l9959:	
	movlw	07h
	subwf	(___CMS_CurAdjust@1047+1),w
	movlw	080h
	skipnz
	subwf	(___CMS_CurAdjust@1047),w
	skipc
	goto	u8611
	goto	u8610
u8611:
	goto	l9983
u8610:
	
l9961:	
	fcall	___CMS_CurJudge
	goto	l9983
	
l9965:	
	
l3588:	
	movlw	0Ch
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	subwf	(___CMS_CurAdjust@1047+1),w
	movlw	0
	skipnz
	subwf	(___CMS_CurAdjust@1047),w
	skipnc
	goto	u8621
	goto	u8620
u8621:
	goto	l9973
u8620:
	
l9967:	
	movlw	04h
	subwf	(___CMS_CurAdjust@1047+1),w
	movlw	01h
	skipnz
	subwf	(___CMS_CurAdjust@1047),w
	skipc
	goto	u8631
	goto	u8630
u8631:
	goto	l9973
u8630:
	
l9969:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
		incf	((406)^0180h),w	;volatile
	btfsc	status,2
	goto	u8641
	goto	u8640
u8641:
	goto	l9973
u8640:
	goto	l9961
	
l9973:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u8651
	goto	u8650
u8651:
	goto	l9979
u8650:
	
l9975:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	movlw	low(0Fh)
	andwf	(indf),w
	movwf	(??___CMS_CurAdjust+0)+0
	movlw	low(06h)
	subwf	0+(??___CMS_CurAdjust+0)+0,w
	skipc
	goto	u8661
	goto	u8660
u8661:
	goto	l9983
u8660:
	
l9977:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(05h)
	movwf	indf
	goto	l9983
	
l9979:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(010h)
	bsf	status, 7	;select IRP bank3
	addwf	indf,f
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_CurAdjust+0)+0
	movlw	04h
u8675:
	clrc
	rrf	(??___CMS_CurAdjust+0)+0,f
	addlw	-1
	skipz
	goto	u8675
	movlw	low(0Fh)
	andwf	0+(??___CMS_CurAdjust+0)+0,w
	movwf	(??___CMS_CurAdjust+1)+0
	movlw	low(06h)
	subwf	0+(??___CMS_CurAdjust+1)+0,w
	skipc
	goto	u8681
	goto	u8680
u8681:
	goto	l9983
u8680:
	
l9981:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(0Fh)
	andwf	indf,f
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movlw	low(050h)
	iorwf	indf,f
	
l9983:	
	fcall	___CMS_KeyModeSet
	
l9985:	
	btfsc	(_926/8),(_926)&7	;volatile
	goto	u8691
	goto	u8690
u8691:
	goto	l9989
u8690:
	goto	l9943
	
l9989:	
	fcall	___CMS_KeyStart
	goto	l3582
	
l9991:	
	movlw	low(0C8h)
	bcf	status, 6	;RP1=0, select bank1
	incf	(___CMS_CurAdjust@F1044)^080h,f
	subwf	((___CMS_CurAdjust@F1044)^080h),w
	skipc
	goto	u8701
	goto	u8700
u8701:
	goto	l3582
u8700:
	
l9993:	
	clrf	(___CMS_CurAdjust@F1044)^080h
	bcf	status, 5	;RP0=0, select bank0
	clrf	(_921)	;volatile
	
l9995:	
	bcf	(_927/8),(_927)&7	;volatile
	clrf	(___CMS_CurAdjust@1045)
	
l10001:	
	movf	(___CMS_CurAdjust@1045),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l10003:	
	incf	(___CMS_CurAdjust@1045),f
	
l10005:	
	movlw	low(02h)
	subwf	(___CMS_CurAdjust@1045),w
	skipc
	goto	u8711
	goto	u8710
u8711:
	goto	l10001
u8710:
	
l3582:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text18
	
l3601:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CurAdjust
	__end_of___CMS_CurAdjust:
	signat	___CMS_CurAdjust,89
	global	___CMS_KeyStart

;; *************** function ___CMS_KeyStart *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1038            1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CurAdjust
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text19,local,class=CODE,delta=2,merge=1,group=1
global __ptext19
__ptext19:	;psect for function ___CMS_KeyStart
psect	text19
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyStart
	__size_of___CMS_KeyStart	equ	__end_of___CMS_KeyStart-___CMS_KeyStart
	
___CMS_KeyStart:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_KeyStart: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
	
l9075:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text19
	
l9077:	
	movlw	low(0C2h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(400)^0180h,f	;volatile
	movlw	low(0E0h)
	andwf	(401)^0180h,f	;volatile
	
l9079:	
	movf	(_919),w
	addlw	low(((_gc_Table_KeyChannel)|8000h))
	movwf	fsr0
	movlw	high(((_gc_Table_KeyChannel)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	andlw	01Fh
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(401)^0180h,f	;volatile
	
l9081:	
	movlw	low(010h)
	movwf	(415)^0180h	;volatile
	
l9083:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u7261
	goto	u7260
u7261:
	goto	l9095
u7260:
	
l9085:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_KeyStart@1038)
	
l9087:	
	movlw	low(0Fh)
	andwf	(___CMS_KeyStart@1038),f
	
l9089:	
	movlw	low(0F1h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(405)^0180h,f	;volatile
	
l9091:	
	movf	(___CMS_KeyStart@1038),w
	addlw	low(((_sc_CurStep_Table)|8000h))
	movwf	fsr0
	movlw	high(((_sc_CurStep_Table)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(405)^0180h,f	;volatile
	
l9093:	
	movf	(_919),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(406)^0180h	;volatile
	goto	l9105
	
l9095:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	swapf	indf,w
	andlw	(0ffh shr 4) & 0ffh
	movwf	(___CMS_KeyStart@1038)
	
l9097:	
	movlw	low(0Fh)
	andwf	(___CMS_KeyStart@1038),f
	
l9099:	
	movlw	low(0F1h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(405)^0180h,f	;volatile
	
l9101:	
	movf	(___CMS_KeyStart@1038),w
	addlw	low(((_sc_CurStep_Table)|8000h))
	movwf	fsr0
	movlw	high(((_sc_CurStep_Table)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(405)^0180h,f	;volatile
	
l9103:	
	movf	(_919),w
	addlw	low(432|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(406)^0180h	;volatile
	
l9105:	
	movf	(406)^0180h,w	;volatile
	movwf	(407)^0180h	;volatile
	
l9109:	
	bsf	(400)^0180h+(0/8),(0)&7	;volatile
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text19
	
l3568:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyStart
	__end_of___CMS_KeyStart:
	signat	___CMS_KeyStart,89
	global	___CMS_KeyModeSet

;; *************** function ___CMS_KeyModeSet *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1035            1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CurAdjust
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text20,local,class=CODE,delta=2,merge=1,group=1
global __ptext20
__ptext20:	;psect for function ___CMS_KeyModeSet
psect	text20
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyModeSet
	__size_of___CMS_KeyModeSet	equ	__end_of___CMS_KeyModeSet-___CMS_KeyModeSet
	
___CMS_KeyModeSet:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_KeyModeSet: [wreg+status,2+status,0]
	
l9049:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text20
	
l9051:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(400)^0180h	;volatile
	movlw	low(0E0h)
	movwf	(403)^0180h	;volatile
	
l9053:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_916),w	;volatile
	addlw	01h
	iorlw	0Ch
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(404)^0180h	;volatile
	
l9055:	
	movlw	low(030h)
	movwf	(405)^0180h	;volatile
	
l9057:	
	movlw	low(099h)
	movwf	(408)^0180h	;volatile
	
l9059:	
	movlw	low(040h)
	movwf	(401)^0180h	;volatile
	
l9061:	
	bsf	(401)^0180h+(5/8),(5)&7	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfsc	status,2
	goto	u7241
	goto	u7240
u7241:
	goto	l9067
u7240:
	
l9063:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	incf	(403)^0180h,f
	incf	(403)^0180h,f	;volatile
	
l9065:	
	movlw	low(010h)
	addwf	(404)^0180h,f	;volatile
	goto	l3557
	
l9067:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	incf	(403)^0180h,f
	incf	(403)^0180h,f	;volatile
	
l9069:	
	movlw	010h
	subwf	(404)^0180h,f	;volatile
	
l9071:	
	bsf	(405)^0180h+(7/8),(7)&7	;volatile
	
l3557:	
	movlw	low(014h)
	movwf	(___CMS_KeyModeSet@1035)
	
l9073:	
	decf	(___CMS_KeyModeSet@1035),f
		incf	(((___CMS_KeyModeSet@1035))),w
	btfss	status,2
	goto	u7251
	goto	u7250
u7251:
	goto	l9073
u7250:
	
l3560:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text20
	
l3561:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyModeSet
	__end_of___CMS_KeyModeSet:
	signat	___CMS_KeyModeSet,89
	global	___CMS_CurJudge

;; *************** function ___CMS_CurJudge *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          2       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CurAdjust
;; This function uses a non-reentrant model
;;
psect	text21,local,class=CODE,delta=2,merge=1,group=1
global __ptext21
__ptext21:	;psect for function ___CMS_CurJudge
psect	text21
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CurJudge
	__size_of___CMS_CurJudge	equ	__end_of___CMS_CurJudge-___CMS_CurJudge
	
___CMS_CurJudge:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CurJudge: [wreg-fsr0h+status,2+status,0]
	
l9111:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text21
	
l9113:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9115:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u7271
	goto	u7270
u7271:
	goto	l9119
u7270:
	
l9117:	
	movf	(_919),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(406)^0180h,w	;volatile
	bsf	status, 7	;select IRP bank3
	movwf	indf
	goto	l9121
	
l9119:	
	movf	(_919),w
	addlw	low(432|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(406)^0180h,w	;volatile
	bsf	status, 7	;select IRP bank3
	movwf	indf
	
l9121:	
	movlw	low(04h)
	movwf	(415)^0180h	;volatile
	
l9123:	
	movlw	0
	movwf	(??___CMS_CurJudge+0)+0
	movlw	0Ch
	movwf	(??___CMS_CurJudge+0)+0+1
	clrc
	rlf	(_919),w	;volatile
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_CurJudge+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_CurJudge+0)+1,w
	movwf	indf
	
l9125:	
	movlw	0
	movwf	(??___CMS_CurJudge+0)+0
	movlw	0Ch
	movwf	(??___CMS_CurJudge+0)+0+1
	clrc
	rlf	(_919),w	;volatile
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(??___CMS_CurJudge+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	(??___CMS_CurJudge+0)+1,w
	movwf	indf
	
l9127:	
	movlw	low(02h)
	incf	(_919),f	;volatile
	subwf	((_919)),w	;volatile
	skipc
	goto	u7281
	goto	u7280
u7281:
	goto	l3573
u7280:
	
l9129:	
	clrf	(_919)	;volatile
	
l9131:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u7291
	goto	u7290
u7291:
	goto	l3574
u7290:
	
l9133:	
	movlw	low(01h)
	movwf	(_921)	;volatile
	goto	l3573
	
l3574:	
	bcf	(13)+(6/8),(6)&7	;volatile
	bsf	(_926/8),(_926)&7	;volatile
	
l9135:	
	clrf	(_920)	;volatile
	clrf	(_921)	;volatile
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	clrf	(402)^0180h	;volatile
	
l3573:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text21
	
l3576:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CurJudge
	__end_of___CMS_CurJudge:
	signat	___CMS_CurJudge,89
	global	___CMS_CurAdjMode

;; *************** function ___CMS_CurAdjMode *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1032            1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       0       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CurAdjust
;; This function uses a non-reentrant model
;;
psect	text22,local,class=CODE,delta=2,merge=1,group=1
global __ptext22
__ptext22:	;psect for function ___CMS_CurAdjMode
psect	text22
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CurAdjMode
	__size_of___CMS_CurAdjMode	equ	__end_of___CMS_CurAdjMode-___CMS_CurAdjMode
	
___CMS_CurAdjMode:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CurAdjMode: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
	
l9011:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text22
	
l9013:	
	
l9015:	
	movf	(_919),w
	addlw	low(((_gc_Table_KeyChannel)|8000h))
	movwf	fsr0
	movlw	high(((_gc_Table_KeyChannel)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	andlw	01Fh
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(401)^0180h,f	;volatile
	
l9017:	
	movlw	low(010h)
	movwf	(415)^0180h	;volatile
	
l9019:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u7211
	goto	u7210
u7211:
	goto	l9033
u7210:
	
l9021:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_CurAdjMode@1032)
	
l9023:	
	movlw	low(0Fh)
	andwf	(___CMS_CurAdjMode@1032),f
	
l9025:	
	movlw	low(06h)
	subwf	(___CMS_CurAdjMode@1032),w
	skipc
	goto	u7221
	goto	u7220
u7221:
	goto	l9029
u7220:
	
l9027:	
	movlw	low(05h)
	movwf	(___CMS_CurAdjMode@1032)
	
l9029:	
	movlw	low(0F1h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(405)^0180h,f	;volatile
	
l9031:	
	movf	(___CMS_CurAdjMode@1032),w
	addlw	low(((_sc_CurStep_Table)|8000h))
	movwf	fsr0
	movlw	high(((_sc_CurStep_Table)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(405)^0180h,f	;volatile
	goto	l9045
	
l9033:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	swapf	indf,w
	andlw	(0ffh shr 4) & 0ffh
	movwf	(___CMS_CurAdjMode@1032)
	
l9035:	
	movlw	low(0Fh)
	andwf	(___CMS_CurAdjMode@1032),f
	
l9037:	
	movlw	low(06h)
	subwf	(___CMS_CurAdjMode@1032),w
	skipc
	goto	u7231
	goto	u7230
u7231:
	goto	l9029
u7230:
	goto	l9027
	
l9045:	
	movlw	low(010h)
	movwf	(402)^0180h	;volatile
	
l9047:	
	bsf	(402)^0180h+(7/8),(7)&7	;volatile
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text22
	
l3553:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CurAdjMode
	__end_of___CMS_CurAdjMode:
	signat	___CMS_CurAdjMode,89
	global	___CMS_CheckValidTime

;; *************** function ___CMS_CheckValidTime *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text23,local,class=CODE,delta=2,merge=1,group=1
global __ptext23
__ptext23:	;psect for function ___CMS_CheckValidTime
psect	text23
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CheckValidTime
	__size_of___CMS_CheckValidTime	equ	__end_of___CMS_CheckValidTime-___CMS_CheckValidTime
	
___CMS_CheckValidTime:	
;incstack = 0
	opt	stack 6
; Regs used in ___CMS_CheckValidTime: [wreg+status,2+status,0]
	
l9921:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text23
	
l9923:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	0+(_g_KeyFlag)+01h,w	;volatile
	iorwf	(_g_KeyFlag),w	;volatile
	btfsc	status,2
	goto	u8551
	goto	u8550
u8551:
	goto	l9929
u8550:
	
l9925:	
	bsf	status, 5	;RP0=1, select bank1
	incf	(___CMS_CheckValidTime@F1029)^080h,f
	skipnz
	incf	(___CMS_CheckValidTime@F1029+1)^080h,f
	movlw	013h
	subwf	((___CMS_CheckValidTime@F1029+1)^080h),w
	movlw	088h
	skipnz
	subwf	((___CMS_CheckValidTime@F1029)^080h),w
	skipc
	goto	u8561
	goto	u8560
u8561:
	goto	l3542
u8560:
	
l9927:	
	bsf	(_gf_kerr/8),(_gf_kerr)&7	;volatile
	
l9929:	
	bsf	status, 5	;RP0=1, select bank1
	clrf	(___CMS_CheckValidTime@F1029)^080h
	clrf	(___CMS_CheckValidTime@F1029+1)^080h
	
l3542:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text23
	
l3546:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CheckValidTime
	__end_of___CMS_CheckValidTime:
	signat	___CMS_CheckValidTime,89
	global	___CMS_CheckOnceResult

;; *************** function ___CMS_CheckOnceResult *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  991             2   14[BANK0 ] unsigned short 
;;  990             2   12[BANK0 ] unsigned short 
;;  989             2    5[BANK0 ] unsigned short 
;;  979             1   20[BANK0 ] unsigned char 
;;  987             1   19[BANK0 ] unsigned char 
;;  988             1   18[BANK0 ] unsigned char 
;;  984             1   17[BANK0 ] unsigned char 
;;  983             1   16[BANK0 ] unsigned char 
;;  982             1   11[BANK0 ] unsigned char 
;;  986             1   10[BANK0 ] unsigned char 
;;  985             1    9[BANK0 ] unsigned char 
;;  981             1    8[BANK0 ] unsigned char 
;;  980             1    7[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0      16       0       0
;;      Temps:          0       5       0       0
;;      Totals:         0      21       0       0
;;Total ram usage:       21 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___CMS_KeyHaveDown
;;		___CMS_KeyIsIn
;;		___CMS_KeyOpen
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text24,local,class=CODE,delta=2,merge=1,group=1
global __ptext24
__ptext24:	;psect for function ___CMS_CheckOnceResult
psect	text24
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CheckOnceResult
	__size_of___CMS_CheckOnceResult	equ	__end_of___CMS_CheckOnceResult-___CMS_CheckOnceResult
	
___CMS_CheckOnceResult:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CheckOnceResult: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	
l9571:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text24
	
l9573:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_CheckOnceResult@979)
	
l9575:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u8061
	goto	u8060
u8061:
	goto	l9579
u8060:
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	112
	
l9577:	
	movlw	low(03h)
	movwf	(___CMS_CheckOnceResult@987)
	line	1
	goto	l3448
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9579:	
	movlw	low(04h)
	movwf	(___CMS_CheckOnceResult@987)
	
l3448:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9581:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u8071
	goto	u8070
u8071:
	goto	l9585
u8070:
	
l9583:	
	clrc
	rlf	(___CMS_CheckOnceResult@979),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@991)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@991+1)
	goto	l9587
	
l9585:	
	clrc
	rlf	(___CMS_CheckOnceResult@979),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@991)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@991+1)
	
l9587:	
	clrc
	rlf	(___CMS_CheckOnceResult@979),w
	addlw	low(((_gc_Table_KeyDown)|8000h))
	movwf	fsr0
	movlw	high(((_gc_Table_KeyDown)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(___CMS_CheckOnceResult@989)
	fcall	stringtab
	movwf	(___CMS_CheckOnceResult@989+1)
	
l9589:	
	movf	((___CMS_CheckOnceResult@991)),w
iorwf	((___CMS_CheckOnceResult@991+1)),w
	btfsc	status,2
	goto	u8081
	goto	u8080
u8081:
	goto	l9699
u8080:
	
l9591:	
	movlw	0Ch
	subwf	(___CMS_CheckOnceResult@991+1),w
	movlw	0
	skipnz
	subwf	(___CMS_CheckOnceResult@991),w
	skipnc
	goto	u8091
	goto	u8090
u8091:
	goto	l9699
u8090:
	
l9593:	
	movf	(___CMS_CheckOnceResult@979),w
	andlw	07h
	addlw	low(((_sc_Table_KeyFalg)|8000h))
	movwf	fsr0
	movlw	high(((_sc_Table_KeyFalg)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(___CMS_CheckOnceResult@988)
	
l9595:	
	movf	(___CMS_CheckOnceResult@989),w
	addwf	(___CMS_CheckOnceResult@991),w
	movwf	(___CMS_CheckOnceResult@990)
	movf	(___CMS_CheckOnceResult@989+1),w
	skipnc
	incf	(___CMS_CheckOnceResult@989+1),w
	addwf	(___CMS_CheckOnceResult@991+1),w
	movwf	1+(___CMS_CheckOnceResult@990)
	
l9597:	
	clrf	(___CMS_CheckOnceResult@980)
	
l9599:	
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyIsIn
	xorlw	0
	skipnz
	goto	u8101
	goto	u8100
u8101:
	goto	l9605
u8100:
	
l9601:	
	clrf	(___CMS_CheckOnceResult@980)
	incf	(___CMS_CheckOnceResult@980),f
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	115
	
l9603:	
	movf	(___CMS_CheckOnceResult@990),w
	addlw	low(0FFE7h)
	movwf	(___CMS_CheckOnceResult@990)
	movf	(___CMS_CheckOnceResult@990+1),w
	skipnc
	addlw	1
	addlw	high(0FFE7h)
	movwf	1+(___CMS_CheckOnceResult@990)
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9605:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9607:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrc
	rlf	indf,f
	
l9609:	
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(464|((0x1)<<8))&0ffh
	movwf	fsr0
	clrc
	rlf	indf,f
	
l9611:	
	movlw	low(08h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9613:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckOnceResult@979),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_CheckOnceResult+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_CheckOnceResult+0)+0+1
	movf	(___CMS_CheckOnceResult@990+1),w
	subwf	1+(??___CMS_CheckOnceResult+0)+0,w
	skipz
	goto	u8115
	movf	(___CMS_CheckOnceResult@990),w
	subwf	0+(??___CMS_CheckOnceResult+0)+0,w
u8115:
	skipc
	goto	u8111
	goto	u8110
u8111:
	goto	l9621
u8110:
	
l9615:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9617:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	indf+(0/8),(0)&7
	
l9619:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(464|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	indf+(0/8),(0)&7
	goto	l9629
	
l9621:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9623:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckOnceResult@979),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??___CMS_CheckOnceResult+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??___CMS_CheckOnceResult+0)+0+1
	movf	(___CMS_CheckOnceResult@990+1),w
	subwf	1+(??___CMS_CheckOnceResult+0)+0,w
	skipz
	goto	u8125
	movf	(___CMS_CheckOnceResult@990),w
	subwf	0+(??___CMS_CheckOnceResult+0)+0,w
u8125:
	skipc
	goto	u8121
	goto	u8120
u8121:
	goto	l9629
u8120:
	
l9625:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	goto	l9619
	
l9629:	
	clrf	(___CMS_CheckOnceResult@983)
	
l9631:	
	clrf	(___CMS_CheckOnceResult@984)
	
l9633:	
	movlw	low(010h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(464|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@985)
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckOnceResult@986)
	
l9635:	
	clrf	(___CMS_CheckOnceResult@981)
	goto	l9647
	
l3457:	
	btfss	(___CMS_CheckOnceResult@985),(0)&7
	goto	u8131
	goto	u8130
u8131:
	goto	l9639
u8130:
	
l9637:	
	incf	(___CMS_CheckOnceResult@983),f
	
l9639:	
	clrc
	rrf	(___CMS_CheckOnceResult@985),f
	
l9641:	
	btfss	(___CMS_CheckOnceResult@986),(0)&7
	goto	u8141
	goto	u8140
u8141:
	goto	l9645
u8140:
	
l9643:	
	incf	(___CMS_CheckOnceResult@984),f
	
l9645:	
	clrc
	rrf	(___CMS_CheckOnceResult@986),f
	incf	(___CMS_CheckOnceResult@981),f
	
l9647:	
	clrc
	rlf	(___CMS_CheckOnceResult@987),w
	subwf	(___CMS_CheckOnceResult@981),w
	skipc
	goto	u8151
	goto	u8150
u8151:
	goto	l3457
u8150:
	
l9649:	
	clrf	(___CMS_CheckOnceResult@982)
	
l9651:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9653:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckOnceResult@987),w
	subwf	(___CMS_CheckOnceResult@984),w
	skipc
	goto	u8161
	goto	u8160
u8161:
	goto	l3461
u8160:
	
l9655:	
	movf	(___CMS_CheckOnceResult@988),w
	movwf	(___CMS_KeyHaveDown@956)
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyHaveDown
	
l9657:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_CheckOnceResult@982)
	incf	(___CMS_CheckOnceResult@982),f
	
l9659:	
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l9677
	
l3461:	
	btfss	(_925/8),(_925)&7	;volatile
	goto	u8171
	goto	u8170
u8171:
	goto	l9677
u8170:
	
l9661:	
	clrc
	rlf	(___CMS_CheckOnceResult@987),w
	subwf	(___CMS_CheckOnceResult@983),w
	skipc
	goto	u8181
	goto	u8180
u8181:
	goto	l9669
u8180:
	
l9663:	
	movf	(___CMS_CheckOnceResult@988),w
	movwf	(___CMS_KeyHaveDown@956)
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyHaveDown
	goto	l9657
	
l9669:	
	movf	(___CMS_CheckOnceResult@987),w
	movwf	(??___CMS_CheckOnceResult+0)+0
	clrc
	rlf	(??___CMS_CheckOnceResult+0)+0,f
	movlw	low(01h)
	addwf	0+(??___CMS_CheckOnceResult+0)+0,w
	movwf	(??___CMS_CheckOnceResult+1)+0
	movf	(___CMS_CheckOnceResult@984),w
	addwf	(___CMS_CheckOnceResult@983),w
	movwf	(??___CMS_CheckOnceResult+2)+0
	clrf	(??___CMS_CheckOnceResult+2)+0+1
	rlf	1+(??___CMS_CheckOnceResult+2)+0,f
	
	movf	1+(??___CMS_CheckOnceResult+2)+0,w
	xorlw	80h
	movwf	(??___CMS_CheckOnceResult+4)+0
	movlw	80h
	subwf	(??___CMS_CheckOnceResult+4)+0,w
	skipz
	goto	u8195
	movf	0+(??___CMS_CheckOnceResult+1)+0,w
	subwf	0+(??___CMS_CheckOnceResult+2)+0,w
u8195:

	skipc
	goto	u8191
	goto	u8190
u8191:
	goto	l3463
u8190:
	
l9671:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@988),w
	movwf	(___CMS_KeyHaveDown@956)
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyHaveDown
	goto	l9657
	
l3463:	
	
l9677:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((___CMS_CheckOnceResult@982)),w
	btfss	status,2
	goto	u8201
	goto	u8200
u8201:
	goto	l9699
u8200:
	
l9679:	
	movf	((___CMS_CheckOnceResult@980)),w
	btfsc	status,2
	goto	u8211
	goto	u8210
u8211:
	goto	l9699
u8210:
	
l9681:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9683:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u8221
	goto	u8220
u8221:
	goto	l9689
u8220:
	
l9685:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckOnceResult@987),w
	addlw	0FFh
	subwf	(___CMS_CheckOnceResult@984),w
	skipnc
	goto	u8231
	goto	u8230
u8231:
	goto	l3471
u8230:
	
l9687:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	goto	l3471
	
l9689:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@987),w
	movwf	(??___CMS_CheckOnceResult+0)+0
	clrc
	rlf	(??___CMS_CheckOnceResult+0)+0,f
	movlw	low(0FFh)
	addwf	0+(??___CMS_CheckOnceResult+0)+0,w
	movwf	(??___CMS_CheckOnceResult+1)+0
	movf	(___CMS_CheckOnceResult@984),w
	addwf	(___CMS_CheckOnceResult@983),w
	movwf	(??___CMS_CheckOnceResult+2)+0
	clrf	(??___CMS_CheckOnceResult+2)+0+1
	rlf	1+(??___CMS_CheckOnceResult+2)+0,f
	
	movf	1+(??___CMS_CheckOnceResult+2)+0,w
	xorlw	80h
	movwf	(??___CMS_CheckOnceResult+4)+0
	movlw	80h
	subwf	(??___CMS_CheckOnceResult+4)+0,w
	skipz
	goto	u8245
	movf	0+(??___CMS_CheckOnceResult+1)+0,w
	subwf	0+(??___CMS_CheckOnceResult+2)+0,w
u8245:

	skipnc
	goto	u8241
	goto	u8240
u8241:
	goto	l3471
u8240:
	goto	l9687
	
l3471:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrc
	rlf	(___CMS_CheckOnceResult@987),w
	addlw	0FFh
	bsf	status, 7	;select IRP bank3
	subwf	indf,w
	skipc
	goto	u8251
	goto	u8250
u8251:
	goto	l9697
u8250:
	
l9693:	
	movf	(___CMS_CheckOnceResult@979),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l9695:	
	movf	(___CMS_CheckOnceResult@988),w
	movwf	(___CMS_KeyOpen@952)
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyOpen
	goto	l9699
	
l9697:	
	movf	(___CMS_CheckOnceResult@988),w
	movwf	(___CMS_KeyHaveDown@956)
	movf	(___CMS_CheckOnceResult@979),w
	fcall	___CMS_KeyHaveDown
	
l9699:	
	movlw	low(02h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(___CMS_CheckOnceResult@979),f
	subwf	((___CMS_CheckOnceResult@979)),w
	skipc
	goto	u8261
	goto	u8260
u8261:
	goto	l3448
u8260:
	
l3475:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text24
	
l3476:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CheckOnceResult
	__end_of___CMS_CheckOnceResult:
	signat	___CMS_CheckOnceResult,89
	global	___CMS_KeyOpen

;; *************** function ___CMS_KeyOpen *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;  951             1    wreg     unsigned char 
;;  952             1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  951             1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckOnceResult
;; This function uses a non-reentrant model
;;
psect	text25,local,class=CODE,delta=2,merge=1,group=1
global __ptext25
__ptext25:	;psect for function ___CMS_KeyOpen
psect	text25
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyOpen
	__size_of___CMS_KeyOpen	equ	__end_of___CMS_KeyOpen-___CMS_KeyOpen
	
___CMS_KeyOpen:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_KeyOpen: [wreg+status,2+status,0]
;___CMS_KeyOpen@951 stored from wreg
	movwf	(___CMS_KeyOpen@951)
	
l8965:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text25
	
l8967:	
	movlw	low(0FFh)
	xorwf	(___CMS_KeyOpen@952),f
	
l8969:	
	btfss	(___CMS_KeyOpen@951),(3)&7
	goto	u7171
	goto	u7170
u7171:
	goto	l8973
u7170:
	
l8971:	
	movf	(___CMS_KeyOpen@952),w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	andwf	0+(_g_KeyFlag)+01h,f	;volatile
	goto	l3394
	
l8973:	
	movf	(___CMS_KeyOpen@952),w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	andwf	(_g_KeyFlag),f	;volatile
	
l3394:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text25
	
l3395:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyOpen
	__end_of___CMS_KeyOpen:
	signat	___CMS_KeyOpen,8313
	global	___CMS_KeyHaveDown

;; *************** function ___CMS_KeyHaveDown *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;  955             1    wreg     unsigned char 
;;  956             1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  955             1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckOnceResult
;; This function uses a non-reentrant model
;;
psect	text26,local,class=CODE,delta=2,merge=1,group=1
global __ptext26
__ptext26:	;psect for function ___CMS_KeyHaveDown
psect	text26
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyHaveDown
	__size_of___CMS_KeyHaveDown	equ	__end_of___CMS_KeyHaveDown-___CMS_KeyHaveDown
	
___CMS_KeyHaveDown:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_KeyHaveDown: [wreg+status,2+status,0]
;___CMS_KeyHaveDown@955 stored from wreg
	movwf	(___CMS_KeyHaveDown@955)
	
l8975:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text26
	
l8977:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(_917),f	;volatile
	
l8979:	
	btfss	(___CMS_KeyHaveDown@955),(3)&7
	goto	u7181
	goto	u7180
u7181:
	goto	l8983
u7180:
	
l8981:	
	movf	(___CMS_KeyHaveDown@956),w
	iorwf	0+(_g_KeyFlag)+01h,f	;volatile
	goto	l3399
	
l8983:	
	movf	(___CMS_KeyHaveDown@956),w
	iorwf	(_g_KeyFlag),f	;volatile
	
l3399:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text26
	
l3400:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyHaveDown
	__end_of___CMS_KeyHaveDown:
	signat	___CMS_KeyHaveDown,8313
	global	___CMS_CheckKeyOldValue

;; *************** function ___CMS_CheckKeyOldValue *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  1009            2   11[BANK0 ] unsigned short 
;;  1008            2    9[BANK0 ] unsigned short 
;;  1007            2    7[BANK0 ] unsigned short 
;;  1006            2    4[BANK0 ] unsigned short 
;;  1003            1   14[BANK0 ] unsigned char 
;;  1005            1   13[BANK0 ] unsigned char 
;;  1004            1    6[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0      11       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0      13       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___CMS_KeyIsIn
;;		_abs
;; This function is called by:
;;		___CMS_CheckTouchKey
;; This function uses a non-reentrant model
;;
psect	text27,local,class=CODE,delta=2,merge=1,group=1
global __ptext27
__ptext27:	;psect for function ___CMS_CheckKeyOldValue
psect	text27
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_CheckKeyOldValue
	__size_of___CMS_CheckKeyOldValue	equ	__end_of___CMS_CheckKeyOldValue-___CMS_CheckKeyOldValue
	
___CMS_CheckKeyOldValue:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_CheckKeyOldValue: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
	
l9701:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text27
	
l9703:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(___CMS_CheckKeyOldValue@1003)
	
l9705:	
	btfsc	(_925/8),(_925)&7	;volatile
	goto	u8271
	goto	u8270
u8271:
	goto	l9711
u8270:
	
l9707:	
	movlw	low(08h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9709:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1009)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1009+1)
	goto	l9715
	
l9711:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9713:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1009)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1009+1)
	
l9715:	
	movf	((_921)),w	;volatile
	btfsc	status,2
	goto	u8281
	goto	u8280
u8281:
	goto	l9763
u8280:
	
l9717:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9719:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1007)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1007+1)
	
l9721:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1008)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1008+1)
	
l9723:	
	movf	(___CMS_CheckKeyOldValue@1007+1),w
	movwf	(abs@a+1)
	movf	(___CMS_CheckKeyOldValue@1007),w
	movwf	(abs@a)
	movf	(___CMS_CheckKeyOldValue@1009),w
	subwf	(abs@a),f
	movf	(___CMS_CheckKeyOldValue@1009+1),w
	skipc
	decf	(abs@a+1),f
	subwf	(abs@a+1),f
	fcall	_abs
	movf	(1+(?_abs)),w
	movwf	(___CMS_CheckKeyOldValue@1006+1)
	movf	(0+(?_abs)),w
	movwf	(___CMS_CheckKeyOldValue@1006)
	
l9725:	
	movlw	0Ch
	subwf	(___CMS_CheckKeyOldValue@1008+1),w
	movlw	0
	skipnz
	subwf	(___CMS_CheckKeyOldValue@1008),w
	skipnc
	goto	u8291
	goto	u8290
u8291:
	goto	l9729
u8290:
	
l9727:	
	movf	((___CMS_CheckKeyOldValue@1008)),w
iorwf	((___CMS_CheckKeyOldValue@1008+1)),w
	btfss	status,2
	goto	u8301
	goto	u8300
u8301:
	goto	l9735
u8300:
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
	
l9729:	
	movlw	low(04Bh)
	movwf	(___CMS_CheckKeyOldValue@1004)
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9731:	
	
l9733:	
	movlw	low(06h)
	movwf	(___CMS_CheckKeyOldValue@1005)
	goto	l3487
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
	
l9735:	
	movlw	low(032h)
	movwf	(___CMS_CheckKeyOldValue@1004)
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9737:	
	btfss	(_925/8),(_925)&7	;volatile
	goto	u8311
	goto	u8310
u8311:
	goto	l9733
u8310:
	
l9739:	
	movlw	low(0Ch)
	movwf	(___CMS_CheckKeyOldValue@1005)
	
l3487:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9743:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_CheckKeyOldValue@1009),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_CheckKeyOldValue@1009+1),w
	movwf	indf
	
l9745:	
	movf	(___CMS_CheckKeyOldValue@1003),w
	fcall	___CMS_KeyIsIn
	xorlw	0
	skipz
	goto	u8321
	goto	u8320
u8321:
	goto	l9759
u8320:
	
l9747:	
	movf	(___CMS_CheckKeyOldValue@1004),w
	movwf	(??___CMS_CheckKeyOldValue+0)+0
	clrf	(??___CMS_CheckKeyOldValue+0)+0+1
	movf	(___CMS_CheckKeyOldValue@1006+1),w
	subwf	1+(??___CMS_CheckKeyOldValue+0)+0,w
	skipz
	goto	u8335
	movf	(___CMS_CheckKeyOldValue@1006),w
	subwf	0+(??___CMS_CheckKeyOldValue+0)+0,w
u8335:
	skipc
	goto	u8331
	goto	u8330
u8331:
	goto	l9759
u8330:
	
l9749:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9751:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	movf	(___CMS_CheckKeyOldValue@1005),w
	subwf	(indf),w
	skipc
	goto	u8341
	goto	u8340
u8341:
	goto	l9815
u8340:
	
l9753:	
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l9755:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9757:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_CheckKeyOldValue@1007),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_CheckKeyOldValue@1007+1),w
	movwf	indf
	goto	l9815
	
l9759:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9761:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	goto	l9815
	
l9763:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9765:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1007)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1007+1)
	
l9767:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1008)
	incf	fsr0,f
	movf	indf,w
	movwf	(___CMS_CheckKeyOldValue@1008+1)
	
l9769:	
	movf	(___CMS_CheckKeyOldValue@1007+1),w
	movwf	(abs@a+1)
	movf	(___CMS_CheckKeyOldValue@1007),w
	movwf	(abs@a)
	movf	(___CMS_CheckKeyOldValue@1009),w
	subwf	(abs@a),f
	movf	(___CMS_CheckKeyOldValue@1009+1),w
	skipc
	decf	(abs@a+1),f
	subwf	(abs@a+1),f
	fcall	_abs
	movf	(1+(?_abs)),w
	movwf	(___CMS_CheckKeyOldValue@1006+1)
	movf	(0+(?_abs)),w
	movwf	(___CMS_CheckKeyOldValue@1006)
	
l9771:	
	movlw	0Ch
	subwf	(___CMS_CheckKeyOldValue@1008+1),w
	movlw	0
	skipnz
	subwf	(___CMS_CheckKeyOldValue@1008),w
	skipnc
	goto	u8351
	goto	u8350
u8351:
	goto	l9775
u8350:
	
l9773:	
	movf	((___CMS_CheckKeyOldValue@1008)),w
iorwf	((___CMS_CheckKeyOldValue@1008+1)),w
	btfss	status,2
	goto	u8361
	goto	u8360
u8361:
	goto	l9785
u8360:
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
	
l9775:	
	movlw	low(064h)
	movwf	(___CMS_CheckKeyOldValue@1004)
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9777:	
	
l9779:	
	movlw	low(04h)
	movwf	(___CMS_CheckKeyOldValue@1005)
	goto	l3501
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	114
	
l9785:	
	movlw	low(04Bh)
	movwf	(___CMS_CheckKeyOldValue@1004)
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9787:	
	btfss	(_925/8),(_925)&7	;volatile
	goto	u8371
	goto	u8370
u8371:
	goto	l9791
u8370:
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\Touch_Kscan_Library.h"
	line	116
	
l9789:	
	movlw	low(06h)
	movwf	(___CMS_CheckKeyOldValue@1005)
	line	1
	goto	l3501
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	
l9791:	
	goto	l9779
	
l3501:	
	movlw	low(02h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9795:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_CheckKeyOldValue@1009),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_CheckKeyOldValue@1009+1),w
	movwf	indf
	
l9797:	
	movf	(___CMS_CheckKeyOldValue@1003),w
	fcall	___CMS_KeyIsIn
	xorlw	0
	skipz
	goto	u8381
	goto	u8380
u8381:
	goto	l9811
u8380:
	
l9799:	
	movf	(___CMS_CheckKeyOldValue@1004),w
	movwf	(??___CMS_CheckKeyOldValue+0)+0
	clrf	(??___CMS_CheckKeyOldValue+0)+0+1
	movf	(___CMS_CheckKeyOldValue@1006+1),w
	subwf	1+(??___CMS_CheckKeyOldValue+0)+0,w
	skipz
	goto	u8395
	movf	(___CMS_CheckKeyOldValue@1006),w
	subwf	0+(??___CMS_CheckKeyOldValue+0)+0,w
u8395:
	skipc
	goto	u8391
	goto	u8390
u8391:
	goto	l9811
u8390:
	
l9801:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9803:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	incf	indf,f
	movf	(___CMS_CheckKeyOldValue@1005),w
	subwf	(indf),w
	skipc
	goto	u8401
	goto	u8400
u8401:
	goto	l9815
u8400:
	
l9805:	
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	
l9807:	
	movlw	low(04h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9809:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrc
	rlf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(___CMS_CheckKeyOldValue@1007),w
	movwf	indf
	incf	fsr0,f
	movf	(___CMS_CheckKeyOldValue@1007+1),w
	movwf	indf
	goto	l9815
	
l9811:	
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
l9813:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(___CMS_CheckKeyOldValue@1003),w
	addlw	low(480|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	clrf	indf
	
l9815:	
	movlw	low(02h)
	incf	(___CMS_CheckKeyOldValue@1003),f
	subwf	((___CMS_CheckKeyOldValue@1003)),w
	skipc
	goto	u8411
	goto	u8410
u8411:
	goto	l9705
u8410:
	
l3508:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text27
	
l3509:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_CheckKeyOldValue
	__end_of___CMS_CheckKeyOldValue:
	signat	___CMS_CheckKeyOldValue,89
	global	_abs

;; *************** function _abs *****************
;; Defined at:
;;		line 4 in file "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\abs.c"
;; Parameters:    Size  Location     Type
;;  a               2    4[COMMON] int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  2    4[COMMON] int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       2       0       0
;;      Totals:         2       2       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckKeyOldValue
;; This function uses a non-reentrant model
;;
psect	text28,local,class=CODE,delta=2,merge=1,group=2
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\abs.c"
	line	4
global __ptext28
__ptext28:	;psect for function _abs
psect	text28
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\abs.c"
	line	4
	global	__size_of_abs
	__size_of_abs	equ	__end_of_abs-_abs
	
_abs:	
;incstack = 0
	opt	stack 5
; Regs used in _abs: [wreg+status,2+status,0]
	line	6
	
l9005:	
	btfss	(abs@a+1),7
	goto	u7201
	goto	u7200
u7201:
	goto	l3720
u7200:
	line	7
	
l9007:	
	comf	(abs@a),w
	movwf	(??_abs+0)+0
	comf	(abs@a+1),w
	movwf	((??_abs+0)+0+1)
	incf	(??_abs+0)+0,f
	skipnz
	incf	((??_abs+0)+0+1),f
	movf	0+(??_abs+0)+0,w
	movwf	(?_abs)
	movf	1+(??_abs+0)+0,w
	movwf	(?_abs+1)
	goto	l3721
	
l3720:	
	line	8
	line	9
	
l3721:	
	return
	opt stack 0
GLOBAL	__end_of_abs
	__end_of_abs:
	signat	_abs,4218
	global	___CMS_KeyIsIn

;; *************** function ___CMS_KeyIsIn *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;  946             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  946             1    5[COMMON] unsigned char 
;;  947             1    4[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         2       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		___CMS_CheckOnceResult
;;		___CMS_CheckKeyOldValue
;; This function uses a non-reentrant model
;;
psect	text29,local,class=CODE,delta=2,merge=1,group=1
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
global __ptext29
__ptext29:	;psect for function ___CMS_KeyIsIn
psect	text29
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_KeyIsIn
	__size_of___CMS_KeyIsIn	equ	__end_of___CMS_KeyIsIn-___CMS_KeyIsIn
	
___CMS_KeyIsIn:	
;incstack = 0
	opt	stack 5
; Regs used in ___CMS_KeyIsIn: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
;___CMS_KeyIsIn@946 stored from wreg
	movwf	(___CMS_KeyIsIn@946)
	
l8949:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text29
	
l8951:	
	movf	(___CMS_KeyIsIn@946),w
	andlw	07h
	addlw	low(((_sc_Table_KeyFalg)|8000h))
	movwf	fsr0
	movlw	high(((_sc_Table_KeyFalg)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	movwf	(___CMS_KeyIsIn@947)
	
l8953:	
	btfss	(___CMS_KeyIsIn@946),(3)&7
	goto	u7161
	goto	u7160
u7161:
	goto	l8957
u7160:
	
l8955:	
	movf	0+(_g_KeyFlag)+01h,w	;volatile
	andwf	(___CMS_KeyIsIn@947),f
	goto	l8959
	
l8957:	
	movf	(_g_KeyFlag),w	;volatile
	andwf	(___CMS_KeyIsIn@947),f
	
l8959:	
	movf	(___CMS_KeyIsIn@947),w
	
l3390:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_KeyIsIn
	__end_of___CMS_KeyIsIn:
	signat	___CMS_KeyIsIn,4217
	global	_Tx_Display

;; *************** function _Tx_Display *****************
;; Defined at:
;;		line 2166 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               2    2[BANK0 ] unsigned int 
;;  Temp1           1    1[BANK0 ] unsigned char 
;;  Sum_Tot         1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       4       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text30,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	2166
global __ptext30
__ptext30:	;psect for function _Tx_Display
psect	text30
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	2166
	global	__size_of_Tx_Display
	__size_of_Tx_Display	equ	__end_of_Tx_Display-_Tx_Display
	
_Tx_Display:	
;incstack = 0
	opt	stack 7
; Regs used in _Tx_Display: [wreg-fsr0h+status,2+status,0]
	line	2169
	
l10615:	
;main.c: 2168: unsigned int i;
;main.c: 2169: U8_T Sum_Tot=0;
	clrf	(Tx_Display@Sum_Tot)
	line	2170
;main.c: 2170: U8_T Temp1=0;
	clrf	(Tx_Display@Temp1)
	line	2172
	
l10617:	
;main.c: 2172: if((FilterROState==3)||(FilterPCFState==3))
		movlw	3
	xorwf	((_FilterROState)),w
	btfsc	status,2
	goto	u9731
	goto	u9730
u9731:
	goto	l10621
u9730:
	
l10619:	
		movlw	3
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u9741
	goto	u9740
u9741:
	goto	l10623
u9740:
	line	2174
	
l10621:	
;main.c: 2173: {
;main.c: 2174: Temp1=0x03;
	movlw	low(03h)
	movwf	(Tx_Display@Temp1)
	line	2175
;main.c: 2175: }
	goto	l10635
	line	2176
	
l10623:	
;main.c: 2176: else if((FilterROState==2)||(FilterPCFState==2))
		movlw	2
	xorwf	((_FilterROState)),w
	btfsc	status,2
	goto	u9751
	goto	u9750
u9751:
	goto	l10627
u9750:
	
l10625:	
		movlw	2
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u9761
	goto	u9760
u9761:
	goto	l10629
u9760:
	line	2178
	
l10627:	
;main.c: 2177: {
;main.c: 2178: Temp1=0x07;
	movlw	low(07h)
	movwf	(Tx_Display@Temp1)
	line	2179
;main.c: 2179: }
	goto	l10635
	line	2180
	
l10629:	
;main.c: 2180: else if((FilterROState==1)&&(FilterPCFState==1)){
		decf	((_FilterROState)),w
	btfss	status,2
	goto	u9771
	goto	u9770
u9771:
	goto	l10635
u9770:
	
l10631:	
		decf	((_FilterPCFState)),w
	btfss	status,2
	goto	u9781
	goto	u9780
u9781:
	goto	l10635
u9780:
	line	2181
	
l10633:	
;main.c: 2181: Temp1=0x01;
	clrf	(Tx_Display@Temp1)
	incf	(Tx_Display@Temp1),f
	line	2184
	
l10635:	
;main.c: 2182: }
;main.c: 2184: Tx_Type.TxType.Tx_FilterLed=Temp1;
	movf	(Tx_Display@Temp1),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	0+(_Tx_Type)^0100h+03h
	line	2188
	
l10637:	
;main.c: 2188: if(!_BITS1.Bits.bit_7){
	bcf	status, 6	;RP1=0, select bank0
	btfsc	(__BITS1),7
	goto	u9791
	goto	u9790
u9791:
	goto	l10641
u9790:
	line	2191
	
l10639:	
;main.c: 2191: Tx_Type.TxType.Tx_TdsData_1=0x03;
	movlw	low(03h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	0+(_Tx_Type)^0100h+06h
	line	2192
;main.c: 2192: Tx_Type.TxType.Tx_TdsData_2=0xE7;
	movlw	low(0E7h)
	movwf	0+(_Tx_Type)^0100h+07h
	line	2193
;main.c: 2193: }
	goto	l10643
	line	2196
	
l10641:	
;main.c: 2194: else
;main.c: 2195: {
;main.c: 2196: Tx_Type.TxType.Tx_TdsData_1=PureTDSTyp.TdsData>>8;
	bsf	status, 6	;RP1=1, select bank2
	movf	1+(_PureTDSTyp)^0100h+0Fh,w
	movwf	0+(_Tx_Type)^0100h+06h
	line	2197
;main.c: 2197: Tx_Type.TxType.Tx_TdsData_2=PureTDSTyp.TdsData;
	movf	0+(_PureTDSTyp)^0100h+0Fh,w
	movwf	0+(_Tx_Type)^0100h+07h
	line	2200
	
l10643:	
;main.c: 2198: }
;main.c: 2200: Tx_Type.TxType.Tx_TdsLed=1;
	clrf	0+(_Tx_Type)^0100h+05h
	incf	0+(_Tx_Type)^0100h+05h,f
	line	2201
	
l10645:	
;main.c: 2201: if(_BITS.Bits.bit_5==0x00){
	btfsc	(__BITS),5
	goto	u9801
	goto	u9800
u9801:
	goto	l1419
u9800:
	line	2203
	
l10647:	
;main.c: 2203: Tx_Type.TxType.Tx_TdsLed=0;
	clrf	0+(_Tx_Type)^0100h+05h
	line	2204
	
l10649:	
;main.c: 2204: Tx_Type.TxType.Tx_TdsData_1=0xff;
	movlw	low(0FFh)
	movwf	0+(_Tx_Type)^0100h+06h
	line	2205
	
l10651:	
;main.c: 2205: Tx_Type.TxType.Tx_TdsData_2=0x00;
	clrf	0+(_Tx_Type)^0100h+07h
	line	2207
	
l1419:	
	line	2213
;main.c: 2207: }
;main.c: 2213: Tx_Type.TxType.Tx_ErrorState=ErrorVar;
	bcf	status, 6	;RP1=0, select bank0
	movf	(_ErrorVar),w
	bsf	status, 6	;RP1=1, select bank2
	movwf	0+(_Tx_Type)^0100h+09h
	line	2214
	
l10653:	
;main.c: 2214: if(ErrorVar==0x02){
		movlw	2
	bcf	status, 6	;RP1=0, select bank0
	xorwf	((_ErrorVar)),w
	btfss	status,2
	goto	u9811
	goto	u9810
u9811:
	goto	l10657
u9810:
	line	2215
	
l10655:	
;main.c: 2215: Tx_Type.TxType.Tx_ErrorLed=0x07;
	movlw	low(07h)
	bsf	status, 6	;RP1=1, select bank2
	movwf	0+(_Tx_Type)^0100h+08h
	line	2216
;main.c: 2216: }
	goto	l10659
	line	2219
	
l10657:	
;main.c: 2217: else
;main.c: 2218: {
;main.c: 2219: Tx_Type.TxType.Tx_ErrorLed=0x00;
	bsf	status, 6	;RP1=1, select bank2
	clrf	0+(_Tx_Type)^0100h+08h
	line	2221
	
l10659:	
;main.c: 2220: }
;main.c: 2221: Tx_Type.TxType.Tx_Mode=_BITS.Bits.bit_5;
	movlw	0
	btfsc	(__BITS),5
	movlw	1
	movwf	0+(_Tx_Type)^0100h+0Ah
	line	2225
;main.c: 2225: for(i=2;i<0x11U-1;i++){
	movlw	02h
	bcf	status, 6	;RP1=0, select bank0
	movwf	(Tx_Display@i)
	clrf	(Tx_Display@i+1)
	line	2226
	
l10663:	
;main.c: 2226: Sum_Tot+=Tx_Type.Tx_Tab[i];
	movf	(Tx_Display@i),w
	addlw	low(_Tx_Type|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	addwf	(Tx_Display@Sum_Tot),f
	line	2225
	
l10665:	
	incf	(Tx_Display@i),f
	skipnz
	incf	(Tx_Display@i+1),f
	
l10667:	
	movlw	0
	subwf	(Tx_Display@i+1),w
	movlw	010h
	skipnz
	subwf	(Tx_Display@i),w
	skipc
	goto	u9821
	goto	u9820
u9821:
	goto	l10663
u9820:
	line	2228
	
l10669:	
;main.c: 2227: }
;main.c: 2228: Tx_Type.TxType.Tx_Check=Sum_Tot+0x11U;
	movf	(Tx_Display@Sum_Tot),w
	addlw	011h
	bsf	status, 6	;RP1=1, select bank2
	movwf	0+(_Tx_Type)^0100h+010h
	line	2229
	
l10671:	
;main.c: 2229: for(i=0;i<0x11U;i++){
	bcf	status, 6	;RP1=0, select bank0
	clrf	(Tx_Display@i)
	clrf	(Tx_Display@i+1)
	line	2230
	
l10677:	
;main.c: 2230: TXREG1=Tx_Type.Tx_Tab[i];
	movf	(Tx_Display@i),w
	addlw	low(_Tx_Type|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	bsf	status, 6	;RP1=1, select bank2
	movwf	(285)^0100h	;volatile
	line	2231
;main.c: 2231: do{
	
l1426:	
	line	2232
# 2232 "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text30
	line	2234
	
l10679:	
;main.c: 2233: }
;main.c: 2234: while(TRMT1==0);
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	btfss	(2297/8)^0100h,(2297)&7	;volatile
	goto	u9831
	goto	u9830
u9831:
	goto	l1426
u9830:
	line	2229
	
l10681:	
	bcf	status, 6	;RP1=0, select bank0
	incf	(Tx_Display@i),f
	skipnz
	incf	(Tx_Display@i+1),f
	
l10683:	
	movlw	0
	subwf	(Tx_Display@i+1),w
	movlw	011h
	skipnz
	subwf	(Tx_Display@i),w
	skipc
	goto	u9841
	goto	u9840
u9841:
	goto	l10677
u9840:
	line	2239
	
l1428:	
	return
	opt stack 0
GLOBAL	__end_of_Tx_Display
	__end_of_Tx_Display:
	signat	_Tx_Display,89
	global	_TaskAlarmHandle

;; *************** function _TaskAlarmHandle *****************
;; Defined at:
;;		line 1561 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          2       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text31,local,class=CODE,delta=2,merge=1,group=0
	line	1561
global __ptext31
__ptext31:	;psect for function _TaskAlarmHandle
psect	text31
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	1561
	global	__size_of_TaskAlarmHandle
	__size_of_TaskAlarmHandle	equ	__end_of_TaskAlarmHandle-_TaskAlarmHandle
	
_TaskAlarmHandle:	
;incstack = 0
	opt	stack 7
; Regs used in _TaskAlarmHandle: [wreg+status,2+status,0]
	line	1565
	
l10393:	
;main.c: 1565: if(BeepAlmCnt)
	bcf	status, 5	;RP0=0, select bank0
	movf	((_BeepAlmCnt)),w
	btfsc	status,2
	goto	u9391
	goto	u9390
u9391:
	goto	l1287
u9390:
	line	1567
	
l10395:	
;main.c: 1566: {
;main.c: 1567: if(BeepOnTimeCnt)
	bsf	status, 5	;RP0=1, select bank1
	movf	((_BeepOnTimeCnt)^080h),w
iorwf	((_BeepOnTimeCnt+1)^080h),w
	btfsc	status,2
	goto	u9401
	goto	u9400
u9401:
	goto	l10403
u9400:
	line	1569
	
l10397:	
;main.c: 1568: {
;main.c: 1569: BeepOnTimeCnt--;
	movlw	01h
	subwf	(_BeepOnTimeCnt)^080h,f
	movlw	0
	skipc
	decf	(_BeepOnTimeCnt+1)^080h,f
	subwf	(_BeepOnTimeCnt+1)^080h,f
	line	1571
	
l10399:	
;main.c: 1571: if(BeepOnTimeCnt>=(BuzzerFilter>>1)){PWM1EN=1;}
	movf	(_BuzzerFilter+1)^080h,w
	movwf	(??_TaskAlarmHandle+0)+0+1
	movf	(_BuzzerFilter)^080h,w
	movwf	(??_TaskAlarmHandle+0)+0
	clrc
	rrf	(??_TaskAlarmHandle+0)+1,f
	rrf	(??_TaskAlarmHandle+0)+0,f
	movf	1+(??_TaskAlarmHandle+0)+0,w
	subwf	(_BeepOnTimeCnt+1)^080h,w
	skipz
	goto	u9415
	movf	0+(??_TaskAlarmHandle+0)+0,w
	subwf	(_BeepOnTimeCnt)^080h,w
u9415:
	skipc
	goto	u9411
	goto	u9410
u9411:
	goto	l1289
u9410:
	
l10401:	
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bsf	(2097/8)^0100h,(2097)&7	;volatile
	goto	l1293
	line	1574
	
l1289:	
;main.c: 1574: else {PWM1EN=0;}
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	bcf	(2097/8)^0100h,(2097)&7	;volatile
	goto	l1293
	line	1578
	
l10403:	
;main.c: 1576: else
;main.c: 1577: {
;main.c: 1578: BeepAlmCnt--;
	bcf	status, 5	;RP0=0, select bank0
	decf	(_BeepAlmCnt),f
	line	1579
	
l10405:	
;main.c: 1579: BeepOnTimeCnt=BuzzerFilter;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_BuzzerFilter+1)^080h,w
	movwf	(_BeepOnTimeCnt+1)^080h
	movf	(_BuzzerFilter)^080h,w
	movwf	(_BeepOnTimeCnt)^080h
	goto	l1293
	line	1582
	
l1287:	
	line	1584
;main.c: 1582: else
;main.c: 1583: {
;main.c: 1584: _BITS.Bits.bit_7=0;
	bcf	(__BITS),7
	line	1586
	
l1293:	
	return
	opt stack 0
GLOBAL	__end_of_TaskAlarmHandle
	__end_of_TaskAlarmHandle:
	signat	_TaskAlarmHandle,89
	global	_TDS_Handle

;; *************** function _TDS_Handle *****************
;; Defined at:
;;		line 438 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  TDSTyp          1    wreg     PTR struct .
;;		 -> PureTDSTyp(17), 
;;  Type            1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  TDSTyp          1   31[BANK0 ] PTR struct .
;;		 -> PureTDSTyp(17), 
;;  Muni_c          4   27[BANK0 ] unsigned long 
;;  NTC_            4   19[BANK0 ] unsigned long 
;;  i               2   25[BANK0 ] unsigned int 
;;  PreTdsData      2   23[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         0      13       0       0
;;      Temps:          0       4       0       0
;;      Totals:         1      17       0       0
;;Total ram usage:       18 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_GetCurTdsHz
;;		___lldiv
;;		___lmul
;;		___lwdiv
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text32,local,class=CODE,delta=2,merge=1,group=0
	line	438
global __ptext32
__ptext32:	;psect for function _TDS_Handle
psect	text32
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	438
	global	__size_of_TDS_Handle
	__size_of_TDS_Handle	equ	__end_of_TDS_Handle-_TDS_Handle
	
_TDS_Handle:	
;incstack = 0
	opt	stack 6
; Regs used in _TDS_Handle: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
;TDS_Handle@TDSTyp stored from wreg
	movwf	(TDS_Handle@TDSTyp)
	line	464
	
l10131:	
	line	465
;main.c: 465: U32_T Muni_c=0;
	clrf	(TDS_Handle@Muni_c)
	clrf	(TDS_Handle@Muni_c+1)
	clrf	(TDS_Handle@Muni_c+2)
	clrf	(TDS_Handle@Muni_c+3)
	line	466
	
l10133:	
	line	468
;main.c: 468: unsigned int i=0;
	clrf	(TDS_Handle@i)
	clrf	(TDS_Handle@i+1)
	line	469
	
l10135:	
;main.c: 469: (TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)])=(TDSTyp->HzCount);
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Dh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+1
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	clrc
	rlf	indf,w
	addwf	(TDS_Handle@TDSTyp),w
	movwf	(??_TDS_Handle+2)+0
	movf	0+(??_TDS_Handle+2)+0,w
	movwf	fsr0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	indf
	line	470
	
l10137:	
;main.c: 470: (TDSTyp->HzCount)=0;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Dh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	475
	
l10139:	
;main.c: 475: if(Mode!=5){
		movlw	5
	xorwf	((_Mode)),w
	btfsc	status,2
	goto	u8921
	goto	u8920
u8921:
	goto	l10157
u8920:
	line	476
	
l10141:	
;main.c: 476: if(Type==1){
		decf	((TDS_Handle@Type)),w
	btfss	status,2
	goto	u8931
	goto	u8930
u8931:
	goto	l1050
u8930:
	line	478
	
l10143:	
;main.c: 478: if(Temp_Ntc >= 25){
	movlw	low(019h)
	subwf	(_Temp_Ntc),w
	skipc
	goto	u8941
	goto	u8940
u8941:
	goto	l10147
u8940:
	line	479
	
l10145:	
;main.c: 479: NTC_ = (U32_T)(Temp_Ntc -25);
	movf	(_Temp_Ntc),w
	addlw	low(-25)
	movwf	(TDS_Handle@NTC_)
	movlw	high(-25)
	skipnc
	movlw	(high(-25)+1)&0ffh
	movwf	((TDS_Handle@NTC_))+1
	clrf	(TDS_Handle@NTC_)+2
	btfsc	(TDS_Handle@NTC_)+1,7
	decf	2+(TDS_Handle@NTC_),f
	movf	(TDS_Handle@NTC_)+2,w
	movwf	3+(TDS_Handle@NTC_)
	line	480
;main.c: 480: NTC_ += 100;
	movlw	064h
	addwf	(TDS_Handle@NTC_),f
	movlw	1
	skipnc
	addwf	(TDS_Handle@NTC_+1),f
	skipnc
	addwf	(TDS_Handle@NTC_+2),f
	skipnc
	addwf	(TDS_Handle@NTC_+3),f
	line	481
;main.c: 481: }
	goto	l10149
	line	483
	
l10147:	
;main.c: 482: else {
;main.c: 483: NTC_ = (U32_T)(25-Temp_Ntc);
	movlw	019h
	movwf	(??_TDS_Handle+0)+0
	movf	(_Temp_Ntc),w
	subwf	(??_TDS_Handle+0)+0,w
	movwf	(TDS_Handle@NTC_)
	clrf	(TDS_Handle@NTC_)+1
	skipc
	decf	1+(TDS_Handle@NTC_),f
	
	clrf	(TDS_Handle@NTC_)+2
	btfsc	(TDS_Handle@NTC_)+1,7
	decf	2+(TDS_Handle@NTC_),f
	movf	(TDS_Handle@NTC_)+2,w
	movwf	3+(TDS_Handle@NTC_)
	line	484
;main.c: 484: NTC_ = 100-NTC_;
	movlw	064h
	movwf	((??_TDS_Handle+0)+0)
	movlw	0
	movwf	((??_TDS_Handle+0)+0+1)
	movlw	0
	movwf	((??_TDS_Handle+0)+0+2)
	movlw	0
	movwf	((??_TDS_Handle+0)+0+3)
	movf	(TDS_Handle@NTC_),w
	subwf	(??_TDS_Handle+0)+0,f
	movf	(TDS_Handle@NTC_+1),w
	skipc
	incfsz	(TDS_Handle@NTC_+1),w
	goto	u8951
	goto	u8952
u8951:
	subwf	(??_TDS_Handle+0)+1,f
u8952:
	movf	(TDS_Handle@NTC_+2),w
	skipc
	incfsz	(TDS_Handle@NTC_+2),w
	goto	u8953
	goto	u8954
u8953:
	subwf	(??_TDS_Handle+0)+2,f
u8954:
	movf	(TDS_Handle@NTC_+3),w
	skipc
	incfsz	(TDS_Handle@NTC_+3),w
	goto	u8955
	goto	u8956
u8955:
	subwf	(??_TDS_Handle+0)+3,f
u8956:

	movf	3+(??_TDS_Handle+0)+0,w
	movwf	(TDS_Handle@NTC_+3)
	movf	2+(??_TDS_Handle+0)+0,w
	movwf	(TDS_Handle@NTC_+2)
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	(TDS_Handle@NTC_+1)
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	(TDS_Handle@NTC_)

	line	487
	
l10149:	
;main.c: 485: }
;main.c: 487: Muni_c = TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)];
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	clrc
	rlf	indf,w
	addwf	(TDS_Handle@TDSTyp),w
	movwf	(??_TDS_Handle+0)+0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+1)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+1)+0+1
	movf	0+(??_TDS_Handle+1)+0,w
	movwf	(TDS_Handle@Muni_c)
	movf	1+(??_TDS_Handle+1)+0,w
	movwf	((TDS_Handle@Muni_c))+1
	clrf	2+((TDS_Handle@Muni_c))
	clrf	3+((TDS_Handle@Muni_c))
	line	488
	
l10151:	
;main.c: 488: Muni_c *= 100;
	movlw	064h
	movwf	(___lmul@multiplier)
	clrf	(___lmul@multiplier+1)
	clrf	(___lmul@multiplier+2)
	clrf	(___lmul@multiplier+3)

	movf	(TDS_Handle@Muni_c+3),w
	movwf	(___lmul@multiplicand+3)
	movf	(TDS_Handle@Muni_c+2),w
	movwf	(___lmul@multiplicand+2)
	movf	(TDS_Handle@Muni_c+1),w
	movwf	(___lmul@multiplicand+1)
	movf	(TDS_Handle@Muni_c),w
	movwf	(___lmul@multiplicand)

	fcall	___lmul
	movf	(3+(?___lmul)),w
	movwf	(TDS_Handle@Muni_c+3)
	movf	(2+(?___lmul)),w
	movwf	(TDS_Handle@Muni_c+2)
	movf	(1+(?___lmul)),w
	movwf	(TDS_Handle@Muni_c+1)
	movf	(0+(?___lmul)),w
	movwf	(TDS_Handle@Muni_c)

	line	489
	
l10153:	
;main.c: 489: Muni_c /= NTC_;
	movf	(TDS_Handle@NTC_+3),w
	movwf	(___lldiv@divisor+3)
	movf	(TDS_Handle@NTC_+2),w
	movwf	(___lldiv@divisor+2)
	movf	(TDS_Handle@NTC_+1),w
	movwf	(___lldiv@divisor+1)
	movf	(TDS_Handle@NTC_),w
	movwf	(___lldiv@divisor)

	movf	(TDS_Handle@Muni_c+3),w
	movwf	(___lldiv@dividend+3)
	movf	(TDS_Handle@Muni_c+2),w
	movwf	(___lldiv@dividend+2)
	movf	(TDS_Handle@Muni_c+1),w
	movwf	(___lldiv@dividend+1)
	movf	(TDS_Handle@Muni_c),w
	movwf	(___lldiv@dividend)

	fcall	___lldiv
	movf	(3+(?___lldiv)),w
	movwf	(TDS_Handle@Muni_c+3)
	movf	(2+(?___lldiv)),w
	movwf	(TDS_Handle@Muni_c+2)
	movf	(1+(?___lldiv)),w
	movwf	(TDS_Handle@Muni_c+1)
	movf	(0+(?___lldiv)),w
	movwf	(TDS_Handle@Muni_c)

	line	490
	
l10155:	
;main.c: 490: TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)] = (U8_T)Muni_c;
	movf	(TDS_Handle@Muni_c),w
	movwf	(??_TDS_Handle+0)+0
	clrf	(??_TDS_Handle+0)+0+1
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	clrc
	rlf	indf,w
	addwf	(TDS_Handle@TDSTyp),w
	movwf	(??_TDS_Handle+2)+0
	movf	0+(??_TDS_Handle+2)+0,w
	movwf	fsr0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	indf
	line	491
;main.c: 491: }
	goto	l10157
	line	492
	
l1050:	
	line	520
	
l10157:	
;main.c: 495: }
;main.c: 496: }
;main.c: 520: (TDSTyp->TdsTime)++;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	incf	indf,f
	line	521
;main.c: 521: if((TDSTyp->TdsTime)>=5){
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	movlw	low(05h)
	subwf	indf,w
	skipc
	goto	u8961
	goto	u8960
u8961:
	goto	l1064
u8960:
	line	522
	
l10159:	
;main.c: 522: (TDSTyp->TdsTime)=0;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Ah
	movwf	fsr0
	clrf	indf
	line	524
;main.c: 524: (TDSTyp->TdsHz)=0;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	525
	
l10161:	
;main.c: 525: for(i=0;i<5;i++){
	clrf	(TDS_Handle@i)
	clrf	(TDS_Handle@i+1)
	line	526
	
l10167:	
;main.c: 526: TDSTyp->TdsHz+=TDSTyp->TdsHz_Tab[i];
	clrc
	rlf	(TDS_Handle@i),w
	addwf	(TDS_Handle@TDSTyp),w
	movwf	(??_TDS_Handle+0)+0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+1)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+1)+0+1
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	movf	0+(??_TDS_Handle+1)+0,w
	addwf	indf,f
	incfsz	fsr0,f
	movf	indf,w
	skipnc
	incf	indf,w
	movwf	btemp+1
	movf	1+(??_TDS_Handle+1)+0,w
	addwf	btemp+1,w
	movwf	indf
	decf	fsr0,f
	line	525
	
l10169:	
	incf	(TDS_Handle@i),f
	skipnz
	incf	(TDS_Handle@i+1),f
	
l10171:	
	movlw	0
	subwf	(TDS_Handle@i+1),w
	movlw	05h
	skipnz
	subwf	(TDS_Handle@i),w
	skipc
	goto	u8971
	goto	u8970
u8971:
	goto	l10167
u8970:
	line	528
	
l10173:	
;main.c: 527: }
;main.c: 528: (TDSTyp->TdsHz)/=5;
	movlw	05h
	movwf	(___lwdiv@divisor)
	clrf	(___lwdiv@divisor+1)
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	movf	indf,w
	movwf	(___lwdiv@dividend)
	incf	fsr0,f
	movf	indf,w
	movwf	(___lwdiv@dividend+1)
	fcall	___lwdiv
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Bh
	movwf	fsr0
	movf	(0+(?___lwdiv)),w
	movwf	indf
	incf	fsr0,f
	movf	(1+(?___lwdiv)),w
	movwf	indf
	line	534
	
l10175:	
;main.c: 534: PreTdsData=TDSTyp->TdsData;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	indf,w
	movwf	(TDS_Handle@PreTdsData)
	incf	fsr0,f
	movf	indf,w
	movwf	(TDS_Handle@PreTdsData+1)
	line	535
	
l10177:	
;main.c: 535: TDSTyp->TdsData=GetCurTdsHz(TDSTyp,(U16_T *)PureHz_Tab,188);
	movlw	low(((_PureHz_Tab)|8000h))
	movwf	(GetCurTdsHz@Tab)
	movlw	high(((_PureHz_Tab)|8000h))
	movwf	((GetCurTdsHz@Tab))+1
	movlw	0BCh
	movwf	(GetCurTdsHz@index)
	clrf	(GetCurTdsHz@index+1)
	movf	(TDS_Handle@TDSTyp),w
	fcall	_GetCurTdsHz
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	(0+(?_GetCurTdsHz)),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movf	(1+(?_GetCurTdsHz)),w
	movwf	indf
	line	536
	
l10179:	
;main.c: 536: if(Mode!=5){
		movlw	5
	xorwf	((_Mode)),w
	btfsc	status,2
	goto	u8981
	goto	u8980
u8981:
	goto	l10193
u8980:
	line	537
	
l10181:	
;main.c: 537: if(_BITS.Bits.bit_6==0){
	btfsc	(__BITS),6
	goto	u8991
	goto	u8990
u8991:
	goto	l10193
u8990:
	line	538
	
l10183:	
;main.c: 538: if(TDSTyp->TdsData>=PreTdsData){
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+1
	movf	(TDS_Handle@PreTdsData+1),w
	subwf	1+(??_TDS_Handle+0)+0,w
	skipz
	goto	u9005
	movf	(TDS_Handle@PreTdsData),w
	subwf	0+(??_TDS_Handle+0)+0,w
u9005:
	skipc
	goto	u9001
	goto	u9000
u9001:
	goto	l1059
u9000:
	line	539
	
l10185:	
;main.c: 539: _BITS1.Bits.bit_5^=1;
	movlw	1<<5
	xorwf	(__BITS1),f
	line	540
	
l10187:	
;main.c: 540: if(_BITS1.Bits.bit_5){
	btfss	(__BITS1),5
	goto	u9011
	goto	u9010
u9011:
	goto	l10191
u9010:
	line	541
	
l10189:	
;main.c: 541: TDSTyp->TdsData=PreTdsData+3;
	movf	(TDS_Handle@PreTdsData),w
	addlw	low(03h)
	movwf	(??_TDS_Handle+0)+0
	movf	(TDS_Handle@PreTdsData+1),w
	skipnc
	addlw	1
	addlw	high(03h)
	movwf	1+(??_TDS_Handle+0)+0
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	indf
	line	542
;main.c: 542: }
	goto	l10193
	line	545
	
l10191:	
;main.c: 543: else
;main.c: 544: {
;main.c: 545: TDSTyp->TdsData=PreTdsData+2;
	movf	(TDS_Handle@PreTdsData),w
	addlw	low(02h)
	movwf	(??_TDS_Handle+0)+0
	movf	(TDS_Handle@PreTdsData+1),w
	skipnc
	addlw	1
	addlw	high(02h)
	movwf	1+(??_TDS_Handle+0)+0
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	0+(??_TDS_Handle+0)+0,w
	movwf	indf
	incf	fsr0,f
	movf	1+(??_TDS_Handle+0)+0,w
	movwf	indf
	goto	l10193
	line	548
	
l1059:	
	line	550
;main.c: 548: else
;main.c: 549: {
;main.c: 550: _BITS.Bits.bit_6=1;
	bsf	(__BITS),6
	line	565
	
l10193:	
;main.c: 551: }
;main.c: 552: }
;main.c: 553: }
;main.c: 565: if(TDSTyp->TdsData>999){
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_TDS_Handle+0)+0+1
	movlw	03h
	subwf	1+(??_TDS_Handle+0)+0,w
	movlw	0E8h
	skipnz
	subwf	0+(??_TDS_Handle+0)+0,w
	skipc
	goto	u9021
	goto	u9020
u9021:
	goto	l1064
u9020:
	line	566
	
l10195:	
;main.c: 566: TDSTyp->TdsData=999;
	movf	(TDS_Handle@TDSTyp),w
	addlw	0Fh
	movwf	fsr0
	movlw	0E7h
	movwf	indf
	incf	fsr0,f
	movlw	03h
	movwf	indf
	line	573
	
l1064:	
	return
	opt stack 0
GLOBAL	__end_of_TDS_Handle
	__end_of_TDS_Handle:
	signat	_TDS_Handle,8313
	global	___lwdiv

;; *************** function ___lwdiv *****************
;; Defined at:
;;		line 6 in file "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lwdiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         2    0[BANK0 ] unsigned int 
;;  dividend        2    2[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  quotient        2    5[BANK0 ] unsigned int 
;;  counter         1    4[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  2    0[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       4       0       0
;;      Locals:         0       3       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       7       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_TDS_Handle
;; This function uses a non-reentrant model
;;
psect	text33,local,class=CODE,delta=2,merge=1,group=2
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lwdiv.c"
	line	6
global __ptext33
__ptext33:	;psect for function ___lwdiv
psect	text33
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lwdiv.c"
	line	6
	global	__size_of___lwdiv
	__size_of___lwdiv	equ	__end_of___lwdiv-___lwdiv
	
___lwdiv:	
;incstack = 0
	opt	stack 6
; Regs used in ___lwdiv: [wreg+status,2+status,0]
	line	14
	
l10085:	
	clrf	(___lwdiv@quotient)
	clrf	(___lwdiv@quotient+1)
	line	15
	
l10087:	
	movf	((___lwdiv@divisor)),w
iorwf	((___lwdiv@divisor+1)),w
	btfsc	status,2
	goto	u8821
	goto	u8820
u8821:
	goto	l10107
u8820:
	line	16
	
l10089:	
	clrf	(___lwdiv@counter)
	incf	(___lwdiv@counter),f
	line	17
	goto	l10093
	line	18
	
l10091:	
	clrc
	rlf	(___lwdiv@divisor),f
	rlf	(___lwdiv@divisor+1),f
	line	19
	incf	(___lwdiv@counter),f
	line	17
	
l10093:	
	btfss	(___lwdiv@divisor+1),(15)&7
	goto	u8831
	goto	u8830
u8831:
	goto	l10091
u8830:
	line	22
	
l10095:	
	clrc
	rlf	(___lwdiv@quotient),f
	rlf	(___lwdiv@quotient+1),f
	line	23
	
l10097:	
	movf	(___lwdiv@divisor+1),w
	subwf	(___lwdiv@dividend+1),w
	skipz
	goto	u8845
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),w
u8845:
	skipc
	goto	u8841
	goto	u8840
u8841:
	goto	l10103
u8840:
	line	24
	
l10099:	
	movf	(___lwdiv@divisor),w
	subwf	(___lwdiv@dividend),f
	movf	(___lwdiv@divisor+1),w
	skipc
	decf	(___lwdiv@dividend+1),f
	subwf	(___lwdiv@dividend+1),f
	line	25
	
l10101:	
	bsf	(___lwdiv@quotient)+(0/8),(0)&7
	line	27
	
l10103:	
	clrc
	rrf	(___lwdiv@divisor+1),f
	rrf	(___lwdiv@divisor),f
	line	28
	
l10105:	
	decfsz	(___lwdiv@counter),f
	goto	u8851
	goto	u8850
u8851:
	goto	l10095
u8850:
	line	30
	
l10107:	
	movf	(___lwdiv@quotient+1),w
	movwf	(?___lwdiv+1)
	movf	(___lwdiv@quotient),w
	movwf	(?___lwdiv)
	line	31
	
l4014:	
	return
	opt stack 0
GLOBAL	__end_of___lwdiv
	__end_of___lwdiv:
	signat	___lwdiv,8314
	global	___lmul

;; *************** function ___lmul *****************
;; Defined at:
;;		line 15 in file "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul32.c"
;; Parameters:    Size  Location     Type
;;  multiplier      4    0[BANK0 ] unsigned long 
;;  multiplicand    4    4[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  product         4    8[BANK0 ] unsigned long 
;; Return value:  Size  Location     Type
;;                  4    0[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       8       0       0
;;      Locals:         0       4       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_TDS_Handle
;; This function uses a non-reentrant model
;;
psect	text34,local,class=CODE,delta=2,merge=1,group=2
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul32.c"
	line	15
global __ptext34
__ptext34:	;psect for function ___lmul
psect	text34
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul32.c"
	line	15
	global	__size_of___lmul
	__size_of___lmul	equ	__end_of___lmul-___lmul
	
___lmul:	
;incstack = 0
	opt	stack 6
; Regs used in ___lmul: [wreg+status,2+status,0]
	line	119
	
l10047:	
	clrf	(___lmul@product)
	clrf	(___lmul@product+1)
	clrf	(___lmul@product+2)
	clrf	(___lmul@product+3)
	line	120
	
l3682:	
	line	121
	btfss	(___lmul@multiplier),(0)&7
	goto	u8751
	goto	u8750
u8751:
	goto	l10051
u8750:
	line	122
	
l10049:	
	movf	(___lmul@multiplicand),w
	addwf	(___lmul@product),f
	movf	(___lmul@multiplicand+1),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u8761
	addwf	(___lmul@product+1),f
u8761:
	movf	(___lmul@multiplicand+2),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u8762
	addwf	(___lmul@product+2),f
u8762:
	movf	(___lmul@multiplicand+3),w
	clrz
	skipnc
	addlw	1
	skipnz
	goto	u8763
	addwf	(___lmul@product+3),f
u8763:

	line	123
	
l10051:	
	clrc
	rlf	(___lmul@multiplicand),f
	rlf	(___lmul@multiplicand+1),f
	rlf	(___lmul@multiplicand+2),f
	rlf	(___lmul@multiplicand+3),f
	line	124
	
l10053:	
	clrc
	rrf	(___lmul@multiplier+3),f
	rrf	(___lmul@multiplier+2),f
	rrf	(___lmul@multiplier+1),f
	rrf	(___lmul@multiplier),f
	line	125
	movf	(___lmul@multiplier+3),w
	iorwf	(___lmul@multiplier+2),w
	iorwf	(___lmul@multiplier+1),w
	iorwf	(___lmul@multiplier),w
	skipz
	goto	u8771
	goto	u8770
u8771:
	goto	l3682
u8770:
	line	128
	
l10055:	
	movf	(___lmul@product+3),w
	movwf	(?___lmul+3)
	movf	(___lmul@product+2),w
	movwf	(?___lmul+2)
	movf	(___lmul@product+1),w
	movwf	(?___lmul+1)
	movf	(___lmul@product),w
	movwf	(?___lmul)

	line	129
	
l3685:	
	return
	opt stack 0
GLOBAL	__end_of___lmul
	__end_of___lmul:
	signat	___lmul,8316
	global	___lldiv

;; *************** function ___lldiv *****************
;; Defined at:
;;		line 6 in file "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lldiv.c"
;; Parameters:    Size  Location     Type
;;  divisor         4    0[BANK0 ] unsigned long 
;;  dividend        4    4[BANK0 ] unsigned long 
;; Auto vars:     Size  Location     Type
;;  quotient        4    8[BANK0 ] unsigned long 
;;  counter         1   12[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  4    0[BANK0 ] unsigned long 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : B00/800
;;		Unchanged: 800/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       8       0       0
;;      Locals:         0       5       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0      13       0       0
;;Total ram usage:       13 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_TDS_Handle
;; This function uses a non-reentrant model
;;
psect	text35,local,class=CODE,delta=2,merge=1,group=2
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lldiv.c"
	line	6
global __ptext35
__ptext35:	;psect for function ___lldiv
psect	text35
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\lldiv.c"
	line	6
	global	__size_of___lldiv
	__size_of___lldiv	equ	__end_of___lldiv-___lldiv
	
___lldiv:	
;incstack = 0
	opt	stack 6
; Regs used in ___lldiv: [wreg+status,2+status,0]
	line	14
	
l10059:	
	clrf	(___lldiv@quotient)
	clrf	(___lldiv@quotient+1)
	clrf	(___lldiv@quotient+2)
	clrf	(___lldiv@quotient+3)
	line	15
	
l10061:	
	movf	(___lldiv@divisor+3),w
	iorwf	(___lldiv@divisor+2),w
	iorwf	(___lldiv@divisor+1),w
	iorwf	(___lldiv@divisor),w
	skipnz
	goto	u8781
	goto	u8780
u8781:
	goto	l10081
u8780:
	line	16
	
l10063:	
	clrf	(___lldiv@counter)
	incf	(___lldiv@counter),f
	line	17
	goto	l10067
	line	18
	
l10065:	
	clrc
	rlf	(___lldiv@divisor),f
	rlf	(___lldiv@divisor+1),f
	rlf	(___lldiv@divisor+2),f
	rlf	(___lldiv@divisor+3),f
	line	19
	incf	(___lldiv@counter),f
	line	17
	
l10067:	
	btfss	(___lldiv@divisor+3),(31)&7
	goto	u8791
	goto	u8790
u8791:
	goto	l10065
u8790:
	line	22
	
l10069:	
	clrc
	rlf	(___lldiv@quotient),f
	rlf	(___lldiv@quotient+1),f
	rlf	(___lldiv@quotient+2),f
	rlf	(___lldiv@quotient+3),f
	line	23
	
l10071:	
	movf	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),w
	skipz
	goto	u8805
	movf	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),w
	skipz
	goto	u8805
	movf	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),w
	skipz
	goto	u8805
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),w
u8805:
	skipc
	goto	u8801
	goto	u8800
u8801:
	goto	l10077
u8800:
	line	24
	
l10073:	
	movf	(___lldiv@divisor),w
	subwf	(___lldiv@dividend),f
	movf	(___lldiv@divisor+1),w
	skipc
	incfsz	(___lldiv@divisor+1),w
	subwf	(___lldiv@dividend+1),f
	movf	(___lldiv@divisor+2),w
	skipc
	incfsz	(___lldiv@divisor+2),w
	subwf	(___lldiv@dividend+2),f
	movf	(___lldiv@divisor+3),w
	skipc
	incfsz	(___lldiv@divisor+3),w
	subwf	(___lldiv@dividend+3),f
	line	25
	
l10075:	
	bsf	(___lldiv@quotient)+(0/8),(0)&7
	line	27
	
l10077:	
	clrc
	rrf	(___lldiv@divisor+3),f
	rrf	(___lldiv@divisor+2),f
	rrf	(___lldiv@divisor+1),f
	rrf	(___lldiv@divisor),f
	line	28
	
l10079:	
	decfsz	(___lldiv@counter),f
	goto	u8811
	goto	u8810
u8811:
	goto	l10069
u8810:
	line	30
	
l10081:	
	movf	(___lldiv@quotient+3),w
	movwf	(?___lldiv+3)
	movf	(___lldiv@quotient+2),w
	movwf	(?___lldiv+2)
	movf	(___lldiv@quotient+1),w
	movwf	(?___lldiv+1)
	movf	(___lldiv@quotient),w
	movwf	(?___lldiv)

	line	31
	
l3961:	
	return
	opt stack 0
GLOBAL	__end_of___lldiv
	__end_of___lldiv:
	signat	___lldiv,8316
	global	_GetCurTdsHz

;; *************** function _GetCurTdsHz *****************
;; Defined at:
;;		line 363 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  AdPtr           1    wreg     PTR struct .
;;		 -> PureTDSTyp(17), 
;;  Tab             2    0[BANK0 ] PTR unsigned int 
;;		 -> PureHz_Tab(380), 
;;  index           2    2[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  AdPtr           1   14[BANK0 ] PTR struct .
;;		 -> PureTDSTyp(17), 
;;  tmp             2   12[BANK0 ] unsigned int 
;;  i               2   10[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  2    0[BANK0 ] unsigned int 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : B00/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       4       0       0
;;      Locals:         0       5       0       0
;;      Temps:          0       6       0       0
;;      Totals:         0      15       0       0
;;Total ram usage:       15 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_TDS_Handle
;; This function uses a non-reentrant model
;;
psect	text36,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	363
global __ptext36
__ptext36:	;psect for function _GetCurTdsHz
psect	text36
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	363
	global	__size_of_GetCurTdsHz
	__size_of_GetCurTdsHz	equ	__end_of_GetCurTdsHz-_GetCurTdsHz
	
_GetCurTdsHz:	
;incstack = 0
	opt	stack 6
; Regs used in _GetCurTdsHz: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
;GetCurTdsHz@AdPtr stored from wreg
	movwf	(GetCurTdsHz@AdPtr)
	line	366
	
l9137:	
;main.c: 365: U16_T tmp, i;
;main.c: 366: tmp=0x00;
	clrf	(GetCurTdsHz@tmp)
	clrf	(GetCurTdsHz@tmp+1)
	line	368
	
l9139:	
;main.c: 368: if(AdPtr->TdsHz<Tab[0])
	movf	(GetCurTdsHz@Tab+1),w
	movwf	btemp+1
	movf	(GetCurTdsHz@Tab),w
	movwf	fsr0
	fcall	stringtab
	movwf	(??_GetCurTdsHz+0)+0
	fcall	stringtab
	movwf	(??_GetCurTdsHz+0)+0+1
	movf	(GetCurTdsHz@AdPtr),w
	addlw	0Bh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_GetCurTdsHz+2)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_GetCurTdsHz+2)+0+1
	movf	1+(??_GetCurTdsHz+0)+0,w
	subwf	1+(??_GetCurTdsHz+2)+0,w
	skipz
	goto	u7305
	movf	0+(??_GetCurTdsHz+0)+0,w
	subwf	0+(??_GetCurTdsHz+2)+0,w
u7305:
	skipnc
	goto	u7301
	goto	u7300
u7301:
	goto	l9143
u7300:
	goto	l1012
	line	371
	
l9143:	
;main.c: 371: else if(AdPtr->TdsHz>=Tab[index]){tmp=index;}
	movf	(GetCurTdsHz@index+1),w
	movwf	(??_GetCurTdsHz+0)+0+1
	movf	(GetCurTdsHz@index),w
	movwf	(??_GetCurTdsHz+0)+0
	clrc
	rlf	(??_GetCurTdsHz+0)+0,f
	rlf	(??_GetCurTdsHz+0)+1,f
	movf	0+(??_GetCurTdsHz+0)+0,w
	addwf	(GetCurTdsHz@Tab),w
	movwf	fsr0
	movf	1+(??_GetCurTdsHz+0)+0,w
	skipnc
	incf	1+(??_GetCurTdsHz+0)+0,w
	addwf	(GetCurTdsHz@Tab+1),w
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_GetCurTdsHz+2)+0
	fcall	stringtab
	movwf	(??_GetCurTdsHz+2)+0+1
	movf	(GetCurTdsHz@AdPtr),w
	addlw	0Bh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_GetCurTdsHz+4)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_GetCurTdsHz+4)+0+1
	movf	1+(??_GetCurTdsHz+2)+0,w
	subwf	1+(??_GetCurTdsHz+4)+0,w
	skipz
	goto	u7315
	movf	0+(??_GetCurTdsHz+2)+0,w
	subwf	0+(??_GetCurTdsHz+4)+0,w
u7315:
	skipc
	goto	u7311
	goto	u7310
u7311:
	goto	l9147
u7310:
	
l9145:	
	movf	(GetCurTdsHz@index+1),w
	movwf	(GetCurTdsHz@tmp+1)
	movf	(GetCurTdsHz@index),w
	movwf	(GetCurTdsHz@tmp)
	goto	l1012
	line	374
	
l9147:	
;main.c: 372: else
;main.c: 373: {
;main.c: 374: for(i = 10; i < index; )
	movlw	0Ah
	movwf	(GetCurTdsHz@i)
	clrf	(GetCurTdsHz@i+1)
	goto	l1015
	line	376
	
l9149:	
;main.c: 375: {
;main.c: 376: if(AdPtr->TdsHz >= Tab[i]){tmp = i;}
	movf	(GetCurTdsHz@i+1),w
	movwf	(??_GetCurTdsHz+0)+0+1
	movf	(GetCurTdsHz@i),w
	movwf	(??_GetCurTdsHz+0)+0
	clrc
	rlf	(??_GetCurTdsHz+0)+0,f
	rlf	(??_GetCurTdsHz+0)+1,f
	movf	0+(??_GetCurTdsHz+0)+0,w
	addwf	(GetCurTdsHz@Tab),w
	movwf	fsr0
	movf	1+(??_GetCurTdsHz+0)+0,w
	skipnc
	incf	1+(??_GetCurTdsHz+0)+0,w
	addwf	(GetCurTdsHz@Tab+1),w
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_GetCurTdsHz+2)+0
	fcall	stringtab
	movwf	(??_GetCurTdsHz+2)+0+1
	movf	(GetCurTdsHz@AdPtr),w
	addlw	0Bh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_GetCurTdsHz+4)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_GetCurTdsHz+4)+0+1
	movf	1+(??_GetCurTdsHz+2)+0,w
	subwf	1+(??_GetCurTdsHz+4)+0,w
	skipz
	goto	u7325
	movf	0+(??_GetCurTdsHz+2)+0,w
	subwf	0+(??_GetCurTdsHz+4)+0,w
u7325:
	skipc
	goto	u7321
	goto	u7320
u7321:
	goto	l1017
u7320:
	
l9151:	
	movf	(GetCurTdsHz@i+1),w
	movwf	(GetCurTdsHz@tmp+1)
	movf	(GetCurTdsHz@i),w
	movwf	(GetCurTdsHz@tmp)
	
l1017:	
	line	377
;main.c: 377: i += 10;
	movlw	0Ah
	addwf	(GetCurTdsHz@i),f
	skipnc
	incf	(GetCurTdsHz@i+1),f
	line	374
	
l1015:	
	movf	(GetCurTdsHz@index+1),w
	subwf	(GetCurTdsHz@i+1),w
	skipz
	goto	u7335
	movf	(GetCurTdsHz@index),w
	subwf	(GetCurTdsHz@i),w
u7335:
	skipc
	goto	u7331
	goto	u7330
u7331:
	goto	l9149
u7330:
	line	379
	
l9153:	
	movf	(GetCurTdsHz@AdPtr),w
	addlw	0Bh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_GetCurTdsHz+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_GetCurTdsHz+0)+0+1
	movf	(GetCurTdsHz@tmp+1),w
	movwf	(??_GetCurTdsHz+2)+0+1
	movf	(GetCurTdsHz@tmp),w
	movwf	(??_GetCurTdsHz+2)+0
	incf	(GetCurTdsHz@tmp),f
	skipnz
	incf	(GetCurTdsHz@tmp+1),f
	clrc
	rlf	(??_GetCurTdsHz+2)+0,f
	rlf	(??_GetCurTdsHz+2)+1,f
	movf	0+(??_GetCurTdsHz+2)+0,w
	addwf	(GetCurTdsHz@Tab),w
	movwf	fsr0
	movf	1+(??_GetCurTdsHz+2)+0,w
	skipnc
	incf	1+(??_GetCurTdsHz+2)+0,w
	addwf	(GetCurTdsHz@Tab+1),w
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_GetCurTdsHz+4)+0
	fcall	stringtab
	movwf	(??_GetCurTdsHz+4)+0+1
	movf	1+(??_GetCurTdsHz+0)+0,w
	subwf	1+(??_GetCurTdsHz+4)+0,w
	skipz
	goto	u7345
	movf	0+(??_GetCurTdsHz+0)+0,w
	subwf	0+(??_GetCurTdsHz+4)+0,w
u7345:
	skipc
	goto	u7341
	goto	u7340
u7341:
	goto	l9153
u7340:
	line	380
	
l9155:	
;main.c: 380: if(tmp){tmp--;}
	movf	((GetCurTdsHz@tmp)),w
iorwf	((GetCurTdsHz@tmp+1)),w
	btfsc	status,2
	goto	u7351
	goto	u7350
u7351:
	goto	l1012
u7350:
	
l9157:	
	movlw	01h
	subwf	(GetCurTdsHz@tmp),f
	movlw	0
	skipc
	decf	(GetCurTdsHz@tmp+1),f
	subwf	(GetCurTdsHz@tmp+1),f
	line	381
	
l1012:	
	line	382
;main.c: 381: }
;main.c: 382: return(tmp);
	movf	(GetCurTdsHz@tmp+1),w
	movwf	(?_GetCurTdsHz+1)
	movf	(GetCurTdsHz@tmp),w
	movwf	(?_GetCurTdsHz)
	line	384
	
l1023:	
	return
	opt stack 0
GLOBAL	__end_of_GetCurTdsHz
	__end_of_GetCurTdsHz:
	signat	_GetCurTdsHz,12410
	global	_Page_ProgramData

;; *************** function _Page_ProgramData *****************
;; Defined at:
;;		line 2637 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               2    3[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       2       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Memory_Write
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text37,local,class=CODE,delta=2,merge=1,group=0
	line	2637
global __ptext37
__ptext37:	;psect for function _Page_ProgramData
psect	text37
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	2637
	global	__size_of_Page_ProgramData
	__size_of_Page_ProgramData	equ	__end_of_Page_ProgramData-_Page_ProgramData
	
_Page_ProgramData:	
;incstack = 0
	opt	stack 6
; Regs used in _Page_ProgramData: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	2638
	
l10715:	
;main.c: 2638: unsigned int i=0;
	clrf	(Page_ProgramData@i)
	clrf	(Page_ProgramData@i+1)
	line	2639
;main.c: 2639: for(i=0;i<12;i++){
	clrf	(Page_ProgramData@i)
	clrf	(Page_ProgramData@i+1)
	line	2640
	
l10721:	
;main.c: 2640: Memory_Write(i,Read_Word_Buff[i]);
	movf	(Page_ProgramData@i+1),w
	movwf	(Memory_Write@Addr+1)
	movf	(Page_ProgramData@i),w
	movwf	(Memory_Write@Addr)
	movf	(Page_ProgramData@i),w
	addlw	low(_Read_Word_Buff|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank1
	movf	indf,w
	movwf	(Memory_Write@Value)
	fcall	_Memory_Write
	line	2639
	
l10723:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(Page_ProgramData@i),f
	skipnz
	incf	(Page_ProgramData@i+1),f
	
l10725:	
	movlw	0
	subwf	(Page_ProgramData@i+1),w
	movlw	0Ch
	skipnz
	subwf	(Page_ProgramData@i),w
	skipc
	goto	u9901
	goto	u9900
u9901:
	goto	l10721
u9900:
	line	2642
	
l1495:	
	return
	opt stack 0
GLOBAL	__end_of_Page_ProgramData
	__end_of_Page_ProgramData:
	signat	_Page_ProgramData,89
	global	_Memory_Write

;; *************** function _Memory_Write *****************
;; Defined at:
;;		line 1732 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Addr            2    0[BANK0 ] unsigned int 
;;  Value           1    2[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  i               1    4[COMMON] volatile unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       3       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       3       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Page_ProgramData
;; This function uses a non-reentrant model
;;
psect	text38,local,class=CODE,delta=2,merge=1,group=0
	line	1732
global __ptext38
__ptext38:	;psect for function _Memory_Write
psect	text38
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	1732
	global	__size_of_Memory_Write
	__size_of_Memory_Write	equ	__end_of_Memory_Write-_Memory_Write
	
_Memory_Write:	
;incstack = 0
	opt	stack 6
; Regs used in _Memory_Write: [wreg+status,2]
	line	1735
	
l9365:	
;main.c: 1735: volatile unsigned char i = 0;
	clrf	(Memory_Write@i)	;volatile
	line	1738
	
l9367:	
;main.c: 1738: EEADR = Addr;
	movf	(Memory_Write@Addr),w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(391)^0180h	;volatile
	line	1739
	
l9369:	
;main.c: 1739: EEDAT= Value;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(Memory_Write@Value),w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(390)^0180h	;volatile
	line	1740
;main.c: 1740: EECON1 = 0;
	clrf	(396)^0180h	;volsfr
	line	1741
	
l9371:	
;main.c: 1741: EEPGD = 0;
	bcf	(3175/8)^0180h,(3175)&7	;volsfr
	line	1742
	
l9373:	
;main.c: 1742: EECON1 | = 0x10;
	bsf	(396)^0180h+(4/8),(4)&7	;volsfr
	line	1743
# 1743 "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text38
	line	1746
	
l9375:	
;main.c: 1746: WREN = 1;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	bsf	(3170/8)^0180h,(3170)&7	;volsfr
	line	1747
	
l9377:	
;main.c: 1747: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	1748
	
l9379:	
;main.c: 1748: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	1749
	
l9381:	
;main.c: 1749: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	1750
;main.c: 1750: while(GIE)
	goto	l1330
	
l1331:	
	line	1752
;main.c: 1751: {
;main.c: 1752: GIE = 0;
	bcf	(95/8),(95)&7	;volatile
	line	1753
;main.c: 1753: if(0 == --i)
	decfsz	(Memory_Write@i),f	;volatile
	goto	u7731
	goto	u7730
u7731:
	goto	l1330
u7730:
	line	1756
	
l9383:	
;main.c: 1754: {
;main.c: 1756: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	1757
;main.c: 1757: return 0;
;	Return value of _Memory_Write is never used
	goto	l1333
	line	1759
	
l1330:	
	line	1750
	btfsc	(95/8),(95)&7	;volatile
	goto	u7741
	goto	u7740
u7741:
	goto	l1331
u7740:
	
l1334:	
	line	1760
# 1760 "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text38
	line	1762
	
l9385:	
;main.c: 1762: EECON2 = 0x55;
	movlw	low(055h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(397)^0180h	;volsfr
	line	1763
;main.c: 1763: EECON2 = 0xaa;
	movlw	low(0AAh)
	movwf	(397)^0180h	;volsfr
	line	1764
	
l9387:	
;main.c: 1764: WR = 1;
	bsf	(3169/8)^0180h,(3169)&7	;volsfr
	line	1765
# 1765 "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	1766
# 1766 "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	1767
# 1767 "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text38
	line	1768
	
l9389:	
;main.c: 1768: WREN = 0;
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	bcf	(3170/8)^0180h,(3170)&7	;volsfr
	line	1770
	
l9391:	
;main.c: 1770: GIE = 1;
	bsf	(95/8),(95)&7	;volatile
	line	1772
	
l9393:	
;main.c: 1772: if(WRERR) return 0;
	line	1774
	
l1333:	
	return
	opt stack 0
GLOBAL	__end_of_Memory_Write
	__end_of_Memory_Write:
	signat	_Memory_Write,8313
	global	_Led_Handle

;; *************** function _Led_Handle *****************
;; Defined at:
;;		line 940 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               2    4[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       2       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_LedControlSt
;;		___bmul
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text39,local,class=CODE,delta=2,merge=1,group=0
	line	940
global __ptext39
__ptext39:	;psect for function _Led_Handle
psect	text39
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	940
	global	__size_of_Led_Handle
	__size_of_Led_Handle	equ	__end_of_Led_Handle-_Led_Handle
	
_Led_Handle:	
;incstack = 0
	opt	stack 6
; Regs used in _Led_Handle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	941
	
l10407:	
;main.c: 941: unsigned int i=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	clrf	(Led_Handle@i)
	clrf	(Led_Handle@i+1)
	line	943
;main.c: 943: for(i=0;i<6;i++){
	clrf	(Led_Handle@i)
	clrf	(Led_Handle@i+1)
	line	944
	
l10413:	
;main.c: 944: LedMod[i].LedTime++;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	bsf	status, 7	;select IRP bank2
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	line	945
;main.c: 945: switch(LedMod[i].LedState){
	goto	l10457
	line	947
	
l10415:	
;main.c: 947: LedControlSt(i,0);
	clrf	(LedControlSt@Sta)
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	948
;main.c: 948: break;
	goto	l10459
	line	950
	
l10417:	
;main.c: 950: LedControlSt(i,1);
	clrf	(LedControlSt@Sta)
	incf	(LedControlSt@Sta),f
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	951
;main.c: 951: break;
	goto	l10459
	line	953
	
l10419:	
;main.c: 953: if(LedMod[i].LedFlashNum){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movf	((??_Led_Handle+0)+0),w
iorwf	((??_Led_Handle+0)+1),w
	btfsc	status,2
	goto	u9421
	goto	u9420
u9421:
	goto	l1142
u9420:
	line	954
	
l10421:	
;main.c: 954: if(LedMod[i].LedTime<=25){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	01Ah
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9431
	goto	u9430
u9431:
	goto	l10425
u9430:
	line	955
	
l10423:	
;main.c: 955: LedControlSt(i,0);
	clrf	(LedControlSt@Sta)
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	956
;main.c: 956: }
	goto	l10459
	line	957
	
l10425:	
;main.c: 957: else if(LedMod[i].LedTime<=25*2)
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	033h
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9441
	goto	u9440
u9441:
	goto	l10429
u9440:
	line	959
	
l10427:	
;main.c: 958: {
;main.c: 959: LedControlSt(i,1);
	clrf	(LedControlSt@Sta)
	incf	(LedControlSt@Sta),f
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	960
;main.c: 960: }
	goto	l10459
	line	963
	
l10429:	
;main.c: 961: else
;main.c: 962: {
;main.c: 963: LedMod[i].LedFlashNum--;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	movlw	low(01h)
	bsf	status, 7	;select IRP bank2
	subwf	indf,f
	incfsz	fsr0,f
	movlw	high(01h)
	skipc
	decf	indf,f
	subwf	indf,f
	decf	fsr0,f
	line	964
;main.c: 964: LedMod[i].LedTime=0;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l10459
	line	967
	
l1142:	
	line	969
;main.c: 967: else
;main.c: 968: {
;main.c: 969: _BITS.Bits.bit_0=0;
	bcf	(__BITS),0
	goto	l10459
	line	973
	
l10431:	
;main.c: 973: if(LedMod[i].LedTime<=100){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	065h
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9451
	goto	u9450
u9451:
	goto	l10435
u9450:
	line	974
	
l10433:	
;main.c: 974: LedControlSt(i,1);
	clrf	(LedControlSt@Sta)
	incf	(LedControlSt@Sta),f
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	975
;main.c: 975: }
	goto	l10459
	line	976
	
l10435:	
;main.c: 976: else if(LedMod[i].LedTime<=100*2)
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	0C9h
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9461
	goto	u9460
u9461:
	goto	l10439
u9460:
	line	978
	
l10437:	
;main.c: 977: {
;main.c: 978: LedControlSt(i,0);
	clrf	(LedControlSt@Sta)
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	979
;main.c: 979: }
	goto	l10459
	line	982
	
l10439:	
;main.c: 980: else
;main.c: 981: {
;main.c: 982: LedMod[i].LedTime=0;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l10459
	line	987
	
l10441:	
;main.c: 987: if(LedMod[i].LedFlashNum){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movf	((??_Led_Handle+0)+0),w
iorwf	((??_Led_Handle+0)+1),w
	btfsc	status,2
	goto	u9471
	goto	u9470
u9471:
	goto	l1154
u9470:
	line	988
	
l10443:	
;main.c: 988: if(LedMod[i].LedTime<=100){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	065h
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9481
	goto	u9480
u9481:
	goto	l10447
u9480:
	line	989
	
l10445:	
;main.c: 989: LedControlSt(i,0);
	clrf	(LedControlSt@Sta)
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	990
;main.c: 990: }
	goto	l10459
	line	991
	
l10447:	
;main.c: 991: else if(LedMod[i].LedTime<=100*2)
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_Led_Handle+0)+0+1
	movlw	0
	subwf	1+(??_Led_Handle+0)+0,w
	movlw	0C9h
	skipnz
	subwf	0+(??_Led_Handle+0)+0,w
	skipnc
	goto	u9491
	goto	u9490
u9491:
	goto	l10451
u9490:
	line	993
	
l10449:	
;main.c: 992: {
;main.c: 993: LedControlSt(i,1);
	clrf	(LedControlSt@Sta)
	incf	(LedControlSt@Sta),f
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	994
;main.c: 994: }
	goto	l10459
	line	997
	
l10451:	
;main.c: 995: else
;main.c: 996: {
;main.c: 997: LedMod[i].LedFlashNum--;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	movlw	low(01h)
	bsf	status, 7	;select IRP bank2
	subwf	indf,f
	incfsz	fsr0,f
	movlw	high(01h)
	skipc
	decf	indf,f
	subwf	indf,f
	decf	fsr0,f
	line	998
;main.c: 998: LedMod[i].LedTime=0;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	goto	l10459
	line	1001
	
l1154:	
	line	1003
;main.c: 1001: else
;main.c: 1002: {
;main.c: 1003: _BITS.Bits.bit_0=0;
	bcf	(__BITS),0
	line	1004
	
l10453:	
;main.c: 1004: LedControlSt(i,0);
	clrf	(LedControlSt@Sta)
	movf	(Led_Handle@i),w
	fcall	_LedControlSt
	line	1005
;main.c: 1005: LedMod[i].LedState=0;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	goto	l10459
	line	945
	
l10457:	
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(Led_Handle@i),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	; Switch size 1, requested type "space"
; Number of cases is 5, Range of values is 0 to 5
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           16     9 (average)
; direct_byte           26     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l10415
	xorlw	1^0	; case 1
	skipnz
	goto	l10417
	xorlw	2^1	; case 2
	skipnz
	goto	l10419
	xorlw	3^2	; case 3
	skipnz
	goto	l10431
	xorlw	5^3	; case 5
	skipnz
	goto	l10441
	goto	l10459
	opt asmopt_pop

	line	943
	
l10459:	
	incf	(Led_Handle@i),f
	skipnz
	incf	(Led_Handle@i+1),f
	
l10461:	
	movlw	0
	subwf	(Led_Handle@i+1),w
	movlw	06h
	skipnz
	subwf	(Led_Handle@i),w
	skipc
	goto	u9501
	goto	u9500
u9501:
	goto	l10413
u9500:
	line	1015
	
l1160:	
	return
	opt stack 0
GLOBAL	__end_of_Led_Handle
	__end_of_Led_Handle:
	signat	_Led_Handle,89
	global	_LedControlSt

;; *************** function _LedControlSt *****************
;; Defined at:
;;		line 858 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Num             1    wreg     unsigned char 
;;  Sta             1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  Num             1    5[COMMON] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Led_Handle
;; This function uses a non-reentrant model
;;
psect	text40,local,class=CODE,delta=2,merge=1,group=0
	line	858
global __ptext40
__ptext40:	;psect for function _LedControlSt
psect	text40
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	858
	global	__size_of_LedControlSt
	__size_of_LedControlSt	equ	__end_of_LedControlSt-_LedControlSt
	
_LedControlSt:	
;incstack = 0
	opt	stack 6
; Regs used in _LedControlSt: [wreg-fsr0h+status,2+status,0]
;LedControlSt@Num stored from wreg
	movwf	(LedControlSt@Num)
	line	860
	
l9205:	
;main.c: 860: switch(Num){
	goto	l9241
	line	862
	
l9207:	
;main.c: 862: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7391
	goto	u7390
u7391:
	goto	l1108
u7390:
	line	863
	
l9209:	
;main.c: 863: RB6=0;
	bcf	(54/8),(54)&7	;volatile
	line	864
;main.c: 864: }
	goto	l1132
	line	865
	
l1108:	
	line	867
;main.c: 865: else
;main.c: 866: {
;main.c: 867: RB6=1;
	bsf	(54/8),(54)&7	;volatile
	goto	l1132
	line	871
	
l9211:	
;main.c: 871: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7401
	goto	u7400
u7401:
	goto	l1112
u7400:
	line	872
	
l9213:	
;main.c: 872: RB3=0;
	bcf	(51/8),(51)&7	;volatile
	line	873
;main.c: 873: }
	goto	l1132
	line	874
	
l1112:	
	line	876
;main.c: 874: else
;main.c: 875: {
;main.c: 876: RB3=1;
	bsf	(51/8),(51)&7	;volatile
	goto	l1132
	line	880
	
l9215:	
;main.c: 880: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7411
	goto	u7410
u7411:
	goto	l1115
u7410:
	line	881
	
l9217:	
;main.c: 881: RA6=0;
	bcf	(46/8),(46)&7	;volatile
	line	882
;main.c: 882: }
	goto	l1132
	line	883
	
l1115:	
	line	885
;main.c: 883: else
;main.c: 884: {
;main.c: 885: RA6=1;
	bsf	(46/8),(46)&7	;volatile
	goto	l1132
	line	889
	
l9219:	
;main.c: 889: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7421
	goto	u7420
u7421:
	goto	l1118
u7420:
	line	890
	
l9221:	
;main.c: 890: RA7=0;
	bcf	(47/8),(47)&7	;volatile
	line	891
;main.c: 891: }
	goto	l1132
	line	892
	
l1118:	
	line	894
;main.c: 892: else
;main.c: 893: {
;main.c: 894: RA7=1;
	bsf	(47/8),(47)&7	;volatile
	goto	l1132
	line	898
	
l9223:	
;main.c: 898: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7431
	goto	u7430
u7431:
	goto	l1121
u7430:
	line	899
	
l9225:	
;main.c: 899: RB0=0;
	bcf	(48/8),(48)&7	;volatile
	line	900
;main.c: 900: }
	goto	l1132
	line	901
	
l1121:	
	line	903
;main.c: 901: else
;main.c: 902: {
;main.c: 903: RB0=1;
	bsf	(48/8),(48)&7	;volatile
	goto	l1132
	line	907
	
l9227:	
;main.c: 907: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7441
	goto	u7440
u7441:
	goto	l1124
u7440:
	line	908
	
l9229:	
;main.c: 908: RB2=0;
	bcf	(50/8),(50)&7	;volatile
	line	909
;main.c: 909: }
	goto	l1132
	line	910
	
l1124:	
	line	912
;main.c: 910: else
;main.c: 911: {
;main.c: 912: RB2=1;
	bsf	(50/8),(50)&7	;volatile
	goto	l1132
	line	916
	
l9231:	
;main.c: 916: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7451
	goto	u7450
u7451:
	goto	l1127
u7450:
	line	917
	
l9233:	
;main.c: 917: RB5=0;
	bcf	(53/8),(53)&7	;volatile
	line	918
;main.c: 918: }
	goto	l1132
	line	919
	
l1127:	
	line	921
;main.c: 919: else
;main.c: 920: {
;main.c: 921: RB5=1;
	bsf	(53/8),(53)&7	;volatile
	goto	l1132
	line	925
	
l9235:	
;main.c: 925: if(Sta==1){
		decf	((LedControlSt@Sta)),w
	btfss	status,2
	goto	u7461
	goto	u7460
u7461:
	goto	l1130
u7460:
	line	926
	
l9237:	
;main.c: 926: RB4=0;
	bcf	(52/8),(52)&7	;volatile
	line	927
;main.c: 927: }
	goto	l1132
	line	928
	
l1130:	
	line	930
;main.c: 928: else
;main.c: 929: {
;main.c: 930: RB4=1;
	bsf	(52/8),(52)&7	;volatile
	goto	l1132
	line	860
	
l9241:	
	movf	(LedControlSt@Num),w
	; Switch size 1, requested type "space"
; Number of cases is 8, Range of values is 0 to 7
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           25    13 (average)
; direct_byte           32     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l9207
	xorlw	1^0	; case 1
	skipnz
	goto	l9211
	xorlw	2^1	; case 2
	skipnz
	goto	l9215
	xorlw	3^2	; case 3
	skipnz
	goto	l9219
	xorlw	4^3	; case 4
	skipnz
	goto	l9223
	xorlw	5^4	; case 5
	skipnz
	goto	l9227
	xorlw	6^5	; case 6
	skipnz
	goto	l9231
	xorlw	7^6	; case 7
	skipnz
	goto	l9235
	goto	l1132
	opt asmopt_pop

	line	936
	
l1132:	
	return
	opt stack 0
GLOBAL	__end_of_LedControlSt
	__end_of_LedControlSt:
	signat	_LedControlSt,8313
	global	_GetDelayFilterFlag

;; *************** function _GetDelayFilterFlag *****************
;; Defined at:
;;		line 411 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  PtrMin          1    wreg     PTR struct .
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;; Auto vars:     Size  Location     Type
;;  PtrMin          1    5[BANK0 ] PTR struct .
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0       3       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Dec
;;		_DecF
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text41,local,class=CODE,delta=2,merge=1,group=0
	line	411
global __ptext41
__ptext41:	;psect for function _GetDelayFilterFlag
psect	text41
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	411
	global	__size_of_GetDelayFilterFlag
	__size_of_GetDelayFilterFlag	equ	__end_of_GetDelayFilterFlag-_GetDelayFilterFlag
	
_GetDelayFilterFlag:	
;incstack = 0
	opt	stack 6
; Regs used in _GetDelayFilterFlag: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;GetDelayFilterFlag@PtrMin stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(GetDelayFilterFlag@PtrMin)
	line	414
	
l10111:	
;main.c: 414: if(Dec(&PtrMin->u8Second,59))
	movlw	low(03Bh)
	movwf	(Dec@max)
	movf	(GetDelayFilterFlag@PtrMin),w
	fcall	_Dec
	xorlw	0
	skipnz
	goto	u8861
	goto	u8860
u8861:
	goto	l10121
u8860:
	line	416
	
l10113:	
;main.c: 415: {
;main.c: 416: if(Dec(&PtrMin->u8Minute,59))
	movlw	low(03Bh)
	movwf	(Dec@max)
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	01h
	fcall	_Dec
	xorlw	0
	skipnz
	goto	u8871
	goto	u8870
u8871:
	goto	l10121
u8870:
	line	418
	
l10115:	
;main.c: 417: {
;main.c: 418: if(Dec(&PtrMin->u8Hour,23))
	movlw	low(017h)
	movwf	(Dec@max)
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	02h
	fcall	_Dec
	xorlw	0
	skipnz
	goto	u8881
	goto	u8880
u8881:
	goto	l10121
u8880:
	line	420
	
l10117:	
;main.c: 419: {
;main.c: 420: if(DecF(&PtrMin->u16Day,65535))
	movlw	0FFh
	movwf	(DecF@max)
	movlw	0FFh
	movwf	((DecF@max))+1
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	03h
	fcall	_DecF
	xorlw	0
	skipnz
	goto	u8891
	goto	u8890
u8891:
	goto	l1040
u8890:
	goto	l1043
	line	425
	
l1040:	
	line	427
	
l10121:	
;main.c: 423: }
;main.c: 424: }
;main.c: 425: }
;main.c: 426: }
;main.c: 427: if(FilterFastCheck==1){
		decf	((_FilterFastCheck)),w
	btfss	status,2
	goto	u8901
	goto	u8900
u8901:
	goto	l1043
u8900:
	line	428
	
l10123:	
;main.c: 428: if(PtrMin->u16Day>=1)
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	03h
	movwf	fsr0
	movf	indf,w
	movwf	(??_GetDelayFilterFlag+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_GetDelayFilterFlag+0)+0+1
	movf	((??_GetDelayFilterFlag+0)+0),w
iorwf	((??_GetDelayFilterFlag+0)+1),w
	btfsc	status,2
	goto	u8911
	goto	u8910
u8911:
	goto	l10127
u8910:
	line	429
	
l10125:	
;main.c: 429: PtrMin->u16Day-=1;
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	03h
	movwf	fsr0
	movlw	low(01h)
	subwf	indf,f
	incfsz	fsr0,f
	movlw	high(01h)
	skipc
	decf	indf,f
	subwf	indf,f
	decf	fsr0,f
	goto	l1043
	line	431
	
l10127:	
;main.c: 430: else
;main.c: 431: PtrMin->u16Day=0;
	movf	(GetDelayFilterFlag@PtrMin),w
	addlw	03h
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	435
	
l1043:	
	return
	opt stack 0
GLOBAL	__end_of_GetDelayFilterFlag
	__end_of_GetDelayFilterFlag:
	signat	_GetDelayFilterFlag,4217
	global	_DecF

;; *************** function _DecF *****************
;; Defined at:
;;		line 395 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  var             1    wreg     PTR unsigned int 
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;;  max             2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;  var             1    2[BANK0 ] PTR unsigned int 
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       2       0       0
;;      Totals:         2       3       0       0
;;Total ram usage:        5 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_GetDelayFilterFlag
;; This function uses a non-reentrant model
;;
psect	text42,local,class=CODE,delta=2,merge=1,group=0
	line	395
global __ptext42
__ptext42:	;psect for function _DecF
psect	text42
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	395
	global	__size_of_DecF
	__size_of_DecF	equ	__end_of_DecF-_DecF
	
_DecF:	
;incstack = 0
	opt	stack 6
; Regs used in _DecF: [wreg-fsr0h+status,2+status,0]
;DecF@var stored from wreg
	movwf	(DecF@var)
	line	397
	
l9175:	
;main.c: 397: if((*var)){(*var)--;}
	movf	(DecF@var),w
	movwf	fsr0
	movf	indf,w
	movwf	(??_DecF+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_DecF+0)+0+1
	movf	((??_DecF+0)+0),w
iorwf	((??_DecF+0)+1),w
	btfsc	status,2
	goto	u7371
	goto	u7370
u7371:
	goto	l9179
u7370:
	
l9177:	
	movf	(DecF@var),w
	movwf	fsr0
	movlw	low(01h)
	subwf	indf,f
	incfsz	fsr0,f
	movlw	high(01h)
	skipc
	decf	indf,f
	subwf	indf,f
	decf	fsr0,f
	goto	l9183
	line	398
	
l9179:	
;main.c: 398: else{return(1);}
	movlw	low(01h)
	goto	l1033
	line	400
	
l9183:	
;main.c: 400: return(0);
	movlw	low(0)
	line	401
	
l1033:	
	return
	opt stack 0
GLOBAL	__end_of_DecF
	__end_of_DecF:
	signat	_DecF,8313
	global	_Dec

;; *************** function _Dec *****************
;; Defined at:
;;		line 387 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  var             1    wreg     PTR unsigned char 
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;;  max             1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  var             1    5[COMMON] PTR unsigned char 
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/800
;;		On exit  : B00/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_GetDelayFilterFlag
;; This function uses a non-reentrant model
;;
psect	text43,local,class=CODE,delta=2,merge=1,group=0
	line	387
global __ptext43
__ptext43:	;psect for function _Dec
psect	text43
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	387
	global	__size_of_Dec
	__size_of_Dec	equ	__end_of_Dec-_Dec
	
_Dec:	
;incstack = 0
	opt	stack 6
; Regs used in _Dec: [wreg-fsr0h+status,2+status,0]
;Dec@var stored from wreg
	movwf	(Dec@var)
	line	389
	
l9161:	
;main.c: 389: if((*var)){(*var)--;}
	movf	(Dec@var),w
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	(indf),w
	btfsc	status,2
	goto	u7361
	goto	u7360
u7361:
	goto	l9165
u7360:
	
l9163:	
	movf	(Dec@var),w
	movwf	fsr0
	decf	indf,f
	goto	l9171
	line	390
	
l9165:	
;main.c: 390: else{(*var)=max;return(1);}
	movf	(Dec@var),w
	movwf	fsr0
	movf	(Dec@max),w
	movwf	indf
	
l9167:	
	movlw	low(01h)
	goto	l1028
	line	392
	
l9171:	
;main.c: 392: return(0);
	movlw	low(0)
	line	393
	
l1028:	
	return
	opt stack 0
GLOBAL	__end_of_Dec
	__end_of_Dec:
	signat	_Dec,8313
	global	_FilterLifeFunc

;; *************** function _FilterLifeFunc *****************
;; Defined at:
;;		line 1227 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_BuzzerSet
;;		_FilterTimeHandle
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text44,local,class=CODE,delta=2,merge=1,group=0
	line	1227
global __ptext44
__ptext44:	;psect for function _FilterLifeFunc
psect	text44
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	1227
	global	__size_of_FilterLifeFunc
	__size_of_FilterLifeFunc	equ	__end_of_FilterLifeFunc-_FilterLifeFunc
	
_FilterLifeFunc:	
;incstack = 0
	opt	stack 4
; Regs used in _FilterLifeFunc: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1231
	
l10375:	
;main.c: 1231: if((Mode!=0)&&(Mode!=3)&&(_BITS.Bits.bit_0==0)){
	movf	((_Mode)),w
	btfsc	status,2
	goto	u9331
	goto	u9330
u9331:
	goto	l1204
u9330:
	
l10377:	
		movlw	3
	xorwf	((_Mode)),w
	btfsc	status,2
	goto	u9341
	goto	u9340
u9341:
	goto	l1204
u9340:
	
l10379:	
	btfsc	(__BITS),0
	goto	u9351
	goto	u9350
u9351:
	goto	l1204
u9350:
	line	1232
	
l10381:	
;main.c: 1232: FilterTimeHandle(FilterRO_time,&FilterROState,1,&FilterROGetWater);
	movlw	(FilterTimeHandle@Filter_time)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_FilterRO_time)^080h,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterRO_time)^080h+1,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterRO_time)^080h+2,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterRO_time)^080h+3,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterRO_time)^080h+4,w
	movwf	indf
	movlw	(low(_FilterROState|((0x0)<<8)))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	movwf	(FilterTimeHandle@FilterState)
	clrf	(FilterTimeHandle@Type)
	incf	(FilterTimeHandle@Type),f
	movlw	(low(_FilterROGetWater|((0x0)<<8)))&0ffh
	movwf	(FilterTimeHandle@FilterGetWater)
	fcall	_FilterTimeHandle
	line	1235
;main.c: 1235: FilterTimeHandle(FilterPCF_time,&FilterPCFState,0,&FilterPCFGetWater);
	movlw	(FilterTimeHandle@Filter_time)&0ffh
	movwf	fsr0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_FilterPCF_time)^080h,w
	bcf	status, 7	;select IRP bank0
	movwf	indf
	incf	fsr0,f
	movf	(_FilterPCF_time)^080h+1,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterPCF_time)^080h+2,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterPCF_time)^080h+3,w
	movwf	indf
	incf	fsr0,f
	movf	(_FilterPCF_time)^080h+4,w
	movwf	indf
	movlw	(low(_FilterPCFState|((0x0)<<8)))&0ffh
	bcf	status, 5	;RP0=0, select bank0
	movwf	(FilterTimeHandle@FilterState)
	clrf	(FilterTimeHandle@Type)
	movlw	(low(_FilterPCFGetWater|((0x0)<<8)))&0ffh
	movwf	(FilterTimeHandle@FilterGetWater)
	fcall	_FilterTimeHandle
	line	1236
	
l10383:	
;main.c: 1236: if(FilterFastCheck==1)
	bcf	status, 5	;RP0=0, select bank0
		decf	((_FilterFastCheck)),w
	btfss	status,2
	goto	u9361
	goto	u9360
u9361:
	goto	l1204
u9360:
	line	1238
	
l10385:	
;main.c: 1237: {
;main.c: 1238: if((FilterPCFState==3)&&(FilterROState==3)){
		movlw	3
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u9371
	goto	u9370
u9371:
	goto	l1204
u9370:
	
l10387:	
		movlw	3
	xorwf	((_FilterROState)),w
	btfss	status,2
	goto	u9381
	goto	u9380
u9381:
	goto	l1204
u9380:
	line	1239
	
l10389:	
;main.c: 1239: FilterFastCheck=2;
	movlw	low(02h)
	movwf	(_FilterFastCheck)
	line	1240
	
l10391:	
;main.c: 1240: BuzzerSet(3, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(03h)
	fcall	_BuzzerSet
	line	1247
	
l1204:	
	return
	opt stack 0
GLOBAL	__end_of_FilterLifeFunc
	__end_of_FilterLifeFunc:
	signat	_FilterLifeFunc,89
	global	_FilterTimeHandle

;; *************** function _FilterTimeHandle *****************
;; Defined at:
;;		line 1117 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Filter_time     5    3[BANK0 ] struct .
;;  FilterState     1    8[BANK0 ] PTR unsigned char 
;;		 -> FilterPCFState(1), FilterROState(1), 
;;  Type            1    9[BANK0 ] unsigned char 
;;  FilterGetWat    1   10[BANK0 ] PTR unsigned int 
;;		 -> FilterPCFGetWater(2), FilterROGetWater(2), 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : B00/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       8       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       4       0       0
;;      Totals:         0      12       0       0
;;Total ram usage:       12 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_LedSetSt
;; This function is called by:
;;		_FilterLifeFunc
;; This function uses a non-reentrant model
;;
psect	text45,local,class=CODE,delta=2,merge=1,group=0
	line	1117
global __ptext45
__ptext45:	;psect for function _FilterTimeHandle
psect	text45
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	1117
	global	__size_of_FilterTimeHandle
	__size_of_FilterTimeHandle	equ	__end_of_FilterTimeHandle-_FilterTimeHandle
	
_FilterTimeHandle:	
;incstack = 0
	opt	stack 4
; Regs used in _FilterTimeHandle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1120
	
l9243:	
;main.c: 1120: Date_Temp=14;
	movlw	0Eh
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Date_Temp)^080h
	clrf	(_Date_Temp+1)^080h
	line	1121
	
l9245:	
;main.c: 1121: if(_BITS.Bits.bit_1==1) return;
	btfss	(__BITS),1
	goto	u7471
	goto	u7470
u7471:
	goto	l9249
u7470:
	goto	l1168
	line	1122
	
l9249:	
;main.c: 1122: if(Type==0){
	bcf	status, 5	;RP0=0, select bank0
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7481
	goto	u7480
u7481:
	goto	l9253
u7480:
	line	1123
	
l9251:	
;main.c: 1123: ML_Temp=3650;
	movlw	042h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_ML_Temp)^080h
	movlw	0Eh
	movwf	((_ML_Temp)^080h)+1
	line	1124
;main.c: 1124: }
	goto	l9255
	line	1127
	
l9253:	
;main.c: 1125: else
;main.c: 1126: {
;main.c: 1127: ML_Temp=10950;
	movlw	0C6h
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_ML_Temp)^080h
	movlw	02Ah
	movwf	((_ML_Temp)^080h)+1
	line	1130
	
l9255:	
;main.c: 1128: }
;main.c: 1130: if(Filter_time.u16Day<=0){
	bcf	status, 5	;RP0=0, select bank0
	movf	(0+(FilterTimeHandle@Filter_time)+03h),w
iorwf	(1+(FilterTimeHandle@Filter_time)+03h),w
	btfss	status,2
	goto	u7491
	goto	u7490
u7491:
	goto	l9265
u7490:
	line	1132
	
l9257:	
;main.c: 1132: *FilterState=3;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(03h)
	movwf	indf
	line	1133
	
l9259:	
;main.c: 1133: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7501
	goto	u7500
u7501:
	goto	l9263
u7500:
	line	1134
	
l9261:	
;main.c: 1134: LedSetSt(4,1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(04h)
	fcall	_LedSetSt
	line	1135
;main.c: 1135: LedSetSt(5, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1136
;main.c: 1136: }
	goto	l1174
	line	1139
	
l9263:	
;main.c: 1137: else
;main.c: 1138: {
;main.c: 1139: LedSetSt(2, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(02h)
	fcall	_LedSetSt
	line	1140
;main.c: 1140: LedSetSt(3, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	goto	l1174
	line	1143
	
l9265:	
;main.c: 1143: else if(Filter_time.u16Day<=Date_Temp)
	movlw	0
	subwf	1+(FilterTimeHandle@Filter_time)+03h,w
	movlw	0Fh
	skipnz
	subwf	0+(FilterTimeHandle@Filter_time)+03h,w
	skipnc
	goto	u7511
	goto	u7510
u7511:
	goto	l9279
u7510:
	line	1145
	
l9267:	
;main.c: 1144: {
;main.c: 1145: if(*FilterState!=2){
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
		movlw	2
	xorwf	(indf),w
	btfsc	status,2
	goto	u7521
	goto	u7520
u7521:
	goto	l9275
u7520:
	line	1146
	
l9269:	
;main.c: 1146: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7531
	goto	u7530
u7531:
	goto	l9273
u7530:
	line	1147
	
l9271:	
;main.c: 1147: LedSetSt(4, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1148
;main.c: 1148: LedSetSt(5, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1149
;main.c: 1149: }
	goto	l9275
	line	1152
	
l9273:	
;main.c: 1150: else
;main.c: 1151: {
;main.c: 1152: LedSetSt(2, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1153
;main.c: 1153: LedSetSt(3, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1156
	
l9275:	
;main.c: 1154: }
;main.c: 1155: }
;main.c: 1156: if(*FilterState<=2)
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(03h)
	bcf	status, 7	;select IRP bank0
	subwf	indf,w
	skipnc
	goto	u7541
	goto	u7540
u7541:
	goto	l1174
u7540:
	line	1157
	
l9277:	
;main.c: 1157: *FilterState=2;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(02h)
	movwf	indf
	goto	l1174
	line	1161
	
l9279:	
;main.c: 1159: else
;main.c: 1160: {
;main.c: 1161: if(*FilterState==1){
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
		decf	(indf),w
	btfss	status,2
	goto	u7551
	goto	u7550
u7551:
	goto	l9287
u7550:
	line	1162
	
l9281:	
;main.c: 1162: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7561
	goto	u7560
u7561:
	goto	l9285
u7560:
	line	1163
	
l9283:	
;main.c: 1163: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1164
;main.c: 1164: LedSetSt(5, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(05h)
	fcall	_LedSetSt
	line	1165
;main.c: 1165: }
	goto	l9287
	line	1168
	
l9285:	
;main.c: 1166: else
;main.c: 1167: {
;main.c: 1168: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1169
;main.c: 1169: LedSetSt(3, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(03h)
	fcall	_LedSetSt
	line	1172
	
l9287:	
;main.c: 1170: }
;main.c: 1171: }
;main.c: 1172: if(*FilterState<=1)
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(02h)
	bcf	status, 7	;select IRP bank0
	subwf	indf,w
	skipnc
	goto	u7571
	goto	u7570
u7571:
	goto	l1174
u7570:
	line	1173
	
l9289:	
;main.c: 1173: *FilterState=1;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	1174
	
l1174:	
	line	1177
;main.c: 1174: }
;main.c: 1177: if(*FilterGetWater>=ML_Temp){
	movf	(FilterTimeHandle@FilterGetWater),w
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	movwf	(??_FilterTimeHandle+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_FilterTimeHandle+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(_ML_Temp+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	1+(??_FilterTimeHandle+0)+0,w
	skipz
	goto	u7585
	bsf	status, 5	;RP0=1, select bank1
	movf	(_ML_Temp)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	0+(??_FilterTimeHandle+0)+0,w
u7585:
	skipc
	goto	u7581
	goto	u7580
u7581:
	goto	l9299
u7580:
	line	1179
	
l9291:	
;main.c: 1179: *FilterState=3;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(03h)
	movwf	indf
	line	1180
	
l9293:	
;main.c: 1180: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7591
	goto	u7590
u7591:
	goto	l9297
u7590:
	line	1181
	
l9295:	
;main.c: 1181: LedSetSt(4, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(04h)
	fcall	_LedSetSt
	line	1182
;main.c: 1182: LedSetSt(5, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1183
;main.c: 1183: }
	goto	l1168
	line	1186
	
l9297:	
;main.c: 1184: else
;main.c: 1185: {
;main.c: 1186: LedSetSt(2, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(02h)
	fcall	_LedSetSt
	line	1187
;main.c: 1187: LedSetSt(3, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	goto	l1168
	line	1190
	
l9299:	
;main.c: 1190: else if(*FilterGetWater>=ML_Temp-140)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_ML_Temp)^080h,w
	addlw	low(0FF74h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_FilterTimeHandle+0)+0
	bsf	status, 5	;RP0=1, select bank1
	movf	(_ML_Temp+1)^080h,w
	skipnc
	addlw	1
	addlw	high(0FF74h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	1+(??_FilterTimeHandle+0)+0
	movf	(FilterTimeHandle@FilterGetWater),w
	movwf	fsr0
	movf	indf,w
	movwf	(??_FilterTimeHandle+2)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_FilterTimeHandle+2)+0+1
	movf	1+(??_FilterTimeHandle+0)+0,w
	subwf	1+(??_FilterTimeHandle+2)+0,w
	skipz
	goto	u7605
	movf	0+(??_FilterTimeHandle+0)+0,w
	subwf	0+(??_FilterTimeHandle+2)+0,w
u7605:
	skipc
	goto	u7601
	goto	u7600
u7601:
	goto	l9313
u7600:
	line	1193
	
l9301:	
;main.c: 1192: {
;main.c: 1193: if(*FilterState!=2){
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
		movlw	2
	xorwf	(indf),w
	btfsc	status,2
	goto	u7611
	goto	u7610
u7611:
	goto	l9309
u7610:
	line	1194
	
l9303:	
;main.c: 1194: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7621
	goto	u7620
u7621:
	goto	l9307
u7620:
	line	1195
	
l9305:	
;main.c: 1195: LedSetSt(4, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1196
;main.c: 1196: LedSetSt(5, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1197
;main.c: 1197: }
	goto	l9309
	line	1200
	
l9307:	
;main.c: 1198: else
;main.c: 1199: {
;main.c: 1200: LedSetSt(2, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1201
;main.c: 1201: LedSetSt(3, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1204
	
l9309:	
;main.c: 1202: }
;main.c: 1203: }
;main.c: 1204: if(*FilterState<=2)
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(03h)
	bcf	status, 7	;select IRP bank0
	subwf	indf,w
	skipnc
	goto	u7631
	goto	u7630
u7631:
	goto	l1168
u7630:
	line	1205
	
l9311:	
;main.c: 1205: *FilterState=2;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(02h)
	movwf	indf
	goto	l1168
	line	1209
	
l9313:	
;main.c: 1207: else
;main.c: 1208: {
;main.c: 1209: if(*FilterState==1){
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
		decf	(indf),w
	btfss	status,2
	goto	u7641
	goto	u7640
u7641:
	goto	l9321
u7640:
	line	1210
	
l9315:	
;main.c: 1210: if(Type==0){
	movf	((FilterTimeHandle@Type)),w
	btfss	status,2
	goto	u7651
	goto	u7650
u7651:
	goto	l9319
u7650:
	line	1211
	
l9317:	
;main.c: 1211: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1212
;main.c: 1212: LedSetSt(5, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(05h)
	fcall	_LedSetSt
	line	1213
;main.c: 1213: }
	goto	l9321
	line	1216
	
l9319:	
;main.c: 1214: else
;main.c: 1215: {
;main.c: 1216: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1217
;main.c: 1217: LedSetSt(3, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(03h)
	fcall	_LedSetSt
	line	1220
	
l9321:	
;main.c: 1218: }
;main.c: 1219: }
;main.c: 1220: if(*FilterState<=1)
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	movlw	low(02h)
	bcf	status, 7	;select IRP bank0
	subwf	indf,w
	skipnc
	goto	u7661
	goto	u7660
u7661:
	goto	l1168
u7660:
	line	1221
	
l9323:	
;main.c: 1221: *FilterState=1;
	movf	(FilterTimeHandle@FilterState),w
	movwf	fsr0
	clrf	indf
	incf	indf,f
	line	1224
	
l1168:	
	return
	opt stack 0
GLOBAL	__end_of_FilterTimeHandle
	__end_of_FilterTimeHandle:
	signat	_FilterTimeHandle,16505
	global	_FilterKeyInputRest

;; *************** function _FilterKeyInputRest *****************
;; Defined at:
;;		line 1588 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_BuzzerSet
;;		_LedSetSt
;;		_SetFilterDelayReset
;;		_ShiftMode_Handle
;;		_WrterEEP
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text46,local,class=CODE,delta=2,merge=1,group=0
	line	1588
global __ptext46
__ptext46:	;psect for function _FilterKeyInputRest
psect	text46
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	1588
	global	__size_of_FilterKeyInputRest
	__size_of_FilterKeyInputRest	equ	__end_of_FilterKeyInputRest-_FilterKeyInputRest
	
_FilterKeyInputRest:	
;incstack = 0
	opt	stack 4
; Regs used in _FilterKeyInputRest: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	1590
	
l10463:	
;main.c: 1589: static U16_T FilterSelect_10ms;
;main.c: 1590: if((Mode==0)||(Mode==3)) return;
	movf	((_Mode)),w
	btfsc	status,2
	goto	u9511
	goto	u9510
u9511:
	goto	l1301
u9510:
	
l10465:	
		movlw	3
	xorwf	((_Mode)),w
	btfss	status,2
	goto	u9521
	goto	u9520
u9521:
	goto	l10467
u9520:
	goto	l1301
	
l1300:	
	goto	l1301
	line	1592
	
l10467:	
;main.c: 1591: if((KeyPacket_y[1].KeyState==LongPressDown)
;main.c: 1592: &&(KeyPacket_y[2].KeyState==NotPress))
		movlw	2
	xorwf	(0+(_KeyPacket_y)+03h),w
	btfss	status,2
	goto	u9531
	goto	u9530
u9531:
	goto	l10521
u9530:
	
l10469:	
	movf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u9541
	goto	u9540
u9541:
	goto	l10521
u9540:
	line	1594
	
l10471:	
;main.c: 1593: {
;main.c: 1594: KeyPacket_y[1].KeyState=SuperPressDown;
	movlw	low(03h)
	movwf	0+(_KeyPacket_y)+03h
	line	1595
;main.c: 1595: if(Time_Power_1s<=10){
	movlw	low(0Bh)
	subwf	(_Time_Power_1s),w
	skipnc
	goto	u9551
	goto	u9550
u9551:
	goto	l10477
u9550:
	line	1596
	
l10473:	
;main.c: 1596: ShiftMode_Handle(5);
	movlw	low(05h)
	fcall	_ShiftMode_Handle
	line	1597
	
l10475:	
;main.c: 1597: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1598
;main.c: 1598: }
	goto	l10519
	line	1601
	
l10477:	
;main.c: 1599: else
;main.c: 1600: {
;main.c: 1601: _BITS.Bits.bit_1^=1;
	movlw	1<<1
	xorwf	(__BITS),f
	line	1602
	
l10479:	
;main.c: 1602: if(_BITS.Bits.bit_1==0){
	btfsc	(__BITS),1
	goto	u9561
	goto	u9560
u9561:
	goto	l1305
u9560:
	line	1603
	
l10481:	
;main.c: 1603: FilterSelect_10ms=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(FilterKeyInputRest@FilterSelect_10ms)^080h
	clrf	(FilterKeyInputRest@FilterSelect_10ms+1)^080h
	line	1604
	
l10483:	
;main.c: 1604: if(_BITS.Bits.bit_3==0)
	btfsc	(__BITS),3
	goto	u9571
	goto	u9570
u9571:
	goto	l10499
u9570:
	line	1606
	
l10485:	
;main.c: 1605: {
;main.c: 1606: PrePCFu16Day=FilterPCF_time.u16Day;
	movf	1+(_FilterPCF_time)^080h+03h,w
	movwf	(_PrePCFu16Day+1)^080h
	movf	0+(_FilterPCF_time)^080h+03h,w
	movwf	(_PrePCFu16Day)^080h
	line	1607
	
l10487:	
;main.c: 1607: SetFilterDelayReset(&FilterPCF_time, 365, 0, 0, 0);
	movlw	06Dh
	bcf	status, 5	;RP0=0, select bank0
	movwf	(SetFilterDelayReset@Day)
	movlw	01h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterPCF_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	1608
	
l10489:	
;main.c: 1608: FilterPCFGetWater=0;
	clrf	(_FilterPCFGetWater)
	clrf	(_FilterPCFGetWater+1)
	line	1609
	
l10491:	
;main.c: 1609: FilterPCFState=1;
	clrf	(_FilterPCFState)
	incf	(_FilterPCFState),f
	line	1610
	
l10493:	
;main.c: 1610: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1611
	
l10495:	
;main.c: 1611: LedSetSt(5, 2);
	movlw	low(02h)
	movwf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1612
	
l10497:	
;main.c: 1612: _BITS1.Bits.bit_3=1;
	bsf	(__BITS1),3
	line	1613
;main.c: 1613: }
	goto	l10513
	line	1616
	
l10499:	
;main.c: 1614: else
;main.c: 1615: {
;main.c: 1616: PreROu16Day=FilterRO_time.u16Day;
	movf	1+(_FilterRO_time)^080h+03h,w
	movwf	(_PreROu16Day+1)^080h
	movf	0+(_FilterRO_time)^080h+03h,w
	movwf	(_PreROu16Day)^080h
	line	1617
	
l10501:	
;main.c: 1617: SetFilterDelayReset(&FilterRO_time, 1095, 0, 0, 0);
	movlw	047h
	bcf	status, 5	;RP0=0, select bank0
	movwf	(SetFilterDelayReset@Day)
	movlw	04h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterRO_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	1618
	
l10503:	
;main.c: 1618: FilterROGetWater=0;
	clrf	(_FilterROGetWater)
	clrf	(_FilterROGetWater+1)
	line	1619
	
l10505:	
;main.c: 1619: FilterROState=1;
	clrf	(_FilterROState)
	incf	(_FilterROState),f
	line	1620
	
l10507:	
;main.c: 1620: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1621
	
l10509:	
;main.c: 1621: LedSetSt(3, 2);
	movlw	low(02h)
	movwf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1622
	
l10511:	
;main.c: 1622: _BITS1.Bits.bit_2=1;
	bsf	(__BITS1),2
	line	1624
	
l10513:	
;main.c: 1623: }
;main.c: 1624: _BITS1.Bits.bit_7=0;
	bcf	(__BITS1),7
	line	1625
	
l10515:	
;main.c: 1625: FilterRst_1s=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_FilterRst_1s)^080h
	clrf	(_FilterRst_1s+1)^080h
	line	1626
	
l10517:	
;main.c: 1626: WrterEEP();
	fcall	_WrterEEP
	line	1627
;main.c: 1627: }
	goto	l10519
	line	1628
	
l1305:	
	line	1630
;main.c: 1628: else
;main.c: 1629: {
;main.c: 1630: _BITS.Bits.bit_3=1;
	bsf	(__BITS),3
	line	1633
	
l10519:	
;main.c: 1631: }
;main.c: 1632: }
;main.c: 1633: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1635
	
l10521:	
;main.c: 1634: }
;main.c: 1635: if(_BITS.Bits.bit_1==1){
	btfss	(__BITS),1
	goto	u9581
	goto	u9580
u9581:
	goto	l10559
u9580:
	line	1636
	
l10523:	
;main.c: 1636: if(++FilterSelect_10ms>=1000){
	bsf	status, 5	;RP0=1, select bank1
	incf	(FilterKeyInputRest@FilterSelect_10ms)^080h,f
	skipnz
	incf	(FilterKeyInputRest@FilterSelect_10ms+1)^080h,f
	movlw	03h
	subwf	((FilterKeyInputRest@FilterSelect_10ms+1)^080h),w
	movlw	0E8h
	skipnz
	subwf	((FilterKeyInputRest@FilterSelect_10ms)^080h),w
	skipc
	goto	u9591
	goto	u9590
u9591:
	goto	l10533
u9590:
	line	1637
	
l10525:	
;main.c: 1637: FilterSelect_10ms=0;
	clrf	(FilterKeyInputRest@FilterSelect_10ms)^080h
	clrf	(FilterKeyInputRest@FilterSelect_10ms+1)^080h
	line	1638
	
l10527:	
;main.c: 1638: BuzzerSet(1, 50);
	movlw	032h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1639
	
l10529:	
;main.c: 1639: _BITS.Bits.bit_1=0;
	bcf	(__BITS),1
	goto	l1301
	line	1643
	
l10533:	
;main.c: 1642: }
;main.c: 1643: if(KeyPacket_y[1].KeyState==ShortRelease)
		movlw	6
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(0+(_KeyPacket_y)+03h),w
	btfss	status,2
	goto	u9601
	goto	u9600
u9601:
	goto	l10541
u9600:
	line	1646
	
l10535:	
;main.c: 1646: BuzzerSet(1, 50);
	movlw	032h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1647
	
l10537:	
;main.c: 1647: FilterSelect_10ms=0;
	clrf	(FilterKeyInputRest@FilterSelect_10ms)^080h
	clrf	(FilterKeyInputRest@FilterSelect_10ms+1)^080h
	line	1648
	
l10539:	
;main.c: 1648: _BITS.Bits.bit_3^=1;
	movlw	1<<3
	xorwf	(__BITS),f
	line	1651
	
l10541:	
;main.c: 1649: }
;main.c: 1651: if(_BITS.Bits.bit_3==0){
	btfsc	(__BITS),3
	goto	u9611
	goto	u9610
u9611:
	goto	l10551
u9610:
	line	1652
	
l10543:	
;main.c: 1652: LedSetSt(3,0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1653
;main.c: 1653: LedSetSt(2,0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1654
	
l10545:	
;main.c: 1654: if(FilterPCFState==1){
		decf	((_FilterPCFState)),w
	btfss	status,2
	goto	u9621
	goto	u9620
u9621:
	goto	l10549
u9620:
	line	1655
	
l10547:	
;main.c: 1655: LedSetSt(5, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1656
;main.c: 1656: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1657
;main.c: 1657: }
	goto	l10559
	line	1660
	
l10549:	
;main.c: 1658: else
;main.c: 1659: {
;main.c: 1660: LedSetSt(4, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1661
;main.c: 1661: LedSetSt(5, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	goto	l10559
	line	1666
	
l10551:	
;main.c: 1664: else
;main.c: 1665: {
;main.c: 1666: LedSetSt(5,0);
	clrf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1667
;main.c: 1667: LedSetSt(4,0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1668
	
l10553:	
;main.c: 1668: if(FilterROState==1){
		decf	((_FilterROState)),w
	btfss	status,2
	goto	u9631
	goto	u9630
u9631:
	goto	l10557
u9630:
	line	1669
	
l10555:	
;main.c: 1669: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1670
;main.c: 1670: LedSetSt(3, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1671
;main.c: 1671: }
	goto	l10559
	line	1674
	
l10557:	
;main.c: 1672: else
;main.c: 1673: {
;main.c: 1674: LedSetSt(3, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1675
;main.c: 1675: LedSetSt(2, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	1681
	
l10559:	
;main.c: 1676: }
;main.c: 1677: }
;main.c: 1678: }
;main.c: 1680: if((KeyPacket_y[2].KeyState==LongPressDown)
;main.c: 1681: &&(KeyPacket_y[1].KeyState==LongPressDown))
		movlw	2
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(0+(_KeyPacket_y)+06h),w
	btfss	status,2
	goto	u9641
	goto	u9640
u9641:
	goto	l1301
u9640:
	
l10561:	
		movlw	2
	xorwf	(0+(_KeyPacket_y)+03h),w
	btfss	status,2
	goto	u9651
	goto	u9650
u9651:
	goto	l1301
u9650:
	line	1683
	
l10563:	
;main.c: 1682: {
;main.c: 1683: KeyPacket_y[2].KeyState=SuperPressDown;
	movlw	low(03h)
	movwf	0+(_KeyPacket_y)+06h
	line	1684
;main.c: 1684: KeyPacket_y[1].KeyState=SuperPressDown;
	movlw	low(03h)
	movwf	0+(_KeyPacket_y)+03h
	line	1686
;main.c: 1686: if(Time_Power_1s<=10){
	movlw	low(0Bh)
	subwf	(_Time_Power_1s),w
	skipnc
	goto	u9661
	goto	u9660
u9661:
	goto	l10585
u9660:
	line	1687
	
l10565:	
;main.c: 1687: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1689
	
l10567:	
;main.c: 1689: ShiftMode_Handle(0);
	movlw	low(0)
	fcall	_ShiftMode_Handle
	line	1690
	
l10569:	
;main.c: 1690: PowerStep=3;
	movlw	low(03h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_PowerStep)
	line	1691
	
l10571:	
;main.c: 1691: SetFilterDelayReset(&FilterPCF_time, 365, 0, 0, 0);
	movlw	06Dh
	movwf	(SetFilterDelayReset@Day)
	movlw	01h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterPCF_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	1692
	
l10573:	
;main.c: 1692: SetFilterDelayReset(&FilterRO_time, 1095, 0, 0, 0);
	movlw	047h
	movwf	(SetFilterDelayReset@Day)
	movlw	04h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterRO_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	1693
	
l10575:	
;main.c: 1693: FilterROGetWater=0;
	clrf	(_FilterROGetWater)
	clrf	(_FilterROGetWater+1)
	line	1694
	
l10577:	
;main.c: 1694: FilterPCFGetWater=0;
	clrf	(_FilterPCFGetWater)
	clrf	(_FilterPCFGetWater+1)
	line	1695
	
l10579:	
;main.c: 1695: _BITS1.Bits.bit_7=0;
	bcf	(__BITS1),7
	line	1696
	
l10581:	
;main.c: 1696: Read_Word_Buff[11]=1;
	bsf	status, 5	;RP0=1, select bank1
	clrf	0+(_Read_Word_Buff)^080h+0Bh
	incf	0+(_Read_Word_Buff)^080h+0Bh,f
	line	1697
	
l10583:	
;main.c: 1697: WrterEEP();
	fcall	_WrterEEP
	line	1698
;main.c: 1698: }
	goto	l1301
	line	1702
	
l10585:	
;main.c: 1699: else
;main.c: 1700: {
;main.c: 1702: if((FilterRst_1s<300)&&((_BITS1.Bits.bit_3)||(_BITS1.Bits.bit_2))){
	movlw	01h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_FilterRst_1s+1)^080h,w
	movlw	02Ch
	skipnz
	subwf	(_FilterRst_1s)^080h,w
	skipnc
	goto	u9671
	goto	u9670
u9671:
	goto	l1321
u9670:
	
l10587:	
	bcf	status, 5	;RP0=0, select bank0
	btfsc	(__BITS1),3
	goto	u9681
	goto	u9680
u9681:
	goto	l1323
u9680:
	
l10589:	
	btfss	(__BITS1),2
	goto	u9691
	goto	u9690
u9691:
	goto	l1321
u9690:
	
l1323:	
	line	1703
;main.c: 1703: if(_BITS.Bits.bit_1==0){
	btfsc	(__BITS),1
	goto	u9701
	goto	u9700
u9701:
	goto	l1300
u9700:
	line	1705
	
l10591:	
;main.c: 1705: BuzzerSet(3, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(03h)
	fcall	_BuzzerSet
	line	1708
	
l10593:	
;main.c: 1708: if(_BITS1.Bits.bit_3){
	bcf	status, 5	;RP0=0, select bank0
	btfss	(__BITS1),3
	goto	u9711
	goto	u9710
u9711:
	goto	l10603
u9710:
	line	1709
	
l10595:	
;main.c: 1709: _BITS1.Bits.bit_3=0;
	bcf	(__BITS1),3
	line	1710
	
l10597:	
;main.c: 1710: FilterPCF_time.u16Day=PrePCFu16Day;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_PrePCFu16Day+1)^080h,w
	movwf	1+(_FilterPCF_time)^080h+03h
	movf	(_PrePCFu16Day)^080h,w
	movwf	0+(_FilterPCF_time)^080h+03h
	line	1711
	
l10599:	
;main.c: 1711: LedSetSt(5, 5);
	movlw	low(05h)
	movwf	(LedSetSt@Sta)
	movlw	low(05h)
	fcall	_LedSetSt
	line	1712
	
l10601:	
;main.c: 1712: LedSetSt(4, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	1714
	
l10603:	
;main.c: 1713: }
;main.c: 1714: if(_BITS1.Bits.bit_2){
	btfss	(__BITS1),2
	goto	u9721
	goto	u9720
u9721:
	goto	l10583
u9720:
	line	1715
	
l10605:	
;main.c: 1715: _BITS1.Bits.bit_2=0;
	bcf	(__BITS1),2
	line	1716
	
l10607:	
;main.c: 1716: FilterRO_time.u16Day=PreROu16Day;
	bsf	status, 5	;RP0=1, select bank1
	movf	(_PreROu16Day+1)^080h,w
	movwf	1+(_FilterRO_time)^080h+03h
	movf	(_PreROu16Day)^080h,w
	movwf	0+(_FilterRO_time)^080h+03h
	line	1717
	
l10609:	
;main.c: 1717: LedSetSt(3, 5);
	movlw	low(05h)
	movwf	(LedSetSt@Sta)
	movlw	low(03h)
	fcall	_LedSetSt
	line	1718
	
l10611:	
;main.c: 1718: LedSetSt(2, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	goto	l10583
	line	1723
	
l1321:	
	line	1725
;main.c: 1723: else
;main.c: 1724: {
;main.c: 1725: _BITS1.Bits.bit_3=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(__BITS1),3
	line	1726
;main.c: 1726: _BITS1.Bits.bit_2=0;
	bcf	(__BITS1),2
	line	1730
	
l1301:	
	return
	opt stack 0
GLOBAL	__end_of_FilterKeyInputRest
	__end_of_FilterKeyInputRest:
	signat	_FilterKeyInputRest,89
	global	_ErrorHandle

;; *************** function _ErrorHandle *****************
;; Defined at:
;;		line 2129 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    6
;; This function calls:
;;		_AllLedFlash
;;		_BuzzerSet
;;		_GetStop
;;		_LedSetSt
;;		_ShiftMode_Handle
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text47,local,class=CODE,delta=2,merge=1,group=0
	line	2129
global __ptext47
__ptext47:	;psect for function _ErrorHandle
psect	text47
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	2129
	global	__size_of_ErrorHandle
	__size_of_ErrorHandle	equ	__end_of_ErrorHandle-_ErrorHandle
	
_ErrorHandle:	
;incstack = 0
	opt	stack 4
; Regs used in _ErrorHandle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	2134
	
l10685:	
;main.c: 2134: if(Timer_LongGetWater_1s>=1800){
	movlw	07h
	bsf	status, 5	;RP0=1, select bank1
	subwf	(_Timer_LongGetWater_1s+1)^080h,w
	movlw	08h
	skipnz
	subwf	(_Timer_LongGetWater_1s)^080h,w
	skipc
	goto	u9851
	goto	u9850
u9851:
	goto	l10705
u9850:
	line	2137
	
l10687:	
;main.c: 2137: ShiftMode_Handle(3);
	movlw	low(03h)
	fcall	_ShiftMode_Handle
	line	2140
	
l10689:	
;main.c: 2140: if(ErrorVar==0x00){
	bcf	status, 5	;RP0=0, select bank0
	movf	((_ErrorVar)),w
	btfss	status,2
	goto	u9861
	goto	u9860
u9861:
	goto	l10701
u9860:
	line	2141
	
l10691:	
;main.c: 2141: Timer_ErrorLong_1s=0;
	clrf	(_Timer_ErrorLong_1s)
	line	2142
	
l10693:	
;main.c: 2142: AllLedFlash(0);
	movlw	low(0)
	fcall	_AllLedFlash
	line	2143
	
l10695:	
;main.c: 2143: LedSetSt(4, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(04h)
	fcall	_LedSetSt
	line	2144
	
l10697:	
;main.c: 2144: LedSetSt(2, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(02h)
	fcall	_LedSetSt
	line	2145
	
l10699:	
;main.c: 2145: LedSetSt(0, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(0)
	fcall	_LedSetSt
	line	2147
	
l10701:	
;main.c: 2146: }
;main.c: 2147: ErrorVar=0x02;
	movlw	low(02h)
	movwf	(_ErrorVar)
	line	2148
	
l10703:	
;main.c: 2148: GetStop();
	fcall	_GetStop
	line	2151
	
l10705:	
;main.c: 2149: }
;main.c: 2151: if((Timer_ErrorLong_1s<=30)&&(Mode==3)){
	movlw	low(01Fh)
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_Timer_ErrorLong_1s),w
	skipnc
	goto	u9871
	goto	u9870
u9871:
	goto	l1405
u9870:
	
l10707:	
		movlw	3
	xorwf	((_Mode)),w
	btfss	status,2
	goto	u9881
	goto	u9880
u9881:
	goto	l1405
u9880:
	line	2152
	
l10709:	
;main.c: 2152: Timer_ErrorLong_1s++;
	incf	(_Timer_ErrorLong_1s),f
	line	2153
	
l10711:	
;main.c: 2153: if(Timer_ErrorLong_1s%2==0){
	btfsc	(_Timer_ErrorLong_1s),(0)&7
	goto	u9891
	goto	u9890
u9891:
	goto	l1405
u9890:
	line	2154
	
l10713:	
;main.c: 2154: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	2160
	
l1405:	
	return
	opt stack 0
GLOBAL	__end_of_ErrorHandle
	__end_of_ErrorHandle:
	signat	_ErrorHandle,89
	global	_ShiftMode_Handle

;; *************** function _ShiftMode_Handle *****************
;; Defined at:
;;		line 1262 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Mod             1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  Mod             1    3[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       1       0       0
;;Total ram usage:        1 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_BuzzerSet
;;		_LedSetSt
;;		_SetStandbyState
;; This function is called by:
;;		_GetMode_Handle
;;		_FilterKeyInputRest
;;		_StandbyMode_Handle
;;		_Run_Mode
;;		_ErrorHandle
;; This function uses a non-reentrant model
;;
psect	text48,local,class=CODE,delta=2,merge=1,group=0
	line	1262
global __ptext48
__ptext48:	;psect for function _ShiftMode_Handle
psect	text48
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	1262
	global	__size_of_ShiftMode_Handle
	__size_of_ShiftMode_Handle	equ	__end_of_ShiftMode_Handle-_ShiftMode_Handle
	
_ShiftMode_Handle:	
;incstack = 0
	opt	stack 4
; Regs used in _ShiftMode_Handle: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;ShiftMode_Handle@Mod stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(ShiftMode_Handle@Mod)
	line	1264
	
l9327:	
;main.c: 1264: Mode=Mod;
	movf	(ShiftMode_Handle@Mod),w
	movwf	(_Mode)
	line	1265
	
l9329:	
;main.c: 1265: RA1=0;
	bcf	(41/8),(41)&7	;volatile
	line	1266
	
l9331:	
;main.c: 1266: RC2=0;
	bcf	(58/8),(58)&7	;volatile
	line	1267
;main.c: 1267: switch(Mod){
	goto	l9355
	line	1269
;main.c: 1269: case 2:
	
l1211:	
	line	1270
;main.c: 1270: RC3=0;
	bcf	(59/8),(59)&7	;volatile
	line	1271
;main.c: 1271: {RA2=0;_BITS2.Bits.bit_1=0;};
	bcf	(42/8),(42)&7	;volatile
	bcf	(__BITS2),1
	line	1274
;main.c: 1274: _BITS.Bits.bit_5=0x00;
	bcf	(__BITS),5
	line	1275
	
l9333:	
;main.c: 1275: LedSetSt(1, 0);
	clrf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1276
	
l9335:	
;main.c: 1276: if(StandByStatus==WashState){
		decf	((_StandByStatus)),w
	btfss	status,2
	goto	u7671
	goto	u7670
u7671:
	goto	l1222
u7670:
	line	1277
	
l9337:	
;main.c: 1277: LedSetSt(1, 3);
	movlw	low(03h)
	movwf	(LedSetSt@Sta)
	movlw	low(01h)
	fcall	_LedSetSt
	line	1278
;main.c: 1278: SetStandbyState(WashState,&WashRunTime, WashRunTime-Timer_WashRun_1s);
	movlw	(low(_WashRunTime|((0x0)<<8)))&0ffh
	movwf	(SetStandbyState@Time)
	bsf	status, 5	;RP0=1, select bank1
	movf	(_Timer_WashRun_1s)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	subwf	(_WashRunTime),w
	movwf	(SetStandbyState@Da)
	movlw	low(01h)
	fcall	_SetStandbyState
	goto	l1222
	line	1281
;main.c: 1281: case 4:
	
l1214:	
	line	1282
;main.c: 1282: _BITS.Bits.bit_5=0x01;
	bsf	(__BITS),5
	line	1285
;main.c: 1285: RC3=1;
	bsf	(59/8),(59)&7	;volatile
	line	1286
;main.c: 1286: {RA2=1;_BITS2.Bits.bit_1=1;};
	bsf	(42/8),(42)&7	;volatile
	bsf	(__BITS2),1
	line	1287
	
l9339:	
;main.c: 1287: LedSetSt(1, 1);
	clrf	(LedSetSt@Sta)
	incf	(LedSetSt@Sta),f
	movlw	low(01h)
	fcall	_LedSetSt
	line	1288
	
l9341:	
;main.c: 1288: if((FilterROState==3)||(FilterPCFState==3)){
		movlw	3
	xorwf	((_FilterROState)),w
	btfsc	status,2
	goto	u7681
	goto	u7680
u7681:
	goto	l9345
u7680:
	
l9343:	
		movlw	3
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u7691
	goto	u7690
u7691:
	goto	l9347
u7690:
	line	1289
	
l9345:	
;main.c: 1289: BuzzerSet(1, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	1290
;main.c: 1290: }
	goto	l1222
	line	1291
	
l9347:	
;main.c: 1291: else if((FilterROState==2)||(FilterPCFState==2)){
		movlw	2
	xorwf	((_FilterROState)),w
	btfsc	status,2
	goto	u7701
	goto	u7700
u7701:
	goto	l9351
u7700:
	
l9349:	
		movlw	2
	xorwf	((_FilterPCFState)),w
	btfss	status,2
	goto	u7711
	goto	u7710
u7711:
	goto	l1222
u7710:
	line	1292
	
l9351:	
;main.c: 1292: BuzzerSet(1, 1200);
	movlw	0B0h
	movwf	(BuzzerSet@filter)
	movlw	04h
	movwf	((BuzzerSet@filter))+1
	movlw	low(01h)
	fcall	_BuzzerSet
	goto	l1222
	line	1267
	
l9355:	
	movf	(ShiftMode_Handle@Mod),w
	; Switch size 1, requested type "space"
; Number of cases is 2, Range of values is 2 to 4
; switch strategies available:
; Name         Instructions Cycles
; simple_byte            7     4 (average)
; direct_byte           20    11 (fixed)
; jumptable            263     9 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	2^0	; case 2
	skipnz
	goto	l1211
	xorlw	4^2	; case 4
	skipnz
	goto	l1214
	goto	l1222
	opt asmopt_pop

	line	1299
	
l1222:	
	return
	opt stack 0
GLOBAL	__end_of_ShiftMode_Handle
	__end_of_ShiftMode_Handle:
	signat	_ShiftMode_Handle,4217
	global	_SetStandbyState

;; *************** function _SetStandbyState *****************
;; Defined at:
;;		line 1363 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  STY             1    wreg     enum E897
;;  Time            1    4[COMMON] PTR unsigned char 
;;		 -> WashRunTime(1), 
;;  Da              1    5[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  STY             1    0[BANK0 ] enum E897
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : B00/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       1       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_Count_Func
;;		_ShiftMode_Handle
;;		_WashHandle
;;		_StatusFun_Handle
;;		_StandbyMode_Handle
;;		_Run_Mode
;; This function uses a non-reentrant model
;;
psect	text49,local,class=CODE,delta=2,merge=1,group=0
	line	1363
global __ptext49
__ptext49:	;psect for function _SetStandbyState
psect	text49
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	1363
	global	__size_of_SetStandbyState
	__size_of_SetStandbyState	equ	__end_of_SetStandbyState-_SetStandbyState
	
_SetStandbyState:	
;incstack = 0
	opt	stack 7
; Regs used in _SetStandbyState: [wreg-fsr0h+status,2+status,0]
;SetStandbyState@STY stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(SetStandbyState@STY)
	line	1364
	
l8921:	
;main.c: 1364: *Time=Da;
	movf	(SetStandbyState@Time),w
	movwf	fsr0
	movf	(SetStandbyState@Da),w
	bcf	status, 7	;select IRP bank0
	movwf	indf
	line	1365
	
l8923:	
;main.c: 1365: StandByStatus=STY;
	movf	(SetStandbyState@STY),w
	movwf	(_StandByStatus)
	line	1371
	
l8925:	
;main.c: 1371: if(STY==WashState){
		decf	((SetStandbyState@STY)),w
	btfss	status,2
	goto	u7111
	goto	u7110
u7111:
	goto	l8929
u7110:
	line	1373
	
l8927:	
;main.c: 1373: {RA2=1;_BITS2.Bits.bit_1=1;};
	bsf	(42/8),(42)&7	;volatile
	bsf	(__BITS2),1
	line	1374
;main.c: 1374: RC3=1;
	bsf	(59/8),(59)&7	;volatile
	line	1375
;main.c: 1375: RC2=1;
	bsf	(58/8),(58)&7	;volatile
	line	1377
;main.c: 1377: }
	goto	l8933
	line	1378
	
l8929:	
;main.c: 1378: else if(STY==BackState){
		movlw	3
	xorwf	((SetStandbyState@STY)),w
	btfss	status,2
	goto	u7121
	goto	u7120
u7121:
	goto	l1237
u7120:
	line	1380
	
l8931:	
;main.c: 1380: {RA2=1;_BITS2.Bits.bit_1=1;};
	bsf	(42/8),(42)&7	;volatile
	bsf	(__BITS2),1
	line	1381
;main.c: 1381: RC3=1;
	bsf	(59/8),(59)&7	;volatile
	line	1382
;main.c: 1382: RA1=1;
	bsf	(41/8),(41)&7	;volatile
	line	1384
;main.c: 1384: }
	goto	l8933
	line	1385
	
l1237:	
	line	1387
;main.c: 1385: else
;main.c: 1386: {
;main.c: 1387: RC2=0;
	bcf	(58/8),(58)&7	;volatile
	line	1388
;main.c: 1388: {RA2=0;_BITS2.Bits.bit_1=0;};
	bcf	(42/8),(42)&7	;volatile
	bcf	(__BITS2),1
	line	1389
;main.c: 1389: RC3=0;
	bcf	(59/8),(59)&7	;volatile
	line	1390
;main.c: 1390: RA1=0;
	bcf	(41/8),(41)&7	;volatile
	line	1395
	
l8933:	
;main.c: 1394: }
;main.c: 1395: Timer_WashRun_1s=0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(_Timer_WashRun_1s)^080h
	clrf	(_Timer_WashRun_1s+1)^080h
	line	1398
	
l1239:	
	return
	opt stack 0
GLOBAL	__end_of_SetStandbyState
	__end_of_SetStandbyState:
	signat	_SetStandbyState,12409
	global	_GetStop

;; *************** function _GetStop *****************
;; Defined at:
;;		line 1257 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		None
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 300/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ErrorHandle
;; This function uses a non-reentrant model
;;
psect	text50,local,class=CODE,delta=2,merge=1,group=0
	line	1257
global __ptext50
__ptext50:	;psect for function _GetStop
psect	text50
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	1257
	global	__size_of_GetStop
	__size_of_GetStop	equ	__end_of_GetStop-_GetStop
	
_GetStop:	
;incstack = 0
	opt	stack 6
; Regs used in _GetStop: []
	line	1258
	
l9325:	
;main.c: 1258: _BITS.Bits.bit_5=0x00;
	bcf	(__BITS),5
	line	1260
	
l1207:	
	return
	opt stack 0
GLOBAL	__end_of_GetStop
	__end_of_GetStop:
	signat	_GetStop,89
	global	_AllLedFlash

;; *************** function _AllLedFlash *****************
;; Defined at:
;;		line 807 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Type            1    wreg     unsigned char 
;; Auto vars:     Size  Location     Type
;;  Type            1    3[BANK0 ] unsigned char 
;;  i               2    4[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       3       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       3       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_LedSetSt
;; This function is called by:
;;		_FactoryMode_Handle
;;		_Run_Mode
;;		_ErrorHandle
;; This function uses a non-reentrant model
;;
psect	text51,local,class=CODE,delta=2,merge=1,group=0
	line	807
global __ptext51
__ptext51:	;psect for function _AllLedFlash
psect	text51
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	807
	global	__size_of_AllLedFlash
	__size_of_AllLedFlash	equ	__end_of_AllLedFlash-_AllLedFlash
	
_AllLedFlash:	
;incstack = 0
	opt	stack 4
; Regs used in _AllLedFlash: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;AllLedFlash@Type stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(AllLedFlash@Type)
	line	809
	
l9193:	
;main.c: 808: unsigned int i;
;main.c: 809: for(i=0;i<6;i++){
	clrf	(AllLedFlash@i)
	clrf	(AllLedFlash@i+1)
	line	810
	
l9199:	
;main.c: 810: LedSetSt(i, Type);
	movf	(AllLedFlash@Type),w
	movwf	(LedSetSt@Sta)
	movf	(AllLedFlash@i),w
	fcall	_LedSetSt
	line	809
	
l9201:	
	incf	(AllLedFlash@i),f
	skipnz
	incf	(AllLedFlash@i+1),f
	
l9203:	
	movlw	0
	subwf	(AllLedFlash@i+1),w
	movlw	06h
	skipnz
	subwf	(AllLedFlash@i),w
	skipc
	goto	u7381
	goto	u7380
u7381:
	goto	l9199
u7380:
	line	812
	
l1096:	
	return
	opt stack 0
GLOBAL	__end_of_AllLedFlash
	__end_of_AllLedFlash:
	signat	_AllLedFlash,4217
	global	_LedSetSt

;; *************** function _LedSetSt *****************
;; Defined at:
;;		line 842 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Num             1    wreg     unsigned char 
;;  Sta             1    5[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  Num             1    2[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/800
;;		On exit  : B00/800
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       1       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		___bmul
;; This function is called by:
;;		_AllLedFlash
;;		_FilterTimeHandle
;;		_ShiftMode_Handle
;;		_WashHandle
;;		_FactoryMode_Handle
;;		_FilterKeyInputRest
;;		_StandbyMode_Handle
;;		_Run_Mode
;;		_ErrorHandle
;; This function uses a non-reentrant model
;;
psect	text52,local,class=CODE,delta=2,merge=1,group=0
	line	842
global __ptext52
__ptext52:	;psect for function _LedSetSt
psect	text52
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	842
	global	__size_of_LedSetSt
	__size_of_LedSetSt	equ	__end_of_LedSetSt-_LedSetSt
	
_LedSetSt:	
;incstack = 0
	opt	stack 4
; Regs used in _LedSetSt: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;LedSetSt@Num stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(LedSetSt@Num)
	line	844
	
l8935:	
;main.c: 844: if(LedMod[Num].LedState!=Sta){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	movf	indf,w
	xorwf	(LedSetSt@Sta),w
	skipnz
	goto	u7131
	goto	u7130
u7131:
	goto	l1103
u7130:
	line	845
	
l8937:	
;main.c: 845: LedMod[Num].LedState=Sta;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(LedSetSt@Sta),w
	bsf	status, 7	;select IRP bank2
	movwf	indf
	line	846
;main.c: 846: if(LedMod[Num].LedState==2){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
		movlw	2
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfss	status,2
	goto	u7141
	goto	u7140
u7141:
	goto	l8943
u7140:
	line	847
	
l8939:	
;main.c: 847: LedMod[Num].LedFlashNum=2;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	movlw	02h
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movlw	0
	movwf	indf
	line	848
	
l8941:	
;main.c: 848: _BITS.Bits.bit_0=1;
	bsf	(__BITS),0
	line	849
;main.c: 849: }
	goto	l1101
	line	850
	
l8943:	
;main.c: 850: else if(LedMod[Num].LedState==5){
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8))&0ffh
	movwf	fsr0
		movlw	5
	bsf	status, 7	;select IRP bank2
	xorwf	(indf),w
	btfss	status,2
	goto	u7151
	goto	u7150
u7151:
	goto	l1101
u7150:
	line	851
	
l8945:	
;main.c: 851: LedMod[Num].LedFlashNum=3;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+03h)&0ffh
	movwf	fsr0
	movlw	03h
	bsf	status, 7	;select IRP bank2
	movwf	indf
	incf	fsr0,f
	movlw	0
	movwf	indf
	goto	l8941
	line	854
	
l1101:	
;main.c: 853: }
;main.c: 854: LedMod[Num].LedTime=0;
	movlw	low(05h)
	movwf	(___bmul@multiplicand)
	movf	(LedSetSt@Num),w
	fcall	___bmul
	addlw	low(_LedMod|((0x1)<<8)+01h)&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank2
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	856
	
l1103:	
	return
	opt stack 0
GLOBAL	__end_of_LedSetSt
	__end_of_LedSetSt:
	signat	_LedSetSt,8313
	global	___bmul

;; *************** function ___bmul *****************
;; Defined at:
;;		line 4 in file "E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul8.c"
;; Parameters:    Size  Location     Type
;;  multiplier      1    wreg     unsigned char 
;;  multiplicand    1    4[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  multiplier      1    1[BANK0 ] unsigned char 
;;  product         1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      unsigned char 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         1       0       0       0
;;      Locals:         0       2       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       2       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_LedSetSt
;;		_Led_Handle
;; This function uses a non-reentrant model
;;
psect	text53,local,class=CODE,delta=2,merge=1,group=2
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul8.c"
	line	4
global __ptext53
__ptext53:	;psect for function ___bmul
psect	text53
	file	"E:\MCU\CMS\738b\CMS_IDE_V2.03.27_Beta18\data\sources\common\Umul8.c"
	line	4
	global	__size_of___bmul
	__size_of___bmul	equ	__end_of___bmul-___bmul
	
___bmul:	
;incstack = 0
	opt	stack 6
; Regs used in ___bmul: [wreg+status,2+status,0]
;___bmul@multiplier stored from wreg
	movwf	(___bmul@multiplier)
	line	6
	
l8905:	
	clrf	(___bmul@product)
	line	43
	
l8907:	
	btfss	(___bmul@multiplier),(0)&7
	goto	u7091
	goto	u7090
u7091:
	goto	l8911
u7090:
	line	44
	
l8909:	
	movf	(___bmul@multiplicand),w
	addwf	(___bmul@product),f
	line	45
	
l8911:	
	clrc
	rlf	(___bmul@multiplicand),f
	line	46
	
l8913:	
	clrc
	rrf	(___bmul@multiplier),f
	line	47
	movf	((___bmul@multiplier)),w
	btfss	status,2
	goto	u7101
	goto	u7100
u7101:
	goto	l8907
u7100:
	line	50
	
l8915:	
	movf	(___bmul@product),w
	line	51
	
l3691:	
	return
	opt stack 0
GLOBAL	__end_of___bmul
	__end_of___bmul:
	signat	___bmul,8313
	global	_CheckKey

;; *************** function _CheckKey *****************
;; Defined at:
;;		line 2038 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               2    7[BANK0 ] unsigned int 
;;  St              1    6[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       3       0       0
;;      Temps:          0       1       0       0
;;      Totals:         0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_KeyScan
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text54,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	2038
global __ptext54
__ptext54:	;psect for function _CheckKey
psect	text54
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	2038
	global	__size_of_CheckKey
	__size_of_CheckKey	equ	__end_of_CheckKey-_CheckKey
	
_CheckKey:	
;incstack = 0
	opt	stack 5
; Regs used in _CheckKey: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	2040
	
l10337:	
	line	2046
	
l10339:	
;main.c: 2041: static U8_T temp;
;main.c: 2044: static unsigned int KeyOldFlag = 0;
;main.c: 2046: unsigned int i = (unsigned int)((g_KeyFlag[1]<<8) | g_KeyFlag[0]);
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	0+(_g_KeyFlag)+01h,w	;volatile
	movwf	(CheckKey@i+1)
	movf	(_g_KeyFlag),w	;volatile
	movwf	(CheckKey@i)
	line	2048
	
l10341:	
;main.c: 2048: if(i)
	movf	((CheckKey@i)),w
iorwf	((CheckKey@i+1)),w
	btfsc	status,2
	goto	u9261
	goto	u9260
u9261:
	goto	l10353
u9260:
	line	2050
	
l10343:	
;main.c: 2049: {
;main.c: 2050: if(i != KeyOldFlag)
	bsf	status, 5	;RP0=1, select bank1
	movf	(CheckKey@KeyOldFlag+1)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(CheckKey@i+1),w
	skipz
	goto	u9275
	bsf	status, 5	;RP0=1, select bank1
	movf	(CheckKey@KeyOldFlag)^080h,w
	bcf	status, 5	;RP0=0, select bank0
	xorwf	(CheckKey@i),w
u9275:

	skipnz
	goto	u9271
	goto	u9270
u9271:
	goto	l10357
u9270:
	line	2052
	
l10345:	
;main.c: 2051: {
;main.c: 2052: KeyOldFlag = i;
	movf	(CheckKey@i+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(CheckKey@KeyOldFlag+1)^080h
	bcf	status, 5	;RP0=0, select bank0
	movf	(CheckKey@i),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(CheckKey@KeyOldFlag)^080h
	line	2054
	
l10347:	
;main.c: 2054: if(0x01 & i){temp |= 0x02;}
	bcf	status, 5	;RP0=0, select bank0
	btfss	(CheckKey@i),(0)&7
	goto	u9281
	goto	u9280
u9281:
	goto	l1391
u9280:
	
l10349:	
	bsf	(CheckKey@temp)+(1/8),(1)&7
	
l1391:	
	line	2055
;main.c: 2055: if(0x02 & i){temp |= 0x04;}
	btfss	(CheckKey@i),(1)&7
	goto	u9291
	goto	u9290
u9291:
	goto	l10357
u9290:
	
l10351:	
	bsf	(CheckKey@temp)+(2/8),(2)&7
	goto	l10357
	line	2060
	
l10353:	
;main.c: 2058: else
;main.c: 2059: {
;main.c: 2060: KeyOldFlag = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(CheckKey@KeyOldFlag)^080h
	clrf	(CheckKey@KeyOldFlag+1)^080h
	line	2062
	
l10355:	
;main.c: 2062: temp&=0x01;
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	andwf	(CheckKey@temp),f
	line	2106
	
l10357:	
;main.c: 2063: }
;main.c: 2106: if(RC1==0){
	btfsc	(57/8),(57)&7	;volatile
	goto	u9301
	goto	u9300
u9301:
	goto	l1394
u9300:
	line	2109
	
l10359:	
;main.c: 2109: temp |= 0x01;
	bsf	(CheckKey@temp)+(0/8),(0)&7
	line	2111
;main.c: 2111: }
	goto	l10361
	line	2112
	
l1394:	
	line	2116
;main.c: 2112: else
;main.c: 2113: {
;main.c: 2116: temp &= ~(0x01);
	bcf	(CheckKey@temp)+(0/8),(0)&7
	line	2121
	
l10361:	
;main.c: 2118: }
;main.c: 2121: for(i=0;i<3;i++){
	clrf	(CheckKey@i)
	clrf	(CheckKey@i+1)
	line	2122
	
l10367:	
;main.c: 2122: St=(U8_T)(temp>>i);
	movf	(CheckKey@temp),w
	movwf	(??_CheckKey+0)+0
	incf	(CheckKey@i),w
	goto	u9314
u9315:
	clrc
	rrf	(??_CheckKey+0)+0,f
u9314:
	addlw	-1
	skipz
	goto	u9315
	movf	0+(??_CheckKey+0)+0,w
	movwf	(CheckKey@St)
	line	2123
;main.c: 2123: St&=0x01;
	movlw	low(01h)
	andwf	(CheckKey@St),f
	line	2124
	
l10369:	
;main.c: 2124: KeyScan(St,i);
	movf	(CheckKey@i),w
	movwf	(KeyScan@num)
	movf	(CheckKey@St),w
	fcall	_KeyScan
	line	2121
	
l10371:	
	incf	(CheckKey@i),f
	skipnz
	incf	(CheckKey@i+1),f
	
l10373:	
	movlw	0
	subwf	(CheckKey@i+1),w
	movlw	03h
	skipnz
	subwf	(CheckKey@i),w
	skipc
	goto	u9321
	goto	u9320
u9321:
	goto	l10367
u9320:
	line	2126
	
l1398:	
	return
	opt stack 0
GLOBAL	__end_of_CheckKey
	__end_of_CheckKey:
	signat	_CheckKey,89
	global	_KeyScan

;; *************** function _KeyScan *****************
;; Defined at:
;;		line 8 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\KeyFunc.c"
;; Parameters:    Size  Location     Type
;;  sw_port         1    wreg     unsigned char 
;;  num             1    1[BANK0 ] unsigned char 
;; Auto vars:     Size  Location     Type
;;  sw_port         1    4[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       1       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       2       0       0
;;      Totals:         0       4       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_BuzzerSet
;; This function is called by:
;;		_CheckKey
;; This function uses a non-reentrant model
;;
psect	text55,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\KeyFunc.c"
	line	8
global __ptext55
__ptext55:	;psect for function _KeyScan
psect	text55
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\KeyFunc.c"
	line	8
	global	__size_of_KeyScan
	__size_of_KeyScan	equ	__end_of_KeyScan-_KeyScan
	
_KeyScan:	
;incstack = 0
	opt	stack 5
; Regs used in _KeyScan: [wreg-fsr0h+status,2+status,0+pclath+cstack]
;KeyScan@sw_port stored from wreg
	movwf	(KeyScan@sw_port)
	line	10
	
l9399:	
;KeyFunc.c: 10: if(sw_port)
	movf	((KeyScan@sw_port)),w
	btfsc	status,2
	goto	u7751
	goto	u7750
u7751:
	goto	l9473
u7750:
	goto	l9435
	line	16
	
l9403:	
;KeyFunc.c: 16: if(KeyPacket_y[num].KeyTime<2200){KeyPacket_y[num].KeyTime++;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	098h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipnc
	goto	u7761
	goto	u7760
u7761:
	goto	l2391
u7760:
	
l9405:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	
l2391:	
	line	17
;KeyFunc.c: 17: if(KeyPacket_y[num].KeyTime>=3){KeyPacket_y[num].KeyState=ShortPressDown;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	0
	subwf	1+(??_KeyScan+0)+0,w
	movlw	03h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipc
	goto	u7771
	goto	u7770
u7771:
	goto	l2413
u7770:
	
l9407:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	incf	indf,f
	goto	l2413
	line	22
	
l9409:	
;KeyFunc.c: 22: if(KeyPacket_y[num].KeyTime<2200){KeyPacket_y[num].KeyTime++;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	098h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipnc
	goto	u7781
	goto	u7780
u7781:
	goto	l2395
u7780:
	
l9411:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	
l2395:	
	line	23
;KeyFunc.c: 23: if(KeyPacket_y[num].KeyTime>=300) {KeyPacket_y[num].KeyState=LongPressDown;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	01h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	02Ch
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipc
	goto	u7791
	goto	u7790
u7791:
	goto	l2413
u7790:
	
l9413:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(02h)
	movwf	indf
	goto	l2413
	line	28
	
l9415:	
;KeyFunc.c: 28: if(KeyPacket_y[num].KeyTime<2200){KeyPacket_y[num].KeyTime++;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	098h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipnc
	goto	u7801
	goto	u7800
u7801:
	goto	l2398
u7800:
	
l9417:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	
l2398:	
	line	29
;KeyFunc.c: 29: if(KeyPacket_y[num].KeyTime>=1000) {KeyPacket_y[num].KeyState=SuperPressDown;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	03h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	0E8h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipc
	goto	u7811
	goto	u7810
u7811:
	goto	l2413
u7810:
	
l9419:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(03h)
	movwf	indf
	goto	l2413
	line	32
	
l9421:	
;KeyFunc.c: 32: if(KeyPacket_y[num].KeyTime<2200){KeyPacket_y[num].KeyTime++;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	098h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipnc
	goto	u7821
	goto	u7820
u7821:
	goto	l2401
u7820:
	
l9423:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	
l2401:	
	line	33
;KeyFunc.c: 33: if(KeyPacket_y[num].KeyTime>=2100) {KeyPacket_y[num].KeyState=SuperLongPressDown;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	034h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipc
	goto	u7831
	goto	u7830
u7831:
	goto	l2413
u7830:
	
l9425:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(04h)
	movwf	indf
	goto	l2413
	line	36
	
l9427:	
;KeyFunc.c: 36: if(KeyPacket_y[num].KeyTime<2200){KeyPacket_y[num].KeyTime++;}
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movf	indf,w
	movwf	(??_KeyScan+0)+0+0
	incf	fsr0,f
	movf	indf,w
	movwf	(??_KeyScan+0)+0+1
	movlw	08h
	subwf	1+(??_KeyScan+0)+0,w
	movlw	098h
	skipnz
	subwf	0+(??_KeyScan+0)+0,w
	skipnc
	goto	u7841
	goto	u7840
u7841:
	goto	l2413
u7840:
	
l9429:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	movlw	01h
	addwf	indf,f
	incf	fsr0,f
	skipnc
	incf	indf,f
	goto	l2413
	line	44
	
l9431:	
;KeyFunc.c: 44: KeyPacket_y[num].KeyTime=0;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	45
;KeyFunc.c: 45: KeyPacket_y[num].KeyState=NotPress;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	clrf	indf
	line	46
;KeyFunc.c: 46: break;
	goto	l2413
	line	13
	
l9435:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	; Switch size 1, requested type "space"
; Number of cases is 5, Range of values is 0 to 4
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           16     9 (average)
; direct_byte           23     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l9403
	xorlw	1^0	; case 1
	skipnz
	goto	l9409
	xorlw	2^1	; case 2
	skipnz
	goto	l9415
	xorlw	3^2	; case 3
	skipnz
	goto	l9421
	xorlw	4^3	; case 4
	skipnz
	goto	l9427
	goto	l9431
	opt asmopt_pop

	line	55
	
l9437:	
;KeyFunc.c: 55: KeyPacket_y[num].KeyTime=0;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8)+01h)&0ffh
	movwf	fsr0
	clrf	indf
	incf	fsr0,f
	clrf	indf
	line	56
;KeyFunc.c: 56: break;
	goto	l2413
	line	59
	
l9439:	
;KeyFunc.c: 59: KeyPacket_y[num].KeyState=ShortRelease;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(06h)
	movwf	indf
	line	60
	
l9441:	
;KeyFunc.c: 60: if(num!=1)
		decf	((KeyScan@num)),w
	btfsc	status,2
	goto	u7851
	goto	u7850
u7851:
	goto	l9453
u7850:
	line	62
	
l9443:	
;KeyFunc.c: 61: {
;KeyFunc.c: 62: if(_BITS.Bits.bit_1==1){
	btfss	(__BITS),1
	goto	u7861
	goto	u7860
u7861:
	goto	l9453
u7860:
	line	63
	
l9445:	
;KeyFunc.c: 63: _BITS.Bits.bit_1=0;
	bcf	(__BITS),1
	line	65
	
l9447:	
;KeyFunc.c: 65: BuzzerSet(1, 50);
	movlw	032h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(01h)
	fcall	_BuzzerSet
	line	66
	
l9449:	
;KeyFunc.c: 66: KeyPacket_y[num].KeyState=NotPress;
	bcf	status, 5	;RP0=0, select bank0
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	clrf	indf
	goto	l2413
	line	70
	
l9453:	
;KeyFunc.c: 68: }
;KeyFunc.c: 69: }
;KeyFunc.c: 70: if((FilterFastCheck==1)&&(num!=0)){
		decf	((_FilterFastCheck)),w
	btfss	status,2
	goto	u7871
	goto	u7870
u7871:
	goto	l2413
u7870:
	
l9455:	
	movf	((KeyScan@num)),w
	btfsc	status,2
	goto	u7881
	goto	u7880
u7881:
	goto	l2413
u7880:
	line	71
	
l9457:	
;KeyFunc.c: 71: FilterFastCheck=2;
	movlw	low(02h)
	movwf	(_FilterFastCheck)
	line	72
	
l9459:	
;KeyFunc.c: 72: BuzzerSet(3, 200);
	movlw	0C8h
	movwf	(BuzzerSet@filter)
	clrf	(BuzzerSet@filter+1)
	movlw	low(03h)
	fcall	_BuzzerSet
	goto	l9449
	line	78
	
l9465:	
;KeyFunc.c: 78: KeyPacket_y[num].KeyState=LongRelease;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(07h)
	movwf	indf
	line	79
;KeyFunc.c: 79: break;
	goto	l2413
	line	81
	
l9467:	
;KeyFunc.c: 81: KeyPacket_y[num].KeyState=SuperRelease;
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	movlw	low(08h)
	movwf	indf
	line	82
;KeyFunc.c: 82: break;
	goto	l2413
	line	52
	
l9473:	
	movf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addwf	(KeyScan@num),w
	addlw	low(_KeyPacket_y|((0x0)<<8))&0ffh
	movwf	fsr0
	bcf	status, 7	;select IRP bank0
	movf	indf,w
	; Switch size 1, requested type "space"
; Number of cases is 4, Range of values is 0 to 3
; switch strategies available:
; Name         Instructions Cycles
; simple_byte           13     7 (average)
; direct_byte           20     8 (fixed)
; jumptable            260     6 (fixed)
;	Chosen strategy is simple_byte

	opt asmopt_push
	opt asmopt_off
	xorlw	0^0	; case 0
	skipnz
	goto	l9437
	xorlw	1^0	; case 1
	skipnz
	goto	l9439
	xorlw	2^1	; case 2
	skipnz
	goto	l9465
	xorlw	3^2	; case 3
	skipnz
	goto	l9467
	goto	l9431
	opt asmopt_pop

	line	90
	
l2413:	
	return
	opt stack 0
GLOBAL	__end_of_KeyScan
	__end_of_KeyScan:
	signat	_KeyScan,8313
	global	_BuzzerSet

;; *************** function _BuzzerSet *****************
;; Defined at:
;;		line 1554 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  cnt             1    wreg     unsigned char 
;;  filter          2    4[COMMON] unsigned short 
;; Auto vars:     Size  Location     Type
;;  cnt             1    0[BANK0 ] unsigned char 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 200/800
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       1       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       1       0       0
;;Total ram usage:        3 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_Count_Func
;;		_FilterLifeFunc
;;		_ShiftMode_Handle
;;		_FactoryMode_Handle
;;		_FilterKeyInputRest
;;		_StandbyMode_Handle
;;		_Run_Mode
;;		_ErrorHandle
;;		_KeyScan
;; This function uses a non-reentrant model
;;
psect	text56,local,class=CODE,delta=2,merge=1,group=0
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	1554
global __ptext56
__ptext56:	;psect for function _BuzzerSet
psect	text56
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	1554
	global	__size_of_BuzzerSet
	__size_of_BuzzerSet	equ	__end_of_BuzzerSet-_BuzzerSet
	
_BuzzerSet:	
;incstack = 0
	opt	stack 6
; Regs used in _BuzzerSet: [wreg]
;BuzzerSet@cnt stored from wreg
	bcf	status, 5	;RP0=0, select bank0
	movwf	(BuzzerSet@cnt)
	line	1556
	
l8919:	
;main.c: 1556: BeepAlmCnt = cnt;
	movf	(BuzzerSet@cnt),w
	movwf	(_BeepAlmCnt)
	line	1557
;main.c: 1557: BuzzerFilter = filter;
	movf	(BuzzerSet@filter+1),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_BuzzerFilter+1)^080h
	movf	(BuzzerSet@filter),w
	movwf	(_BuzzerFilter)^080h
	line	1558
;main.c: 1558: BeepOnTimeCnt=BuzzerFilter;
	movf	(_BuzzerFilter+1)^080h,w
	movwf	(_BeepOnTimeCnt+1)^080h
	movf	(_BuzzerFilter)^080h,w
	movwf	(_BeepOnTimeCnt)^080h
	line	1559
	
l1284:	
	return
	opt stack 0
GLOBAL	__end_of_BuzzerSet
	__end_of_BuzzerSet:
	signat	_BuzzerSet,8313
	global	_AD_Testing

;; *************** function _AD_Testing *****************
;; Defined at:
;;		line 2392 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  ad_fd           1    wreg     unsigned char 
;;  ad_ch           1    4[COMMON] unsigned char 
;;  ad_lr           1    5[COMMON] unsigned char 
;; Auto vars:     Size  Location     Type
;;  ad_fd           1    2[BANK0 ] unsigned char 
;;  data            2    6[BANK0 ] volatile unsigned int 
;;  AD_Result       2    3[BANK0 ] volatile unsigned int 
;;  i               1    5[BANK0 ] volatile unsigned char 
;; Return value:  Size  Location     Type
;;                  2    4[COMMON] unsigned int 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       6       0       0
;;      Temps:          0       2       0       0
;;      Totals:         2       8       0       0
;;Total ram usage:       10 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Time_Count_Func
;; This function uses a non-reentrant model
;;
psect	text57,local,class=CODE,delta=2,merge=1,group=0
	line	2392
global __ptext57
__ptext57:	;psect for function _AD_Testing
psect	text57
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	2392
	global	__size_of_AD_Testing
	__size_of_AD_Testing	equ	__end_of_AD_Testing-_AD_Testing
	
_AD_Testing:	
;incstack = 0
	opt	stack 7
; Regs used in _AD_Testing: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
;AD_Testing@ad_fd stored from wreg
	movwf	(AD_Testing@ad_fd)
	line	2400
	
l10197:	
;main.c: 2395: static volatile unsigned char adtimes;
;main.c: 2396: static volatile unsigned int admin,admax, adsum;
;main.c: 2397: volatile unsigned int data;
;main.c: 2398: volatile unsigned int AD_Result;
;main.c: 2400: volatile unsigned char i = 0;
	clrf	(AD_Testing@i)	;volatile
	line	2402
	
l10199:	
;main.c: 2402: if(!ad_lr)
	movf	((AD_Testing@ad_lr)),w
	btfss	status,2
	goto	u9031
	goto	u9030
u9031:
	goto	l10203
u9030:
	line	2403
	
l10201:	
;main.c: 2403: ADCON1 = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(159)^080h	;volatile
	goto	l10205
	line	2405
	
l10203:	
;main.c: 2404: else
;main.c: 2405: ADCON1 = 0x80;
	movlw	low(080h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(159)^080h	;volatile
	line	2407
	
l10205:	
;main.c: 2407: if(ad_ch & 0x10)
	btfss	(AD_Testing@ad_ch),(4)&7
	goto	u9041
	goto	u9040
u9041:
	goto	l10209
u9040:
	line	2408
	
l10207:	
;main.c: 2408: ADCON1 |= 0x40;
	bsf	(159)^080h+(6/8),(6)&7	;volatile
	line	2410
	
l10209:	
;main.c: 2410: ADCON0 = 0;
	clrf	(158)^080h	;volatile
	line	2411
	
l10211:	
;main.c: 2411: ad_ch &= 0x0f;
	movlw	low(0Fh)
	andwf	(AD_Testing@ad_ch),f
	line	2412
	
l10213:	
;main.c: 2412: ADCON0 |= (unsigned char)(ad_fd << 6);
	bcf	status, 5	;RP0=0, select bank0
	movf	(AD_Testing@ad_fd),w
	movwf	(??_AD_Testing+0)+0
	rrf	(??_AD_Testing+0)+0,f
	rrf	(??_AD_Testing+0)+0,f
	rrf	(??_AD_Testing+0)+0,w
	andlw	0c0h
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(158)^080h,f	;volatile
	line	2413
	
l10215:	
;main.c: 2413: ADCON0 |= (unsigned char)(ad_ch << 2);
	movf	(AD_Testing@ad_ch),w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_AD_Testing+0)+0
	movlw	(02h)-1
u9055:
	clrc
	rlf	(??_AD_Testing+0)+0,f
	addlw	-1
	skipz
	goto	u9055
	clrc
	rlf	(??_AD_Testing+0)+0,w
	bsf	status, 5	;RP0=1, select bank1
	iorwf	(158)^080h,f	;volatile
	line	2414
	
l10217:	
;main.c: 2414: ADCON0 |= 0x01;
	bsf	(158)^080h+(0/8),(0)&7	;volatile
	line	2416
# 2416 "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	2417
# 2417 "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
nop ;# 
psect	text57
	line	2418
	
l10219:	
;main.c: 2418: GODONE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	bsf	(1265/8)^080h,(1265)&7	;volatile
	line	2420
;main.c: 2420: while(GODONE)
	goto	l1457
	
l1458:	
	line	2422
# 2422 "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	2423
# 2423 "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
nop ;# 
psect	text57
	line	2424
;main.c: 2424: if((--i) == 0)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	decfsz	(AD_Testing@i),f	;volatile
	goto	u9061
	goto	u9060
u9061:
	goto	l1457
u9060:
	goto	l1460
	line	2426
	
l1457:	
	line	2420
	bsf	status, 5	;RP0=1, select bank1
	btfsc	(1265/8)^080h,(1265)&7	;volatile
	goto	u9071
	goto	u9070
u9071:
	goto	l1458
u9070:
	line	2428
	
l10223:	
;main.c: 2426: }
;main.c: 2428: if(!ad_lr)
	movf	((AD_Testing@ad_lr)),w
	btfss	status,2
	goto	u9081
	goto	u9080
u9081:
	goto	l10229
u9080:
	line	2430
	
l10225:	
;main.c: 2429: {
;main.c: 2430: data = (unsigned int)(ADRESH<<4);
	movf	(157)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(AD_Testing@data)	;volatile
	clrf	(AD_Testing@data+1)	;volatile
	swapf	(AD_Testing@data),f	;volatile
	swapf	(AD_Testing@data+1),f	;volatile
	movlw	0f0h
	andwf	(AD_Testing@data+1),f	;volatile
	movf	(AD_Testing@data),w	;volatile
	andlw	0fh
	iorwf	(AD_Testing@data+1),f	;volatile
	movlw	0f0h
	andwf	(AD_Testing@data),f	;volatile
	line	2431
	
l10227:	
;main.c: 2431: data |= (unsigned int)(ADRESL>>4);
	bsf	status, 5	;RP0=1, select bank1
	swapf	(156)^080h,w	;volatile
	andlw	(0ffh shr 4) & 0ffh
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(AD_Testing@data),f	;volatile
	line	2432
;main.c: 2432: }
	goto	l10231
	line	2435
	
l10229:	
;main.c: 2433: else
;main.c: 2434: {
;main.c: 2435: data = (unsigned int)(ADRESH<<8);
	movf	(157)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(AD_Testing@data+1)	;volatile
	clrf	(AD_Testing@data)	;volatile
	line	2436
;main.c: 2436: data |= (unsigned int)ADRESL;
	bsf	status, 5	;RP0=1, select bank1
	movf	(156)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(AD_Testing@data),f	;volatile
	line	2439
	
l10231:	
;main.c: 2437: }
;main.c: 2439: if(adtimes == 0)
	movf	((AD_Testing@adtimes)),w	;volatile
	btfss	status,2
	goto	u9091
	goto	u9090
u9091:
	goto	l10235
u9090:
	line	2441
	
l10233:	
;main.c: 2440: {
;main.c: 2441: admax = data;
	movf	(AD_Testing@data+1),w	;volatile
	movwf	(AD_Testing@admax+1)	;volatile
	movf	(AD_Testing@data),w	;volatile
	movwf	(AD_Testing@admax)	;volatile
	line	2442
;main.c: 2442: admin = data;
	movf	(AD_Testing@data+1),w	;volatile
	movwf	(AD_Testing@admin+1)	;volatile
	movf	(AD_Testing@data),w	;volatile
	movwf	(AD_Testing@admin)	;volatile
	line	2443
;main.c: 2443: }
	goto	l1465
	line	2444
	
l10235:	
;main.c: 2444: else if(data > admax)
	movf	(AD_Testing@data+1),w	;volatile
	subwf	(AD_Testing@admax+1),w	;volatile
	skipz
	goto	u9105
	movf	(AD_Testing@data),w	;volatile
	subwf	(AD_Testing@admax),w	;volatile
u9105:
	skipnc
	goto	u9101
	goto	u9100
u9101:
	goto	l10239
u9100:
	line	2446
	
l10237:	
;main.c: 2445: {
;main.c: 2446: admax = data;
	movf	(AD_Testing@data+1),w	;volatile
	movwf	(AD_Testing@admax+1)	;volatile
	movf	(AD_Testing@data),w	;volatile
	movwf	(AD_Testing@admax)	;volatile
	line	2447
;main.c: 2447: }
	goto	l1465
	line	2448
	
l10239:	
;main.c: 2448: else if(data < admin)
	movf	(AD_Testing@admin+1),w	;volatile
	subwf	(AD_Testing@data+1),w	;volatile
	skipz
	goto	u9115
	movf	(AD_Testing@admin),w	;volatile
	subwf	(AD_Testing@data),w	;volatile
u9115:
	skipnc
	goto	u9111
	goto	u9110
u9111:
	goto	l1465
u9110:
	line	2450
	
l10241:	
;main.c: 2449: {
;main.c: 2450: admin = data;
	movf	(AD_Testing@data+1),w	;volatile
	movwf	(AD_Testing@admin+1)	;volatile
	movf	(AD_Testing@data),w	;volatile
	movwf	(AD_Testing@admin)	;volatile
	line	2453
	
l1465:	
;main.c: 2451: }
;main.c: 2453: adsum += data;
	movf	(AD_Testing@data),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	addwf	(AD_Testing@adsum)^080h,f	;volatile
	skipnc
	incf	(AD_Testing@adsum+1)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(AD_Testing@data+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	addwf	(AD_Testing@adsum+1)^080h,f	;volatile
	line	2454
	
l10243:	
;main.c: 2454: if(++adtimes >= 10)
	movlw	low(0Ah)
	bcf	status, 5	;RP0=0, select bank0
	incf	(AD_Testing@adtimes),f	;volatile
	subwf	((AD_Testing@adtimes)),w	;volatile
	skipc
	goto	u9121
	goto	u9120
u9121:
	goto	l1460
u9120:
	line	2456
	
l10245:	
;main.c: 2455: {
;main.c: 2456: adsum -= admax;
	movf	(AD_Testing@admax),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	subwf	(AD_Testing@adsum)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(AD_Testing@admax+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	skipc
	decf	(AD_Testing@adsum+1)^080h,f	;volatile
	subwf	(AD_Testing@adsum+1)^080h,f	;volatile
	line	2457
;main.c: 2457: adsum -= admin;
	bcf	status, 5	;RP0=0, select bank0
	movf	(AD_Testing@admin),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	subwf	(AD_Testing@adsum)^080h,f	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movf	(AD_Testing@admin+1),w	;volatile
	bsf	status, 5	;RP0=1, select bank1
	skipc
	decf	(AD_Testing@adsum+1)^080h,f	;volatile
	subwf	(AD_Testing@adsum+1)^080h,f	;volatile
	line	2459
	
l10247:	
;main.c: 2459: AD_Result = adsum >> 3;
	movf	(AD_Testing@adsum+1)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_AD_Testing+0)+0+1
	bsf	status, 5	;RP0=1, select bank1
	movf	(AD_Testing@adsum)^080h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	movwf	(??_AD_Testing+0)+0
	clrc
	rrf	(??_AD_Testing+0)+1,f
	rrf	(??_AD_Testing+0)+0,f
	clrc
	rrf	(??_AD_Testing+0)+1,f
	rrf	(??_AD_Testing+0)+0,f
	clrc
	rrf	(??_AD_Testing+0)+1,f
	rrf	(??_AD_Testing+0)+0,f
	movf	0+(??_AD_Testing+0)+0,w
	movwf	(AD_Testing@AD_Result)	;volatile
	movf	1+(??_AD_Testing+0)+0,w
	movwf	(AD_Testing@AD_Result+1)	;volatile
	line	2461
	
l10249:	
;main.c: 2461: adsum = 0;
	bsf	status, 5	;RP0=1, select bank1
	clrf	(AD_Testing@adsum)^080h	;volatile
	clrf	(AD_Testing@adsum+1)^080h	;volatile
	line	2462
	
l10251:	
;main.c: 2462: admin = 0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(AD_Testing@admin)	;volatile
	clrf	(AD_Testing@admin+1)	;volatile
	line	2463
	
l10253:	
;main.c: 2463: admax = 0;
	clrf	(AD_Testing@admax)	;volatile
	clrf	(AD_Testing@admax+1)	;volatile
	line	2464
	
l10255:	
;main.c: 2464: adtimes = 0;
	clrf	(AD_Testing@adtimes)	;volatile
	line	2465
	
l10257:	
;main.c: 2465: for(i=0;i<50;i++){
	clrf	(AD_Testing@i)	;volatile
	
l10259:	
	movlw	low(032h)
	subwf	(AD_Testing@i),w	;volatile
	skipc
	goto	u9131
	goto	u9130
u9131:
	goto	l10263
u9130:
	goto	l1460
	line	2466
	
l10263:	
;main.c: 2466: if(NTC_Tab[i]<=AD_Result){
	clrc
	rlf	(AD_Testing@i),w	;volatile
	addlw	low(((_NTC_Tab)|8000h))
	movwf	fsr0
	movlw	high(((_NTC_Tab)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	movwf	(??_AD_Testing+0)+0
	fcall	stringtab
	movwf	(??_AD_Testing+0)+0+1
	movf	1+(??_AD_Testing+0)+0,w
	subwf	(AD_Testing@AD_Result+1),w	;volatile
	skipz
	goto	u9145
	movf	0+(??_AD_Testing+0)+0,w
	subwf	(AD_Testing@AD_Result),w	;volatile
u9145:
	skipc
	goto	u9141
	goto	u9140
u9141:
	goto	l10267
u9140:
	line	2467
	
l10265:	
;main.c: 2467: Temp_Ntc=i;
	movf	(AD_Testing@i),w	;volatile
	movwf	(_Temp_Ntc)
	line	2468
;main.c: 2468: break;
	goto	l1460
	line	2465
	
l10267:	
	incf	(AD_Testing@i),f	;volatile
	
l10269:	
	movlw	low(032h)
	subwf	(AD_Testing@i),w	;volatile
	skipc
	goto	u9151
	goto	u9150
u9151:
	goto	l10263
u9150:
	line	2475
	
l1460:	
	return
	opt stack 0
GLOBAL	__end_of_AD_Testing
	__end_of_AD_Testing:
	signat	_AD_Testing,12410
	global	_Initialize

;; *************** function _Initialize *****************
;; Defined at:
;;		line 2547 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/100
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Init_ram
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text58,local,class=CODE,delta=2,merge=1,group=0
	line	2547
global __ptext58
__ptext58:	;psect for function _Initialize
psect	text58
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	2547
	global	__size_of_Initialize
	__size_of_Initialize	equ	__end_of_Initialize-_Initialize
	
_Initialize:	
;incstack = 0
	opt	stack 7
; Regs used in _Initialize: [wreg+status,2+status,0+pclath+cstack]
	line	2549
	
l8745:	
# 2549 "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	2550
# 2550 "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text58
	line	2553
	
l8747:	
;main.c: 2553: OSCCON = 0X70;
	movlw	low(070h)
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	movwf	(143)^080h	;volatile
	line	2557
;main.c: 2557: PORTA=0B11111111;
	movlw	low(0FFh)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(5)	;volatile
	line	2558
;main.c: 2558: PORTB=0B11111111;
	movlw	low(0FFh)
	movwf	(6)	;volatile
	line	2559
;main.c: 2559: PORTC=0x01;
	movlw	low(01h)
	movwf	(7)	;volatile
	line	2561
;main.c: 2561: TRISA = 0B00111000;
	movlw	low(038h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(133)^080h	;volatile
	line	2562
;main.c: 2562: TRISB = 0B00000010;
	movlw	low(02h)
	movwf	(134)^080h	;volatile
	line	2563
;main.c: 2563: TRISC = 0B00100011;
	movlw	low(023h)
	movwf	(135)^080h	;volatile
	line	2564
;main.c: 2564: TRISD = 0B00000100;
	movlw	low(04h)
	movwf	(136)^080h	;volatile
	line	2566
;main.c: 2566: WPUA = 0B00000001;
	movlw	low(01h)
	movwf	(153)^080h	;volatile
	line	2567
;main.c: 2567: WPUB = 0B00000010;
	movlw	low(02h)
	movwf	(149)^080h	;volatile
	line	2568
;main.c: 2568: WPUC = 0B00000001;
	movlw	low(01h)
	movwf	(154)^080h	;volatile
	line	2570
;main.c: 2570: OPTION_REG = 0x02;
	movlw	low(02h)
	movwf	(129)^080h	;volatile
	line	2571
;main.c: 2571: TMR0 = 255-125;
	movlw	low(082h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(1)	;volatile
	line	2573
;main.c: 2573: TMR1L = (65535-32000)%256;
	movlw	low(0FFh)
	movwf	(14)	;volatile
	line	2574
;main.c: 2574: TMR1H = (65535-32000)/256;
	movlw	low(082h)
	movwf	(15)	;volatile
	line	2575
	
l8749:	
;main.c: 2575: TMR1IF = 0;
	bcf	(96/8),(96)&7	;volatile
	line	2576
	
l8751:	
;main.c: 2576: TMR1IE = 1;
	bsf	status, 5	;RP0=1, select bank1
	bsf	(1120/8)^080h,(1120)&7	;volatile
	line	2577
;main.c: 2577: T1CON = 0x01;
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(16)	;volatile
	line	2578
;main.c: 2578: ANSEL1 = 0B10000000;
	movlw	low(080h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(137)^080h	;volatile
	line	2580
	
l8753:	
;main.c: 2580: Init_ram();
	fcall	_Init_ram
	line	2581
	
l8755:	
;main.c: 2581: INTEDG = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	(1038/8)^080h,(1038)&7	;volatile
	line	2582
	
l8757:	
;main.c: 2582: INTCON = 0xe0;
	movlw	low(0E0h)
	movwf	(11)	;volatile
	line	2585
	
l1478:	
	return
	opt stack 0
GLOBAL	__end_of_Initialize
	__end_of_Initialize:
	signat	_Initialize,89
	global	_Init_ram

;; *************** function _Init_ram *****************
;; Defined at:
;;		line 2533 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Initialize
;; This function uses a non-reentrant model
;;
psect	text59,local,class=CODE,delta=2,merge=1,group=0
	line	2533
global __ptext59
__ptext59:	;psect for function _Init_ram
psect	text59
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	2533
	global	__size_of_Init_ram
	__size_of_Init_ram	equ	__end_of_Init_ram-_Init_ram
	
_Init_ram:	
;incstack = 0
	opt	stack 7
; Regs used in _Init_ram: [wreg+status,2]
	line	2535
	
l8641:	
# 2535 "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
clrwdt ;# 
psect	text59
	line	2536
	
l8643:	
;main.c: 2536: PIE2 = 0;
	bsf	status, 5	;RP0=1, select bank1
	bcf	status, 6	;RP1=0, select bank1
	clrf	(141)^080h	;volatile
	line	2537
	
l8645:	
;main.c: 2537: PIE1 = 0B00000010;
	movlw	low(02h)
	movwf	(140)^080h	;volatile
	line	2538
	
l8647:	
;main.c: 2538: PR2 = 125;
	movlw	low(07Dh)
	movwf	(146)^080h	;volatile
	line	2539
	
l8649:	
;main.c: 2539: T2CON = 5;
	movlw	low(05h)
	bcf	status, 5	;RP0=0, select bank0
	movwf	(18)	;volatile
	line	2542
	
l1475:	
	return
	opt stack 0
GLOBAL	__end_of_Init_ram
	__end_of_Init_ram:
	signat	_Init_ram,89
	global	_EEPROM_Page

;; *************** function _EEPROM_Page *****************
;; Defined at:
;;		line 2337 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    5
;; This function calls:
;;		_ReadDataArry
;;		_SetFilterDelayReset
;;		_WrterEEP
;; This function is called by:
;;		_main
;; This function uses a non-reentrant model
;;
psect	text60,local,class=CODE,delta=2,merge=1,group=0
	line	2337
global __ptext60
__ptext60:	;psect for function _EEPROM_Page
psect	text60
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	2337
	global	__size_of_EEPROM_Page
	__size_of_EEPROM_Page	equ	__end_of_EEPROM_Page-_EEPROM_Page
	
_EEPROM_Page:	
;incstack = 0
	opt	stack 6
; Regs used in _EEPROM_Page: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	2339
	
l11129:	
;main.c: 2339: ReadDataArry();
	fcall	_ReadDataArry
	line	2341
	
l11131:	
;main.c: 2341: if(Read_Word_Buff[0]==0xA5){
		movlw	165
	bsf	status, 5	;RP0=1, select bank1
	xorwf	((_Read_Word_Buff)^080h),w
	btfss	status,2
	goto	u10511
	goto	u10510
u10511:
	goto	l1440
u10510:
	line	2342
	
l11133:	
;main.c: 2342: FilterPCF_time.u8Hour=Read_Word_Buff[1];
	movf	0+(_Read_Word_Buff)^080h+01h,w
	movwf	0+(_FilterPCF_time)^080h+02h
	line	2343
;main.c: 2343: FilterPCF_time.u16Day=(U16_T)Read_Word_Buff[2]<<8;
	movf	0+(_Read_Word_Buff)^080h+02h,w
	movwf	1+(_FilterPCF_time)^080h+03h
	clrf	0+(_FilterPCF_time)^080h+03h
	line	2344
;main.c: 2344: FilterPCF_time.u16Day|=Read_Word_Buff[3];
	movf	0+(_Read_Word_Buff)^080h+03h,w
	iorwf	0+(_FilterPCF_time)^080h+03h,f
	line	2346
;main.c: 2346: FilterRO_time.u8Hour=Read_Word_Buff[4];
	movf	0+(_Read_Word_Buff)^080h+04h,w
	movwf	0+(_FilterRO_time)^080h+02h
	line	2347
;main.c: 2347: FilterRO_time.u16Day=(U16_T)Read_Word_Buff[5]<<8;
	movf	0+(_Read_Word_Buff)^080h+05h,w
	movwf	1+(_FilterRO_time)^080h+03h
	clrf	0+(_FilterRO_time)^080h+03h
	line	2348
;main.c: 2348: FilterRO_time.u16Day|=Read_Word_Buff[6];
	movf	0+(_Read_Word_Buff)^080h+06h,w
	iorwf	0+(_FilterRO_time)^080h+03h,f
	line	2350
;main.c: 2350: FilterPCFGetWater=Read_Word_Buff[7];
	movf	0+(_Read_Word_Buff)^080h+07h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_FilterPCFGetWater)
	clrf	(_FilterPCFGetWater+1)
	line	2351
;main.c: 2351: FilterPCFGetWater=FilterPCFGetWater<<8;
	movf	(_FilterPCFGetWater),w
	movwf	(_FilterPCFGetWater+1)
	clrf	(_FilterPCFGetWater)
	line	2352
;main.c: 2352: FilterPCFGetWater|=Read_Word_Buff[8];
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_Read_Word_Buff)^080h+08h,w
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(_FilterPCFGetWater),f
	line	2354
;main.c: 2354: FilterROGetWater=Read_Word_Buff[9];
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_Read_Word_Buff)^080h+09h,w
	bcf	status, 5	;RP0=0, select bank0
	movwf	(_FilterROGetWater)
	clrf	(_FilterROGetWater+1)
	line	2355
;main.c: 2355: FilterROGetWater=FilterROGetWater<<8;
	movf	(_FilterROGetWater),w
	movwf	(_FilterROGetWater+1)
	clrf	(_FilterROGetWater)
	line	2356
;main.c: 2356: FilterROGetWater|=Read_Word_Buff[10];
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_Read_Word_Buff)^080h+0Ah,w
	bcf	status, 5	;RP0=0, select bank0
	iorwf	(_FilterROGetWater),f
	line	2361
;main.c: 2361: }
	goto	l11149
	line	2362
	
l1440:	
	line	2364
;main.c: 2362: else
;main.c: 2363: {
;main.c: 2364: _BITS1.Bits.bit_1=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(__BITS1),1
	line	2365
	
l11135:	
;main.c: 2365: Read_Word_Buff[0]=0xA5;
	movlw	low(0A5h)
	bsf	status, 5	;RP0=1, select bank1
	movwf	(_Read_Word_Buff)^080h
	line	2367
	
l11137:	
;main.c: 2367: Read_Word_Buff[11]=1;
	clrf	0+(_Read_Word_Buff)^080h+0Bh
	incf	0+(_Read_Word_Buff)^080h+0Bh,f
	line	2368
	
l11139:	
;main.c: 2368: SetFilterDelayReset(&FilterPCF_time, 365, 0, 0, 0);
	movlw	06Dh
	bcf	status, 5	;RP0=0, select bank0
	movwf	(SetFilterDelayReset@Day)
	movlw	01h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterPCF_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	2369
	
l11141:	
;main.c: 2369: SetFilterDelayReset(&FilterRO_time, 1095, 0, 0, 0);
	movlw	047h
	movwf	(SetFilterDelayReset@Day)
	movlw	04h
	movwf	((SetFilterDelayReset@Day))+1
	clrf	(SetFilterDelayReset@hour)
	clrf	(SetFilterDelayReset@min)
	clrf	(SetFilterDelayReset@sec)
	clrf	(SetFilterDelayReset@sec+1)
	movlw	(low(_FilterRO_time|((0x0)<<8)))&0ffh
	fcall	_SetFilterDelayReset
	line	2370
	
l11143:	
;main.c: 2370: FilterROGetWater=0;
	clrf	(_FilterROGetWater)
	clrf	(_FilterROGetWater+1)
	line	2371
	
l11145:	
;main.c: 2371: FilterPCFGetWater=0;
	clrf	(_FilterPCFGetWater)
	clrf	(_FilterPCFGetWater+1)
	line	2372
	
l11147:	
;main.c: 2372: WrterEEP();
	fcall	_WrterEEP
	line	2374
	
l11149:	
;main.c: 2373: }
;main.c: 2374: _BITS1.Bits.bit_0=1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(__BITS1),0
	line	2375
	
l11151:	
;main.c: 2375: PreROu16Day=FilterRO_time.u16Day;
	bsf	status, 5	;RP0=1, select bank1
	movf	1+(_FilterRO_time)^080h+03h,w
	movwf	(_PreROu16Day+1)^080h
	movf	0+(_FilterRO_time)^080h+03h,w
	movwf	(_PreROu16Day)^080h
	line	2376
	
l11153:	
;main.c: 2376: PrePCFu16Day=FilterPCF_time.u16Day;
	movf	1+(_FilterPCF_time)^080h+03h,w
	movwf	(_PrePCFu16Day+1)^080h
	movf	0+(_FilterPCF_time)^080h+03h,w
	movwf	(_PrePCFu16Day)^080h
	line	2377
	
l11155:	
;main.c: 2377: _BITS1.Bits.bit_7=0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(__BITS1),7
	line	2385
	
l11157:	
;main.c: 2384: if((FilterROGetWater>=(21*2))
;main.c: 2385: &&(FilterPCFGetWater>=(21*2))){
	movlw	0
	subwf	(_FilterROGetWater+1),w
	movlw	02Ah
	skipnz
	subwf	(_FilterROGetWater),w
	skipc
	goto	u10521
	goto	u10520
u10521:
	goto	l1443
u10520:
	
l11159:	
	movlw	0
	subwf	(_FilterPCFGetWater+1),w
	movlw	02Ah
	skipnz
	subwf	(_FilterPCFGetWater),w
	skipc
	goto	u10531
	goto	u10530
u10531:
	goto	l1443
u10530:
	line	2388
	
l11161:	
;main.c: 2388: _BITS1.Bits.bit_7=1;
	bsf	(__BITS1),7
	line	2390
	
l1443:	
	return
	opt stack 0
GLOBAL	__end_of_EEPROM_Page
	__end_of_EEPROM_Page:
	signat	_EEPROM_Page,89
	global	_WrterEEP

;; *************** function _WrterEEP *****************
;; Defined at:
;;		line 2311 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, status,2, status,0
;; Tracked objects:
;;		On entry : 200/0
;;		On exit  : 200/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_GetMode_Handle
;;		_FilterKeyInputRest
;;		_StandbyMode_Handle
;;		_EEPROM_Page
;; This function uses a non-reentrant model
;;
psect	text61,local,class=CODE,delta=2,merge=1,group=0
	line	2311
global __ptext61
__ptext61:	;psect for function _WrterEEP
psect	text61
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	2311
	global	__size_of_WrterEEP
	__size_of_WrterEEP	equ	__end_of_WrterEEP-_WrterEEP
	
_WrterEEP:	
;incstack = 0
	opt	stack 6
; Regs used in _WrterEEP: [wreg+status,2+status,0]
	line	2312
	
l9357:	
;main.c: 2312: if(FilterFastCheck) return;
	bcf	status, 5	;RP0=0, select bank0
	movf	((_FilterFastCheck)),w
	btfsc	status,2
	goto	u7721
	goto	u7720
u7721:
	goto	l9361
u7720:
	goto	l1432
	line	2314
	
l9361:	
;main.c: 2314: Read_Word_Buff[1]=FilterPCF_time.u8Hour;
	bsf	status, 5	;RP0=1, select bank1
	movf	0+(_FilterPCF_time)^080h+02h,w
	movwf	0+(_Read_Word_Buff)^080h+01h
	line	2315
;main.c: 2315: Read_Word_Buff[2]=FilterPCF_time.u16Day>>8;
	movf	1+(_FilterPCF_time)^080h+03h,w
	movwf	0+(_Read_Word_Buff)^080h+02h
	line	2316
;main.c: 2316: Read_Word_Buff[3]=FilterPCF_time.u16Day&0X00FF;
	movf	0+(_FilterPCF_time)^080h+03h,w
	movwf	0+(_Read_Word_Buff)^080h+03h
	line	2318
;main.c: 2318: Read_Word_Buff[4]=FilterRO_time.u8Hour;
	movf	0+(_FilterRO_time)^080h+02h,w
	movwf	0+(_Read_Word_Buff)^080h+04h
	line	2319
;main.c: 2319: Read_Word_Buff[5]=FilterRO_time.u16Day>>8;
	movf	1+(_FilterRO_time)^080h+03h,w
	movwf	0+(_Read_Word_Buff)^080h+05h
	line	2320
;main.c: 2320: Read_Word_Buff[6]=FilterRO_time.u16Day&0X00FF;
	movf	0+(_FilterRO_time)^080h+03h,w
	movwf	0+(_Read_Word_Buff)^080h+06h
	line	2322
;main.c: 2322: Read_Word_Buff[7]=FilterPCFGetWater>>8;
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(_FilterPCFGetWater)+01h,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_Read_Word_Buff)^080h+07h
	line	2323
;main.c: 2323: Read_Word_Buff[8]=FilterPCFGetWater&0X00FF;
	bcf	status, 5	;RP0=0, select bank0
	movf	(_FilterPCFGetWater),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_Read_Word_Buff)^080h+08h
	line	2325
;main.c: 2325: Read_Word_Buff[9]=FilterROGetWater>>8;
	bcf	status, 5	;RP0=0, select bank0
	movf	0+(_FilterROGetWater)+01h,w
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_Read_Word_Buff)^080h+09h
	line	2326
;main.c: 2326: Read_Word_Buff[10]=FilterROGetWater&0X00FF;
	bcf	status, 5	;RP0=0, select bank0
	movf	(_FilterROGetWater),w
	bsf	status, 5	;RP0=1, select bank1
	movwf	0+(_Read_Word_Buff)^080h+0Ah
	line	2328
	
l9363:	
;main.c: 2328: _BITS.Bits.bit_4=1;
	bsf	(__BITS),4
	line	2329
	
l1432:	
	return
	opt stack 0
GLOBAL	__end_of_WrterEEP
	__end_of_WrterEEP:
	signat	_WrterEEP,89
	global	_SetFilterDelayReset

;; *************** function _SetFilterDelayReset *****************
;; Defined at:
;;		line 403 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  TimPtr          1    wreg     PTR struct .
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;;  Day             2    0[BANK0 ] unsigned int 
;;  hour            1    2[BANK0 ] unsigned char 
;;  min             1    3[BANK0 ] unsigned char 
;;  sec             2    4[BANK0 ] unsigned int 
;; Auto vars:     Size  Location     Type
;;  TimPtr          1    4[COMMON] PTR struct .
;;		 -> FilterRO_time(5), FilterPCF_time(5), 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       6       0       0
;;      Locals:         1       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         1       6       0       0
;;Total ram usage:        7 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_FilterKeyInputRest
;;		_EEPROM_Page
;; This function uses a non-reentrant model
;;
psect	text62,local,class=CODE,delta=2,merge=1,group=0
	line	403
global __ptext62
__ptext62:	;psect for function _SetFilterDelayReset
psect	text62
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	403
	global	__size_of_SetFilterDelayReset
	__size_of_SetFilterDelayReset	equ	__end_of_SetFilterDelayReset-_SetFilterDelayReset
	
_SetFilterDelayReset:	
;incstack = 0
	opt	stack 6
; Regs used in _SetFilterDelayReset: [wreg-fsr0h+status,2+status,0]
;SetFilterDelayReset@TimPtr stored from wreg
	movwf	(SetFilterDelayReset@TimPtr)
	line	405
	
l9187:	
;main.c: 405: TimPtr->u16Day=Day;
	movf	(SetFilterDelayReset@TimPtr),w
	addlw	03h
	movwf	fsr0
	movf	(SetFilterDelayReset@Day),w
	bcf	status, 7	;select IRP bank0
	movwf	indf
	incf	fsr0,f
	movf	(SetFilterDelayReset@Day+1),w
	movwf	indf
	line	406
;main.c: 406: TimPtr->u8Hour=hour;
	movf	(SetFilterDelayReset@TimPtr),w
	addlw	02h
	movwf	fsr0
	movf	(SetFilterDelayReset@hour),w
	movwf	indf
	line	407
	
l9189:	
;main.c: 407: TimPtr->u8Minute=min;
	incf	(SetFilterDelayReset@TimPtr),w
	movwf	fsr0
	movf	(SetFilterDelayReset@min),w
	movwf	indf
	line	408
	
l9191:	
;main.c: 408: TimPtr->u8Second=sec;
	movf	(SetFilterDelayReset@TimPtr),w
	movwf	fsr0
	movf	(SetFilterDelayReset@sec),w
	movwf	indf
	line	409
	
l1036:	
	return
	opt stack 0
GLOBAL	__end_of_SetFilterDelayReset
	__end_of_SetFilterDelayReset:
	signat	_SetFilterDelayReset,20601
	global	_ReadDataArry

;; *************** function _ReadDataArry *****************
;; Defined at:
;;		line 2330 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;  i               2    0[BANK0 ] unsigned int 
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, pclath, cstack
;; Tracked objects:
;;		On entry : 300/100
;;		On exit  : B00/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       2       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       2       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    4
;; This function calls:
;;		_Memory_Read
;; This function is called by:
;;		_EEPROM_Page
;; This function uses a non-reentrant model
;;
psect	text63,local,class=CODE,delta=2,merge=1,group=0
	line	2330
global __ptext63
__ptext63:	;psect for function _ReadDataArry
psect	text63
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	2330
	global	__size_of_ReadDataArry
	__size_of_ReadDataArry	equ	__end_of_ReadDataArry-_ReadDataArry
	
_ReadDataArry:	
;incstack = 0
	opt	stack 6
; Regs used in _ReadDataArry: [wreg-fsr0h+status,2+status,0+pclath+cstack]
	line	2332
	
l11057:	
;main.c: 2332: unsigned int i=0;
	bcf	status, 5	;RP0=0, select bank0
	clrf	(ReadDataArry@i)
	clrf	(ReadDataArry@i+1)
	line	2333
;main.c: 2333: for(i=0;i<12;i++){
	clrf	(ReadDataArry@i)
	clrf	(ReadDataArry@i+1)
	line	2334
	
l11063:	
;main.c: 2334: Read_Word_Buff[i]=Memory_Read(i);
	movf	(ReadDataArry@i),w
	addlw	low(_Read_Word_Buff|((0x0)<<8))&0ffh
	movwf	fsr0
	movf	(ReadDataArry@i+1),w
	movwf	(Memory_Read@Addr+1)
	movf	(ReadDataArry@i),w
	movwf	(Memory_Read@Addr)
	fcall	_Memory_Read
	movf	(0+(?_Memory_Read)),w
	bcf	status, 7	;select IRP bank1
	movwf	indf
	line	2333
	
l11065:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	incf	(ReadDataArry@i),f
	skipnz
	incf	(ReadDataArry@i+1),f
	
l11067:	
	movlw	0
	subwf	(ReadDataArry@i+1),w
	movlw	0Ch
	skipnz
	subwf	(ReadDataArry@i),w
	skipc
	goto	u10461
	goto	u10460
u10461:
	goto	l11063
u10460:
	line	2336
	
l1437:	
	return
	opt stack 0
GLOBAL	__end_of_ReadDataArry
	__end_of_ReadDataArry:
	signat	_ReadDataArry,89
	global	_Memory_Read

;; *************** function _Memory_Read *****************
;; Defined at:
;;		line 1785 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;  Addr            2    4[COMMON] unsigned int 
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  2    4[COMMON] unsigned int 
;; Registers used:
;;		wreg
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 300/300
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         2       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         2       0       0       0
;;Total ram usage:        2 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    3
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_ReadDataArry
;; This function uses a non-reentrant model
;;
psect	text64,local,class=CODE,delta=2,merge=1,group=0
	line	1785
global __ptext64
__ptext64:	;psect for function _Memory_Read
psect	text64
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	1785
	global	__size_of_Memory_Read
	__size_of_Memory_Read	equ	__end_of_Memory_Read-_Memory_Read
	
_Memory_Read:	
;incstack = 0
	opt	stack 6
; Regs used in _Memory_Read: [wreg]
	line	1788
	
l10879:	
;main.c: 1788: EEADR = Addr;
	movf	(Memory_Read@Addr),w
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(391)^0180h	;volatile
	line	1789
	
l10881:	
;main.c: 1789: EEPGD = 0;
	bcf	(3175/8)^0180h,(3175)&7	;volsfr
	line	1796
	
l10883:	
;main.c: 1796: RD=1;
	bsf	(3168/8)^0180h,(3168)&7	;volsfr
	line	1797
# 1797 "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
nop ;# 
	line	1798
# 1798 "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
nop ;# 
psect	text64
	line	1801
;main.c: 1801: return (EEDAT);
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(390)^0180h,w	;volatile
	movwf	(?_Memory_Read)
	clrf	(?_Memory_Read+1)
	line	1805
	
l1339:	
	return
	opt stack 0
GLOBAL	__end_of_Memory_Read
	__end_of_Memory_Read:
	signat	_Memory_Read,4218
	global	_Timer1_Isr

;; *************** function _Timer1_Isr *****************
;; Defined at:
;;		line 2588 in file "E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath, cstack
;; Tracked objects:
;;		On entry : 0/0
;;		On exit  : 300/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          4       0       0       0
;;      Totals:         4       0       0       0
;;Total ram usage:        4 bytes
;; Hardware stack levels used:    1
;; Hardware stack levels required when called:    2
;; This function calls:
;;		___CMS_TouchKeyValue
;; This function is called by:
;;		Interrupt level 1
;; This function uses a non-reentrant model
;;
psect	text65,local,class=CODE,delta=2,merge=1,group=0
	line	2588
global __ptext65
__ptext65:	;psect for function _Timer1_Isr
psect	text65
	file	"E:\Project\SbaakLite\Sbaak_738B\Sbaake\main.c"
	line	2588
	global	__size_of_Timer1_Isr
	__size_of_Timer1_Isr	equ	__end_of_Timer1_Isr-_Timer1_Isr
	
_Timer1_Isr:	
;incstack = 0
	opt	stack 2
; Regs used in _Timer1_Isr: [wreg-fsr0h+status,2+status,0+btemp+1+pclath+cstack]
psect	intentry,class=CODE,delta=2
global __pintentry
__pintentry:
global interrupt_function
interrupt_function:
	global saved_w
	saved_w	set	btemp+0
	movwf	saved_w
	swapf	status,w
	movwf	(??_Timer1_Isr+0)
	movf	fsr0,w
	movwf	(??_Timer1_Isr+1)
	movf	pclath,w
	movwf	(??_Timer1_Isr+2)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	btemp+1,w
	movwf	(??_Timer1_Isr+3)
	ljmp	_Timer1_Isr
psect	text65
	line	2591
	
i1l8847:	
;main.c: 2590: static U8_T T1_1ms=0;
;main.c: 2591: if(T0IF)
	btfss	(90/8),(90)&7	;volatile
	goto	u704_21
	goto	u704_20
u704_21:
	goto	i1l8853
u704_20:
	line	2594
	
i1l8849:	
;main.c: 2592: {
;main.c: 2594: TMR0 += 255-125;
	movlw	low(082h)
	addwf	(1),f	;volatile
	line	2597
	
i1l8851:	
;main.c: 2597: T0IF = 0;
	bcf	(90/8),(90)&7	;volatile
	line	2608
	
i1l8853:	
;main.c: 2606: }
;main.c: 2608: if(TMR1IF)
	btfss	(96/8),(96)&7	;volatile
	goto	u705_21
	goto	u705_20
u705_21:
	goto	i1l8863
u705_20:
	line	2611
	
i1l8855:	
;main.c: 2609: {
;main.c: 2611: TMR1L += (65535-32000)%256;
	movlw	low(0FFh)
	addwf	(14),f	;volatile
	line	2612
;main.c: 2612: TMR1H += (65535-32000)/256;
	movlw	low(082h)
	addwf	(15),f	;volatile
	line	2616
;main.c: 2616: if(++T1_1ms>=10){
	movlw	low(0Ah)
	bsf	status, 5	;RP0=1, select bank1
	incf	(Timer1_Isr@T1_1ms)^080h,f
	subwf	((Timer1_Isr@T1_1ms)^080h),w
	skipc
	goto	u706_21
	goto	u706_20
u706_21:
	goto	i1l8861
u706_20:
	line	2617
	
i1l8857:	
;main.c: 2617: T1_1ms=0;
	clrf	(Timer1_Isr@T1_1ms)^080h
	line	2618
	
i1l8859:	
;main.c: 2618: _BITS2.Bits.bit_0=1;
	bcf	status, 5	;RP0=0, select bank0
	bsf	(__BITS2),0
	line	2621
	
i1l8861:	
;main.c: 2619: }
;main.c: 2621: TMR1IF = 0;
	bcf	status, 5	;RP0=0, select bank0
	bcf	(96/8),(96)&7	;volatile
	line	2623
	
i1l8863:	
;main.c: 2622: }
;main.c: 2623: if(TMR2IF)
	btfss	(97/8),(97)&7	;volatile
	goto	u707_21
	goto	u707_20
u707_21:
	goto	i1l8869
u707_20:
	line	2625
	
i1l8865:	
;main.c: 2624: {
;main.c: 2625: TMR2IF = 0;
	bcf	(97/8),(97)&7	;volatile
	line	2627
	
i1l8867:	
;main.c: 2627: __CMS_TouchKeyValue();
	fcall	___CMS_TouchKeyValue
	line	2629
	
i1l8869:	
;main.c: 2628: }
;main.c: 2629: if(INTF)
	btfss	(89/8),(89)&7	;volatile
	goto	u708_21
	goto	u708_20
u708_21:
	goto	i1l1490
u708_20:
	line	2631
	
i1l8871:	
;main.c: 2630: {
;main.c: 2631: INTF = 0;
	bcf	(89/8),(89)&7	;volatile
	line	2632
	
i1l8873:	
;main.c: 2632: PureTDSTyp.HzCount++;
	bcf	status, 5	;RP0=0, select bank2
	bsf	status, 6	;RP1=1, select bank2
	incf	0+(_PureTDSTyp)^0100h+0Dh,f
	skipnz
	incf	1+(_PureTDSTyp)^0100h+0Dh,f
	line	2635
	
i1l1490:	
	movf	(??_Timer1_Isr+3),w
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	movf	(??_Timer1_Isr+2),w
	movwf	pclath
	movf	(??_Timer1_Isr+1),w
	movwf	fsr0
	swapf	(??_Timer1_Isr+0)^0FFFFFF80h,w
	movwf	status
	swapf	saved_w,f
	swapf	saved_w,w
	retfie
	opt stack 0
GLOBAL	__end_of_Timer1_Isr
	__end_of_Timer1_Isr:
	signat	_Timer1_Isr,89
	global	___CMS_TouchKeyValue

;; *************** function ___CMS_TouchKeyValue *****************
;; Defined at:
;;		line 1 in file "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
;; Parameters:    Size  Location     Type
;;		None
;; Auto vars:     Size  Location     Type
;;		None
;; Return value:  Size  Location     Type
;;                  1    wreg      void 
;; Registers used:
;;		wreg, fsr0l, fsr0h, status,2, status,0, btemp+1, pclath
;; Tracked objects:
;;		On entry : 300/0
;;		On exit  : 0/0
;;		Unchanged: 0/0
;; Data sizes:     COMMON   BANK0   BANK1   BANK2
;;      Params:         0       0       0       0
;;      Locals:         0       0       0       0
;;      Temps:          0       0       0       0
;;      Totals:         0       0       0       0
;;Total ram usage:        0 bytes
;; Hardware stack levels used:    2
;; This function calls:
;;		Nothing
;; This function is called by:
;;		_Timer1_Isr
;; This function uses a non-reentrant model
;;
psect	text66,local,class=CODE,delta=2,merge=1,group=1
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
global __ptext66
__ptext66:	;psect for function ___CMS_TouchKeyValue
psect	text66
	file	"G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
	line	1
	global	__size_of___CMS_TouchKeyValue
	__size_of___CMS_TouchKeyValue	equ	__end_of___CMS_TouchKeyValue-___CMS_TouchKeyValue
	
___CMS_TouchKeyValue:	
;incstack = 0
	opt	stack 2
; Regs used in ___CMS_TouchKeyValue: [wreg-fsr0h+status,2+status,0+btemp+1+pclath]
	
i1l8759:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt nolist ;# 
psect	text66
	btfss	(_926/8),(_926)&7	;volatile
	goto	u699_21
	goto	u699_20
u699_21:
	goto	i1l3658
u699_20:
	
i1l8761:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	btfss	(13),(6)&7	;volatile
	goto	u700_21
	goto	u700_20
u700_21:
	goto	i1l3658
u700_20:
	
i1l8763:	
	bcf	(13)+(6/8),(6)&7	;volatile
	
i1l8765:	
	movf	((_918)),w	;volatile
	btfss	status,2
	goto	u701_21
	goto	u701_20
u701_21:
	goto	i1l3658
u701_20:
	
i1l8767:	
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movf	(415)^0180h,w	;volatile
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_922)	;volatile
	movlw	low(01h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
i1l8769:	
	clrc
	rlf	(_919),w	;volatile
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(411)^0180h,w	;volatile
	bsf	status, 7	;select IRP bank3
	movwf	indf
	incf	fsr0,f
	movf	(412)^0180h,w	;volatile
	movwf	indf
	
i1l8771:	
	clrc
	rlf	(_919),w	;volatile
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(409)^0180h,w	;volatile
	movwf	indf
	incf	fsr0,f
	movf	(410)^0180h,w	;volatile
	movwf	indf
	movlw	low(08h)
	movwf	(415)^0180h	;volatile
	
i1l8773:	
	clrc
	rlf	(_919),w	;volatile
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	movf	(413)^0180h,w	;volatile
	movwf	indf
	incf	fsr0,f
	movf	(414)^0180h,w	;volatile
	movwf	indf
	
i1l8775:	
	movlw	low(02h)
	incf	(_919),f	;volatile
	subwf	((_919)),w	;volatile
	skipc
	goto	u702_21
	goto	u702_20
u702_21:
	goto	i1l8781
u702_20:
	
i1l8777:	
	clrf	(_919)	;volatile
	
i1l8779:	
	movlw	low(01h)
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	(_918)	;volatile
	goto	i1l8815
	
i1l8781:	
	movlw	low(0C2h)
	andwf	(400)^0180h,f	;volatile
	movlw	low(0E0h)
	andwf	(401)^0180h,f	;volatile
	
i1l8783:	
	movf	(_919),w
	addlw	low(((_gc_Table_KeyChannel)|8000h))
	movwf	fsr0
	movlw	high(((_gc_Table_KeyChannel)|8000h))
	skipnc
	addlw	1
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movwf	btemp+1
	fcall	stringtab
	andlw	01Fh
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(401)^0180h,f	;volatile
	
i1l8785:	
	movlw	low(010h)
	movwf	(415)^0180h	;volatile
	
i1l8787:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	((_921)),w	;volatile
	btfss	status,2
	goto	u703_21
	goto	u703_20
u703_21:
	goto	i1l8799
u703_20:
	
i1l8789:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(_923)	;volatile
	
i1l8791:	
	movlw	low(0Fh)
	andwf	(_923),f	;volatile
	
i1l8793:	
	movlw	low(0F1h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(405)^0180h,f	;volatile
	
i1l8795:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_923),w
	addlw	low(((_sc_CurStep_Table)|8000h))
	movwf	fsr0
	movlw	high(((_sc_CurStep_Table)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(405)^0180h,f	;volatile
	
i1l8797:	
	movf	(_919),w
	addlw	low(416|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(406)^0180h	;volatile
	goto	i1l8809
	
i1l8799:	
	movf	(_919),w
	addlw	low(448|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	swapf	indf,w
	andlw	(0ffh shr 4) & 0ffh
	movwf	(_923)	;volatile
	
i1l8801:	
	movlw	low(0Fh)
	andwf	(_923),f	;volatile
	
i1l8803:	
	movlw	low(0F1h)
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	andwf	(405)^0180h,f	;volatile
	
i1l8805:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_923),w
	addlw	low(((_sc_CurStep_Table)|8000h))
	movwf	fsr0
	movlw	high(((_sc_CurStep_Table)|8000h))
	skipnc
	addlw	1
	movwf	btemp+1
	fcall	stringtab
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	iorwf	(405)^0180h,f	;volatile
	
i1l8807:	
	movf	(_919),w
	addlw	low(432|((0x1)<<8))&0ffh
	movwf	fsr0
	bsf	status, 7	;select IRP bank3
	movf	indf,w
	movwf	(406)^0180h	;volatile
	
i1l8809:	
	movf	(406)^0180h,w	;volatile
	movwf	(407)^0180h	;volatile
	
i1l8813:	
	bsf	(400)^0180h+(0/8),(0)&7	;volatile
	
i1l8815:	
	bcf	status, 5	;RP0=0, select bank0
	bcf	status, 6	;RP1=0, select bank0
	movf	(_922),w	;volatile
	bsf	status, 5	;RP0=1, select bank3
	bsf	status, 6	;RP1=1, select bank3
	movwf	(415)^0180h	;volatile
	
i1l3658:	
# 1 "G:\Work\touch\Դ\79FT73xB_8F070x\CS��\CheckTouchKey_8F070x_CS_REDUCE_V1.10(Դ)\CheckTouchKey_8F070x_CS_V1.10.c"
opt list ;# 
psect	text66
	
i1l3667:	
	return
	opt stack 0
GLOBAL	__end_of___CMS_TouchKeyValue
	__end_of___CMS_TouchKeyValue:
	signat	___CMS_TouchKeyValue,89
global	___latbits
___latbits	equ	2
	global	btemp
	btemp set 07Eh

	DABS	1,126,2	;btemp
	global	wtemp0
	wtemp0 set btemp+0
	end

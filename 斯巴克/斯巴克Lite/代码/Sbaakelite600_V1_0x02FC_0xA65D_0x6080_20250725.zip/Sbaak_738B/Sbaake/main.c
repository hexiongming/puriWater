

/*
  ******************************************************************************
  * @file    main.c
  * @author  
  * @version V0.95
  * @date    2023/08/30
  ******************************************************************************
  *THIS SOFTWARE WHICH IS FOR ILLUSTRATIVE PURPOSES ONLY WHICH PROVIDES 
  *CUSTOMER WITH CODING INFORMATION REGARDING THEIR PRODUCTS.
  *APT CHIP SHALL NOT BE HELD RES ��  PONSIBILITY ADN LIABILITY FOR ANY DIRECT, 
  *INDIRECT DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE CONTENT OF 
  *SUCH SOFTWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING INFORMATION 
  *CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.AND APT CHIP RESERVES 
  *THE RIGHT TO MAKE CHANGES IN THE SOFTWARE WITHOUT NOTIFICATION
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include <cms.h>					//оƬͷ�ļ�������ݹ���ѡ���Զ�Ѱ�Ҷ�Ӧ�ͺ�ͷ�ļ�

 
/* defines -------------------------------------------------------------------*/

/* externs Register-------------------------------------------------------------------*/
//extern volatile unsigned long dwKey_Map;		//touch key press result
/* externs function-------------------------------------------------------------------*/


#define	Main_F
#include "delay.h"
#include "mytype.h"
#include "Touch_Kscan_Library.h"
#include "REL_Sender.h"
#include "Func.h"
#include "KeyFunc.h"

/****************************************************
//define
*****************************************************/

/*
typedef enum 
{
	LedOn=0,	
	LedOff=1,	
	LedFastFlash=2,
	LedFlash=3,
	
}LedStat;
*/

#define NTC_Max_Num   50
#define Pure_Max_Num   188    
#define Raw_Max_Num   488


const U16_T PureHz_Tab[]=
{
28, 38, 48, 58, 68, 78, 88, 98, 108, 118,  // 0-9   +10
131, 144, 156, 169, 182, 195, 208, 221, 234, 247,  //10-19	+13
255, 263, 271, 281, 291, 301, 311,   321,   331,   341,        // 20-29  +10
350,   363,   375,   385,   395,   405,  415,   425,   435,   445,  //30-39
457,  470,   482,    493,   503,   513,  523,   533,   543,   553,//40-49
563,  570,   580,	590,	  600,   610,  620,   631,  642,    653,  //50-59
667,  681,   695,     710,   723,  737,  747,   757,  767,    777,  //60-69
787,  797,   807,     817,   827,  835,  843,   851,  855,    860,  //70-79  +8
863,  868,   876,    884,    892,  900,  908,   916,  924,   932,  //80-89   +8
940,  948,   956,    964,    972,  980,  988,  996,   1004,1012, //90-99  +8
1020,1035,1050,  1058, 1065, 1073, 1080, 1088, 1096, 1103, //100-109
1111, 1118,1126, 1134, 1141, 1149, 1156, 1164, 1172, 1179, // 110-119
1187, 1194, 1202, 1210, 1217, 1225, 1232, 1240, 1248, 1255, //120-129
1263, 1270, 1278, 1286, 1293, 1301, 1308, 1316, 1324, 1331, // 130-139
1339, 1346, 1354, 1362, 1369, 1377, 1384, 1388, 1392, 1396, //140-149,
1400, 1404, 1408, 1412, 1416, 1420,1424, 1428, 1432, 1436, //150-159
1440, 1444, 1448, 1452, 1456, 1460, 1464, 1468, 1472, 1476, //160-169
1480, 1484, 1488, 1492, 1496, 1500, 1504, 1508, 1512, 1516, // 179-179
1520, 1524, 1528, 1532, 1536, 1540, 1544, 1548, 1552, 1556, //180-189

};
/*
const U16_T RawHz_Tab[]=
{
5, 10, 15, 20, 25,30, 35, 40, 44, 49,    //0-9
54, 59, 64, 68, 73, 78, 83, 88, 93, 98,    //10-19
103, 108, 113, 118, 122, 127, 132, 137, 142, 147,  //20-29
152, 157, 162, 167, 171, 176, 181, 186, 191, 196,  //30-39
201, 205, 209, 213, 217, 221, 225, 229, 233, 237, //40-49
241, 245, 249, 253, 257, 261, 265, 269, 273, 277, //50-59
281, 285, 289, 293, 297, 301, 305, 309, 313, 317, //60-69
321, 325, 329, 333, 338, 342, 347, 351, 356, 360, //70-79
365, 369, 374, 378, 383, 387, 392, 396, 399, 402, //80-89
405, 408, 412, 415, 418, 421, 424, 427, 430, 433, //90-99
436, 439, 443, 446, 449, 452, 455, 458, 460, 463, //100-109
466, 468, 471, 474, 477, 479, 482, 485, 487, 490, //110-119
493, 495, 498, 501, 504, 506, 509, 512, 514, 518, //120-129
521, 524, 527, 530, 534, 537, 540, 543, 546, 550, //130-139
553, 556, 559, 562, 566, 569, 572, 575, 578, 582, //140-149
585, 588, 591, 594, 598, 601, 603, 606, 608, 611, //150-159
613, 616, 618, 621, 623, 626, 628, 631, 633, 636, //160-169
638, 641, 643, 646, 648, 651, 653, 656, 658, 661, //170-179
663, 666, 668, 670, 671, 673, 675, 677, 678, 680, //180-189
682, 683, 685, 687, 688, 690, 692, 694, 695, 697, //190-199
699, 700, 702, 704, 705, 707, 709, 711, 712, 714, //200-209
716, 717, 719, 721, 722, 724, 726, 728, 729, 731, //210-219
732, 734, 736, 738, 739, 741, 743, 744, 746, 748, //220-229
749, 751, 753, 755, 756, 758, 760, 761, 763, 765, //230-239
766, 768, 770, 772, 773, 775, 777, 778, 780, 782, //240-249
783, 785, 787, 789, 790, 792, 794, 795, 797, 799, //250-259
800, 802, 804, 806, 807, 809, 811, 812, 814, 816, //260-269
817, 819, 821, 823, 824, 826, 828, 829, 831, 833, //270-279
834, 836, 838, 840, 841, 843, 845, 846, 848, 849, //280-289
850, 851, 852, 853, 854, 855, 856, 857, 858, 859, //290-299
860, 861, 862, 863, 864, 865, 866, 867, 868, 869, //300-309
870, 871, 872, 873, 874, 875, 876, 877, 878, 879, //310-319
880, 881, 882, 883, 884, 885, 886, 887, 888, 889, //320-329
890, 891, 892, 893, 894, 895, 896, 897, 898, 899, //330-339
900, 901, 902, 903, 904, 905, 906, 907, 908, 909, //340-349
910, 911, 912, 913, 914, 915, 916, 917, 918, 919, //350-359
920, 921, 922, 923, 924, 925, 926, 927, 928, 929, //360-369
930, 931, 932, 933, 934, 935, 936, 937, 938, 939, //370-3579
940, 941, 942, 943, 944, 945, 946, 947, 948, 949, //380-389
950, 951, 952, 953, 954, 955, 956, 957, 958, 959, //390-399
960, 961, 962, 963, 964, 965, 966, 967, 968, 969, //400-409
970, 971, 972, 973, 974, 975, 976, 977, 978, 979, //410-419
980, 981, 982, 983, 984, 985, 986, 987, 988, 989, //420-429
990, 991, 992, 993, 994, 995, 996, 997, 998, 999, //430-439
1000, 1001, 1002, 1003, 1004, 1005, 1006,1007, 1008, 1009, //440-449
};
*/



const U16_T NTC_Tab[]=
{
	3004, 2968, 2933, 2897, 2860, 2823, 2786, 2748, 2711, 2672,  // 0-9
	2634, 2595, 2556, 2517, 2478, 2439, 2400, 2360, 2321, 2282,   //10-19
	2243, 2203, 2164, 2125, 2087, 2048, 2010, 1972, 1934, 1896,  // 20-29
	1859, 1822,1785, 1749, 1713, 1678, 1643, 1609, 1574, 1541,   //30-39
	1508, 1475, 1443, 1411, 1380, 1349, 1319, 1289, 1260, 		//40-48
	0,
};



#define	LedOff 0	
#define	LedOn 1	
#define	LedFastFlash 2
#define	LedFlash 3
#define	LedBreath 4
#define	LedFactotyFlash 5



#define  Max_Tx_Num 0x11U

#if G800==G_800

typedef struct
{
	U8_T Tx_FH1;
	U8_T Tx_FH2;
	U8_T Tx_TotalLength;
	U8_T Tx_FilterLed;
	U8_T Tx_Wifi;
	U8_T Tx_TdsLed;
	U8_T Tx_TdsData_1;
	U8_T Tx_TdsData_2;
	U8_T Tx_ErrorLed;
	U8_T Tx_ErrorState;
	
	U8_T Tx_Mode;	
	U8_T Reserver11;
	U8_T Reserver12;
	U8_T Reserver13;
	U8_T Reserver14;
	U8_T Reserver15;
	U8_T Tx_Check;
}TxTyp;
typedef union
{
	TxTyp TxType;
	U8_T Tx_Tab[Max_Tx_Num];
}T_Type;

static T_Type Tx_Type;

#endif
//static U8_T Timer_DisplayTds_1s;
//static U8_T  DisplayTdsType;
static U8_T FilterBuzzer_1s;
static U8_T Temp_Ntc;

#define Tube_A1  8
#define Tube_B1  10
#define Tube_C1  15
#define Tube_D1  14
#define Tube_E1  12
#define Tube_F1  9
#define Tube_G1  0

#define Tube_H1  2

#define Tube_COM1  11
#define Tube_COM2  6

#define Temp_C  Tube_H1
#define Water_150ML  Tube_A1
#define Water_300ML  Tube_F1
#define Water_500ML  Tube_B1


#define Indicate_COM3  12

#define Degree_C_H1  2


#define OneNixieTube 0
#define TwoNixeTube 1
#define IndicationLed 2
#define OffAllLed 4




#define Off_G   0
#define On_G  1

#define ErrorU    12
#define ErrorE    10
#define ErrorNixie    0x79    

#define Nixe_Off  11





#define Power_0   0
#define Power_1  1
#define Power_2   2
#define Power_3   3
#define Power_4   4
#define Power_5   5

#define Lock 1
#define Unlock 0
#define T_25c    0
#define T_45c    1
#define T_55c    2
#define T_65c    3
#define T_75c    4
#define T_85c    5
#define T_99c    6


#define Ml_150   0x00
#define Ml_300   0x05
#define Ml_500   	    0x01
#define Ml_AllOff  	    0x03
#define NotWater  	0x07
#define ChildLock       0x06


#define Ml_All_0ff   0b11011100

#define NotWaterOff   0b01111111
#define ChildLockOff  0b10111111



#define NotWaFlag      (U8_T)(1<<1)
#define InTempFlag      (U8_T)(1<<5)
#define OutTempFlag      (U8_T)(1<<0)
#define HighTempFlag      (U8_T)(1<<2)
#define ErrorEUFlag      (U8_T)(1<<7)

static U8_T Time_Power_1s;
 static U16_T  PrePCFu16Day;
  static U16_T  PreROu16Day;
    static U16_T  FilterRst_1s;

U8_T ErrorVar;
// U8_T Time_flag_10ms;
static U16_T Timer_WashRun_1s;
//exter U16_T Timer_DisplayTds_1s;

static U16_T Timer_Standby_1s;
static U16_T Timer_BackT_1H;

static U16_T Timer_Standby_1H;
/*
unsigned char   NixieTube[]={
	0x3f,  //0
	0x06,  //1//1
	0x5b,//2            //2
	0x4f,  // 3
	0x66,  // 4
	0x6d,   //5
	0x7d,  // 6
	0X07,  // 7
	0x7f,  // 8
	0x6f,  //9
	0x79,  //E
	0x00,  //off
	0x3e,  //u

};	
*/
/*
unsigned char   Marquee[]={
	0x01,  //0
	0x02,  //1//1
	0x04,//2            //2
	0x08,  // 3
	0x10,  // 4s
	0x20,   //5
	0x40,  // 6
};	
*/
/*
unsigned char   Marquee1[]={
	(0b00111001),  //0
	(0b00111001),  //1//1
	(0b00111001),//2            //2
	(0b00111001),  // 3
	(0b00110001),  //0
	(0b00101001),  //1//1
	(0b00011001),//2            //2
	(0b00110000),  // 3
};
*/
/*
unsigned char   Marquee2[]={
	(0b00001110),  //0
	(0b00001101),  //1//1
	(0b00001011),//2            //2
	(0b00000111),  // 3
	(0b00001111),  //0
	(0b00001111),  //1//1
	(0b00001111),//2            //2
	(0b00001111),  // 3
};
*/
/*
unsigned char   Marquee1[]={
	(0b00010001),  //0
	(0b00000000),  //0
	(0b00101000),  //1//1
	(0b00000000),  //0
};

unsigned char   Marquee2[]={
	(0b00001010),  //0
	(0b00000000),  //0
	(0b00000101),  //1//1
	(0b00000000),  //0
};*/



static U16_T GetCurTdsHz(TDSType_t * AdPtr,U16_T* Tab,U16_T index)
{
    U16_T tmp, i;	
    tmp=0x00;
 
	if(AdPtr->TdsHz<Tab[0])
	{
	}
	else if(AdPtr->TdsHz>=Tab[index]){tmp=index;}
	else
	{
	    for(i = 10; i < index; )
	    {
		if(AdPtr->TdsHz >= Tab[i]){tmp = i;}
		i += 10;
	    }
	    while(AdPtr->TdsHz > Tab[tmp++]);
	    if(tmp){tmp--;}
	}
	return(tmp); 

}


U8_T Dec(U8_T *var,U8_T max)
{
	 if((*var)){(*var)--;}
	 else{(*var)=max;return(1);}

	 return(0);
}

U8_T DecF(U16_T *var,U16_T max)
{
	 if((*var)){(*var)--;}
	 else{return(1);}

	 return(0);
}

void SetFilterDelayReset(Filter_time_t *TimPtr,U16_T Day,U8_T hour,U8_T min,U16_T sec)
{ 
    TimPtr->u16Day=Day;	
    TimPtr->u8Hour=hour;
    TimPtr->u8Minute=min;
    TimPtr->u8Second=sec;
}

U8_T GetDelayFilterFlag(Filter_time_t * PtrMin)
{ 	

		 if(Dec(&PtrMin->u8Second,FILTER_X_SEC))
		 {
				if(Dec(&PtrMin->u8Minute,FILTER_X_MIN))
				{
					 if(Dec(&PtrMin->u8Hour,FILTER_X_HOUR))
					 {
					 	 if(DecF(&PtrMin->u16Day,65535))
						 {
					 		return(1);
					 	}
					 }				
				}
		}
		if(FilterFastCheck==1){  // //Filter element acceleration test - standby
			if(PtrMin->u16Day>=1)
				PtrMin->u16Day-=1;
			else
				PtrMin->u16Day=0;
		}
	
  return(0x00);
}


void TDS_Handle(TDSType_t  *TDSTyp,U8_T Type){
#if 0
	 F32_T NTC_=0;
	 F32_T Muni_c=0;
	 U16_T PreTdsData=0;
	 
	int i=0;
	(TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)])=(TDSTyp->HzCount);     // 1 S comperlate Hz
	(TDSTyp->HzCount)=0;

#ifdef TestHz
	Muni_c=0;
#else
	if(Mode!=FactoryMod){
		if(Type==Pure_Flag){
			NTC_=(F32_T)(0.01*(Temp_Ntc-25));
			Muni_c=(F32_T)(1+NTC_);
			(TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)])=(((F32_T)TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)])/(F32_T)(Muni_c));
		}
		else
		{
			Muni_c=0;
		}
	}
#endif	
#else
	U32_T NTC_=0;
	 U32_T Muni_c=0;
	 U16_T PreTdsData=0;
	 
	uint i=0;
	(TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)])=(TDSTyp->HzCount);     // 1 S comperlate Hz
	(TDSTyp->HzCount)=0;

#ifdef TestHz
	Muni_c=0;
#else
	if(Mode!=FactoryMod){
		if(Type==Pure_Flag){

				if(Temp_Ntc >= 25){
					NTC_ = (U32_T)(Temp_Ntc -25);		// 1~230
					NTC_ += 100;				// 101~330   ---> 1.01~3.3
				}
				else {
					NTC_ = (U32_T)(25-Temp_Ntc);	
					NTC_ = 100-NTC_;			// 1~0.75	
				}
				
				Muni_c = TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)];
				Muni_c *= 100;
				Muni_c /= NTC_;
				TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)] = (U8_T)Muni_c;			
		}
		else
		{
			Muni_c=0;
		}
	}
#endif	
#endif
	
	/*
	if(TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)]>=TDSTyp->TdsHzMin)	{
		TDSTyp->TdsHzMin=TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)];
	}
	if(TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)]<=TDSTyp->TdsHzMax)	{
		TDSTyp->TdsHzMax=TDSTyp->TdsHz_Tab[(TDSTyp->TdsTime)];
	}
	*/
				/*
				  if(++Timer_DisplayTds_1s<=3){       
					  DisplayTdsType=1;
				  }
				  else   if(++Timer_DisplayTds_1s<=6){
				  	DisplayTdsType=2;
				  }
				  else
				  {
				  	Timer_DisplayTds_1s=0;
				  }	
				  */
	(TDSTyp->TdsTime)++;
	if((TDSTyp->TdsTime)>=TdsTab_Max){
		(TDSTyp->TdsTime)=0;

		(TDSTyp->TdsHz)=0;
		for(i=0;i<TdsTab_Max;i++){
			TDSTyp->TdsHz+=TDSTyp->TdsHz_Tab[i];
		}
		(TDSTyp->TdsHz)/=TdsTab_Max;
		
#ifdef TestHz
	TDSTyp->TdsData=TDSTyp->TdsHz;
#else		
//		if(Type==Pure_Flag){
			PreTdsData=TDSTyp->TdsData;
			TDSTyp->TdsData=GetCurTdsHz(TDSTyp,(U16_T *)PureHz_Tab,Pure_Max_Num);
			if(Mode!=FactoryMod){
				if(TdsMake_Flag==0){
					if(TDSTyp->TdsData>=PreTdsData){
						TdsCk60sFlag^=1;
						if(TdsCk60sFlag){
							TDSTyp->TdsData=PreTdsData+3;
						}
						else
						{
							TDSTyp->TdsData=PreTdsData+2;
						}
					}
					else
					{
						TdsMake_Flag=1;
					}
				}
			}
		
			
//		}
//		else
//		{
		//	TDSTyp->TdsData=TDSTyp->TdsHz;
//			TDSTyp->TdsHz=(F32_T)(TDSTyp->TdsHz*1.5);
//			TDSTyp->TdsData=GetCurTdsHz(TDSTyp,RawHz_Tab,Raw_Max_Num);
//		}

#endif		
		if(TDSTyp->TdsData>999){
			TDSTyp->TdsData=999;
		}

// 3S Update Display		
		
	}
	
}

void Time_Count_Func(void){
	
	if(Time_flag_10ms){		    //10MA ADD
		Time_flag_10ms=0;
		
			AD_Testing(1,15,0);
			__CMS_CheckTouchKey();
			CheckKey();
			 
			if(Mode!=FactoryMod)
			 FilterLifeFunc();		
			 TaskAlarmHandle();
			Led_Handle();	


		
		FilterKeyInputRest();
		Time_100ms++;
		if(Time_100ms>=10){              //100MS ADD
			Time_100ms=0;
			 Timer_Power_100ms++;	 
		//	 Timer_HISoff_100ms++;
			Time_1s++;				
			if(Time_1s>=10){      // 1s add 
				Time_1s=0;
				if(Mode!=PowerMode){
					Tx_Display();
				}	
				if(Mode!=PowerMode)
				ErrorHandle();
					
				if(Time_Power_1s<0xf0)
					Time_Power_1s++;
				 if(WriteEEP_Flag==1){
				 		WriteEEP_Flag=0;
				 		Page_ProgramData();
				 }			
				 if(FilterRst_1s<0xfff0)
				 FilterRst_1s++;


				if(MotoFalg==1){
					Timer_LongGetWater_1s++;
				}
				else
				{
					Timer_LongGetWater_1s=0;
				}
				 
				if(GetWaterState==GetWaterMod){
					BackRunFlag=0;
					BackRun12HFlag=0;
					Wash72HFlag=0;
					Time_GetWater_1s++;
					Timer_Standby_1s=0;
					Timer_BackT_1H=0;
					
					if(FilterFastCheck==1){  //Filter element acceleration test - Water sampling
						FilterROGetWater+=Unit_L;
						FilterPCFGetWater+=Unit_L;
					}					
					
					Time_made_1s++;
				TDS_KG_On;
#ifdef TestHz
						
				//		TDS_Handle(&RawTDSTyp,Raw_Flag);
						TDS_Handle(&PureTDSTyp,Pure_Flag);
#else
					
					if(++Timer_TdsMake_1s>=60){
						TdsMake_Flag=1;
					}
					//	TDS_Handle(&RawTDSTyp,Raw_Flag);
						TDS_Handle(&PureTDSTyp,Pure_Flag);
#endif	
		
				
					
					if((FilterROState==FilterExpire)||(FilterPCFState==FilterExpire)){
						FilterBuzzer_1s++;
						if(FilterBuzzer_1s>=2){
							FilterBuzzer_1s=0;
							BuzzerSet(1, Bu_1s);
						}
					}				
				}
				else
				{
					FilterBuzzer_1s=0;
					TdsCk60sFlag=0;
					if((Time_made_1s>=300)&&(Mode!=ErrorMode)){
						Time_made_1s=0;
						if(StandByStatus!=WashState){
							SetStandbyState(WashState,&WashRunTime, 6);
						}
						else
						{
							if(StandByStatus!=BackState){
								if(WashRunTime-Timer_WashRun_1s<6){  //if getwater finish wash time <6S,into makewater 5min wash
									SetStandbyState(WashState,&WashRunTime, 6);
								}
							}
						}
					}					
		
					TDS_KG_Off;  
					TdsMake_Flag=0;
					Timer_TdsMake_1s=0;
					 Timer_WashRun_1s++;
					
					Timer_Standby_1s++;
					
				}
				
				
				  


				GetDelayFilterFlag(&FilterPCF_time);
				GetDelayFilterFlag(&FilterRO_time);
			}
		}
		
	}


}

/*
void  Tx_Display(void){
	int i;
	U8_T Sum_Tot=0;
	U8_T Temp1=0;
	
//	if(Mode==SleepMode){
//		Tx_Type.TxType.Tx_FilterPCFLed=FilterLedOff;
//		Tx_Type.TxType.Tx_TdsLed=FilterLedOff;
//	}
//	else
//	{
		Tx_Type.TxType.Tx_FilterPCFLed=FilterPCFState;          //PCF Filter register
//	}
	if(FilterROState==FilterNormal){
		Temp1=0x02;
	}
	else if(FilterROState==FilterPreWarning)
	{
		Temp1=0x03;
	}
	else if(FilterROState==FilterExpire)
	{
		Temp1=0x04;
	}
	Tx_Type.TxType.Tx_FilterROLed=Temp1;          //RO  Filter register
//	if(DiaplayWashState==WashLedOff){
//		Tx_Type.TxType.Tx_FilterROLed=WashLedOff;          //RO  Filter register
//		Tx_Type.TxType.Tx_FilterPCFLed=WashLedOff;
//	}

	
	
	if(DisplayTdsType==1){								//TDS register
		
		Tx_Type.TxType.Tx_TdsData_1=PureTDSTyp.TdsData>>8;
		Tx_Type.TxType.Tx_TdsData_2=PureTDSTyp.TdsData;
	}
	else
	{
		
		Tx_Type.TxType.Tx_TdsData_1=RawTDSTyp.TdsData>>8;	
		Tx_Type.TxType.Tx_TdsData_2=RawTDSTyp.TdsData;
	}
	Tx_Type.TxType.Tx_TdsLed=DisplayTdsType;
	if(GetWaterState==GetStyMod){               //no makeing water into Led Off		
		Tx_Type.TxType.Tx_FilterROLed=WashLedOff;         
		Tx_Type.TxType.Tx_FilterPCFLed=WashLedOff;
		Tx_Type.TxType.Tx_TdsLed=WashLedOff;
		
		Tx_Type.TxType.Tx_TdsData_1=0xff;	
		Tx_Type.TxType.Tx_TdsData_2=0x00;
	}
	
//	Temp1=StandByStatus;
//	if(Temp1>=1) Temp1=1;	     // washing and draining to send state wash led  falsh
	Tx_Type.TxType.Tx_WashLed=DiaplayWashState;      //Wash state Led

	Tx_Type.TxType.Tx_ErrorState=ErrorVar;    //Error register
	
	Tx_Type.TxType.Tx_Mode=GetWaterState;    // State register
	
	
	
	for(i=2;i<Max_Tx_Num-1;i++){
		Sum_Tot+=Tx_Type.Tx_Tab[i];
	}
//	Tx_Type.TxType.Reserver11=PuarHz>>8;
//	Tx_Type.TxType.Reserver12=PuarHz;
//	Tx_Type.TxType.Reserver13=RawHz>>8;
//	Tx_Type.TxType.Reserver14=RawHz;
	Tx_Type.TxType.Tx_Check=Sum_Tot+Max_Tx_Num;                //CHECK SUM
	for(i=0;i<Max_Tx_Num;i++){
		UARTTxByte(UART1,Tx_Type.Tx_Tab[i]);
	//	if(i<5)    =
	//	Rx_Type.Rx_Tab[i]=0;        //Get Clean RX ML Value, 
	}
	Time_Tx_10ms=0;
	
}
*/
#if 0
void  GetWaterSend(void){
/*
	int i;
	U16_T Sum_Tot;
	Sum_Tot=0;
	for(i=1;i<Max_Tx_Num-2;i++){
		Sum_Tot+=Tx_Type.Tx_Tab[i];
	}
	Tx_Type.TxType.Tx_CheckL=Sum_Tot;
	Tx_Type.TxType.Tx_CheckH=Sum_Tot>>8;

	for(i=0;i<Max_Tx_Num;i++){
		UARTTxByte(UART1,Tx_Type.Tx_Tab[i]);
		if(i<5)    
		Rx_Type.Rx_Tab[i]=0;        //Get Clean RX ML Value, 
	}
	Time_Tx_10ms=0;
	*/
}
#endif

void AllLedFlash(U8_T Type){
	uint i;
	for(i=0;i<Max_Led_Num;i++){
		LedSetSt(i, Type);
	}
}


/*
void IndicateLedAllOff(void){
	uint i=0;
	for(i=0;i<Max_Led_Num;i++){
		LedMod[i].LedState=LedOff; 
	}
}
void IndicateLedAllOn(void){
	uint i=0;
	for(i=0;i<Max_Led_Num;i++){
		LedMod[i].LedState=LedOn;
	}
}
*/






/***************************************************/
//uart1_send
/**************************************************/




void LedSetSt(U8_T Num,U8_T Sta){
//	PreLedMod[Num].LedState=LedMod[Num].LedState;		//Keep the last value
	if(LedMod[Num].LedState!=Sta){
		LedMod[Num].LedState=Sta;
		if(LedMod[Num].LedState==LedFastFlash){
			LedMod[Num].LedFlashNum=2;	
			LedFlashFinish_Flag=1;
		}
		else if(LedMod[Num].LedState==LedFactotyFlash){
			LedMod[Num].LedFlashNum=3;	
			LedFlashFinish_Flag=1;
		}	
		LedMod[Num].LedTime=0;
	}
}

void LedControlSt(U8_T Num,U8_T Sta){

	switch(Num){
		case Wash_LedRed:
			if(Sta==On_L){
				LedWashRed_O=On;
			}
			else
			{
				LedWashRed_O=Off;
			}	
			break;
		case Wash_LedBlue:
			if(Sta==On_L){
				LedWashBlue_O=On;
			}
			else
			{
				LedWashBlue_O=Off;
			}	
			break;		
		case AQP_LedRed:
			if(Sta==On_L){
				LedAQPRed_O=On;
			}
			else
			{
				LedAQPRed_O=Off;
			}	
			break;
		case AQP_LedBlue:
			if(Sta==On_L){
				LedAQPBlue_O=On;
			}
			else
			{
				LedAQPBlue_O=Off;
			}	
			break;	
		case in3_LedRed:
			if(Sta==On_L){
				Led3inRed_O=On;
			}
			else
			{
				Led3inRed_O=Off;
			}	
			break;
		case in3_LedBlue:
			if(Sta==On_L){
				Led3inBlue_O=On;
			}
			else
			{
				Led3inBlue_O=Off;
			}
			break;
		case Wifi_LedRed:
			if(Sta==On_L){
				LedWifiRed_O=On;
			}
			else
			{
				LedWifiRed_O=Off;
			}	
			break;
		case Wifi_LedBlue:
			if(Sta==On_L){
				LedWifiBlue_O=On;
			}
			else
			{
				LedWifiBlue_O=Off;
			}			
			break;			
	}
	

}



void Led_Handle(){
	uint i=0;
	
	for(i=0;i<Max_Led_Num;i++){
		LedMod[i].LedTime++;
		switch(LedMod[i].LedState){
			case LedOff:
				LedControlSt(i,Off_L);
				break;
			case LedOn:
				LedControlSt(i,On_L);
				break;
			case LedFastFlash:
				if(LedMod[i].LedFlashNum){
					if(LedMod[i].LedTime<=FastFlashTime){
						LedControlSt(i,Off_L);
					}
					else if(LedMod[i].LedTime<=FastFlashTime*2)
					{
						LedControlSt(i,On_L);
					}
					else
					{
						LedMod[i].LedFlashNum--;
						LedMod[i].LedTime=0;
					}
				}
				else
				{
					LedFlashFinish_Flag=0;
				}
				break;
			case LedFlash:
					if(LedMod[i].LedTime<=FlashTime){
						LedControlSt(i,On_L);
					}
					else if(LedMod[i].LedTime<=FlashTime*2)
					{
						LedControlSt(i,Off_L);
					}
					else
					{
						LedMod[i].LedTime=0;
					}	
						
				break;
			case LedFactotyFlash:
				if(LedMod[i].LedFlashNum){
					if(LedMod[i].LedTime<=FlashTime){
						LedControlSt(i,Off_L);
					}
					else if(LedMod[i].LedTime<=FlashTime*2)
					{
						LedControlSt(i,On_L);
					}
					else
					{
						LedMod[i].LedFlashNum--;
						LedMod[i].LedTime=0;
					}	
				}
				else
				{
					LedFlashFinish_Flag=0;
					LedControlSt(i,Off_L);
					LedMod[i].LedState=LedOff;
				}					
				break;
	
	
		}
	} 



}
/***************************************************/
//key data get
/***************************************************/
/*
U32_T TCH_Ck(U8_T Num){
	U32_T i=0;
	i=1<<Num;
	return i;
}*/
//U8_T Timer_HIS_10ms;
#if 0
void Keymap_Porg(void)
{

	static unsigned int KeyOldFlag = 0;
//	static unsigned char KeyOldFlagH = 0;
	unsigned int i = (unsigned int)((g_KeyFlag[1]<<8) | g_KeyFlag[0]);
	 U8_T temp;

//	unsigned char j = g_KeyFlag[2];
	if(i)
	{
		if(i != KeyOldFlag)
		{
			KeyOldFlag = i;			//�м�⵽����

			if(0x01 & i){temp |= 0x02;}    //TK1
			if(0x02 & i){temp |= 0x04;}   //TK2
		}
	}
	else
	{
		KeyOldFlag = 0;
//	KeyOldFlagH = 0;
		temp&=0x01;
	}
	/*
	if(dwKey_Map!=0)
	{
		if(Key_Map_bk!=dwKey_Map)
		{
			Key_Map_bk=dwKey_Map;
			//GPIO_Write_Low(GPIOB0,1);	
			//
			temp=0;
	//		if(dwKey_Map&TCH_Ck(0))
	//		{
	//			temp |= 1;
	//			nop;
	//		}
			 if(dwKey_Map&TCH_Ck(0))
			{
				temp |= 2;
				nop;
			}
			 if(dwKey_Map&TCH_Ck(16))
			{
				temp |= 4;
				nop;
			}
			 if(dwKey_Map&TCH_Ck(17))
			{
				temp |= 8;
				nop;
			}			
			//......
		}
	}
	else
	{
		Key_Map_bk=0;
		temp = 0;
		//GPIO_Write_High(GPIOB0,1);	
	}
	*/
//	if(Timer_HIS_10ms<0xf0){
//		Timer_HIS_10ms++;
//	}
	if(Read_HallSwitch_IO==0){
	//	Timer_HISoff_100ms=0;
	//	if(Timer_HIS_10ms>=5){
			temp |= 0x01;
	//	}
	}
	else
	{
	//	Timer_HIS_10ms=0; 
	//	if(Timer_HISoff_100ms>=15){
			temp &= ~(0x01);
	//	}
	}


}
#endif


#define F_3IN   0
#define F_AQP     1
static U16_T Date_Temp;
static U16_T ML_Temp;
void FilterTimeHandle(Filter_time_t Filter_time,U8_T *FilterState,U8_T Type,U16_T *FilterGetWater )
{
	
			Date_Temp=14;
			if(FilterRstState==RstSelect) return;
			if(Type==F_3IN){		
				ML_Temp=3650; 
			}
			else
			{
				ML_Temp=10950;
			}
		
			if(Filter_time.u16Day<=0){
			
				*FilterState=FilterExpire;
					if(Type==F_3IN){
						LedSetSt(in3_LedRed,LedOn);
						LedSetSt(in3_LedBlue, LedOff);
					}
					else
					{
						LedSetSt(AQP_LedRed, LedOn);
						LedSetSt(AQP_LedBlue, LedOff);
					}
			}
			else if(Filter_time.u16Day<=Date_Temp)
			{
					if(*FilterState!=FilterPreWarning){
						if(Type==F_3IN){
							LedSetSt(in3_LedRed, LedFlash);
							LedSetSt(in3_LedBlue, LedOff);
						}
						else
						{
							LedSetSt(AQP_LedRed, LedFlash);
							LedSetSt(AQP_LedBlue, LedOff);
						}	
					}
				if(*FilterState<=FilterPreWarning)
				*FilterState=FilterPreWarning;
			}
			else
			{
				if(*FilterState==FilterNormal){
					if(Type==F_3IN){
						LedSetSt(in3_LedRed, LedOff);
						LedSetSt(in3_LedBlue, LedOn);
					}
					else
					{
						LedSetSt(AQP_LedRed, LedOff);
						LedSetSt(AQP_LedBlue, LedOn);
					}
				}
				if(*FilterState<=FilterNormal)
				*FilterState=FilterNormal;
			}


			if(*FilterGetWater>=ML_Temp){        // Get water 150L
	//		if(FilterLifeGetWater>=60){        // Get water 150L
				*FilterState=FilterExpire;
					if(Type==F_3IN){
						LedSetSt(in3_LedRed, LedOn);
						LedSetSt(in3_LedBlue, LedOff);
					}
					else
					{
						LedSetSt(AQP_LedRed, LedOn);
						LedSetSt(AQP_LedBlue, LedOff);
					}				
			}	
			else if(*FilterGetWater>=ML_Temp-140)
	//		else if(FilterLifeGetWater>=30)
			{
					if(*FilterState!=FilterPreWarning){
						if(Type==F_3IN){
							LedSetSt(in3_LedRed, LedFlash);
							LedSetSt(in3_LedBlue, LedOff);
						}
						else
						{
							LedSetSt(AQP_LedRed, LedFlash);
							LedSetSt(AQP_LedBlue, LedOff);
						}	
					}			
				if(*FilterState<=FilterPreWarning)
				*FilterState=FilterPreWarning;
			}
			else
			{
				if(*FilterState==FilterNormal){
					if(Type==F_3IN){
						LedSetSt(in3_LedRed, LedOff);
						LedSetSt(in3_LedBlue, LedOn);
					}
					else
					{
						LedSetSt(AQP_LedRed, LedOff);
						LedSetSt(AQP_LedBlue, LedOn);
					}
				}			
				if(*FilterState<=FilterNormal)
				*FilterState=FilterNormal;
			}
			
}


void FilterLifeFunc(void){

//			RTC_TIMR_DATR_Read(&RTC_TimeDate_buf);	
			
			if((Mode!=PowerMode)&&(Mode!=ErrorMode)&&(LedFlashFinish_Flag==0)){
				FilterTimeHandle(FilterRO_time,&FilterROState,F_AQP,&FilterROGetWater);
	/*******************************************************************************************
	*******************************************************************************************/
				FilterTimeHandle(FilterPCF_time,&FilterPCFState,F_3IN,&FilterPCFGetWater);
				if(FilterFastCheck==1)
				{
					if((FilterPCFState==FilterExpire)&&(FilterROState==FilterExpire)){
						FilterFastCheck=2;
						BuzzerSet(3, Bu_1s);
					}
				}
			}

			

}
/*
void GetStart(void){
	if(GetWaterState!=GetWaterMod){
		GetWaterState=GetWaterMod;
	//	Time_Tx_10ms=0;	
	}

}
*/
void GetStop(void){
	GetWaterState=GetStyMod;
		
}

void ShiftMode_Handle(U8_T Mod){

	Mode=Mod;
	BackValveClose;
	WasteValveClose;	
	switch(Mod){
	//	case ErrorMode:
		case StandbyMode:
			InputValveClose;
			MotoClose;
//			BackValveClose;
//			WasteValveClose;
			GetWaterState=GetStyMod;
			LedSetSt(Wash_LedBlue, LedOff);
			if(StandByStatus==WashState){
				LedSetSt(Wash_LedBlue, LedFlash);
				SetStandbyState(WashState,&WashRunTime, WashRunTime-Timer_WashRun_1s);
			}
			break;
		case GetMode:
			GetWaterState=GetWaterMod;
//			BackValveClose;
//			WasteValveClose;
			InputValveOpen;
			MotoOpen;
			LedSetSt(Wash_LedBlue, LedOn);
			if((FilterROState==FilterExpire)||(FilterPCFState==FilterExpire)){
				BuzzerSet(1, Bu_1s);
			}				
			else if((FilterROState==FilterPreWarning)||(FilterPCFState==FilterPreWarning)){
				BuzzerSet(1, Bu_6s);
			}				
			break;			
	}
//	if(Powerfirst){	
//		LedSetSt(Wash_LedBlue, LedFlash);
//	}	
}
/*
void SleepMode_Handle(void){

}*/
void GetMode_Handle(void){

	

	if(KeyPacket_y[HiVSwitch].KeyState==NotPress)
	{
		ShiftMode_Handle(StandbyMode);
		Timer_Standby_1H=0;
	}
			
	
			if(Time_GetWater_1s>=60){
				Time_GetWater_1s=0;
				GetWater_ML+=Unit_L;     //  2.1L
				/*
				if(Powerfirst){
				
					FilterROGetWater+=1;    // ADD 21L
					if(FilterROGetWater>=25){
						Powerfirst=0;
						EEP_Me=1;
						LedSetSt(Wash_LedBlue, LedOff);
						FilterROGetWater=0;
						SetStandbyState(NornalStopState,&WashRunTime, 0);
					}
					WrterEEP();
				}	
				else
				{
				*/
					if(GetWater_ML>=(Unit_L*10)){    //  21L
						GetWater_ML=0;
						if(FilterROGetWater<0xfff0)
							FilterROGetWater+=Unit_L;    // ADD 21L
						if(FilterPCFGetWater<0xfff0)
							FilterPCFGetWater+=Unit_L;	//ADD  21L
							WrterEEP();
					}
			//	}
			}
#ifdef Debug	
	if((FilterROGetWater>=(2))
	&&(FilterPCFGetWater>=(2))){
#else
			
			if((FilterROGetWater>=(Unit_L*2))
			&&(FilterPCFGetWater>=(Unit_L*2))){
#endif			
				FirstMakeWater=1;
			}
			if(Read_Word_Buff[11]!=0)
			Read_Word_Buff[11]=Ba_run;
	
}





void SetStandbyState(StyStat STY,U8_T *Time,U8_T Da){
	*Time=Da;
	StandByStatus=STY;

	
	

//	DiaplayWashState=WashOn;
	if(STY==WashState){
				
		MotoOpen;
		InputValveOpen;	
		WasteValveOpen;
	//	LedSetSt(Wash_LedBlue, LedFlash);
	}
	else if(STY==BackState){
				
		MotoOpen;
		InputValveOpen;	
		BackValveOpen;
	//	LedSetSt(Wash_LedBlue, LedFlash);
	}	
	else
	{
		WasteValveClose;				
		MotoClose;
		InputValveClose;	
		BackValveClose;
//		if(Powerfirst==0)
//		LedSetSt(Wash_LedBlue, LedOff);
		
	}
	Timer_WashRun_1s=0;

	
}

void WashHandle(void){
	if((LedMod[Wash_LedBlue].LedState==LedOff)&&(StandByStatus==WashState)){
		LedSetSt(Wash_LedBlue, LedFlash);
	}
	if(Timer_WashRun_1s>=WashRunTime){
	//	Timer_BackStandby_1s=0;
	//	StandByStatus=NornalStopState;
	//	if(WashRunTime==DrainT){
	//		BuzzerSet(1, Bu_1s);
	//	}
		Time_made_1s=0;
	//	Timer_Standby_1s=0;
	//	Timer_Standby_1H=0;
		Powerfirst=0;
		LedSetSt(Wash_LedBlue, LedOff);
		SetStandbyState(NornalStopState,&WashRunTime, 0);
	}
}


void StatusFun_Handle()
{
		switch(StandByStatus){
				
			case WashState:
			case BackState:
				WashHandle();
				break;
			case NornalStopState:
				SetStandbyState(NornalStopState,&WashRunTime, 0);
				break;				
		}
}

void FactoryMode_Handle(){
	U8_T Step=0;
	Timer_Power_100ms=0;
	AllLedFlash(LedOff);
	while(1){
		asm("clrwdt");						//clear IWDT	
		GetWaterState=GetWaterMod;
		switch(Step){
			case 0:		
#if G800==G_400

		//	LedSetSt(AQP_LedBlue, LedOn);	
			LedSetSt(Wash_LedBlue, LedOn);	

#elif G800==G_600 

		//	LedSetSt(AQP_LedRed, LedOn);	
			LedSetSt(Wash_LedRed, LedOn);	

#else

		//	LedSetSt(AQP_LedBlue, LedOn);	
			LedSetSt(Wash_LedBlue, LedOn);
		//	LedSetSt(AQP_LedRed, LedOn);	
			LedSetSt(Wash_LedRed, LedOn);			
#endif			
					
				if(Timer_Power_100ms>=10){
		//			AllLedFlash(LedOff);
					Step=1;
				} 
				break;
			case 1: 
				WasteValveOpen;				 
				MotoOpen;
				InputValveOpen;	
				BackValveOpen;
				if(KeyPacket_y[KeyFilter].KeyState==ShortRelease)
				{
					KeyPacket_y[KeyFilter].KeyState=NotPress;
					WasteValveClose;				
					MotoClose;
					InputValveClose;	
					BackValveClose;
					AllLedFlash(LedOff);
					Step=2;
					BuzzerSet(1, Bu_1s);
				}				
				break;
			case 2:
				if(KeyPacket_y[HiVSwitch].KeyState==NotPress)
				{
					LedSetSt(in3_LedRed, LedOff);
					LedSetSt(AQP_LedRed, LedOff);
					LedSetSt(Wash_LedRed, LedOff);	
				}	
				else
				{
					LedSetSt(in3_LedRed, LedOn);
					LedSetSt(AQP_LedRed, LedOn);
					LedSetSt(Wash_LedRed, LedOn);				
				}
				if(KeyPacket_y[KeyWash].KeyState==ShortRelease)
				{
					KeyPacket_y[KeyWash].KeyState=NotPress;
					Step=3;
					AllLedFlash(LedOff);
					BuzzerSet(1, Bu_1s);
				}				
				break;
			case 3:
				
				if(PureTDSTyp.TdsData>10&&PureTDSTyp.TdsData<50){
					LedSetSt(in3_LedBlue, LedOn);
					LedSetSt(AQP_LedBlue, LedOn);
					LedSetSt(Wash_LedBlue, LedOn);					
				}
				else
				{
					LedSetSt(in3_LedRed, LedOn);
					LedSetSt(AQP_LedRed, LedOn);
					LedSetSt(Wash_LedRed, LedOn);					
				}
				if(KeyPacket_y[KeyWash].KeyState==ShortPressDown)
				{
					KeyPacket_y[KeyWash].KeyState=NotPress;
					Step=4;
					AllLedFlash(LedOff);
					BuzzerSet(1, Bu_1s);
				}				
			break;
			 case 4:
				if(Temp_Ntc>15&&PureTDSTyp.TdsData<45){

					LedSetSt(Wash_LedBlue, LedOn);					
				}
				else
				{
					LedSetSt(Wash_LedRed, LedOn);					
				}				
			break;
		}
		Time_Count_Func();
	}
	

}
U8_T  BeepAlmCnt;
U16_T BuzzerFilter,BeepOnTimeCnt;	
/*
void BuzzerON(void)
{
	BuzzerEnableFlag=1;
}
*/
/*
void BuzzerOFF(void)
{
   BuzzerEnableFlag=0;
}*/
void BuzzerSet(uint8_t cnt,uint16_t filter)
{
    BeepAlmCnt = cnt;
    BuzzerFilter = filter;
    BeepOnTimeCnt=BuzzerFilter;		
}
/***************************************************************/
void TaskAlarmHandle(void)
{

    
        if(BeepAlmCnt)
        {
            if(BeepOnTimeCnt)
            {
                BeepOnTimeCnt--;
                
                if(BeepOnTimeCnt>=(BuzzerFilter>>1)){PWM1EN=1;}

                //{BuzzerEnableFlag=1;}
                else	{PWM1EN=0;}
            }
            else
            {
                BeepAlmCnt--;	
                BeepOnTimeCnt=BuzzerFilter;		
            }	
        }
        else
        {	
            BuzzerEnableFlag=0;
        }      
}

void FilterKeyInputRest(void){
	static U16_T FilterSelect_10ms;
	if((Mode==PowerMode)||(Mode==ErrorMode)) return;
	if((KeyPacket_y[KeyFilter].KeyState==LongPressDown)
	&&(KeyPacket_y[KeyWash].KeyState==NotPress))
	{
		KeyPacket_y[KeyFilter].KeyState=SuperPressDown;
		if(Time_Power_1s<=10){
			ShiftMode_Handle(FactoryMod);
			BuzzerSet(1, Bu_1s);
		}
		else
		{
			FilterRstState^=1;
			if(FilterRstState==RstSty){
				FilterSelect_10ms=0;
				if(FilterSelectType==F_3IN)
				{
					PrePCFu16Day=FilterPCF_time.u16Day;
					SetFilterDelayReset(&FilterPCF_time, In3FilterT, 0, 0, 0);
					FilterPCFGetWater=0;
					FilterPCFState=FilterNormal;
					LedSetSt(in3_LedRed, LedOff);
					LedSetSt(in3_LedBlue, LedFastFlash);
					Filter3inRstFlag=1;
				}
				else
				{
					PreROu16Day=FilterRO_time.u16Day;
					SetFilterDelayReset(&FilterRO_time, AQPFilterT, 0, 0, 0);
					FilterROGetWater=0;
					FilterROState=FilterNormal;
					LedSetSt(AQP_LedRed, LedOff);
					LedSetSt(AQP_LedBlue, LedFastFlash);	
					FilterAqpRstFlag=1;
				}	
				FirstMakeWater=0;
				FilterRst_1s=0;
				WrterEEP();
			}
			else
			{	
				FilterSelectType=F_AQP;
			}
		}
		BuzzerSet(1, Bu_1s);
	}	
	if(FilterRstState==RstSelect){
		if(++FilterSelect_10ms>=1000){
			FilterSelect_10ms=0;
			BuzzerSet(1, bu_250ms);
			FilterRstState=RstSty;
			return;

		}
		if(KeyPacket_y[KeyFilter].KeyState==ShortRelease)
		{
			KeyPacket_y[KeyFilter].KeyState==NotPress;
			BuzzerSet(1, bu_250ms);
			FilterSelect_10ms=0;
			FilterSelectType^=1;
		}
		
		if(FilterSelectType==F_3IN){
			LedSetSt(AQP_LedBlue,LedOff);
			LedSetSt(AQP_LedRed,LedOff);
			if(FilterPCFState==FilterNormal){
				LedSetSt(in3_LedBlue, LedFlash);
				LedSetSt(in3_LedRed, LedOff);
			}
			else
			{
				LedSetSt(in3_LedRed, LedFlash);
				LedSetSt(in3_LedBlue, LedOff);
			}
		}
		else
		{
			LedSetSt(in3_LedBlue,LedOff);
			LedSetSt(in3_LedRed,LedOff);
			if(FilterROState==FilterNormal){
				LedSetSt(AQP_LedRed, LedOff);
				LedSetSt(AQP_LedBlue, LedFlash);
			}
			else
			{
				LedSetSt(AQP_LedBlue, LedOff);
				LedSetSt(AQP_LedRed, LedFlash);
			}		
		}
	}

	if((KeyPacket_y[KeyWash].KeyState==LongPressDown)
	&&(KeyPacket_y[KeyFilter].KeyState==LongPressDown))
	{
		KeyPacket_y[KeyWash].KeyState=SuperPressDown;
		KeyPacket_y[KeyFilter].KeyState=SuperPressDown;

		if(Time_Power_1s<=10){
			BuzzerSet(1, Bu_1s);	
	//		Powerfirst=1;
			ShiftMode_Handle(PowerMode);
			PowerStep=Power_3;
			SetFilterDelayReset(&FilterPCF_time, In3FilterT, 0, 0, 0);	
			SetFilterDelayReset(&FilterRO_time, AQPFilterT, 0, 0, 0);
			FilterROGetWater=0;
			FilterPCFGetWater=0;
			FirstMakeWater=0;
			Read_Word_Buff[11]=1;
			WrterEEP();
		}
		else
		{
			
			if((FilterRst_1s<300)&&((Filter3inRstFlag)||(FilterAqpRstFlag))){				
				if(FilterRstState==RstSty){

					BuzzerSet(3, Bu_1s);
					
					
					if(Filter3inRstFlag){
						Filter3inRstFlag=0;
						FilterPCF_time.u16Day=PrePCFu16Day;
						LedSetSt(in3_LedBlue, LedFactotyFlash);
						LedSetSt(in3_LedRed, LedOff);
					}
					if(FilterAqpRstFlag){
						FilterAqpRstFlag=0;
						FilterRO_time.u16Day=PreROu16Day;
						LedSetSt(AQP_LedBlue, LedFactotyFlash);
						LedSetSt(AQP_LedRed, LedOff);
					}
					WrterEEP();
				}
			}
			else
			{
				Filter3inRstFlag=0;
				FilterAqpRstFlag=0;
			}
		}
	}	
}
#define Data_EEP
unsigned char Memory_Write(unsigned int Addr,unsigned char Value)
{
	
	volatile unsigned char i = 0;

										//��Ҫд��ĵ�ַ����EEADDR�Ĵ���
	EEADR = Addr;		
	EEDAT= Value;						//��Ҫд������ݸ�EEPROM�����ݼĴ���
	EECON1 = 0;
	EEPGD = 0;							//�������ݴ洢��
	EECON1 | = 0x10;	//  2.5ms				//��дʱ��10ms,ʱ��ǹ̶���׼,�û����Զ���
	asm("clrwdt");

	
	WREN = 1;								//����д����
	GIE = 0;								//�ر��ж�
	GIE = 0;
	GIE = 0;
	while(GIE)
	{
		GIE = 0;							//ȷ���ж��ѹر�
		if(0 == --i)
		{
			//ע������ʹ�����ж���ִ��GIE = 1�����������δ������									
			GIE = 1;						//���ж�GIE��1
			return 0;	
		}	
	}
	asm("clrwdt");
	
	EECON2 = 0x55;							//��EECON2д��0x55
	EECON2 = 0xaa;							//��EECON2д��0xaa
	WR = 1;									//����д����
	asm("nop");
	asm("nop");
	asm("clrwdt");
	WREN = 0;								//��ֹд��
	//ע������ʹ�����ж���ִ��GIE = 1�����������δ������	
	GIE = 1;							//���ж�GIE��1

	if(WRERR)	return 0;				//д��������							
	else		return 1;				//д���
}


/***********************************************
�������ƣ�Memory_Read
�������ܣ�������/����Ĵ���
��ڲ�����Addr - ��ȡ��ַ
���ڲ��������ض�ȡ��ַ��Ӧ��ֵ
��ע��
1.����EEPROM���ɶ�д8λ���ݣ�����洢�����ɶ�16λ���ݣ�����ʱ��ע�����ߵĲ��졣
************************************************/
unsigned int Memory_Read(unsigned int Addr)
{
	#if defined(Data_EEP)							//��Ҫд��ĵ�ַ����EEADDR�Ĵ���
		EEADR = Addr;
		EEPGD = 0;							//�������ݴ洢��
	#elif defined(Flash_EEP)
		EEADR=(Addr & 0xff);				
		EEADRH=(Addr >> 8);
		EEPGD = 1;							//���ʳ���洢��
	#endif

	RD=1;									//����������
	asm("nop");
	asm("nop");
	
	#if defined(Data_EEP)							
		return (EEDAT);
	#elif defined(Flash_EEP)
		return ((EEDATH << 8) | EEDAT);
	#endif
}

void StandbyMode_Handle(void)
{
/****************************************************************************************************
****************************************************************************************************/
	static U8_T Ti_1h=0;
	/*
	if(Read_Word_Buff[11]==Ba_run){
//#ifdef Debug	
//	if(Timer_Standby_1s>=30){
//#else
		if(Timer_Standby_1s>=300){
//#endif	
			if(BackRunFlag==0){
				BackRunFlag=1;
				SetStandbyState(BackState,&WashRunTime, BackT);
			}
		}
#ifdef Debug	
	if(Timer_BackT_1H>=1){
#else		
	if(Timer_BackT_1H>=12){
#endif	
	//	if(Timer_Standby_1s>=90){
			if(BackRun12HFlag==0){
				BackRun12HFlag=1;
				SetStandbyState(BackState,&WashRunTime, BackT);
				Read_Word_Buff[11]=Ba_Stop;
			}
		}
	}
	*/
#ifdef Debug	
	if(Timer_Standby_1s>=3600)
#else
	if(Timer_Standby_1s>=3600)
#endif	
	{
		Timer_Standby_1s=0;
		if(Timer_Standby_1H<0xf0) 
		Timer_Standby_1H++;
		Timer_BackT_1H++;
		if(++Ti_1h>=10){
			Ti_1h=0; 
			WrterEEP();
		}
	}
#ifdef Debug	
	if(Timer_Standby_1H>=2)
#else	
	if(Timer_Standby_1H>=72)
#endif		
	{
	//	Timer_Standby_1s=0;
		Timer_Standby_1H=0;
		if(Wash72HFlag==0){
		//	Wash72HFlag=1;
			if(StandByStatus==NornalStopState){
				SetStandbyState(WashState,&WashRunTime, WashT);
			}	
		}
	}
/****************************************************************************************************
****************************************************************************************************/



	if((KeyPacket_y[KeyWash].KeyState==LongPressDown)
	&&(KeyPacket_y[KeyFilter].KeyState==NotPress))
	{
		KeyPacket_y[KeyWash].KeyState=SuperPressDown;
		if(Time_Power_1s<=10){
			BuzzerSet(3, Bu_1s);	
			FilterFastCheck=1;
		}
		else
		{	/*
			if(Read_Word_Buff[11]==Ba_Colse){
				Read_Word_Buff[11]=Ba_Stop;
			}
			else
			{
				Read_Word_Buff[11]=Ba_Colse;
			}
			
		//	Read_Word_Buff[11]=(Read_Word_Buff[11]==Ba_Colse)?Ba_Stop:Ba_Colse;
			WrterEEP();
			if(Read_Word_Buff[11]){
				Read_Word_Buff[11]=Ba_Stop;
				Timer_Standby_1s=0;
				Timer_BackT_1H=0;
				BuzzerSet(1, Bu_1s);
				LedSetSt(Wash_LedBlue, LedFactotyFlash);
				LedMod[Wash_LedBlue].LedFlashNum=1;
			}
			else
			{
				LedSetSt(Wash_LedBlue, LedFactotyFlash);
				BuzzerSet(3, Bu_1s);
			}
			*/
		}
	}
		
	if(KeyPacket_y[KeyWash].KeyState==ShortRelease)
	{
		KeyPacket_y[KeyWash].KeyState=NotPress;
		if(Powerfirst==0){            //first power up not into wash
			BuzzerSet(1, bu_250ms);
			if(StandByStatus==WashState)
			{
				LedSetSt(Wash_LedBlue, LedOff);
				SetStandbyState(NornalStopState,&WashRunTime, 0);			
			}
			else
			{
				SetStandbyState(WashState,&WashRunTime, DrainT);	
			}
		}
		
	}	




	if(KeyPacket_y[HiVSwitch].KeyState==NotPress){	
		StatusFun_Handle();
	}
	else
	{
			if(StandByStatus==BackState)
			{
				SetStandbyState(NornalStopState,&WashRunTime, 0);
			}	
		ShiftMode_Handle(GetMode);
	}
	
}
void Run_Mode(void){
	//uint8_t i;
	switch(Mode){
		case PowerMode:
			switch(PowerStep){
				case Power_0:
					AllLedFlash(LedOn);
					GetWaterState=GetWaterMod;
					 Timer_Power_100ms=0;
					 PowerStep=Power_1;
					 LedSetSt(Wash_LedRed, LedOn);
					 BuzzerSet(1, Bu_1s);
					
					break;
				case Power_1:
					if(Timer_Power_100ms>=30){
						AllLedFlash(LedOff);
						PowerStep=Power_2;
					//	PWMD1L = 0;
						
					}
					break;
				case Power_2:
					if(Timer_Power_100ms>=31){	
						ShiftMode_Handle(StandbyMode);
					//	if(Powerfirst==0)
						SetStandbyState(WashState,&WashRunTime, 18);						
					}
					break;
				case Power_3:
					Timer_Power_100ms=0;
					AllLedFlash(LedOff);
				//	LedSetSt(Wash_LedRed, LedOff);
				//	LedSetSt(in3_LedRed, LedOff);
				///	LedSetSt(AQP_LedRed, LedOff);				
					LedSetSt(Wash_LedBlue, LedOn);
					LedSetSt(in3_LedBlue, LedOn);
					LedSetSt(AQP_LedBlue, LedOn);
					/*
					for(i=0;i<Max_Led_Num;i+=2){
						LedSetSt(i, LedOn);
						Timer_Power_100ms=0;
					}
					*/
					PowerStep=Power_4;
					break;
				case Power_4:	
					if(Timer_Power_100ms>=10){	
					AllLedFlash(LedOff);
					LedSetSt(Wash_LedRed, LedOn);
					LedSetSt(in3_LedRed, LedOn);
					LedSetSt(AQP_LedRed, LedOn);				
				//	LedSetSt(Wash_LedBlue, LedOff);
				//	LedSetSt(in3_LedBlue, LedOff);
				//	LedSetSt(AQP_LedBlue, LedOff);		
					/*
						AllLedFlash(LedOff);
						for(i=1;i<Max_Led_Num;i+=2){
							LedSetSt(i, LedOn);
							Timer_Power_100ms=0;
						}	
						*/
						PowerStep=Power_5;
					}				
					
					
					break;	
				case Power_5:	
					if(Timer_Power_100ms>=20){	
						AllLedFlash(LedOff);
						ShiftMode_Handle(StandbyMode);				
					}				
					
					break;					
			}
			break;
		
		case StandbyMode:
			StandbyMode_Handle();
			break;
		case GetMode:
			GetMode_Handle();
			break;	
		case FactoryMod:
			FactoryMode_Handle();
			break;
		case ErrorMode:
			MotoClose;
			InputValveClose;
			WasteValveClose;			
			break;					
	}
}

void CheckKey(void){
//	int i=0;
	U8_T St=0;
	static U8_T temp;

//	Keymap_Porg();
	static unsigned int KeyOldFlag = 0;
//	static unsigned char KeyOldFlagH = 0;
	unsigned int i = (unsigned int)((g_KeyFlag[1]<<8) | g_KeyFlag[0]);
//	unsigned char j = g_KeyFlag[2];
	if(i)
	{
		if(i != KeyOldFlag)
		{
			KeyOldFlag = i;			//�м�⵽����

			if(0x01 & i){temp |= 0x02;}    //TK1
			if(0x02 & i){temp |= 0x04;}   //TK2
		}
	}
	else
	{
		KeyOldFlag = 0;
//	KeyOldFlagH = 0;
		temp&=0x01;
	}
	/*
	if(dwKey_Map!=0)
	{
		if(Key_Map_bk!=dwKey_Map)
		{
			Key_Map_bk=dwKey_Map;
			//GPIO_Write_Low(GPIOB0,1);	
			//
			temp=0;
	//		if(dwKey_Map&TCH_Ck(0))
	//		{
	//			temp |= 1;
	//			nop;
	//		}
			 if(dwKey_Map&TCH_Ck(0))
			{
				temp |= 2;
				nop;
			}
			 if(dwKey_Map&TCH_Ck(16))
			{
				temp |= 4;
				nop;
			}
			 if(dwKey_Map&TCH_Ck(17))
			{
				temp |= 8;
				nop;
			}			
			//......
		}
	}
	else
	{
		Key_Map_bk=0;
		temp = 0;
		//GPIO_Write_High(GPIOB0,1);	
	}
	*/
//	if(Timer_HIS_10ms<0xf0){
//		Timer_HIS_10ms++;
//	}
	if(Read_HallSwitch_IO==0){
	//	Timer_HISoff_100ms=0;
	//	if(Timer_HIS_10ms>=5){
			temp |= 0x01;
	//	}
	}
	else
	{
	//	Timer_HIS_10ms=0; 
	//	if(Timer_HISoff_100ms>=15){
			temp &= ~(0x01);
	//	}
	}

	
	for(i=0;i<Max_Key_Num;i++){
		St=(U8_T)(temp>>i);
		St&=0x01;
		KeyScan(St,i);
	}
}


void ErrorHandle(){



	
	 if(Timer_LongGetWater_1s>=1800){  //get water 2H ->long time Error
//	if(Timer_LongGetWater_1s>=10){  //get water 2H ->long time Error
	// 	Timer_LongGetWater_1s=120;
	 	ShiftMode_Handle(ErrorMode);
//	 	GetWaterState=GetErrorMod;
//	 	DiaplayWashState=WashErrorLong;
	 	if(ErrorVar==Error_Normal){	 		
	 		Timer_ErrorLong_1s=0;
	 		AllLedFlash(LedOff);
	 		LedSetSt(in3_LedRed, LedFlash);
	 		LedSetSt(AQP_LedRed, LedFlash);
	 		LedSetSt(Wash_LedRed, LedFlash);
	 	}	 		
	 	ErrorVar=Error_Get;						
		GetStop(); 
	} 
	
       if((Timer_ErrorLong_1s<=30)&&(Mode==ErrorMode)){  //buzzer on 1s off 1s
       		Timer_ErrorLong_1s++;
		 if(Timer_ErrorLong_1s%2==0){
		 	BuzzerSet(1, Bu_1s);
		 }
	 }	



}
enum  datastep{
      RECVHEADER =200,
      RECVDATANUM,
      RECVDATA
};  
void  Tx_Display(void){
#if G800==G_800
	uint i;
	U8_T Sum_Tot=0;
	U8_T Temp1=0;

	 if((FilterROState==FilterExpire)||(FilterPCFState==FilterExpire))
	{
		Temp1=0x03;
	}
	else if((FilterROState==FilterPreWarning)||(FilterPCFState==FilterPreWarning))
	{
		Temp1=0x07;
	}	
	else  if((FilterROState==FilterNormal)&&(FilterPCFState==FilterNormal)){
		Temp1=0x01;
	}
	
	Tx_Type.TxType.Tx_FilterLed=Temp1;          //Filter register


	
	if(!FirstMakeWater){
		//Tx_Type.TxType.Tx_TdsData_1=999>>8;
		//Tx_Type.TxType.Tx_TdsData_2=999;		// 999 = 0x3E7
		Tx_Type.TxType.Tx_TdsData_1=0x03;
		Tx_Type.TxType.Tx_TdsData_2=0xE7;	
	}
	else
	{
		Tx_Type.TxType.Tx_TdsData_1=PureTDSTyp.TdsData>>8;
		Tx_Type.TxType.Tx_TdsData_2=PureTDSTyp.TdsData;
	}
	
	Tx_Type.TxType.Tx_TdsLed=StateLedOn;
	if(GetWaterState==GetStyMod){               //no makeing water into Led Off		
		//	Tx_Type.TxType.Tx_FilterLed=StateLedOff;         
			Tx_Type.TxType.Tx_TdsLed=StateLedOff;
			Tx_Type.TxType.Tx_TdsData_1=0xff;	
			Tx_Type.TxType.Tx_TdsData_2=0x00;
		
	}
	
//	Temp1=StandByStatus;
//	if(Temp1>=1) Temp1=1;	     // washing and draining to send state wash led  flash   
//	Tx_Type.TxType.Tx_WashLed=DiaplayWashState;      //Wash state Led

	Tx_Type.TxType.Tx_ErrorState=ErrorVar;    //Error register
	if(ErrorVar==Error_Get){
		Tx_Type.TxType.Tx_ErrorLed=0x07;    //Error display led flash
	}
	else
	{
		Tx_Type.TxType.Tx_ErrorLed=0x00;    //Error display led off
	}
	Tx_Type.TxType.Tx_Mode=GetWaterState;    // State register
	
	
	
	for(i=2;i<Max_Tx_Num-1;i++){
		Sum_Tot+=Tx_Type.Tx_Tab[i];
	}
	Tx_Type.TxType.Tx_Check=Sum_Tot+Max_Tx_Num;                //CHECK SUM
	for(i=0;i<Max_Tx_Num;i++){
		TXREG1=Tx_Type.Tx_Tab[i];
		do{
			asm("clrwdt");						//clear IWDT
		}
		while(TRMT1==0);
	//	UARTTxByte(UART1,Tx_Type.Tx_Tab[i]);
	}
//	Time_Tx_10ms=0;
#endif
}
/*
U8_T CountCrcData(U8_T *CheckDataBuf, U8_T DataLen)
{
	U8_T i, tmpData;

	tmpData = CheckDataBuf[0];
	for(i =1; i<DataLen; i++)
	{
        tmpData ^= CheckDataBuf[i];
	}
	 return tmpData;
}
*/
//static uchar CurRecvDataLen;
//static U8_T Rx_BufferTab[Max_Rx_Num];
#if 0
void  RecvData_Handle(U8_T recdata)
{
	/*
     U8_T   tmpData; 
     static  U8_T  RecvHeadBuf[3] = {0x00, 0x00, 0x00}, RecvDataStep =RECVHEADER, RecvDataNum, CurRecvDataNum =0;
     
//-------------------------------------------------------------------
	  switch(RecvDataStep)
	  {
	      case RECVHEADER:
			    RecvHeadBuf[0] = RecvHeadBuf[1];
			  RecvHeadBuf[1] = recdata;
			  	if(	RecvHeadBuf[0]  == HEADDATAI&& RecvHeadBuf[1] ==HEADDATAII)
				{
		  			 RecvDataStep = RECVDATANUM;
					 RecvDataNum =0;
					 RecvHeadBuf[0]  = RecvHeadBuf[1] =0;
				}
	            break;
              case RECVDATANUM:
	           RecvDataNum = recdata;
			   if(RecvDataNum >Rx_Max)
			   { 
			       CurRecvDataNum = 0;
			       RecvDataStep = RECVHEADER;
				}
			   else
			   {
	               CurRecvDataNum = 0;
	               RecvDataStep = RECVDATA;
				}
		   break;
             case RECVDATA:
			   Rx_BufferTab[CurRecvDataNum++] =recdata;
		       if(CurRecvDataNum == RecvDataNum)
			   {
                  		  RecvDataStep =RECVHEADER;
			        tmpData = CountCrcData(Rx_BufferTab, RecvDataNum-1);
				    if(tmpData == Rx_BufferTab[RecvDataNum-1])
					 { 
						 CurRecvDataLen = RecvDataNum-1;
						 memcpy(Rx_Type.Rx_Tab,Rx_BufferTab ,CurRecvDataLen);
					 }
					 else
					 {
					       CurRecvDataNum = 0;
					       RecvDataStep = RECVHEADER;					 
					 }
			   }
               break;
	  } 
	  */
}
#endif

void WrterEEP(){
	if(FilterFastCheck) return;
//	Read_Word_Buff[0]=EEP_Me;
	Read_Word_Buff[1]=FilterPCF_time.u8Hour;
	Read_Word_Buff[2]=FilterPCF_time.u16Day>>8;
	Read_Word_Buff[3]=FilterPCF_time.u16Day&0X00FF;
	
	Read_Word_Buff[4]=FilterRO_time.u8Hour;
	Read_Word_Buff[5]=FilterRO_time.u16Day>>8;
	Read_Word_Buff[6]=FilterRO_time.u16Day&0X00FF;	

	Read_Word_Buff[7]=FilterPCFGetWater>>8;
	Read_Word_Buff[8]=FilterPCFGetWater&0X00FF;

	Read_Word_Buff[9]=FilterROGetWater>>8;
	Read_Word_Buff[10]=FilterROGetWater&0X00FF;	
//	Read_Word_Buff[11]=BackSwitch;
	WriteEEP_Flag=1;
}
void ReadDataArry()
{
	uint i=0;
	for(i=0;i<ReadNum;i++){
		Read_Word_Buff[i]=Memory_Read(i);
	}
}
void EEPROM_Page(void){

	ReadDataArry();
//	EEP_Me=Read_Word_Buff[0];
	if(Read_Word_Buff[0]==0xA5){
		FilterPCF_time.u8Hour=Read_Word_Buff[1];
		FilterPCF_time.u16Day=(U16_T)Read_Word_Buff[2]<<8;	
		FilterPCF_time.u16Day|=Read_Word_Buff[3];
		
		FilterRO_time.u8Hour=Read_Word_Buff[4];
		FilterRO_time.u16Day=(U16_T)Read_Word_Buff[5]<<8;
		FilterRO_time.u16Day|=Read_Word_Buff[6];
		
		FilterPCFGetWater=Read_Word_Buff[7];
		FilterPCFGetWater=FilterPCFGetWater<<8;
		FilterPCFGetWater|=Read_Word_Buff[8];

		FilterROGetWater=Read_Word_Buff[9];
		FilterROGetWater=FilterROGetWater<<8;  
		FilterROGetWater|=Read_Word_Buff[10];
	//	BackSwitch=Read_Word_Buff[11];
	//	Powerfirst=0;
 
		
	} 
	else
	{
		EEP_Me=0;
		Read_Word_Buff[0]=0xA5;
	//	BackSwitch=1;
		Read_Word_Buff[11]=1;
		SetFilterDelayReset(&FilterPCF_time, In3FilterT, 0, 0, 0);	
		SetFilterDelayReset(&FilterRO_time, AQPFilterT, 0, 0, 0);
		FilterROGetWater=0;
		FilterPCFGetWater=0;
		WrterEEP();
	}
	Powerfirst=1;
	PreROu16Day=FilterRO_time.u16Day;
	PrePCFu16Day=FilterPCF_time.u16Day;
	FirstMakeWater=0;

#ifdef Debug	
	FilterROGetWater=(Unit_L*2);
	FilterPCFGetWater=(Unit_L*2);
#else
#endif
	if((FilterROGetWater>=(Unit_L*2))
	&&(FilterPCFGetWater>=(Unit_L*2))){

	
		FirstMakeWater=1;
	}
}

unsigned int  AD_Testing(unsigned char ad_fd,unsigned char ad_ch,unsigned char ad_lr)
{
	
	static volatile unsigned char adtimes;	
	static volatile unsigned int  admin,admax, adsum;
	volatile unsigned int data;
	volatile unsigned int AD_Result;

	volatile unsigned char i = 0;     
	
	if(!ad_lr)
		ADCON1 = 0;						//�����,��12λ
	else
		ADCON1 = 0x80;					//�Ҷ���,��10λ
		
	if(ad_ch & 0x10)					//����CHS4����λ��ADCON1�Ĵ�����
		ADCON1 |= 0x40;
	
	ADCON0 = 0;
	ad_ch &= 0x0f;
	ADCON0 |= (unsigned char)(ad_fd << 6);//��ͬ��VDD��ο���ѹ��Ҫ���ú����ķ�Ƶ
	ADCON0 |= (unsigned char)(ad_ch << 2);//����ͨ��
	ADCON0 |= 0x01;						  //ʹ��ADC		
	
	asm("nop");
	asm("nop");
	GODONE = 1;							//��ʼת��
	
	while(GODONE)
	{
		asm("nop");
		asm("nop");
		if((--i) == 0)					//ad�ȴ���ʱ����ֹ������ѭ������Ҫ����ת��ʱ�䲻�ܳ��ڴ�ʱ��
			return 0;
	}
 
	if(!ad_lr)							//�����
	{
		data =  (unsigned int)(ADRESH<<4);
		data |= (unsigned int)(ADRESL>>4);
	}
	else								//�Ҷ���
	{
		data =  (unsigned int)(ADRESH<<8);
		data |= (unsigned int)ADRESL;			
	}         

	if(adtimes == 0)
	{
		admax = data;
		admin = data;	
	}
	else if(data > admax)
	{
		admax = data;  				//AD�������ֵ
	}
	else if(data < admin)
	{
		admin = data;  				//AD������Сֵ
	}
	
	adsum += data;
	if(++adtimes >= 10)
	{
		adsum -= admax;
		adsum -= admin;			
					
		AD_Result = adsum >> 3;		//8��ƽ��ֵ��Ϊ���ս��
			
		adsum = 0;
		admin = 0;
		admax = 0;
		adtimes = 0;		
		for(i=0;i<NTC_Max_Num;i++){
			if(NTC_Tab[i]<=AD_Result){
				Temp_Ntc=i;
				break;
			}
		}		
	}
	
	return AD_Result;
	
}


#if 0
void Deal_ADC(){

	/*
	ADC12_ConversionChannel_Config(ADC12_ADCIN9,ADC12_CV_RepeatNum1,ADC12_AVGDIS,0);    //SEQ0 chose ADCIN0, 6 Holding cycles, Average 1 time 																//wait ADC get ready
	ADC12_Control(ADC12_START);
	ADC12_EOC_wait();	
	ADCV_Nun++;
	if(ADCV_Nun>=10){
	
		ADCV_Nun=0;
		adsum -= admax;
		if(adsum >= admin)	adsum -= admin;
		else	adsum = 0;			
		Voltage_ntc=adsum>>3;
		admax = 0;
		admin = 0xffff;
		adsum = 0;		
	}
	ADCV_Tab[0]=ADC12_DATA_OUPUT(0);
		if(ADCV_Tab[0] > admax)
			admax = ADCV_Tab[0];				
		if(ADCV_Tab[0]  < admin)
			admin = ADCV_Tab[0];
				
		adsum +=  ADCV_Tab[0];
	for(i=0;i<NTC_Max_Num;i++){
		if(NTC_Tab[i]<=Voltage_ntc){
			Temp_Ntc=i;
			break;
		}
	}
	*/
}
#endif
#ifdef  DebugTouch

void UART1_offset(void)
{
	UARTTxByte(UART1, 0X0D);
	UARTTxByte(UART1, 0X0A);
	
	UARTTxByte(UART1, hwOffset_data0_abs[15] >> 8);
	UARTTxByte(UART1, hwOffset_data0_abs[15] & 0xff);

	UARTTxByte(UART1, hwOffset_data0_abs[16] >> 8);
	UARTTxByte(UART1, hwOffset_data0_abs[16] & 0xff);
	UARTTxByte(UART1, hwOffset_data0_abs[17] >> 8);
	UARTTxByte(UART1, hwOffset_data0_abs[17] & 0xff);

}
#endif
/***************************************************/
//main
/**************************************************/
void Init_ram (void)
{
	asm("clrwdt");
	PIE2 = 0;
	PIE1 = 0B00000010;
	PR2 = 125;				//16M�½�TMR2����Ϊ125us�ж�
	T2CON = 5;				//ʹ�ܶ�ʱ��2
	
//	INTCON = 0XC0;			//ʹ���ж�
}

#define HzBuzz      32000
#define T0HzBuzz      125

void Initialize()
{
	asm("nop");
	asm("clrwdt");
	
//	OPTION_REG =0;					//Ԥ��Ƶ��TMR0  
	OSCCON = 0X70;					//�ڲ�����Fosc/1
	


	PORTA=0B11111111;
	PORTB=0B11111111;
	PORTC=0x01;
	
	TRISA = 0B00111000;				//����IO״̬��0Ϊ�����1Ϊ����
	TRISB = 0B00000010; 
	TRISC = 0B00100011;
	TRISD = 0B00000100;

	WPUA = 0B00000001;				//����������1Ϊʹ������
	WPUB = 0B00000010;
	WPUC = 0B00000001;

	OPTION_REG = 0x02;		//Timer0Ԥ��Ƶ��Ϊ1:4��ÿ��ֵ0.25uS*4=1uS
	TMR0 = 255-T0HzBuzz;				//�����ʼֵ

	TMR1L = (65535-HzBuzz)%256;			//����ֵ
	TMR1H = (65535-HzBuzz)/256;
	TMR1IF = 0;				//���жϱ�־λ
	TMR1IE = 1;				//����Timer1�ж�	
	T1CON = 0x01;			//����Timer1��ʹ���ڲ�ʱ��ԴFosc��Ԥ��Ƶ��Ϊ1:1
	ANSEL1 = 0B10000000;
//---------------------------------------	
	 Init_ram();
	INTEDG = 0;				//INT�����½��ش���
	INTCON = 0xe0;			//��������δ�����ε��жϡ������ж�
	
	
}


void interrupt Timer1_Isr()
{
	static U8_T T1_1ms=0;
	if(T0IF)
	{
	//---------------------------------------
		TMR0 += 255-T0HzBuzz;		//�ڲ���TIME��ʱ��,TIME�ǲ������ģ�һ��Ϊ�������ڣ����Զ��������
	//---------------------------------------
			
		T0IF = 0;			//���жϱ�־λ
	//        if(BuzzerEnableFlag)	
	 //       {
	 //           B_ON;
	   //     }			
	   //     else	
	   //     {
	   //  	   B_OFF;
	    //    }	
	}
	
	if(TMR1IF)
	{
	//---------------------------------------
	TMR1L += (65535-HzBuzz)%256;			//����ֵ
	TMR1H += (65535-HzBuzz)/256;			//���¸���ֵ���ڸ�ֵǰTimer1���м��������ڸû����ϼӳ�ֵ
								//�ڽ����жϵȹ�������ʵTime��һֱ�ڼ�����
	//---------------------------------------	
		
		if(++T1_1ms>=10){
			T1_1ms=0;
			Time_flag_10ms=1;
		}
	
	        TMR1IF = 0;				//���жϱ�־λ
	}
	if(TMR2IF)
	{
		TMR2IF = 0;
	
		__CMS_TouchKeyValue();
	}	
	if(INTF)
	{
		INTF = 0;			//���жϱ�־
		PureTDSTyp.HzCount++;
		
	}	
}

void Page_ProgramData(){
	uint i=0;
	for(i=0;i<ReadNum;i++){
		Memory_Write(i,Read_Word_Buff[i]);	
	}
}
void Set_Usart_Async()
{
//	SPBRG0 = 95;			//���ò�����Ϊ10417 bps�����0%		
//	SPBRG0 = 207;			//���ò�����Ϊ9600 bps�����0.16%	
	/*
	SYNC0 = 0;				//0Ϊ�첽ģʽ��1Ϊͬ��ģʽ
	SCKP0 = 0;
	
    SPEN0 = 1;				//�������ڲ���
	RC0IE = 1;				//�����ж�  
	TX0IE = 0;				//�����ж�
    RX9EN0 = 0;				//0Ϊ8λ���գ�1Ϊ9λ����
	TX9EN0 = 0;				//0Ϊ8λ���ͣ�1Ϊ9λ����
	CREN0 = 1;				//0Ϊ��ֹ���գ�1Ϊʹ�ܽ���
    TXEN0 = 1;				//0Ϊ��ֹ���ͣ�1Ϊʹ�ܷ���
*/
	SPBRG1 = 103;			//���ò�����Ϊ9600 bps�����0.16%	
	SYNC1 = 0;				//0Ϊ�첽ģʽ��1Ϊͬ��ģʽ
	SCKP1 = 0;
	
    SPEN1 = 1;				//�������ڲ���
	RC1IE = 0;				//�����ж�  
	TX1IE = 0;				//�����ж�
    RX9EN1 = 0;				//0Ϊ8λ���գ�1Ϊ9λ����
	TX9EN1 = 0;				//0Ϊ8λ���ͣ�1Ϊ9λ����
	CREN1 = 0;				//0Ϊ��ֹ���գ�1Ϊʹ�ܽ���
    TXEN1 = 1;				//0Ϊ��ֹ���ͣ�1Ϊʹ�ܷ���
}
void Set_PWM()
{
	PWMTL = 0xfa;					//PWM0~3�����ڣ����ڵ�λ	
//	PWM4TL = 0x8f;					//PWM4���ڵ�λ
	PWMTH = 0B00000100;				//PWM0~3,PWM4���ڸ���λ

									//PWM0~4����Ϊ��(0B110001111+1)*(1/16)*2 =50uS
	

	PWMD01H = 0x00;					//��λ�ı����������Ч����Ҫ��ռ�ձȵĵ�λ�Ĵ�������ܼ���
	//PWM1 ռ�ձ�����Ϊ20%
//	PWMD0L = 0x4f;					//(79+1)/(399+1) = 20%
	//PWM1 ռ�ձ�����Ϊ40%
	PWMD1L = 0x7d;					//(159+1)/(399+1) = 40%

//	PWMD23H = 0x10;
	//PWM2 ռ�ձ�����Ϊ60%
//	PWMD2L = 0xef;					//(239+1)/(399+1) = 60%
	//PWM3 ռ�ձ�����Ϊ80%
//	PWMD3L = 0x3f;					//(319+1)/(399+1) = 80%

	//PWM4 ռ�ձ�����Ϊ50%
//	PWMD4L = 0xC7;					//(199+1)/(399+1) = 50%
	
	
	PWMCON1 = 0B01000000;			//PWMλ��ѡ��ΪB��
	PWMCON0 = 0B10100000;			//PWM��ƵFosc/2��ʹ��PWM0��PWM1��PWM2��PWM3��PWM4

}
void main(void) 
{
	
	asm("nop");
	asm("clrwdt");	
	Initialize();
	EEPROM_Page();
//	tekey_initial();
	Set_PWM();
	Set_Usart_Async();
#if G800==G_800
	Tx_Type.TxType.Tx_FH1=0xa5;
	Tx_Type.TxType.Tx_FH2=0xa6;	
	Tx_Type.TxType.Tx_TotalLength=Max_Tx_Num;
#endif	
	PureTDSTyp.TdsData=0x03;
//	RawTDSTyp.TdsHzMin=0x0000;
//	if(RC0==0){
//		Mode=FactoryMod;
		//	Run_Mode();
		
//	}
		WasteValveClose;				
		MotoClose;
		InputValveClose;	
		
//TDS_KG_On;
//	PureTDSTyp.TdsData=0x03;
//	RawTDSTyp.TdsData=192;
//	TdsMake_Flag=1;

	
    while(1)
	{
		
	//	TDS_KG_Off;
		asm("clrwdt");						//clear IWDT
		//...
		Time_Count_Func();
		
		
		Run_Mode();	
		

		

	

    }
}

/******************* (C) COPYRIGHT 2023 APT Chip *****END OF FILE****/
